# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "bbsreporting/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "Config":{
            "header":"true",
            "delimiter":"|",
            "multiline":"true"
        },
        "SourceFileFormat" : "csv"
    },
    "BBS_REPORTING_TREADDR":{
        "FileRegex" : "BBS_REPORTING_TREADDR.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREADDR"
    }, 

    "BBS_REPORTING_TRE2280":{
        "FileRegex" : "BBS_REPORTING_TRE2280.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTRE2280"
    }, 
    "BBS_REPORTING_TREPRCT":{
        "FileRegex" : "BBS_REPORTING_TREPRCT.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREPRCT"
    },
    "BBS_REPORTING_TREGPAF":{
        "FileRegex" : "BBS_REPORTING_TREGPAF.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREGPAF"
    },
    "BBS_REPORTING_TREROUT":{
        "FileRegex" : "BBS_REPORTING_TREROUT.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREROUT"
    },
    "BBS_REPORTING_TREEPKG":{
        "FileRegex" : "BBS_REPORTING_TREEPKG.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREEPKG"
    },
    "BBS_REPORTING_TREEPKF":{
        "FileRegex" : "BBS_REPORTING_TREEPKF.TXT",
        "StagePathSuffix" : "bbsreporting/stage/StageTREEPKF"
    },
}

# COMMAND ----------

tregpaf_schema ={
'GRP_AFFIL_TY_CD':'STRING',
'GRP_AFFIL_GEN_KEY':'INTEGER',
'GRP_DEST_CNTR_ID':'STRING',
'GRP_DST_GRPR_TY_CD':'STRING',
'GRP_GK_SEL_SRC_CD ':'STRING',
'GRP_RPT_PKG_TBL_ID':'STRING',
'REC_UPDT_DATE':'DATE',
'REC_UPDT_ID':'STRING',
'REC_UPDT_FAC_ID  ':'STRING',
'GRP_GEO_MARKET_IND':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
}

# COMMAND ----------

treepkf_schema= {
'EDID_PKG_GEN_KEY':'INTEGER',
'SRC_GEN_KEY':'INTEGER',
'REC_CREATE_DATE':'DATE',
'REC_CREATE_ID':'STRING',
'REC_UPDT_DATE':'DATE',
'REC_UPDT_ID':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

treepkg_schema = {
'EDID_PKG_GEN_KEY':'INT'
,'EDID_PKG_ID':'STRING'
,'EDID_PKG_NAME':'STRING'
,'EDID_PKG_DESC':'STRING'
,'RPTG_PKG_LVL_CD':'INT'
,'FILE_HEADER_IND':'STRING'
,'FILE_FMT_TY_CD':'STRING'
,'ACTIVE_IND':'STRING'
,'EFF_DATE':'DATE'
,'END_DATE':'DATE'
,'COMMENT_TXT':'STRING'
,'REC_CREATE_DATE':'DATE'
,'REC_CREATE_ID':'STRING'
,'REC_UPDT_DATE':'DATE'
,'REC_UPDT_ID':'STRING'
,'IND1':'STRING'
,'TIMESTAMP':'TIMESTAMP' 
}

# COMMAND ----------

#TREADDR
treaddr_schema={
"Ind1":"STRING"
,"Timestamp":"TIMESTAMP"
,"AFFIL_TY_CD":"STRING"
,"AFFIL_GEN_KEY":"INT"
,"ADDR_GEN_KEY":"INT"
,"ADDR_USER_USE_CD":"STRING"
,"ADDR_CO_NAME":"STRING"
,"ADDR_LAST_NAME":"STRING"
,"ADDR_FST_NAME":"STRING "
,"ADDR_LINE1_ADDR":"STRING"
,"ADDR_LINE2_ADDR":"STRING"
,"ADDR_CITY_NAME":"STRING"
,"ADDR_ST_CD":"STRING"
,"ADDR_ZIP_CD":"STRING"
,"ADDR_ZIP_PLUS_CD":"STRING"
,"ADDR_PH_AREA_CD":"STRING"
,"ADDR_PH_NBR":"STRING"
,"ADDR_PH_EXT_NBR":"STRING"
,"ADDR_FAX_AREA_CD":"STRING"
,"ADDR_FAX_NBR":"STRING"
,"ADDR_EMAIL_ADDR":"STRING"
,"REC_UPDT_DATE":"DATE"
,"REC_UPDT_ID":"STRING"
,"REC_UPDT_FAC_ID":"STRING"
,"ADDR_CMT_TXT":"STRING"
}

# COMMAND ----------

#TREROUT
trerout_schema={
"Ind1":"STRING"
,"Timestamp":"Timestamp"
,"AFFIL_TY_CD":"STRING"
,"AFFIL_GEN_KEY":"INT"
,"ROUTE_GEN_KEY":"INT"
,"RT_DATA_ROUTE_CD":"STRING"
,"RT_DATA_DEFLT_IND":"STRING"
,"RT_DELV_MTHD_DESC":"STRING"
,"RT_USER_HDW_TY_CD":"STRING"
,"RT_DATA_MED_TY_CD":"STRING"
,"RT_DATA_FMT_CD":"STRING"
,"RT_REEL_BLK_FACT":"STRING"
,"RT_REEL_FILL_IND":"STRING"
,"RT_REEL_LBL_CD":"STRING"
,"RT_FILE_SPLIT_IND":"STRING"
,"RT_BBS_DIR_NAME":"STRING"
,"RT_BBS_CON_MTHD_CD":"STRING"
,"RT_SERV_CD":"STRING"
,"RT_BBS_HDR_IND":"STRING"
,"RT_FL_DIR_NAME_LEN ":"STRING"
,"RT_FL_DIR_NAME_TEXT":"STRING"
,"REC_UPDT_DATE":"DATE    "
,"REC_UPDT_ID":"STRING"
,"REC_UPDT_FAC_ID":"STRING"
,"RT_ENCRYP_TYPE_CD":"STRING"
,"RT_NEW_PASSWD_IND":"STRING"
,"RT_LAST_UPDT_PE_DT":"STRING"
}
			

# COMMAND ----------

#TRE2280
tre2280_schema={
"Ind1":"STRING"
,"Timestamp":"Timestamp"
,"USER_REQST_NBR":"STRING"
,"REQST_TY_CD":"INT"
,"REC_STAT_IND":"STRING"
,"UPDT_INIT_NM":"STRING"
,"UPDT_DT":"STRING"
,"EMAIL_ID":"STRING"
,"PLTFM_CD":"DATE"
}
			

# COMMAND ----------

#TREPRCT
treprct_schema={
"Ind1":"STRING"
,"Timestamp":"TIMESTAMP"
,"AFFIL_TY_CD":"STRING"
,"AFFIL_GEN_KEY":"INT"
,"PARCT_GEN_KEY":"STRING"
,"PARCT_ID":"STRING"
,"PARCT_SUFF_CD":"STRING"
,"PARCT_SERV_TY_CD":"STRING"
,"PARCT_SEQ_NBR":"DATE"
,"REC_UPDT_DATE":"STRING"
,"REC_UPDT_ID":"STRING"
,"REC_UPDT_FAC_ID":"STRING"
}

# COMMAND ----------


# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREEPKG TREEPKF
# MAGIC ##### Curated Tables
# MAGIC - BBSReporting.BbsPackageFileMapper
# MAGIC ##### Target Table
# MAGIC - BBSReporting.BbsPackageFileMapper

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./BBSReportingStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','FullLoad')
dbutils.widgets.text('PIPELINE_NAME','Nb_BbsPackageFileMapper')
                     
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "BBS_REPORTING_TREEPKF"
buz_keys = ['EdidPkgGenKey','SrcGenKey']

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    treepkg_tbl_name = table_name_selector(tbl_conf_df, 'BBS_REPORTING_TREEPKG')
    cur_tbl_name = table_name_selector(tbl_conf_df, 'BBS_REPORTING_BbsPackageFileMapper')
    cur_package_tbl = table_name_selector(tbl_conf_df, 'BBS_REPORTING_BbsPackage')
except Exception as e:
    raise Exception("Table Not Found",str(e))

# COMMAND ----------

# DBTITLE 1,Load data into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treepkf_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# %sql

# select * from bbsreporting.stagetreepkf

# COMMAND ----------

# %sql

# -- select * from bbsreporting.stagetreepkf

# select * from bbsreporting.stagetreepkg

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
# #Reading data from stage table & filtering the valid records
# try:
#     treepkf_stage_df = read_table_to_df(stage_tbl_name)\
#         .filter(col('Status') == 'S')
    
#     treepkg_stage_df = read_table_to_df(treepkg_tbl_name)\
#         .filter(col('Status') == 'S')

#     cur_package_tbl_df = read_table_to_df(cur_package_tbl).select('BbsPackageId','BbsPackageUId')
        
# except Exception as e:
#     raise Exception("validation failed",str(e))   

# COMMAND ----------

# window_spec = Window.partitionBy('EdidPkgGenKey').orderBy(desc('RecUpdtDate'))
# rn_window_spec = treepkf_stage_df.withColumn('RN',row_number().over(window_spec))
# maxupdatedate_df = rn_window_spec.filter(col('RN') == 1).drop('RN')
# min_df = rn_window_spec.filter(col('RN') > 1)


# COMMAND ----------

# join_df= maxupdatedate_df.alias('LH').join(treepkg_stage_df.alias('RH'),
#                                            (col('LH.EdidPkgGenKey')==col('RH.EdidPkgGenKey')),'left')\
#                                            .select('LH.EdidPkgGenKey','LH.SrcGenKey','LH.RecCreateDate','LH.RecCreateId','LH.RecUpdtDate','LH.RecUpdtId','RH.EdidPkgId')
                                           

# COMMAND ----------

# join_df.display()

# COMMAND ----------

# %sql

# select * from bbsreporting.bbspackage

# COMMAND ----------

# joined_package_df = join_df.alias('LH').join(cur_package_tbl_df.alias('RH'),
#                                              (col('LH.EdidPkgId')==col('RH.BbsPackageUId')),'left')\
#                                                  .select('LH.*','RH.BbsPackageId')
                                        

# COMMAND ----------

# joined_package_df.display()

# COMMAND ----------

# from pyspark.sql.functions import coalesce

# col_map= {
#     'SrcGenKey' :when(col('SrcGenKey').isin([2000040,2000004]),'2000040,2000004,2000006')
#                 .when(col('SrcGenKey')==2000039,'2000039,2000037')
#                 .when(col('SrcGenKey').isin([2000041,2000005]),'2000041,2000005,2000006')
#                 .when(col('SrcGenKey')==2000038,'2000038,2000037')
#                 .when(col('SrcGenKey').isin([2000021,2000022]),'2000021,2000022')
#                 .otherwise(col('SrcGenKey')),
#     'LastUpdatedBy' : when(col('RecUpdtId')=='ONESHOT','SYSTEM').otherwise(col('RecUpdtId')),
#     'LastUpdatedOn' : coalesce(col('RecUpdtDate'),lit('1900-01-01')),
#     'IsActive' : lit(None),
#     'CreatedBy' : lit(PIPELINE_NAME),
#     'CreatedOn' : current_timestamp()


# }

# df= joined_package_df.withColumns(col_map).select('SrcGenKey','BbsPackageId','LastUpdatedBy','LastUpdatedOn','IsActive','CreatedBy','CreatedOn')

# COMMAND ----------

# df.display()
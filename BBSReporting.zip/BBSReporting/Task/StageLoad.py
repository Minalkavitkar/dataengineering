# Databricks notebook source
# DBTITLE 1,ADLS connection notebook
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./BBSReportingStageSchema"

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
#dbutils.widgets.text('PIPELINE_NAME','pl_BBSReporting_BbsPackage')
dbutils.widgets.text('LOAD_TYPE','FullLoad')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREEPKG

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key_TREEPKG = "BBS_REPORTING_TREEPKG"
buz_keys_TREEPKG = ['EdidPkgGenKey']

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREEPKG]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREEPKG = table_name_selector(tbl_conf_df, file_conf_key_TREEPKG)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREEPKG, treepkg_schema, buz_keys_TREEPKG)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREADDR

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key_TREADDR = "BBS_REPORTING_TREADDR"
buz_keys_TREADDR = ['AffilGenKey'] #AFFIL_GEN_KEY

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREADDR]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREADDR = table_name_selector(tbl_conf_df, file_conf_key_TREADDR)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREADDR, treaddr_schema, buz_keys_TREADDR)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREROUT

# COMMAND ----------

file_conf_key_TREROUT = "BBS_REPORTING_TREROUT"
buz_keys_TREROUT = ['AffilGenKey','RouteGenKey'] #AFFIL_GEN_KEY,ROUTE_GEN_KEY

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREROUT]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREROUT = table_name_selector(tbl_conf_df, file_conf_key_TREROUT)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREROUT, trerout_schema, buz_keys_TREROUT)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table hive_metastore.BBSReporting.StageTREROUT

# COMMAND ----------

# MAGIC %md
# MAGIC ##TRE2280

# COMMAND ----------

file_conf_key_TRE2280 = "BBS_REPORTING_TRE2280"
buz_keys_TRE2280 = ['UserReqstNbr'] #USER_REQST_NBR  

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TRE2280]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TRE2280 = table_name_selector(tbl_conf_df, file_conf_key_TRE2280)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TRE2280, tre2280_schema, buz_keys_TRE2280)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREPRCT

# COMMAND ----------

file_conf_key_TREPRCT = "BBS_REPORTING_TREPRCT"
buz_keys_TREPRCT = ['AffilGenKey',"ParctGenkey"] #AFFIL_GEN_KEY,PARCT_GEN_KEY

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREPRCT]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREPRCT = table_name_selector(tbl_conf_df, file_conf_key_TREPRCT)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREPRCT, treprct_schema, buz_keys_TREPRCT)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREGPAF

# COMMAND ----------

file_conf_key_TREGPAF = "BBS_REPORTING_TREGPAF"
buz_keys_TREGPAF = ['GrpAffilGenKey'] #GRP_AFFIL_GEN_KEY

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREGPAF]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREGPAF = table_name_selector(tbl_conf_df, file_conf_key_TREGPAF)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREGPAF, tregpaf_schema, buz_keys_TREGPAF)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ##TREEPKF

# COMMAND ----------

file_conf_key_TREEPKF = "BBS_REPORTING_TREEPKF"
buz_keys_TREEPKF = ['EdidPkgGenKey','SrcGenKey'] #EDID_PKG_GEN_KEY  SRC_GEN_KEY       

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key_TREEPKF]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name_TREEPKF = table_name_selector(tbl_conf_df, file_conf_key_TREEPKF)
    #cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BbsPackage')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name_TREEPKF, treepkf_schema, buz_keys_TREEPKF)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))
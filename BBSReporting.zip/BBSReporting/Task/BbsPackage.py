# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREEPKG
# MAGIC
# MAGIC ##### Target Table 
# MAGIC - BBSREporting.BbsPackage

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "BBS_REPORTING_TREEPKG"
buz_keys = ['EdidPkgGenKey']
table_code = "BBSReporting_BbsPackage" 

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    notebook_run_check('Claim', table_code)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Import Libraries to be used
from pyspark.sql.functions import coalesce

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./BBSReportingStageSchema"

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','pl_BBSReporting_BbsPackage')
dbutils.widgets.text('LOAD_TYPE','FullLoad')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treepkg_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    treepkg_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping dictionary as per SQL
#Column name mapping
col_mapping = {
            'EdidPkgDesc':'BbsPackageDescription'
            ,'EdidPkgName':'BbsPackageName'
            ,'RptgPkgLvlCd':'BbsPackageReportingLevelId'
            ,'EdidPkgId':'BbsPackageUId'
            ,'CommentTxt':'Comments'
            ,'EffDate':'EffectiveDate'
            ,'EndDate':'EndDate'
            ,'ActiveInd':'IsActive'
            ,'RecUpdtId':'LastUpdatedBy'
            ,'RecUpdtDate':'LastUpdatedOn'
}

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
#Column mapping and adding audit columns
try:
    col_mapped_df = col_name_mapping(treepkg_stage_df, col_mapping)
    col_added_df = add_tgt_audit_column(col_mapped_df, PIPELINE_NAME)
except Exception as e:
    raise Exception('Adding audit columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Select required columns and apply transformation logic on them
#Passing null in BbsPackageReportingLevelId for now as it is dependent on RefCode table
df_trns = col_added_df.select(
trim(coalesce('BbsPackageDescription',lit(''))).alias('BbsPackageDescription'),
trim(coalesce('BbsPackageName',lit(''))).alias('BbsPackageName'),
lit(None).alias('BbsPackageReportingLevelId'),
trim(coalesce('BbsPackageUId',lit(''))).alias('BbsPackageUId'),
trim(coalesce('Comments',lit(''))).alias('Comments'),
coalesce('EffectiveDate',lit('1900-01-01')).alias('EffectiveDate'),
coalesce('EffectiveDate',lit('9999-12-31')).alias('EndDate'),
when(coalesce('IsActive',lit('Y'))=='Y',1).otherwise(0).alias('IsActive'),
when(trim(coalesce('LastUpdatedBy',lit(''))).isin('ONESHOT','RELOAD01'),'SYSTEM').otherwise(trim(coalesce('LastUpdatedBy',lit('')))).alias('LastUpdatedBy'),
coalesce('LastUpdatedOn',lit('1900-01-01')).alias('LastUpdatedOn'),
'CreatedBy',
col('CreatedDateTime').alias('CreatedOn')
)

# COMMAND ----------

# DBTITLE 1,Data type conversion
#Datatype change
schema = {'LastUpdatedOn':'TIMESTAMP',
          'IsActive':'BOOLEAN',
          'EffectiveDate':'DATE',
          'EndDate':'DATE'
          }
try:
    dtype_chng_df = dtype_tgt_conversion(df_trns, schema)
except Exception as e:
    raise Exception('Datatype change failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        write_to_curated(dtype_chng_df,cur_tbl_name)
        BBsPackage_df = read_table_to_df(cur_tbl_name)
        load_df_to_sf_sql_db_spark(BBsPackage_df, 'BBSReporting.BBsPackage')
except Exception as e:
    raise Exception ('load failed: ',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates BbsReporting Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES') 

# COMMAND ----------

# DBTITLE 1,Database Creation
database_name = f"BBSReporting{databricks_database_suf}"
spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")

# COMMAND ----------

Bbs_package = f"""CREATE OR REPLACE TABLE hive_metastore.{database_name}.BbsPackage(
    BbsPackageId BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL,
    BbsPackageUId STRING not null,
    BbsPackageName STRING,
    BbsPackageDescription STRING,
    BbsPackageReportingLevelId BIGINT,
    IsActive BOOLEAN not null,
    EffectiveDate DATE not null,
    EndDate DATE not null,
    Comments STRING,
    CreatedBy STRING not null,
    CreatedOn TIMESTAMP not null,
    LastUpdatedBy STRING not null,
    LastUpdatedOn TIMESTAMP not null   
)
USING DELTA LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/bbsreporting/curated/BbsPackage' """


# COMMAND ----------

tbl_mapping = {
    "BbsPackage":Bbs_package
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
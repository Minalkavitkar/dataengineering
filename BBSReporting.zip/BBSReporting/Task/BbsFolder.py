# Databricks notebook source
# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = ""
buz_keys = ['']
table_code = ''

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    notebook_run_check('BBSReporting', table_code)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./BBSReportingDDL"

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','Nb_BBSReporting_BbsFolder')
dbutils.widgets.text('LOAD_TYPE','FullLoad')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
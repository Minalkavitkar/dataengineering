# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - DB2 Tables
# MAGIC   - TREGPAF
# MAGIC - Curated
# MAGIC   - 
# MAGIC - SQL Tables for PK and FK relationships
# MAGIC   - Product, Member and ProviderContract
# MAGIC   
# MAGIC ##### Target Table 
# MAGIC - BBSReporting.BBSEdid

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./BBSReportingDDL"

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','')
dbutils.widgets.text('LOAD_TYPE','')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
treaddr_trefile_conf_key = 'BBS_REPORTING_TREADDR'
tregpaf_trefile_conf_key = 'BBS_REPORTING_TREGPAF'
trerout_trefile_conf_key = 'BBS_REPORTING_TREROUT'
treepkg_trefile_conf_key = 'BBS_REPORTING_TREEPKG'

# COMMAND ----------

# Load TRE2321 file to Stage table using function in Ingest Notebook
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()

    stage_treaddr_tbl_name = table_name_selector(tbl_conf_df, treaddr_trefile_conf_key)
    stage_tregpaf_tbl_name = table_name_selector(tbl_conf_df, tregpaf_trefile_conf_key)
    stage_trerout_tbl_name = table_name_selector(tbl_conf_df, trerout_trefile_conf_key)
    stage_treepkg_tbl_name = table_name_selector(tbl_conf_df, treepkg_trefile_conf_key)
    
    cur_tbl_name = table_name_selector(tbl_conf_df, 'BBSReporting_BBSEdid')

    file_list = [
        [treaddr_trefile_conf_key, stage_treaddr_tbl_name, treaddr_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd',  'PcaSeqNbr']],
        [tregpaf_trefile_conf_key, stage_tregpaf_tbl_name, tregpaf_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd', 'PcaSeqNbr']],
        [trerout_trefile_conf_key, stage_trerout_tbl_name, trerout_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd', 'PcaSeqNbr']],
        [treepkg_trefile_conf_key, stage_treepkg_tbl_name, treepkg_schema, ['CtrctGenKey']]
        ]
    
    buz_keys = ['ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr','ReProvJctTs','Re2321MbrprvTs']
    stage_tbl_name2321 = table_name_selector(tbl_conf_df, file_conf_key)
    tabSchema = tre2321_schema
    stageCreation(file_conf_key, LOAD_TYPE, stage_tbl_name2321, tabSchema, buz_keys)

    return stage_tbl_name2321

except Exception as e:
    raise Exception("LoadTre2321: ", str(e))


# COMMAND ----------

conf = {**file_config["DEFAULT"], **file_config[file_conf_key]}
main_function(conf, LOAD_TYPE, stage_tbl_name, tabSchema, buz_keys)
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREGPAF
# MAGIC ##### Curated Tables
# MAGIC - BBSReporting.BbsEdidContractInclusion
# MAGIC ##### Target Table
# MAGIC - BBSReporting.BbsEdidContractInclusion

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./BBSReportingStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','FullLoad')
dbutils.widgets.text('PIPELINE_NAME','Nb_BbsEdidContractInclusion')
                     
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "BBS_REPORTING_TREGPAF"
buz_keys = ['GrpAffilGenKey']

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, 'BBS_REPORTING_BbsEdidContractInclusion')
except Exception as e:
    raise Exception("Table Not Found",str(e))

# COMMAND ----------

# DBTITLE 1,Load data into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tregpaf_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    tregpaf_stage_df = read_table_to_df(stage_tbl_name)\
        .filter((col('Status') == 'S') & (col('GrpDestCntrId')!='FORDASO'))
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# col_map = {
#     "BbsEdIdContractInclusionId":when((col('GrpGeoMarketInd')!='Y') & (trim(col('GrpGkSelSrcCd')).isin(['B','G'])),lit("GTK"))
#     .when((col('GrpGeoMarketInd')!='Y') & (trim(col('GrpGkSelSrcCd')).isin(['B','S'])),lit("OTH"))
#     .when((col('GrpGeoMarketInd')!='Y') & (trim(col('GrpGkSelSrcCd')) =='M'),lit("MBR"))
#     .when(col('GrpGeoMarketInd')=='Y',lit("GEO"))
#     .otherwise(lit("NA"))
# }

# df= tregpaf_stage_df.withColumns(col_map)
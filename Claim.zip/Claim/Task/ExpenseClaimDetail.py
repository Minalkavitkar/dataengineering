# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRECLMX
# MAGIC
# MAGIC ##### Target Table 
# MAGIC - Claim.ExpenseClaimDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "CLAIM_TRECLMX"
buz_keys = ['ClmGenKey','FundTyCd','ReencInd']
not_null_col_lst = ['ExpenseClaimKey','ClaimIncurredDate']
table_code = "Claim_ExpenseClaimDetail" 

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','pl_Claim_ExpenseClaimDetail')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Claim', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Claim', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./ClaimStageSchema"

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    expns_clm_tbl_name = table_name_selector(tbl_conf_df, 'Claim_ExpenseClaim')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treclmx_schema, buz_keys,reject_dup="KeepOne")
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage and curated table
#Reading data from stage table & filtering the valid records
try:
    treclmx_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    expnse_clm_df = read_table_to_df(expns_clm_tbl_name).select('ClmGenKey','ExpenseClaimKey','ClaimIncurredDate').distinct()
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping dictionary
#Column name mapping
col_mapping = {
'ClmExtrVerNbr':'ClaimExternalVersionNumber'
,'ExpsProvIdNbr':'ExpenseProviderId'
,'ExpsProvSuffCd':'ExpenseProviderSuffixCode'
,'ExpsServTyCd':'ExpenseServiceTypeCode'
,'ExpsSeqNbr':'ExpenseSequenceNumber'
,'FundTyCd':'FundTypeCode'
,'FundClmDiscAmt':'FundClaimDiscountAmount'
,'FundClmExpsAmt':'FundClaimExcessAmount'
,'StoplsExcessAmt':'StoplossExcessAmount'
,'CurrMoStatCd':'CurrentMonthStatusCode'
,'ReinsurInd':'ReInsuranceIndicator'
,'ReencInd':'ReencIndicator'
,'ClmGenKey':'ClmGenKey',
"StgUnqId":"StgUnqId",
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
# adding audit columns
try:
    col_mapped_df = col_name_mapping(treclmx_stage_df, col_mapping).distinct()
    col_added_df = add_tgt_audit_column(col_mapped_df, PIPELINE_NAME)
except Exception as e:
    raise Exception('Adding audit columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ExpenseClaim table to get the ExpenseClaimKey
#Join with ExpenseClaim table to get the ExpenseClaimKey and ClaimIncurredDate
try:
    cond1 = col('LH.ClmGenKey')==col('RH.ClmGenKey')
    df_join = col_added_df.alias('LH').join(expnse_clm_df.alias('RH'),cond1,'left').select('LH.*','RH.ExpenseClaimKey',col('RH.ClaimIncurredDate'))\
              .drop('ClmGenKey')
except Exception as e:
    raise Exception('Join with ExpenseClaim table failed',str(e))

# COMMAND ----------

# DBTITLE 1,Datatype conversion
#data type conversion 
datatype_change_schema = {
    'ExpenseSequenceNumber':'INT',
    'FundClaimDiscountAmount':'DECIMAL(20,6)',
    'FundClaimExcessAmount':'DECIMAL(20,6)',
    'StoplossExcessAmount':'DECIMAL(20,6)'
}
try:
    data_type_converted_df = dtype_tgt_conversion(df_join, datatype_change_schema)
except Exception as e:
    raise Exception('data type conversion',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    final_df = remove_invalid_records(data_type_converted_df, stage_tbl_name, not_null_col_lst).drop('RunId','DerivedIndicator','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ClaimDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        # lst = sorted(spark.sql(f'SHOW PARTITIONS {cur_tbl_name}').rdd.map(lambda x : x.part_col).collect())
        # for part_id in lst:
        #     df = read_table_to_df(cur_tbl_name).filter(col('part_col') == part_id).drop('part_col')
        #     load_df_to_sf_sql_db_spark(df, 'Claim.ExpenseClaimDetail')
        
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
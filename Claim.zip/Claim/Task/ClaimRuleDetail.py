# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2387
# MAGIC ##### Curated Tables
# MAGIC - Claim.ClaimRuleDetail
# MAGIC ##### Target Table
# MAGIC - Claim.ClaimRuleDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'CLAIM_TRE2387'
buz_keys = ['ClmRuleNbr']
table_code = "Claim_ClaimRuleDetail" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Claim_ClaimRuleDetail')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Claim', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Claim', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ClaimStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,importing functions
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

# DBTITLE 1,getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2387_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    tre2387_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,column mapping 
#column mapping db2 to cloud columns
col_mapping = {
'CausCatCd' : 'CauseCategoryCode',
'ClmRuleNbr' : 'ClaimRuleNumber',
'Re2387RulbasTs' : 'CreatedDateTime',
'DerivedIndicator':'DerivedIndicator',
'FundPrepayInd' : 'FundPrepayIndicator',
'GcnCd' : 'GCNCode',
'Icd10DiagFromCd' : 'ICD10DiagnosisFromCode',
'Icd10DiagToCd' : 'ICD10DiagnosisToCode',
'Icd9DiagFromCd' : 'ICD9DiagnosisFromCode',
'Icd9DiagToCd' : 'ICD9DiagnosisToCode',
'LevelNbr' : 'LevelNumber',
'NdcMfrNbr' : 'NDCManufactureNumber',
'NdcPkgSzNbr' : 'NDCPackageSize',
'NdcProdCd' : 'NDCProductCode',
'PotCatCd1' : 'POTCategory1Code',
'PotCatCd2' : 'POTCategory2Code',
'PotCatCd3' : 'POTCategory3Code',
'ProcSuffFromCd' : 'ProcedureSuffixFromCode',
'ProcSuffToCd' : 'ProcedureSuffixToCode',
'ProcTyCdInd' : 'ProcedureTypeCodeIndicator',
'ProcTyFromCd' : 'ProcedureTypeFromCode',
'ProcTyToCd' : 'ProcedureTypeToCode',
'ProvParCd' : 'ProviderParticipatingCode',
'ProvSpclFromCd' : 'ProviderSpecialtyFromCode',
'ProvSpclToCd' : 'ProviderSpecialtyToCode',
'ProvTyCd1' : 'ProviderType1Code',
'ProvTyCd2' : 'ProviderType2Code',
'ProvTyCd3' : 'ProviderType3Code',
'ProvTyCd4' : 'ProviderType4Code',
'RidrCd' : 'RiderCode',
'RidrOptCd' : 'RiderOptCode',
'RidrPlanCd' : 'RiderPlanCode',
'Icd9Icd10Ind' : 'ICDVersion',
'RevFromCd' : 'RevenueFromCode',
'RevToCd' : 'RevenueToCode',
'PrtbdInd' : 'PartBDCode',
'ReServTyCd' : 'ServiceTypeCode'
}

# COMMAND ----------

# DBTITLE 1,adding audit columns
#column mapping and adding audit columns
try:
    col_mapped_df = col_name_mapping(tre2387_stage_df,col_mapping)
    add_audit_col_df = col_mapped_df.selectExpr("*", f"'{PIPELINE_NAME}' as CreatedBy")\
    .withColumn('ModifiedDateTime',col('CreatedDateTime'))\
    .withColumn('ModifiedBy',col('CreatedBy'))
except Exception as e:
    raise Exception('column mapping or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ClaimDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(add_audit_col_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        claim_rule_detail_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(claim_rule_detail_df, 'Claim.ClaimRuleDetail')

        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions =['ClaimRuleNumber']

        delta_operate(cur_tbl_name,add_audit_col_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ClaimRuleDetailKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus':lit(None).cast('STRING'),
        'ClaimRuleDetailKey':lit(None).cast("BIGINT")
        }
        mapped_df= add_audit_col_df.withColumns(mapping)

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Claim.StageClaimRuleDetail')
        
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))

# COMMAND ----------


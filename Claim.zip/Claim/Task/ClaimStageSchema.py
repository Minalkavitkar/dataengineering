# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "claim/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|"
        },
        "SourceFileFormat" : "csv"
    },
    "CLAIM_TRE2387":{
        "FileRegex" : "CLAIM_TRE2387.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2387"

    },
    "CLAIM_TRE2382":{
        "FileRegex" : "CLAIM_TRE2382.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2382"

    },
    "CLAIM_TRE2383":{
        "FileRegex" : "CLAIM_TRE2383.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2383"

    },
    "CLAIM_TRE2384":{
        "FileRegex" : "CLAIM_TRE2384.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2384"
    },
    "CLAIM_TREGCLM":{
        "FileRegex" : "CLAIM_TREGCLM.TXT",
        "StagePathSuffix" : "claim/stage/StageTREGCLM"

    },
    "CLAIM_TRE2385":{
        "FileRegex" : "CLAIM_TRE2385.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2385"
    },
    "CLAIM_TRE2386":{
        "FileRegex" : "CLAIM_TRE2386.TXT",
        "StagePathSuffix" : "claim/stage/StageTRE2386"
    },
    "CLAIM_TREMCLM":{
        "FileRegex" : "CLAIM_TREMCLM.TXT",
        "StagePathSuffix" : "claim/stage/StageTREMCLM"

    },
    "CLAIM_TRECLM":{
        "FileRegex" : "CLAIM_TRECLM.TXT",
        "StagePathSuffix" : "claim/stage/StageTRECLM"

    },
    "CLAIM_TRECLMX":{
        "FileRegex" : "CLAIM_TRECLMX.TXT",
        "StagePathSuffix" : "claim/stage/StageTRECLMX"
    }


}

# COMMAND ----------

tre2387_schema = {
"CLM_RULE_NBR" : "INT",
"FUND_PREPAY_IND" : "STRING",
"POT_CAT_CD1" : "STRING",
"POT_CAT_CD2" : "STRING",
"POT_CAT_CD3" : "STRING",
"PROV_SPCL_FROM_CD" : "STRING",
"PROV_SPCL_TO_CD" : "STRING",
"PROC_TY_CD_IND" : "STRING",
"ICD9_ICD10_IND" : "STRING",
"PROC_TY_FROM_CD" : "STRING",
"PROC_TY_TO_CD" : "STRING",
"PROC_SUFF_FROM_CD" : "STRING",
"PROC_SUFF_TO_CD" : "STRING",
"PROV_TY_CD1" : "STRING",
"PROV_TY_CD2" : "STRING",
"PROV_TY_CD3" : "STRING",
"PROV_TY_CD4" : "STRING",
"ICD9_DIAG_FROM_CD" : "STRING",
"ICD9_DIAG_TO_CD" : "STRING",
"RE_SERV_TY_CD" : "STRING",
"CAUS_CAT_CD" : "STRING",
"PROV_PAR_CD" : "STRING",
"REV_FROM_CD" : "STRING",
"REV_TO_CD" : "STRING",
"PRTBD_IND" : "STRING",
"RIDR_CD" : "STRING",
"RIDR_PLAN_CD" : "STRING",
"RIDR_OPT_CD" : "STRING",
"NDC_MFR_NBR" : "STRING",
"NDC_PROD_CD" : "STRING",
"NDC_PKG_SZ_NBR" : "STRING",
"ICD10_DIAG_FROM_CD" : "STRING",
"ICD10_DIAG_TO_CD" : "STRING",
"GCN_CD" : "STRING",
"LEVEL_NBR" : "STRING",
"RE2387_RULBAS_TS" : "TIMESTAMP",
"PLTFM_CD" : "STRING",
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP"	 
}

# COMMAND ----------

tre2382_schema = {
"CLM_RULE_TBL_ID" : "STRING",
"CLM_RULE_TBL_DESC" : "STRING",
"UPDT_INIT_NM" : "STRING",
"LAST_CHG_CYMD_DT" : "DATE",
"PLTFM_CD" : "STRING",
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP"
}

# COMMAND ----------

tre2383_schema = {
"CLM_RULE_TBL_ID" : "STRING",
"PROD_MKT_NBR" : "STRING",
"PROD_LOB_CD" : "STRING",   
"PROD_PLAN_NBR" : "STRING",  
"PROD_OPT_NBR" : "STRING", 
"PLTFM_CD" : "STRING",
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP" 
}

# COMMAND ----------

tre2384_schema = {
'CLM_RULE_TBL_ID':'STRING',
'PROD_MKT_NBR':'STRING',
'PROD_LOB_CD':'STRING',
'PROD_PLAN_NBR':'STRING',
'PROD_OPT_NBR':'STRING',
'FUND_PROC_SEQ_NBR':'SMALLINT',
'BEG_CPT4_MOD_CD':'STRING',
'FUND_TY_CD':'STRING',
'END_CPT4_MOD_CD':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2386_schema = {
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP",
"CLM_RULE_TBL_ID" : "STRING",  
"PROD_MKT_NBR" : "STRING",   
"PROD_LOB_CD" : "STRING",      
"PROD_PLAN_NBR" : "STRING",    
"PROD_OPT_NBR" : "STRING",     
"FUND_PROC_SEQ_NBR" : "SMALLINT",
"BEG_CPT4_MOD_CD" : "STRING",  
"EFF_CYMD_DT" : "DATE",      
"RE2386_RULNBR_TS" : "TIMESTAMP",
"CLM_RULE_NBR " : "INTEGER",
"PLTFM_CD" : "STRING"  
}

# COMMAND ----------

tre2385_schema = {
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP",
"CLM_RULE_TBL_ID" : "STRING",  
"PROD_MKT_NBR" : "STRING",   
"PROD_LOB_CD" : "STRING",      
"PROD_PLAN_NBR" : "STRING",    
"PROD_OPT_NBR" : "STRING",     
"FUND_PROC_SEQ_NBR" : "SMALLINT",
"BEG_CPT4_MOD_CD" : "STRING",  
"EFF_CYMD_DT" : "DATE",      
"END_CYMD_DT" : "DATE",      
"CLM_RULE_TY_CD" : "STRING", 
"RE2385_RULDTE_TS" : "TIMESTAMP", 
"PLTFM_CD" : "STRING"
}

# COMMAND ----------

tregclm_schema ={
"IND1" : "STRING",
"TIMESTAMP" : "TIMESTAMP",
"GK_PROV_ID_NBR" : "STRING",
"GK_PROV_SUFF_CD" : "STRING",
"GK_SERV_TY_CD" : "STRING",
"GK_SEQ_NBR" : "STRING",
"GTK_GEN_KEY" : "INTEGER"
}

# COMMAND ----------

tremclm_schema = { 
     'MBR_PID': "STRING"
    ,'MBR_GEN_KEY': "INT"    
    ,'Ind1' : "STRING"
    ,'Timestamp': "TIMESTAMP"   
}

# COMMAND ----------

treclm_schema = { 
'MBR_GEN_KEY': "INT"       
,'GTK_GEN_KEY' : "INT"       
,'CLM_GEN_KEY' : "INT"       
,'CLM_INCRD_DATE' : "DATE"    
,'CLM_EXTR_SEQ_NBR': "INT"   
,'CAS_CLM_NBR' : "BIGINT"      
,'CLM_EXTR_CYM_DATE':"DATE" 
,'CLM_PRST_REVS_CD': "STRING"   
,'CLM_FUND_EXCP_IND': "STRING"  
,'PROD_SEQ_NBR': "INT"      
,'CAS_PROC_SP_DATE':"DATE"  
,'LAST_RPROC_DATE':"DATE"    
,'RPROC_IND': "STRING"         
,'CLNT_S_NBR': "INT"        
,'CAS_LOB_CD': "STRING"         
,'CLM_PYMT_OVR_CD': "STRING"    
,'PAT_PCERT_AUTH_CD': "STRING"  
,'CAUSE_CAT_CD': "STRING"        
,'ICD9_DIAG_CD': "STRING"       
,'ICD9_PROC_CD': "STRING"        
,'POT_CAT_CD' : "STRING"         
,'PROC_TY_CD_IND': "STRING"     
,'PROC_TY_CD': "STRING"         
,'CLM_ROLL_UP_IND' : "STRING"    
,'REFRL_AUTH_NBR' : "STRING"    
,'SERV_PROV_ID_NBR': "STRING"   
,'SERV_PROV_SUFF_CD': "STRING" 
,'PROV_TY_CD': "STRING"        
,'PROV_SPCL_CD': "STRING"      
,'PROV_PAR_CD': "STRING"        
,'FUND_CLM_BEN_AMT': "DECIMAL(11,2)"  
,'PROV_DISC_TBL_ID' : "STRING" 
,'PROV_CLM_DISC_PCT': "DECIMAL(5,2)"  
,'STOPLS_TBL_ID': "STRING"    
,'REDIR_FUND_TY_CD': "STRING"  
,'PHAR_NDC_NBR' : "STRING"      
,'POST_PAY4_IND': "STRING"      
,'DNTL_RIDR_CD': "STRING"       
,'DNTL_RIDR_PLN_ID': "STRING"
,'VISN_RIDR_CD': "STRING"    
,'VISN_RIDR_PLN_ID': "STRING"
,'HER_RIDR_CD': "STRING"     
,'HER_RIDR_PLN_ID': "STRING"
,'ICD10_DIAG_CD': "STRING"   
,'ICD10_PROC_CD': "STRING"   
,'ICD9_ICD10_IND': "STRING"  
,'GC_NBR': "STRING"          
,'CLM_RULE_SRC_KEY': "STRING"
,'RECLM_CLM_NBR': "STRING"
,'Ind1': "STRING"
,'Timestamp': "TIMESTAMP" 
}

# COMMAND ----------

treclmx_schema = { 
'CLM_GEN_KEY': "INT"
,'CLM_EXTR_VER_NBR': "INT"
,'EXPS_PROV_ID_NBR': "STRING"
,'EXPS_PROV_SUFF_CD': "STRING"
,'EXPS_SERV_TY_CD': "STRING"
,'EXPS_SEQ_NBR': "STRING"
,'FUND_TY_CD': "STRING"
,'FUND_CLM_DISC_AMT': "DECIMAL(11,2)"
,'FUND_CLM_EXPS_AMT': "DECIMAL(11,2)"
,'STOPLS_EXCESS_AMT': "DECIMAL(9,2)"
,'CURR_MO_STAT_CD': "STRING"
,'REINSUR_IND': "STRING"
,'REENC_IND' : "STRING" 
,'Ind1' : "STRING"
,'Timestamp': "TIMESTAMP"   
}
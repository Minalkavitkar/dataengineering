# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRECLM
# MAGIC
# MAGIC ##### Target Table 
# MAGIC - Claim.ExpenseClaim

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "CLAIM_TRECLM"
buz_keys = ['ClmGenKey']
not_null_col_lst = ['ExpenseClaimMemberKey','ExpenseClaimProviderKey','ProductKey']
table_code = "Claim_ExpenseClaim" 

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','pl_Claim_ExpenseClaim')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Claim', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Claim', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./ClaimStageSchema"

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    expns_clmmbr_tbl_name = table_name_selector(tbl_conf_df, 'Claim_ExpenseClaimMember')
    expns_clmpvd_tbl_name = table_name_selector(tbl_conf_df, 'Claim_ExpenseClaimProvider')
    prdt_tbl_name = table_name_selector(tbl_conf_df, 'Product_Product')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treclm_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage and curated table
#Reading data from stage table & filtering the valid records
try:
    treclm_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    product_df = read_table_to_df(prdt_tbl_name)\
        .select('ProductKey','ExtProdSeqNo').distinct()
    expnse_clmmbr_df = read_table_to_df(expns_clmmbr_tbl_name).select('MbrGenKey','ExpenseClaimMemberKey').distinct()
    expnse_clmpvdr_df = read_table_to_df(expns_clmpvd_tbl_name).select('GtkGenKey','ExpenseClaimProviderKey').distinct()
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping dictionary
#Column name mapping
col_mapping = {
'CasClmNbr':'CASClaimNumber'
,'CasLobCd':'CASLOBCode'
,'ClntSNbr':'CLNTSNumber'
,'CauseCatCd':'CauseCategoryCode'
,'ClmExtrCymDate':'ClaimExternalDate'
,'ClmExtrSeqNbr':'ClaimExternalSequenceNumber'
,'ClmFundExcpInd':'ClaimFundExceptionIndicator'
,'ClmIncrdDate':'ClaimIncurredDate'
,'ClmPymtOvrCd':'ClaimPaymentOverrideCode'
,'ClmRollUpInd':'ClaimRollUpIndicator'
,'ClmRuleSrcKey':'ClaimRuleSourceKey'
,'DntlRidrPlnId':'DentalRiderPlanId'
,'DntlRidrCd':'DentalRiderCode'
,'FundClmBenAmt':'FundClaimBenefitAmount'
,'GcNbr':'GCNbr'
,'HerRidrCd':'HERRiderCode'
,'HerRidrPlnId':'HERRiderPlanIdentifier'
,'Icd10DiagCd':'ICD10DiagnosisCode'
,'Icd10ProcCd':'ICD10ProcedureCode'
,'Icd9DiagCd':'ICD9DiagnosisCode'
,'Icd9ProcCd':'ICD9ProcedureCode'
,'LastRprocDate':'LastReprocessDate'
,'PotCatCd':'POTCategoryCode'
,'PatPcertAuthCd':'PatientPercentageAuthCode'
,'PharNdcNbr':'PharmacyNDCNumber'
,'PostPay4Ind':'PostPayForIndicator'
,'ProcTyCd':'ProcedureTypeCode'
,'ProcTyCdInd':'ProcedureTypeCodeIndicator'
,'ProvClmDiscPct':'ProviderClaimDiscountPercent'
,'ProvDiscTblId':'ProviderDiscountId'
,'ProvParCd':'ProviderParticipatingCode'
,'ProvSpclCd':'ProviderSpecialtyCode'
,'ProvTyCd':'ProviderTypeCode'
,'RefrlAuthNbr':'ReferralAuthNumber'
,'RprocInd':'ReprocessIndicator'
,'RedirFundTyCd':'RiderFundTypeCode'
,'ServProvIdNbr':'ServiceProviderId'
,'ServProvSuffCd':'ServiceProviderSuffixCode'
,'StoplsTblId':'StoplossId'
,'VisnRidrCd':'VisionRiderCode'
,'VisnRidrPlnId':'VisionRiderPlanId'
,'Icd9Icd10Ind':'ICDVersion'
,'CasProcSpDate':'CASClaimProcessDate'
,'ClmPrstRevsCd':'ClaimRevisionCode'
,'ReclmClmNbr':'ReclmClaimNumber',
'MbrGenKey':'MbrGenKey',
'GtkGenKey':'GtkGenKey',
'ProdSeqNbr':'ProdSeqNbr',
'ClmGenKey':'ClmGenKey',
"StgUnqId":"StgUnqId",
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Column mapping
# Column mapping
try:
    col_mapped_df = col_name_mapping(treclm_stage_df, col_mapping).distinct()
    col_mapped_df_final = col_mapped_df.withColumn('CASProcessDate',col('CASClaimProcessDate'))
except Exception as e:
    raise Exception('Column mapping failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ExpenseClaimMember, ExpenseClaimProvider and Product to get their respective keys
#Join with ExpenseClaimMember, ExpenseClaimProvider and Product to get ExpenseClaimMemberKey,ExpenseClaimProviderKey and ProductKey respectively.
try:
    cond1 = col('LH.MbrGenKey')==col('RH.MbrGenKey')
    cond2 = col('LH.GtkGenKey')==col('RH.GtkGenKey')
    cond3 = col('LH.ProdSeqNbr')==col('RH.ExtProdSeqNo')
    df_clm_mclm = col_mapped_df_final.alias('LH').join(expnse_clmmbr_df.alias('RH'),cond1,'left').select('LH.*','RH.ExpenseClaimMemberKey')
    df_mbr_prov = df_clm_mclm.alias('LH').join(expnse_clmpvdr_df.alias('RH'),cond2,'left').select('LH.*','RH.ExpenseClaimProviderKey')
    df_join = df_mbr_prov.alias('LH').join(product_df.alias('RH'),cond3,'left').select('LH.*','RH.ProductKey').drop('MbrGenKey','ProdSeqNbr','GtkGenKey')
except Exception as e:
    raise Exception('Joining failed',str(e))

# COMMAND ----------

# DBTITLE 1,Data type conversion and adding audit columns
#data type conversion and adding audit columns
datatype_change_schema = {
    'CASClaimNumber':'STRING',
    'GCNbr':'INT',
    'FundClaimBenefitAmount':'DECIMAL(20,6)',
    'ProviderClaimDiscountPercent':'DECIMAL(10,5)'
}
try:
    data_type_converted_df = dtype_tgt_conversion(df_join, datatype_change_schema)
    col_added_df = add_tgt_audit_column(data_type_converted_df, PIPELINE_NAME)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    final_df = remove_invalid_records(col_added_df, stage_tbl_name, not_null_col_lst).drop('RunId','DerivedIndicator','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ClaimDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        # lst = sorted(spark.sql(f'SHOW PARTITIONS {cur_tbl_name}').rdd.map(lambda x : x.part_col).collect())
        # for part_id in lst:
        #     df = read_table_to_df(cur_tbl_name).filter(col('part_col') == part_id).drop('part_col','ClmGenKey')
        #     load_df_to_sf_sql_db_spark(df, 'Claim.ExpenseClaim')
        
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
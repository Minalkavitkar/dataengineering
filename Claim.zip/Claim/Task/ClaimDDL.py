# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates Claim Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Adls Connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish transformation functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database creation
# database_name = f"Claim{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRuleDetail

# COMMAND ----------

claim_rule_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRuleDetail(
ClaimRuleDetailKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
CauseCategoryCode STRING,
ClaimRuleNumber INT,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
DerivedIndicator STRING,
FundPrepayIndicator STRING,
GCNCode STRING,
ICD10DiagnosisFromCode STRING,
ICD10DiagnosisToCode STRING,
ICD9DiagnosisFromCode STRING,
ICD9DiagnosisToCode STRING,
LevelNumber STRING,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
NDCManufactureNumber STRING,
NDCPackageSize STRING,
NDCProductCode STRING,
POTCategory1Code STRING,
POTCategory2Code STRING,
POTCategory3Code STRING,
ProcedureSuffixFromCode STRING,
ProcedureSuffixToCode STRING,
ProcedureTypeCodeIndicator STRING,
ProcedureTypeFromCode STRING,
ProcedureTypeToCode STRING,
ProviderParticipatingCode STRING,
ProviderSpecialtyFromCode STRING,
ProviderSpecialtyToCode STRING,
ProviderType1Code STRING,
ProviderType2Code STRING,
ProviderType3Code STRING,
ProviderType4Code STRING,
RiderCode STRING,
RiderOptCode STRING,
RiderPlanCode STRING,
ICDVersion STRING,
RevenueFromCode STRING,
RevenueToCode STRING,
PartBDCode STRING,
ServiceTypeCode STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRuleDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRule

# COMMAND ----------

claim_rule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRule(
ClaimRuleDescription STRING,
ClaimRuleId STRING,
ClaimRuleKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
LastChangedDate Date,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRuleSchedule

# COMMAND ----------

claim_rule_schedule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRuleSchedule(
ClaimRuleKey BIGINT NOT NULL,
ClaimRuleScheduleKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
CreatedBy STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
DerivedIndicator STRING,
ModifiedBy	STRING,
ModifiedDateTime TIMESTAMP,
ProductLineOfBusinessCode STRING,
ProductMarketNumber	STRING,
ProductOptNumber STRING,
ProductPlanNumber STRING,
ClaimRuleId STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRuleSchedule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRuleFund

# COMMAND ----------

claim_rule_fund = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRuleFund(
BeginCPTModifierCode STRING,
ClaimRuleFundKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ClaimRuleScheduleKey BIGINT NOT NULL,
CreatedBy STRING NOT NULL,
DerivedIndicator STRING,
CreatedDateTime	TIMESTAMP NOT NULL,
EndCPTModifierCode STRING,
FundSequenceNumber INT,
FundTypeCode STRING,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
ProductLineOfBusinessCode STRING,
ProductMarketNumber	STRING,
ProductOptNumber STRING,
ProductPlanNumber STRING,
ClaimRuleId STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRuleFund'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRuleDate

# COMMAND ----------

claim_rule_date = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRuleDate(
ClaimRuleDateKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
ClaimRuleFundKey BIGINT not null,
ClaimRuleTypeCode VARCHAR(20),
FundSequenceNumber INTEGER,
EndDate DATE,
StartDate DATE,
DerivedIndicator STRING,
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
ProductLineOfBusinessCode STRING,
ProductMarketNumber	STRING,
ProductOptNumber STRING,
ProductPlanNumber STRING,
ClaimRuleId STRING,
BeginCPTModifierCode STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRuleDate'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ExpenseClaimProvider

# COMMAND ----------

expense_claim_provider = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ExpenseClaimProvider(
ExpenseClaimProviderKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
ProviderId VARCHAR(50),
ProviderSequenceNumber INTEGER,
ProviderServiceTypeCode VARCHAR(20),
ProviderSuffixCode VARCHAR(20),
ProviderContractId VARCHAR(50),
DerivedIndicator STRING,
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
GtkGenKey INTEGER
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ExpenseClaimProvider'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimRuleNumber

# COMMAND ----------

claim_Rule_Number = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ClaimRuleNumber(
ClaimRuleNumberKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
ClaimRuleDateKey BIGINT not null,
ClaimRuleNumber INTEGER,
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP not null,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ClaimRuleNumber'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ####ExpenseClaimMember

# COMMAND ----------

expense_claim_member = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ExpenseClaimMember(
ExpenseClaimMemberKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
SourceSystemCode STRING,
MemberId STRING,
DerivedIndicator STRING,
CreatedBy STRING not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
MbrGenKey INT
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ExpenseClaimMember'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ####ExpenseClaim

# COMMAND ----------

expense_claim = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ExpenseClaim(
ExpenseClaimKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null
,ExpenseClaimMemberKey BIGINT NOT NULL
,ExpenseClaimProviderKey BIGINT NOT NULL
,ProductKey BIGINT NOT NULL
,ClaimIncurredDate DATE NOT NULL
,ClaimExternalSequenceNumber INTEGER
,CASClaimNumber STRING 
,ClaimExternalDate DATE 
,ClaimFundExceptionIndicator STRING 
,CASProcessDate DATE 
,LastReprocessDate DATE 
,ReprocessIndicator STRING 
,CLNTSNumber INT 
,CASLOBCode  STRING 
,ClaimPaymentOverrideCode STRING 
,PatientPercentageAuthCode STRING
,CauseCategoryCode STRING 
,ICD9DiagnosisCode STRING 
,ICD9ProcedureCode STRING 
,POTCategoryCode STRING 
,ProcedureTypeCode STRING
,ProcedureTypeCodeIndicator STRING 
,ClaimRollUpIndicator STRING 
,ReferralAuthNumber STRING 
,ServiceProviderId STRING 
,ServiceProviderSuffixCode STRING 
,ProviderTypeCode STRING 
,ProviderSpecialtyCode STRING 
,ProviderParticipatingCode STRING 
,FundClaimBenefitAmount	DECIMAL(20,6) 
,ProviderDiscountId STRING 
,ProviderClaimDiscountPercent DECIMAL(10,5) 
,StoplossId STRING 
,RiderFundTypeCode STRING 
,PharmacyNDCNumber STRING
,PostPayForIndicator STRING
,DentalRiderPlanId STRING
,DentalRiderCode STRING
,VisionRiderCode STRING
,VisionRiderPlanId STRING
,HERRiderCode STRING
,HERRiderPlanIdentifier STRING 
,ICD10DiagnosisCode STRING 
,ICD10ProcedureCode  STRING 
,GCNbr INT 
,ClaimRuleSourceKey STRING 
,ICDVersion STRING 
,CASClaimProcessDate DATE 
,ClaimRevisionCode STRING 
,ReclmClaimNumber STRING 
,CreatedBy STRING not null
,CreatedDateTime TIMESTAMP not null
,ModifiedBy STRING
,ModifiedDateTime TIMESTAMP,
ClmGenKey INT
,part_col double generated always as (round((ExpenseClaimKey/5000000),0))
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ExpenseClaim'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ####ExpenseClaimDetail

# COMMAND ----------

expense_claim_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.claim_ExpenseClaimDetail(
ExpenseClaimDetailKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null
,ExpenseClaimKey BIGINT NOT NULL
,ClaimExternalVersionNumber INT
,ClaimIncurredDate DATE NOT NULL
,ExpenseProviderId STRING 
,ExpenseProviderSuffixCode STRING 
,ExpenseServiceTypeCode STRING 
,ExpenseSequenceNumber INT 
,FundTypeCode STRING 
,FundClaimDiscountAmount DECIMAL(20,6) 
,FundClaimExcessAmount DECIMAL(20,6) 
,StoplossExcessAmount DECIMAL(20,6)
,CurrentMonthStatusCode STRING 
,ReInsuranceIndicator STRING 
,ReencIndicator STRING 
,CreatedBy STRING not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
,part_col double generated always as (round((ExpenseClaimDetailKey/5000000),0))
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/claim/curated/ExpenseClaimDetail'"""

# COMMAND ----------

tbl_mapping = {
"claim_ClaimRuleDetail" : claim_rule_detail,
"claim_ClaimRule" : claim_rule,
"claim_ClaimRuleSchedule" : claim_rule_schedule,
"claim_ClaimRuleFund" : claim_rule_fund,
"claim_ExpenseClaimProvider" : expense_claim_provider,
"claim_ClaimRuleDate" : claim_rule_date,
"claim_ClaimRuleNumber" : claim_Rule_Number,
"claim_ExpenseClaimMember": expense_claim_member,
"claim_ExpenseClaim": expense_claim,
"claim_ExpenseClaimDetail":expense_claim_detail
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
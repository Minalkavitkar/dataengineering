# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2386
# MAGIC ##### Curated Tables
# MAGIC - Claim.ClaimRuleNumber
# MAGIC ##### Target Table
# MAGIC - Claim.ClaimRuleNumber

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "CLAIM_TRE2386"
buz_keys = ['ClmRuleTblId','ProdMktNbr','ProdLobCd','ProdPlanNbr','ProdOptNbr','FundProcSeqNbr','BegCpt4ModCd','EffCymdDt','Re2386RulnbrTs']
not_null_col_lst = ['ClaimRuleDateKey']
table_code = "Claim_ClaimRuleNumber" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Claim')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Claim', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Claim', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ClaimStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df,table_code)
    cur_claimRule_date = table_name_selector(tbl_conf_df, 'Claim_ClaimRuleDate')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name,tre2386_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    tre2386_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    claimRule_date_df = read_table_to_df(cur_claimRule_date)

    foreign_char_removed_df = replace_foreign_char(tre2386_stage_df, ['ProdLobCd','ProdMktNbr','ProdPlanNbr','ProdOptNbr','BegCpt4ModCd'], "�", "X")
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,joining with claimRuleDate to get ClaimRuleDateKey
#joining tre2385 with claimRuleDate to get ClaimRuleDateKey
try:
    final_df=foreign_char_removed_df.alias('LH').join(claimRule_date_df.alias('RH'),\
        (col('LH.ClmRuleTblId') == col('RH.ClaimRuleId')) & \
        (col('LH.ProdMktNbr') == col('RH.ProductMarketNumber')) & \
        (col('LH.ProdLobCd') == col('RH.ProductLineOfBusinessCode')) & \
        (col('LH.ProdPlanNbr') == col('RH.ProductPlanNumber')) & \
        (col('LH.ProdOptNbr') == col('RH.ProductOptNumber')) & \
        (col('LH.BegCpt4ModCd') == col('RH.BeginCPTModifierCode')) & \
        (col('LH.FundProcSeqNbr') == col('RH.FundSequenceNumber')) & \
        (col('LH.EffCymdDt') == col('RH.StartDate')),'left')\
        .select('LH.*', 'RH.ClaimRuleDateKey')
except Exception as e:
    raise Exception('joining failed',str(e))

# COMMAND ----------

# DBTITLE 1,column mapping
#column mapping with domain tables
col_mapping = {
'ClaimRuleDateKey':'ClaimRuleDateKey',
'ClmRuleNbr':'ClaimRuleNumber',
'ClmRuleTblId':'ClaimRuleId',
'ProdMktNbr':'ProductMarketNumber',
'ProdLobCd':'ProductLineOfBusinessCode',
'ProdPlanNbr':'ProductPlanNumber',
'ProdOptNbr':'ProductOptNumber',
'BegCpt4ModCd':'BeginCPTModifierCode',
'FundProcSeqNbr':'FundSequenceNumber',
'EffCymdDt':'StartDate',
'Re2386RulnbrTs':'CreatedDateTime',
"StgUnqId":"StgUnqId",
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,adding audit columns
try:
    col_mapped_df = col_name_mapping(final_df,col_mapping)
    add_audit_col_df = col_mapped_df.selectExpr("*", f"'{PIPELINE_NAME}' as CreatedBy")\
    .withColumn('ModifiedDateTime',col('CreatedDateTime'))\
    .withColumn('ModifiedBy',col('CreatedBy'))
except Exception as e:
    raise Exception('column mapping or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
try:
    final_stage_df = remove_invalid_records(add_audit_col_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ClaimRuleId','ProductMarketNumber','ProductLineOfBusinessCode','ProductPlanNumber','ProductOptNumber','BeginCPTModifierCode','FundSequenceNumber','StartDate')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ClaimDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        ClaimRule_Number_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(ClaimRule_Number_df, 'Claim.ClaimRuleNumber')
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
    elif LOAD_TYPE == 'DeltaLoad':
        conditions =['ClaimRuleNumber', 'ModifiedDateTime', 'ClaimRuleDateKey']

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ClaimRuleNumberKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus':lit(None).cast('STRING'),
        'ClaimRuleNumberKey':lit(None).cast("BIGINT"),
        'ClaimRuleDateKey':lit(None).cast("BIGINT"),
        'FundSequenceNumber' :col("FundSequenceNumber").cast("INT")
        }
        mapped_df= final_stage_df.withColumns(mapping)

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','ModifiedDateTime'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Claim.StageClaimRuleNumber')
        
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))

# COMMAND ----------


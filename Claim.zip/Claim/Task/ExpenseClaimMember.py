# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREMCLM
# MAGIC ##### Curated Tables
# MAGIC - Claim.ExpenseClaimMember
# MAGIC ##### Target Table 
# MAGIC - Claim.ExpenseClaimMember

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "CLAIM_TREMCLM"
buz_keys = ['MbrGenKey']
table_code = "Claim_ExpenseClaimMember" 

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','pl_Claim_ExpenseClaimMember')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Claim', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Claim', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Import libraries to be used
from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./ClaimStageSchema"

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    member_tbl_name = table_name_selector(tbl_conf_df, 'Member_Member')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tremclm_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage and curated table
#Reading data from stage table & filtering the valid records
try:
    tremclm_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    # member_df = read_table_to_df(member_tbl_name)\
    #     .select('MemberId','SourceSystemCode').distinct()
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping
#Column name mapping
col_mapping = {
    'MbrPid':'MemberId' ,
    'MbrGenKey':'MbrGenKey',
    'DerivedIndicator':'DerivedIndicator' 
}
try:
    col_mapped_df = col_name_mapping(tremclm_stage_df, col_mapping)
except Exception as e:
    raise Exception('Column mapping failed',str(e))

# COMMAND ----------

# DBTITLE 1,Getting minimum of MbrGenKey to remove duplicate MbrPid
# #Getting minimum of MbrGenKey to remove duplicate MbrPid
# try:
#     windowSpec = Window.partitionBy('MemberId').orderBy(col('MbrGenKey').asc())
#     col_mapped_df_min = col_mapped_df.withColumn('min',row_number().over(windowSpec))\
#         .filter(col('min')==1).drop('min')
# except Exception as e:
#     raise Exception('Filter min MbrGenKey failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join with member table to get the SourceSystemCode
# #Join with member table to get the SourceSystemCode
# try:
#     cond = col('LH.MemberId')==col('RH.MemberId')
#     df_join = col_mapped_df_min.alias('LH').join(member_df.alias('RH'),cond,'left').select('LH.*','RH.SourceSystemCode')
# except Exception as e:
#     raise Exception('Join with Member table failed',str(e))

# COMMAND ----------

# DBTITLE 1,Adding audit columns
# adding audit columns
try:
    col_added_df = add_tgt_audit_column(col_mapped_df, PIPELINE_NAME,LOAD_TYPE)\
        .withColumn('SourceSystemCode',lit('CI'))
except Exception as e:
    raise Exception('Adding audit columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ClaimDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        
        write_to_curated(col_added_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        # ExpenseClaimMember_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        # load_df_to_sf_sql_db_spark(ExpenseClaimMember_df, 'Claim.ExpenseClaimMember')
        
        exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    # elif LOAD_TYPE == 'DeltaLoad':
    #     conditions =[' ']
    #     delta_operation(cur_tbl_name,col_added_df,conditions)
    #     cur_loaded_time = datetime.now()

    #     mapping = {
    #     'ProcessName' : lit(None).cast('STRING'),
    #     'DeltaStatus':lit(None).cast('STRING'),
    #     'ExpenseClaimMemberKey':lit(None).cast("BIGINT")
    #     }
    #     mapped_df= col_added_df.withColumns(mapping)

    #     delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

    #     df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
    #     load_df_to_sf_sql_db_spark(df, 'Claim.StageExpenseClaimMember')
        
    #     exit_notebook(run_id, "Claim", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
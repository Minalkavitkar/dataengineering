# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREPAYP
# MAGIC ##### Curated Tables
# MAGIC - Provider.Payer
# MAGIC ##### Target Table
# MAGIC - Provider.Payer

# COMMAND ----------

# DBTITLE 1,Run validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_TREPAYP'
buz_keys = ['PayerId', 'PayerAddrSeqNbr']
table_code = 'Provider_Payer'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_Payer')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Provider', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Provider', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trepayp_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    trepayp_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping
#column mapping db2 to cloud columns
col_mapping = {
    'PayerId' : 'PayerId'
    ,'PayerAddrSeqNbr' : 'PayerAddressSequenceNumber'
    ,'ClmAdjdLn1Addr' : 'AddressLine1Text'
    ,'ClmAdjdLn2Addr' : 'AddressLine2Text'
    ,'ClmAdjdCityNm' : 'CityName'
    ,'ClmAdjdCoNm' : 'CompanyName'
    ,'ClmAdjdCntctNm' : 'ContactName'
    ,'ClmAdjdStateCd' : 'StateCode'
    ,'ClmAdjdPhoneNbr' : 'TelephoneNumber'
    ,'ClmAdjdZipCd' : 'ZipCode'
    ,'RejectCd' : 'RejectCode'
    ,"DerivedIndicator":"DerivedIndicator"
}

# COMMAND ----------

# DBTITLE 1,data type conversion
dtype_map = {
    "ZipCode" : "STRING"
}

# COMMAND ----------

# DBTITLE 1,column mapping and data type conversion and adding audit columns
#data type converstion and adding audit columns
try:
    col_mapped_df = col_name_mapping(trepayp_stage_df,col_mapping)
    add_col_df = add_tgt_audit_column(col_mapped_df, PIPELINE_NAME, LOAD_TYPE)
    dtype_trans_df = dtype_tgt_conversion(add_col_df, dtype_map)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated Load & SQL Load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(dtype_trans_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(df, 'Provider.Payer')
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['PayerId','PayerAddressSequenceNumber']

        delta_operate(cur_tbl_name,dtype_trans_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"PayerKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'PayerKey':lit(None).cast("BIGINT"),
        'DeltaStatus':lit(None).cast("STRING")
        }
        mapped_df= dtype_trans_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Provider.StagePayer')
        
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
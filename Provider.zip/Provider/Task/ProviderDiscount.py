# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2371
# MAGIC ##### Curated Tables
# MAGIC - Provider.ProviderDiscount
# MAGIC ##### Target Table
# MAGIC - Provider.ProviderDiscount

# COMMAND ----------

# DBTITLE 1,Run validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_TRE2371'
buz_keys = ['ProvDiscTblId','ProvParCatCd','ProvTyCd','ProvIdNbr','ProvSuffCd','PotCd','ProvDiscBegDt']
not_null_col_lst = ['ProviderKey']
table_code = 'Provider_ProviderDiscount'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','pl_Provider')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM') 

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Provider', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Provider', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run "./ProviderStageSchema"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    child_tbl_config_path = conf["ChildTblConfigPath"]
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_cur_tbl_name = table_name_selector(tbl_conf_df, 'Provider_Provider')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2371_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    tre2371_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table and applying transformation logic
#Reading data from stage table & applying transformation logic for Type2Code 
try:
    prv_df = read_table_to_df(prv_cur_tbl_name).select('ProviderKey','ProviderId', 'SuffixCode', 'Type2Code')
    prv_trans_df = prioritize_prv_type2Code(prv_df)
except Exception as e:
    raise Exception("Transformation logic failed",str(e))

# COMMAND ----------

# DBTITLE 1,column mapping
#column mapping db2 to cloud columns
col_mapping = {
    "ProvDiscTblId" : "ProviderDiscountId"
    ,"ProvParCatCd" : "ParticipatingCategoryCode"
    ,"PotCd" : "PotCode"
    ,"ProvDiscBegDt" : "ProviderDiscountBeginDate"
    ,"ProvDiscEndDt" : "ProviderDiscountEndDate"
    ,"ProvClmDiscPct" : "ProviderClaimDiscountPercent"
    ,"ProvDiscDelInd" : "DiscountDeletedIndicator"
    ,"ProvIdNbr" : "ProviderId"
    ,"ProvSuffCd" : "SuffixCode"
    ,'StgUnqId':'StgUnqId'
    ,"RunId":"RunId"
    ,"DerivedIndicator":"DerivedIndicator"
    ,"Status":"Status"
    ,"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,datatype mapping
dtype_map = {
    "ProviderClaimDiscountPercent" : "decimal(20,6)"
}

# COMMAND ----------

# DBTITLE 1,column mapping and adding audit columns,Joining with provider and datatype conversion
#column mapping and joining with provider and datatype conversion and adding audit columns
try:
    col_mapped_df = col_name_mapping(tre2371_stage_df,col_mapping)
    audit_col_added_df = add_tgt_audit_column(col_mapped_df, PIPELINE_NAME,LOAD_TYPE)\
                        .withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
    joined_df = audit_col_added_df.alias('LH')\
                .join(prv_trans_df.alias('RH'), (col('LH.ProviderId') == col('RH.ProviderId')) & (col('LH.SuffixCode') == col('RH.SuffixCode')), 'left')\
                    .select('LH.*', 'RH.ProviderKey')
    dtype_conv_df = dtype_tgt_conversion(joined_df, dtype_map)
except Exception as e:
    raise Exception('joining or datatype conversion adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filter valid record
try:
    final_stage_df = remove_invalid_records(dtype_conv_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderId', 'SuffixCode')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Loading data into curated and Azure SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        prv_dist_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(prv_dist_df, 'Provider.ProviderDiscount')
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderKey', 'ProviderDiscountId', 'ParticipatingCategoryCode', 'PotCode', 'ProviderDiscountBeginDate']

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderDiscountKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderDiscountKey':lit(None).cast("BIGINT"),
        'ProviderKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_stage_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime',])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Provider.StageProviderDiscount')
        
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name) 
except Exception as e:
    raise Exception ('load failed',str(e))
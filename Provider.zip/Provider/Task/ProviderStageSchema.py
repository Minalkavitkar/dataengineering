# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "ContainerName" : "datamovement",
        "StorageAccountName" : env_storage_account_name,
        "FilePathSuffix" : "provider/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|"
        },
        "SourceFileFormat" : "csv"
    },
    "PROVIDER_TREFPRV":{
        "FileRegex" : "PROVIDER_TREFPRV.TXT",
        "StagePathSuffix" : "provider/stage/StageTREFPRV",
        "Config":{
            "header":"true",
            "delimiter":"|"
        },
    },
    "PROVIDER_TRE2340" : {
        "FileRegex" : "PROVIDER_TRE2340.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2340"
    },
    "PROVIDER_TREPAYP" : {
        "FileRegex" : "PROVIDER_TREPAYP.TXT",
        "StagePathSuffix" : "provider/stage/StageTREPAYP"
    },
    "PROVIDER_TRETRDP" : {
        "FileRegex" : "PROVIDER_TRETRDP.TXT",
        "StagePathSuffix" : "provider/stage/StageTRETRDP"
    },
    "PROVIDER_TREXRTE" : {
        "FileRegex" : "PROVIDER_TREXRTE.TXT",
        "StagePathSuffix" : "provider/stage/StageTREXRTE"
    },
    "PROVIDER_TRE2486" : {
        "FileRegex" : "PROVIDER_TRE2486.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2486" 
    },
    "PROVIDER_TRESADR" : {
        "FileRegex" : "PROVIDER_TRESADR.TXT",
        "StagePathSuffix" : "provider/stage/StageTRESADR"
    },
    "PROVIDER_TRE2379" : {
        "FileRegex" : "PROVIDER_TRE2379.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2379"
    },
    "PROVIDER_TRE2370" : {
        "FileRegex" : "PROVIDER_TRE2370.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2370"
    },
    "PROVIDER_TRE2371" : {
        "FileRegex" : "PROVIDER_TRE2371.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2371"
    },
    "PROVIDER_TREGRCD" : {
        "FileRegex" : "PROVIDER_TREGRCD.TXT",
        "StagePathSuffix" : "provider/stage/StageTREGRCD"
    },
    "PROVIDER_TRE2380" : {
        "FileRegex" : "PROVIDER_TRE2380.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2380"
    },
    "PROVIDER_TRE2329" : {
        "FileRegex" : "PROVIDER_TRE2329.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2329"
    },
    "PROVIDER_TRE2327" : {
        "FileRegex" : "PROVIDER_TRE2327.TXT",
        "StagePathSuffix" : "provider/stage/StageTRE2327"
    },
    "PROVIDER_TREPRVD" : {
        "FileRegex" : "PROVIDER_TREPRVD.TXT",
        "StagePathSuffix" : "provider/stage/StageTREPRVD"
    },
    "PROVIDER_TRECORR" : {
        "FileRegex" : "PROVIDER_TRECORR.TXT",
        "StagePathSuffix" : "provider/stage/StageTRECORR"
    },
    "PROVIDER_TRERFCD" : {
        "FileRegex" : "PROVIDER_TRERFCD.TXT",
        "StagePathSuffix" : "provider/stage/StageTRERFCD"
    }
}

# COMMAND ----------

trecorr_schema = {
    "GROUPER_ID" : "STRING"
    ,"GROUPER_TY_CD" : "STRING"
    ,"CORR_ADDR_IND" : "STRING"
    ,"CORR_NM" : "STRING"
    ,"CORR_ADDR1_DESC" : "STRING"
    ,"CORR_ADDR2_DESC" : "STRING"
    ,"CORR_CITY_NM" : "STRING"
    ,"CORR_ST_NM" : "STRING"
    ,"CORR_ZIP_NBR" : "STRING"
    ,"CORR_EXT_ZIP_NBR" : "STRING"
    ,"CTRCT_LEGAL_ID" : "STRING"
    ,"CTRCT_LEGAL_NM" : "STRING"
    ,"CTRCT_LEGAL_DESC" : "STRING"
    ,"DELGTED_SVS_IND" : "STRING"
    ,"REC_UPDT_ID" : "STRING"
    ,"REC_UPDT_DT" : "DATE"
    ,"IND1" : "STRING"
    ,"TIMESTAMP" : "TIMESTAMP"
}

# COMMAND ----------

treprvd_schema = {
    "PROV_NBR" : "STRING"
    ,"PROV_SUFX_CD" : "STRING"
    ,"VEND_BEG_DT" : "STRING"
    ,"AP_VEND_NBR" : "STRING"
    ,"AP_VEND_IND" : "STRING"
    ,"NTWK_TY_CD" : "STRING"
    ,"PLTFM_CD" : "STRING"
    ,"IND1" : "STRING"
    ,"TIMESTAMP" : "TIMESTAMP"
}

# COMMAND ----------

tre2380_schema={
    'DIST_USER_ID':'STRING',
    'DIST_USER_USE_CD':'STRING',
    'USER_LEDGR_NBR':'STRING',
    'DIST_USER_LAST_NM':'STRING',
    'DIST_USER_FST_NM':'STRING',
    'DIST_USER_MID_NM':'STRING',
    'DIST_USER_CO_NM':'STRING',
    'DIST_USER_LN1_ADDR':'STRING',
    'DIST_USER_LN2_ADDR':'STRING',
    'DIST_USER_CITY_NM':'STRING',
    'DIST_USER_ST_CD':'STRING',
    'DIST_USER_ZIP_CD':'STRING',
    'USER_ZIP_PLUS_CD':'STRING',
    'USER_HDW_TY_CD':'STRING',
    'DATA_FMT_CD':'STRING',
    'DATA_MEDIA_TY_CD':'STRING',
    'CLM_GRPR_IND':'STRING',
    'ALT_PCP_GRPR_IND':'STRING',
    'OFF_PH_AREA_CD':'STRING',
    'OFF_PH_EXCH_NBR':'STRING',
    'OFF_PH_STA_NBR':'STRING',
    'REEL_BLK_FACT':'SMALLINT',
    'REEL_LBL_CD':'STRING',
    'REEL_FILL_IND':'STRING',
    'DEFLT_PAY_CLM_CNT':'SMALLINT',
    'BYP_REFRL_EDIT_IND':'STRING',
    'BYP_SYS_PEND20_IND':'STRING',
    'BYP_REWRK_LIM_AMT':'SMALLINT',
    'SUSP_REJ_CLM_IND':'STRING',
    'DELV_MTHD_DESC':'STRING',
    'PAPER_GRPR_IND':'STRING',
    'ELEC_RE608_IND':'STRING',
    'ELEC_RE610_IND':'STRING',
    'ELEC_RE627_IND':'STRING',
    'ELEC_RE645_IND':'STRING',
    'ELEC_GRPR_REQ_IND':'STRING',
    'ELEC_QTRLY_IND':'STRING',
    'ELEC_GRPR_HIST_IND':'STRING',
    'RPT_CTRL_TBL_ID':'STRING',
    'SEL_HIST_IND':'STRING',
    'GRPR_RPT_SEQ_IND':'STRING',
    'UPDT_DD_DT':'SMALLINT',
    'ELEC_GRPR_BAL_CD':'STRING',
    'ELEC_MAN_ADJ_CD':'STRING',
    'ELEC_SPC_CAP_CD':'STRING',
    'ELEC_MBR_CAP_CD':'STRING',
    'PRI_DATA_RTE_CD':'STRING',
    'SECDRY_DATA_RTE_CD':'STRING',
    'BBS_DIR_NM':'STRING',
    'BBS_CONN_MTHD_CD':'STRING',
    'ELEC_CONTST_CD':'STRING',
    'DELG_SW_CD':'STRING',
    'ID_CARD_ADDR_IND':'STRING',
    'BYP_AUTH_EDIT_IND':'STRING',
    'BYP_3G_PEND_IND':'STRING',
    'PLTFM_CD':'STRING',
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tregrcd_schema={
    'GROUPER_ID':'STRING',
    'GROUPER_TY_CD':'STRING',
    'VARIABLE_ID':'STRING',
    'VARIABLE_CD':'STRING',
    'REC_UPDT_ID':'STRING',
    'REC_UPDT_DT':'DATE',
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP',
}

# COMMAND ----------

tre2371_schema={
    'PROV_DISC_TBL_ID':'STRING',
    'PROV_PAR_CAT_CD':'STRING',
    'PROV_TY_CD':'STRING',
    'PROV_ID_NBR':'STRING',
    'PROV_SUFF_CD':'STRING',
    'POT_CD':'STRING',
    'PROV_DISC_BEG_DT':'DATE',
    'PROV_DISC_END_DT':'DATE',
    'PROV_CLM_DISC_PCT':'DECIMAL(5,2)',
    'PROV_DISC_DEL_IND':'STRING',
    'PLTFM_CD':'STRING',
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2370_schema={
    'PROV_DISC_TBL_ID':'STRING',
    'PLTFM_CD':'STRING',
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2379_schema={
    'IND1':'STRING',
	'TIMESTAMP':'TIMESTAMP',
	'DIST_USER_ID':'STRING',
	'SUPER_DIST_USER_ID':'STRING',
	'PLTFM_CD ':'STRING'
}

# COMMAND ----------

tre2486_schema={
'RPT_IDENTIFIER':'STRING'
,'RPT_DEST_CNTR_ID':'STRING'
,'EPIC_ID':'STRING'
,'BEG_CYMD_DT':'DATE'
,'END_CYMD_DT':'DATE'
,'UPD_USER_ID':'STRING'
,'IND1':'STRING'
,'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

trefprv_schema = {'IND1': 'STRING',
'TIMESTAMP': 'TIMESTAMP',
'PROV_ID': 'STRING',
'ADDR_KEY': 'STRING',
'PROV_TY_CD': 'STRING',
'PROV_TY_2_CD': 'STRING',
'PROV_NM': 'STRING',
'LIC_NBR': 'INT',
'IRS_NBR': 'INT',
'GRP_NM': 'STRING',
'GRP_IND': 'STRING',
'PROV_SPCL_CD': 'STRING',
'MULT_ADDR_IND': 'STRING',
'PROV_PROF_AREA_CD': 'STRING',
'CAS_ADDR1_NM': 'STRING',
'CAS_ADDR2_NM': 'STRING',
'CAS_ADDR3_NM': 'STRING',
'CAS_ADDR4_NM': 'STRING',
'CAS_CITY_NM': 'STRING',
'CAS_ST_NM': 'STRING',
'CAS_ZIP_CD': 'STRING',
'PH_NBR': 'STRING',
'PAY_INFO_CD': 'STRING',
'XREF_NBR': 'INT',
'CNTY_CD': 'INT',
}

# COMMAND ----------

tre2340_schema = {
    'PCA_GRP_ID' : 'STRING'
    ,'PCA_GRP_CYC_NBR' : 'INTEGER'
    ,'PCA_GRP_NM' : 'STRING'
    ,'PCA_GRP_STAT_CD' : 'STRING'
    ,'PCA_GRP_STAT_DT' : 'DATE'
    ,'PLTFM_CD' : 'STRING'
    ,'IND1' : 'STRING'
    ,'TIMESTAMP' : 'TIMESTAMP'
}

# COMMAND ----------

trepayp_schema = {
    'PAYER_ID':'STRING'
    ,'PAYER_ADDR_SEQ_NBR':'INTEGER'
    ,'CLM_ADJD_CO_NM':'STRING'
    ,'CLM_ADJD_LN1_ADDR':'STRING'
    ,'CLM_ADJD_LN1_ADDR_NI':'STRING'
    ,'CLM_ADJD_LN2_ADDR':'STRING'
    ,'CLM_ADJD_LN2_ADDR_NI':'STRING'
    ,'CLM_ADJD_CITY_NM':'STRING'
    ,'CLM_ADJD_CITY_NM_NI':'STRING'
    ,'CLM_ADJD_STATE_CD':'STRING'
    ,'CLM_ADJD_STATE_CD_NI':'STRING'
    ,'CLM_ADJD_ZIP_CD':'INTEGER'
    ,'CLM_ADJD_ZIP_CD_NI':'DATE'
    ,'CLM_ADJD_CNTCT_NM':'STRING'
    ,'CLM_ADJD_CNTCT_NM_NI':'STRING'
    ,'CLM_ADJD_PHONE_NBR':'STRING'
    ,'CLM_ADJD_PHONE_NBR_NI':'STRING'
    ,'REJECT_CD':'STRING'
    ,'REJECT_CD_NI':'STRING'
    ,'REC_UPDT_ID':'STRING'
    ,'REC_UPDT_ID_NI':'STRING'
    ,'REC_UPDT_DT':'DATE'
    ,'REC_UPDT_DT_NI':'DATE'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'STRING'
}

# COMMAND ----------

tretrdp_schema = {
    'TRADE_PRTNR_ID' : 'STRING'
    ,'TRADE_PRTNR_NM' : 'STRING'
    ,'IND1' : 'STRING'
    ,'TIMESTAMP' : 'TIMESTAMP'
}

# COMMAND ----------

trexrte_schema = {
    'DIST_USER_ID' : 'STRING'
    ,'DIST_USER_CO_NM' : 'STRING'
    ,'TRADE_PRTNR_ID' : 'STRING'
    ,'PAYER_ID' : 'STRING'
    ,'PAYER_ADDR_SEQ_NBR' : 'INTEGER'
    ,'EFF_DT' : 'DATE'
    ,'END_DT' : 'DATE'
    ,'REC_UPDT_ID' : 'STRING'
    ,'REC_UPDT_DT' : 'DATE'
    ,'IND1' : 'STRING'
    ,'TIMESTAMP' : 'TIMESTAMP'
}

# COMMAND ----------

tresadr_schema={
'PROV_ID':'STRING',
'PROV_SUFF_CD':'STRING',
'PROV_LN1_ADDR_NM':'STRING',
'PROV_LN2_ADDR_NM':'STRING',
'PROV_ADDR_CITY_NM':'STRING',
'PROV_ADDR_ST_CD':'STRING',
'PROV_ADDR_ZIP_CD':'STRING',
'PROV_ADDR_PLUS_CD':'STRING',
'PROV_CNTY_FIPS_CD':'STRING',
'PROV_PRIM_IND':'STRING',
'PROV_12B_LAT_NBR':'INTEGER',
'PROV_34B_LAT_NBR':'INTEGER',
'PROV_13B_LONG_NBR':'INTEGER',
'PROV_45B_LONG_NBR':'INTEGER',
'PROV_LAT_DIR_IND':'STRING',
'PROV_LONG_DIR_IND':'STRING',
'PROV_VEND_NBR':'STRING',
'PROV_CTR_NBR':'STRING',
'PROV_CTR_SUFX_CD':'STRING',
'IND1' : 'STRING',
'TIMESTAMP' : 'TIMESTAMP'
}

# COMMAND ----------

tre2327_schema={
'PROV_NBR':'STRING'     
,'PROV_SUFX_CD':'STRING'
,'PROV_EXPL_KEY':'STRING'     
,'PROV_IMPL_KEY':'STRING'     
,'RE2327_PRVROL_TS':'TIMESTAMP'
,'EFF_DT':'INTEGER'  
,'INACT_DT':'INTEGER'  
,'PROD_SEQ_NBR':'DECIMAL'  
,'PCP_IND':'STRING'    
,'CAS_PROV_SPCL_CD':'STRING'     
,'HUM_CLM_PYMT_IND':'STRING'    
,'PROV_HOME_BASE_IND':'STRING'    
,'PLTFM_CD':'STRING'     
,'IND1':'STRING'
,'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2329_schema={
'PROV_NBR':'STRING'
,'PROV_SUFX_CD':'STRING'
,'PROV_EXPL_KEY':'STRING'
,'PROV_IMPL_KEY':'STRING' 
,'PROV_2_NBR':'STRING'
,'PROV_SUFX_2_CD':'STRING' 
,'RE_PROVID_IMPL_IND':'STRING'
,'PLTFM_CD':'STRING'
,'IND1' : 'STRING'
,'TIMESTAMP' : 'TIMESTAMP'
}

# COMMAND ----------

trerfcd_schema={
"IND1" : "STRING"
,"TIMESTAMP" : "TIMESTAMP"
,"VARIABLE_ID" : "STRING"
,"VARIABLE_CD" : "STRING"
,"VARIABLE_DESC" : "STRING"
,"REC_UPDT_ID" : "STRING"
,"REC_UPDT_DT" : "DATE"
}
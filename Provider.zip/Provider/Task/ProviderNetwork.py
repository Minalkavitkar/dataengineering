# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2327
# MAGIC - TRE2329
# MAGIC ##### Curated Tables
# MAGIC - Provider.ProviderNetwork
# MAGIC ##### Target Table
# MAGIC - Provider.ProviderNetwork

# COMMAND ----------

# DBTITLE 1,Run validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
tre2327_file_conf_key = 'PROVIDER_TRE2327'
tre2329_file_conf_key = 'PROVIDER_TRE2329'
not_null_col_lst = ['ProviderKey']
table_code = 'Provider_ProviderNetwork'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderNetwork')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Provider', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Provider', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderStageSchema 

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform/ 

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load                  

# COMMAND ----------

# DBTITLE 1,Import Functions
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]

    stage_tre2327_tbl_name = table_name_selector(tbl_conf_df, tre2327_file_conf_key)
    stage_tre2329_tbl_name = table_name_selector(tbl_conf_df, tre2329_file_conf_key)
    stage_tre2327_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_TRE2327_FULL")
    stage_tre2329_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_TRE2329_FULL")
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_cur_tbl_name = table_name_selector(tbl_conf_df, 'Provider_Provider')

    file_list = [
            [tre2327_file_conf_key, stage_tre2327_tbl_name, tre2327_schema, ['ProvNbr','ProvSufxCd','ProvExplKey','ProvImplKey','Re2327PrvrolTs']],
            [tre2329_file_conf_key, stage_tre2329_tbl_name, tre2329_schema, ['ProvNbr','ProvSufxCd','ProvExplKey','ProvImplKey']]
    ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
try:
    for key, tbl_name, schema, buz_keys in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]} 
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full="StageFull")
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Filtering Valid Records
try:
    tre2327_stage_df = read_table_to_df(stage_tre2327_tbl_name).filter(col('Status') == 'S')
    tre2329_stage_df = read_table_to_df(stage_tre2329_tbl_name).filter(col('Status') == 'S')
    provider_curated = prioritize_prv_type2Code(read_table_to_df(prov_cur_tbl_name))
    tre2327_stage_full_df = read_table_to_df(stage_tre2327_full_tbl_name)
    tre2329_stage_full_df = read_table_to_df(stage_tre2329_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition_tre2329 = (col('LH.ProvNbr')==col('RH.ProvNbr')) & \
                                    (col('LH.ProvSufxCd')==col('RH.ProvSufxCd')) & \
                                    (col('LH.ProvExplKey')==col('RH.ProvExplKey')) & \
                                    (col('LH.ProvImplKey')==col('RH.ProvImplKey'))

    joining_condition_tre2327  = (col('LH.ProvNbr')==col('RH.ProvNbr')) & \
                                    (col('LH.ProvSufxCd')==col('RH.ProvSufxCd')) & \
                                    (col('LH.ProvExplKey')==col('RH.ProvExplKey')) & \
                                    (col('LH.ProvImplKey')==col('RH.ProvImplKey')) & \
                                    (col('LH.Re2327PrvrolTs')==col('RH.Re2327PrvrolTs'))  

    if LOAD_TYPE == "FullLoad":
        tre2327_tre2329_df              = tre2327_stage_df.alias('LH')\
                                            .join(tre2329_stage_df.alias('RH'),joining_condition_tre2329,'left')\
                                            .select('LH.*','RH.ProvSufx2Cd','RH.ReProvidImplInd')

        tre2329_rejc_df                 = tre2329_stage_df.alias('LH')\
                                            .join(tre2327_stage_df.alias('RH'),joining_condition_tre2329,'left_anti')\
                                            .select('LH.StgUnqId','LH.Status','LH.RejectReason')

        update_rej_records(tre2329_rejc_df , "Child Not Found", stage_tre2329_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        tre2327_with_tre2329_df = tre2327_stage_df.alias('LH')\
                                            .join(tre2329_stage_full_df.alias('RH'),joining_condition_tre2329,'left')\
                                            .select('LH.*','RH.ProvSufx2Cd','RH.ReProvidImplInd')\
                                            .drop('ProdSeqNbr')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))
                
        tre2329_with_tre2327full_df = tre2329_stage_df.alias('LH')\
                                            .join(tre2327_stage_full_df.alias('RH'),joining_condition_tre2329,'inner')\
                                            .select('LH.*','RH.HumClmPymtInd','RH.PcpInd','RH.ProvHomeBaseInd','RH.CasProvSpclCd','RH.Re2327PrvrolTs','RH.InactDt','RH.EffDt')\
                                            .drop('Prov2Nbr')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))

        tre2329_rejected_df         = tre2329_stage_df.alias('LH')\
                                            .join(tre2327_stage_full_df.alias('RH'),joining_condition_tre2329,'left_anti')\
                                            .select('StgUnqId','Status','RejectReason')


        #this join is required to avoid the duplicate delta formation
        tre2329_with_tre2327_df = tre2329_with_tre2327full_df.alias('LH')\
                                            .join(tre2327_with_tre2329_df.alias('RH'),joining_condition_tre2327,'left_anti')\
                                            .drop('StgUnqId')

       
        #union all constructed dataframes
        tre2327_tre2329_df =  tre2327_with_tre2329_df.unionByName(tre2329_with_tre2327_df, allowMissingColumns=True)

        update_rej_records(tre2329_rejected_df, "Child Not Found", stage_tre2329_tbl_name)
        
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Column Mapping
column_mapping={
'ProvNbr':'ProviderNumber',
'ProvSufxCd':'SuffixCode',
'ProvExplKey':'NetworkId',
'ProvImplKey':'ProviderId',
'HumClmPymtInd':'HumanaClaimPaymentIndicator',
'PcpInd':'PCPIndicator',
'ProvHomeBaseInd':'ProviderHomeBaseIndicator',
'InactDt':'ProviderNetworkEndDate',
'EffDt':'ProviderNetworkStartDate',
'CasProvSpclCd':'ProviderSpecialtyCode',
'Re2327PrvrolTs':'Re2327PrvrolTs',
'ProvSufx2Cd':'ProviderSuffix2Code',
'ReProvidImplInd':'ProviderIdImplIndicator',
'StgUnqId':'StgUnqId',
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

try:
    col_mapped_df = col_name_mapping(tre2327_tre2329_df,column_mapping)
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Joining with provider table
#Joining with provider table to get ProviderKey
try:
    cond = (col('LH.ProviderNumber') == col('RH.ProviderId')) &\
       (col('LH.SuffixCode') == col('RH.SuffixCode'))
    joined_with_provider_df = col_mapped_df.alias('LH').join(provider_curated.alias('RH'), cond,'left').select('LH.*',col('RH.ProviderKey').alias('ProviderKey'))
    lpad_added_df = joined_with_provider_df.withColumn('ProviderNetworkEndDate', lpad(col('ProviderNetworkEndDate'), 6, '0'))\
                       .withColumn('ProviderNetworkStartDate', lpad(col('ProviderNetworkStartDate'), 6, '0'))
except Exception as e:
    raise Exception("joining failed",str(e))

# COMMAND ----------

# DBTITLE 1,Data Type Conversion
schema = {"ProviderIdImplIndicator" : "BOOLEAN"}

# COMMAND ----------

# DBTITLE 1,date format conversion and data type conversion 
#date format conversion and data type conversion and adding audit columns
try:
    lst = ['ProviderNetworkEndDate','ProviderNetworkStartDate']
    inp_dt_format = 'yyMMdd'
    df_datecnvrt = date_format_conversion(lpad_added_df, lst, inp_dt_format)

    df_datecnvrt_fltr = df_datecnvrt.filter(col('ProviderNetworkStartDate').isNotNull())

    dtype_chng_df = dtype_tgt_conversion(df_datecnvrt_fltr, schema)
    
except Exception as e:
    raise Exception("date format conversion or data type conversion failed",str(e))

# COMMAND ----------

# DBTITLE 1,Adding Audit Columns
col_maps = {
            'CreatedBy'         : lit(pipeline_name),
            'CreatedDateTime'   : col('Re2327PrvrolTs'),
            'ModifiedBy'        : lit(pipeline_name),
            'ModifiedDateTime'  : col('Re2327PrvrolTs')
            }
    
try:
    audit_col_added_df = dtype_chng_df.withColumns(col_maps).drop('Re2327PrvrolTs')
except Exception as e:
    raise Exception("aduit col updation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Filtering Valid Records
try:
    final_df = remove_invalid_records(audit_col_added_df, stage_tre2327_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalid records failed", str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        ProviderNetwork_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','ProviderNumber','SuffixCode')
        load_df_to_sf_sql_db_spark(ProviderNetwork_df, 'Provider.ProviderNetwork')
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['NetworkId','ProviderId','ModifiedDateTime','ProviderKey']

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderNetworkKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderNetworkKey':lit(None).cast("BIGINT"),
        'ProviderKey': lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)
        delta_df= set_df_columns_nullable(spark, set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','ModifiedDateTime']), ['ModifiedBy'])\
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Provider.StageProviderNetwork')
        
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREFPRV
# MAGIC ##### Curated Tables
# MAGIC - Provider.Provider
# MAGIC ##### Target Table
# MAGIC - Provider.Provider

# COMMAND ----------

# DBTITLE 1,Run validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_TREFPRV'
buz_keys = ['ProvId','AddrKey','ProvTy2Cd']
table_code = 'Provider_Provider'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider') 
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Provider', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Provider', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trefprv_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    trefprv_stage_df = read_table_to_df(stage_tbl_name)
    validated_df = trefprv_stage_df.filter(trefprv_stage_df["Status"] == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Curated added Column Schema
curated_added_col_schema={'SourceSystemCode': 'STRING',
                          'ProviderStartDate': 'DATE',
                          'ProviderEndDate': 'DATE'}

# COMMAND ----------

# DBTITLE 1,Column Mapping
#column mapping db2 to cloud columns
col_mapping = { 'ProvId': 'ProviderId',
 'AddrKey': 'SuffixCode',
 'ProvTyCd': 'TypeCode',
 'ProvTy2Cd': 'Type2Code',
 'ProvNm': 'ProviderName',
 'LicNbr': 'LicenseNumber',
 'IrsNbr': 'IRSNumber',
 'GrpNm': 'GroupName',
 'GrpInd': 'GroupIndicator',
 'ProvSpclCd': 'SpecialtyCode',
 'MultAddrInd': 'MultiAddressIndicator',
 'CasAddr1Nm': 'AddressLine1Text',
 'CasAddr2Nm': 'AddressLine2Text',
 'CasAddr3Nm': 'AddressLine3Text',
 'CasAddr4Nm': 'AddressLine4Text',
 'CasCityNm': 'CityName',
 'CasStNm': 'StateCode',
 'CasZipCd': 'ZipCode',
 'PhNbr': 'TelephoneNumber',
'ProvProfAreaCd': 'ProviderProfAreaCode',
 'PayInfoCd': 'PayInfoCode',
 'XrefNbr': 'CrossReferenceNumber',
 'CntyCd': 'CountyCode',
 'CreatedBy':'CreatedBy',
 'CreatedDateTime':'CreatedDateTime',
 'ModifiedBy':'ModifiedBy',
 'ModifiedDateTime':'ModifiedDateTime',
'SourceSystemCode':'SourceSystemCode',
'ProviderStartDate':'ProviderStartDate',
'ProviderEndDate':'ProviderEndDate',
"DerivedIndicator":"DerivedIndicator"
}

# COMMAND ----------

# DBTITLE 1,Data type conversion and adding audit columns
#data type converstion and adding audit columns
try:
    audit_col_added_df = add_tgt_audit_column(validated_df, pipeline_name, LOAD_TYPE)

    #changing date format from  MMddyy --> yyyy-MM-dd

    cnst_added_df = audit_col_added_df.withColumn('SourceSystemCode',lit('CAS'))\
        .withColumn('ProviderStartDate',lit('1990-01-01'))\
        .withColumn('ProviderEndDate',lit('9999-12-31'))

    dtype_converted_df = dtype_tgt_conversion(cnst_added_df, curated_added_col_schema)
    
    final_df = col_name_mapping(dtype_converted_df,col_mapping)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Load data into curated and Azure SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        
        df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(df, 'Provider.Provider')
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['ProviderId','SuffixCode','Type2Code']

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderKey")
        cur_loaded_time = datetime.now()
        
        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'ProviderKey':lit(None).cast("BIGINT"),
        'DeltaStatus':lit(None).cast("STRING")
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,set_df_columns_nullable(spark,mapped_df,['SourceSystemCode']),['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Provider.StageProvider')
        
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
except Exception as e:
    raise Exception ('load failed',str(e))
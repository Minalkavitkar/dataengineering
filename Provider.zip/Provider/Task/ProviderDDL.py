# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates Provider Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Provider{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderDiscount

# COMMAND ----------

provider_discount = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderDiscount(
  ProviderDiscountKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  ProviderKey BIGINT NOT NULL,
  ProviderDiscountId VARCHAR(50),
  ParticipatingCategoryCode VARCHAR(20),   
  PotCode VARCHAR(20),
  ProviderDiscountBeginDate DATE,
  ProviderDiscountEndDate DATE,
  ProviderClaimDiscountPercent Decimal(20,6),
  DiscountDeletedIndicator CHAR(1),
  CreatedBy STRING NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP,
  DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderDiscount'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GrouperCorrespondenceAddress

# COMMAND ----------

grouper_correspondence_address = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_GrouperCorrespondenceAddress(
GrouperCorrespondAddressKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) NOT NULL
,ProviderGrouperKey BIGINT NOT NULL
,ContractLegalId	VARCHAR(50)
,ContractLegalName	VARCHAR(55)
,ContractLegalDescription	VARCHAR(128)
,CorrespondenceAddressIndicator	CHAR(1)
,CorrespondenceAddressLine1Text	VARCHAR(30)
,CorrespondenceAddressLine2Text	VARCHAR(30)
,CorrespondenceCityName	VARCHAR(55)
,CorrespondenceName	VARCHAR(55)
,CorrespondenceStateCode	VARCHAR(20)
,CorrespondenceZipCode	VARCHAR(5)
,CorrespondenceZipPlusCode	VARCHAR(5)
,DelegatedServiceIndicator	CHAR(1)
,ProviderGrouperTypeCode	VARCHAR(20)
,CreatedBy STRING NOT NULL
,CreatedDateTime	TIMESTAMP NOT NULL
,ModifiedBy	STRING
,ModifiedDateTime	TIMESTAMP
,DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/GrouperCorrespondenceAddress'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouper

# COMMAND ----------

provider_grouper = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderGrouper(
ProviderGrouperKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) NOT NULL,
AddressLine1Text VARCHAR(30),
AddressLine2Text VARCHAR(30),
AlternatePCPGrouperIndicator CHAR(1),
BBSConnectionMethodCode VARCHAR(20),
BBSDirectoryName VARCHAR(30),
Bypass3gPendIndicator CHAR(1),
BypassAuthenEditIndicator CHAR(1),
BypassReferrallEditIndicator CHAR(1),
BypassReworkLimitAmount DECIMAL(20,6),
BypassSuspendPendIndicator CHAR(1),
CityName VARCHAR(55),
ClaimGrouperIndicator CHAR(1),
CompanyName VARCHAR(50),
DataFormatCode VARCHAR(20),
DataMediaTypeCode VARCHAR(20),
DefaultPayClaimCount INTEGER,
DelgatedSWCode VARCHAR(20),
DeliveryMethodDescription VARCHAR(128),
ELECContestCode VARCHAR(20),
ELECGrouperBalanceCode VARCHAR(20),
ELECGrouperHistIndicator VARCHAR(55),
ELECGrouperRequestIndicator CHAR(1),
ELECManualAdjustmentCode VARCHAR(20),
ELECQuarterlyIndicator CHAR(1),
ELECRE608Indicator CHAR(1),
ELECRE610Indicator CHAR(1),
ELECRE627Indicator CHAR(1),
ELECRE645Indicator CHAR(1),
ElecMbrCapCode VARCHAR(20),
ElecSpcCapCode VARCHAR(20),
FirstName VARCHAR(30),
IdCardAddressIndicator CHAR(1),
LastName VARCHAR(30),
LedgerNumber INTEGER,
MiddleInitial VARCHAR(30),
PaperGrouperIndicator CHAR(1),
PrimaryDataRateCode VARCHAR(20),
ProviderGrouperId VARCHAR(50),
ReelBlkFact INTEGER,
ReelCode VARCHAR(20), 
ReelFillIndicator CHAR(1),
SecondaryDataRateCode VARCHAR(20),
StateCode VARCHAR(20),
SuspendRejectClaimIndicator CHAR(1),
TelephoneExchangeNumber VARCHAR(20),
TelephoneNumber VARCHAR(20),
TypeCode VARCHAR(20),
UserHDWTypeCode VARCHAR(20),
ZipPlusCode VARCHAR(5),
ZipCode VARCHAR(5),
GrouperReportSequenceIndicator CHAR(1),
ReportControlId VARCHAR(55),
SELHistoryIndicator CHAR(1),
SuspendedCutOffDay SMALLINT,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderGrouper'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouperSuperior

# COMMAND ----------

provider_grouper_superior = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderGrouperSuperior(
  ProviderGrouperSuperiorKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  ProviderGrouperId VARCHAR(50),
  SuperiorId VARCHAR(50),
  DerivedIndicator STRING,
  CreatedBy STRING NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderGrouperSuperior'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouperVariable

# COMMAND ----------

provider_grouper_variable = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderGrouperVariable(
  ProviderGrouperVariableKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  ProviderGrouperId VARCHAR(50),
  TypeCode VARCHAR(50),
  VariableId VARCHAR(50),
  VariableCode VARCHAR(50),
  CreatedBy STRING NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP,
  DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderGrouperVariable'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - Provider

# COMMAND ----------

provider = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_Provider(
ProviderKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderId VARCHAR(50),
SuffixCode Varchar(20),
TypeCode Varchar(20),
Type2Code Varchar(20),
ProviderName Varchar(55),
LicenseNumber INTEGER,
IRSNumber INTEGER,
GroupName Varchar(55),
GroupIndicator Char(1),
SpecialtyCode Varchar(20),
MultiAddressIndicator char(1),
ProviderProfAreaCode VARCHAR(128),
AddressLine1Text VARCHAR (40) ,
AddressLine2Text VARCHAR (40) ,
AddressLine3Text VARCHAR (40) ,
AddressLine4Text VARCHAR (40) ,
CityName Varchar(55),
StateCode Varchar(20),
ZipCode VARCHAR(10),
TelephoneNumber Varchar(20),
PayInfoCode Varchar(20),
ProviderStartDate Date,
ProviderEndDate Date,
CrossReferenceNumber INTEGER,
CountyCode INTEGER,
SourceSystemCode Varchar(10),
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/Provider'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GeoMarket

# COMMAND ----------

geo_market = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_GeoMarket(
  GeoMarketKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,GeoMarketId Varchar(50)
  ,GeoMarketName Varchar(55)
  ,SourceSystemCode Varchar(10)
  ,StatusCode Varchar(20)
  ,GeoMarketStartDate DATE
  ,GeoMarketEndDate DATE
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/GeoMarket'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GeoMarketCycle

# COMMAND ----------

geo_market_cycle = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_GeoMarketCycle(
  GeoMarketCycleKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,GeoMarketKey BIGINT NOT NULL
  ,CycleNumber INTEGER
  ,DerivedIndicator STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/GeoMarketCycle'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouperAssociation

# COMMAND ----------

provider_grouper_association = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderGrouperAssociation(
  ProviderGrouperAssociationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,ProviderGrouperAssociateId	INTEGER
  ,ProviderGrouperId VARCHAR(50)
  ,AssociationTypeCode VARCHAR(20)
  ,AssociationStartDate DATE
  ,AssociationEndDate DATE
  ,DerivedIndicator STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderGrouperAssociation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - Payer

# COMMAND ----------

payer = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_Payer(
  PayerKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,PayerId	VARCHAR(50)
  ,PayerAddressSequenceNumber INTEGER
  ,ContactName	VARCHAR(55)
  ,CompanyName	VARCHAR(55)
  ,AddressLine1Text VARCHAR(30)
  ,AddressLine2Text VARCHAR(30)
  ,CityName VARCHAR(55)
  ,StateCode VARCHAR(20)
  ,ZipCode	VARCHAR(5)
  ,TelephoneNumber VARCHAR(20)
  ,RejectCode VARCHAR(20)
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/Payer'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - TradePartner

# COMMAND ----------

trade_partner = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_TradePartner(
  TradePartnerKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,TradePartnerId VARCHAR(50)
  ,TradePartnerName VARCHAR(55)
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/TraderPartner'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderVendor

# COMMAND ----------

provider_vendor = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderVendor
(
  ProviderVendorKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  ProviderKey BIGINT NOT NULL,
  NetworkTypeCode	VARCHAR(20),
  VendorNumber VARCHAR(50),
  VendorStartDate	DATE,
  VendorEndDate DATE,
  VendorTypeCode Varchar(20),
  CreatedBy STRING NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP,
  DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderVendor'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - PayerProviderGrouper

# COMMAND ----------

payer_provider_grouper = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_PayerProviderGrouper(
  PayerProviderGrouperKey	BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,PayerKey BIGINT NOT NULL
  ,TradePartnerKey	BIGINT NOT NULL
  ,ProviderGrouperId VARCHAR(50)
  ,CompanyName VARCHAR(50)
  ,PayerProviderGrouperEndDate	DATE
  ,PayerProviderGrouperStartDate DATE
  ,DerivedIndicator STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/PayerProviderGrouper'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderServiceAddress

# COMMAND ----------

provider_service_address = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderServiceAddress 
    (
     ProviderServiceAddressKey BIGINT GENERATED ALWAYS AS IDENTITY NOT NULL, 
     ProviderKey BIGINT NOT NULL , 
     AddressLine1Text STRING , 
     AddressLine2Text STRING , 
     CityName STRING , 
     StateCode STRING , 
     --StateCodeLabel STRING , 
     ZipCode STRING , 
     ZipPlusCode STRING , 
     CountyFIPSCode STRING , 
     12BLatitudeNumber INTEGER , 
     34BLatitudeNumber INTEGER , 
     13BLongitudeNumber INTEGER , 
     45BLongitudeNumber INTEGER , 
     LatitudeDirectionIndicator STRING , 
     LongitudeDirectionIndicator STRING , 
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING, 
     ModifiedDateTime TIMESTAMP,
     DerivedIndicator STRING
    )"""
  
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderServiceAddress'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderNetwork

# COMMAND ----------

provider_network = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_ProviderNetwork 
    (
     ProviderNetworkKey BIGINT GENERATED ALWAYS AS IDENTITY NOT NULL
     ,ProviderNumber STRING
     ,SuffixCode STRING
     ,ProviderKey BIGINT NOT NULL
     ,NetworkId VARCHAR(50)
     ,ProviderId VARCHAR(50)
     ,ProviderNetworkEndDate DATE
     ,ProviderNetworkStartDate DATE
     ,PCPIndicator CHAR(1)
     ,ProviderHomeBaseIndicator CHAR(1)
     ,HumanaClaimPaymentIndicator CHAR(1)
     ,ProviderSpecialtyCode VARCHAR(20)
     ,ProviderSuffix2Code VARCHAR(20)
     ,ProviderIdImplIndicator BOOLEAN
     ,DerivedIndicator STRING
     ,CreatedBy STRING NOT NULL
     ,CreatedDateTime TIMESTAMP NOT NULL
     ,ModifiedBy STRING
     ,ModifiedDateTime TIMESTAMP NOT NULL
    )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/ProviderNetwork'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - VariableDetail

# COMMAND ----------

variable_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.provider_VariableDetail 
(
  VariableDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
  ,VariableID VARCHAR(50)
  ,VariableCode VARCHAR(20)
  ,VariableDescription VARCHAR(128)
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/provider/curated/VariableDetail'"""

# COMMAND ----------

tbl_mapping = {
"provider_ProviderDiscount" : provider_discount,
"provider_GrouperCorrespondenceAddress" : grouper_correspondence_address,
"provider_ProviderGrouper" : provider_grouper,
"provider_ProviderGrouperSuperior" : provider_grouper_superior,
"provider_ProviderGrouperVariable" : provider_grouper_variable,
"provider_Provider" : provider,
"provider_GeoMarket" : geo_market,
"provider_GeoMarketCycle" : geo_market_cycle,
"provider_ProviderGrouperAssociation" : provider_grouper_association,
"provider_Payer" : payer,
"provider_TradePartner" : trade_partner,
"provider_ProviderVendor" : provider_vendor,
"provider_PayerProviderGrouper" : payer_provider_grouper,
"provider_ProviderServiceAddress" : provider_service_address,
"provider_ProviderNetwork" : provider_network,
"provider_VariableDetail" : variable_detail
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
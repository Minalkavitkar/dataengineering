# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREPRVD
# MAGIC ##### Curated Tables
# MAGIC - Provider.ProviderVendor
# MAGIC ##### Target Table
# MAGIC - Provider.ProviderVendor

# COMMAND ----------

# DBTITLE 1,Run validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_TREPRVD'
buz_keys = ['ProvNbr', 'ProvSufxCd']
not_null_col_lst = ['ProviderKey']
table_code = 'Provider_ProviderVendor'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_ProviderVendor')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Provider', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Provider', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_tbl_name = table_name_selector(tbl_conf_df, 'Provider_Provider')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treprvd_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    treprvd_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & applying transformation logic for Type2Code 
#Reading data from stage table & applying transformation logic for Type2Code 
try:
    prv_df = read_table_to_df(prov_tbl_name)\
    .select('ProviderKey','ProviderId', 'SuffixCode', 'Type2Code')
    prv_trans_df = prioritize_prv_type2Code(prv_df)
except Exception as e:
    raise Exception("Transformation logic failed",str(e))

# COMMAND ----------

# DBTITLE 1,column mapping 
#column mapping db2 to cloud columns
col_mapping = {
    'NtwkTyCd' : 'NetworkTypeCode'
    ,'ApVendNbr' : 'VendorNumber'
    ,'VendBegDt' : 'VendorStartDate'
    ,'ApVendInd' : 'VendorTypeCode'
    ,'ProvNbr' : 'ProviderId'
    ,'ProvSufxCd' : 'SuffixCode'
    ,'StgUnqId':'StgUnqId'
    ,"RunId":"RunId"
    ,"DerivedIndicator":"DerivedIndicator"
    ,"Status":"Status"
    ,"RejectReason":"RejectReason"
    }

# COMMAND ----------

# DBTITLE 1, joining with provider and data type conversion and adding audit columns
#column mapping and joining with provider and data type conversion and adding audit columns
try:
    col_mapped_df = col_name_mapping(treprvd_stage_df, col_mapping)
    joined_df = col_mapped_df\
     .join(prv_trans_df, ['ProviderId', 'SuffixCode'], 'left').drop('Type2Code')
    dt_trans_df = date_format_conversion(joined_df, ['VendorStartDate'], 'MMddyy')\
                    .withColumn('VendorEndDate', to_date(lit('12-31-9999'), 'MM-dd-yyyy'))
    col_added_df = add_tgt_audit_column(dt_trans_df, PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('joining or data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
try:
    final_stage_df = remove_invalid_records(col_added_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderId','SuffixCode')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        provider_vendor_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(provider_vendor_df, 'Provider.ProviderVendor')
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['VendorNumber']

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderVendorKey")   
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderVendorKey' : lit(None).cast('BIGINT'),
        'ProviderKey' : lit(None).cast('BIGINT')
        }
        mapped_df= final_stage_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime',])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Provider.StageProviderVendor')
        
        exit_notebook(run_id, "Provider", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name) 
except Exception as e:
    raise Exception ('load failed',str(e))

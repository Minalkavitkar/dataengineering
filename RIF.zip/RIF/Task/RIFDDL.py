# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates RIF Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Adls connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transformation functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Rif{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name


# COMMAND ----------

# MAGIC %md
# MAGIC ### RIF

# COMMAND ----------

RIF = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.rif_RIF(
RIFKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
AffiliationCode VARCHAR(20),
RIFId VARCHAR(50),
RIFDescription VARCHAR(128),
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/rif/curated/RIF'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIFSchedule

# COMMAND ----------

RIF_Schedule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.rif_RIFSchedule(
RIFScheduleKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
RIFKey BIGINT not null,
ScheduleLedgerNumber VARCHAR(50),
SchedulePlanNumber VARCHAR(50),
ScheduleOPTNumber VARCHAR(50),
RIFId VARCHAR(50),
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/rif/curated/RIFSchedule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIFScheduleDate

# COMMAND ----------

RIF_Schedule_Date = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.rif_RIFScheduleDate(
RIFScheduleDateKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) NOT NULL,
RIFScheduleKey BIGINT NOT NULL,
RIFScheduleRiderEndDate DATE,
RIFScheduleRiderStartDate DATE,
ScheduleLedgerNumber VARCHAR(50),
SchedulePlanNumber VARCHAR(50),
ScheduleOPTNumber VARCHAR(50),
RIFId VARCHAR(50),
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/rif/curated/RIFScheduleDate'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIFRiderDetail

# COMMAND ----------

RIF_RiderDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.rif_RIFRiderDetail(
RIFRiderDetailKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) NOT NULL,
RIFScheduleDateKey BIGINT NOT NULL,
RiderCode VARCHAR(20),
RiderPlanNumber VARCHAR(50),
RiderOPTNumber VARCHAR(50),
BeginAgeNumber INTEGER,
EndAgeNumber INTEGER,
CustomerNumber VARCHAR(50),
GroupNumber VARCHAR(50),
StateCode VARCHAR(20),
CountyCode VARCHAR(20),
GenderCode VARCHAR(20),
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING,
RIFScheduleRiderStartDate DATE,
ScheduleLedgerNumber VARCHAR(50),
SchedulePlanNumber VARCHAR(50),
ScheduleOPTNumber VARCHAR(50),
RIFId VARCHAR(50)
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/rif/curated/RIFRiderDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIFProviderContract

# COMMAND ----------

RIF_ProviderContract = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.rif_RIFProviderContract(
RIFProviderContractKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
RIFKey BIGINT not null,
ProviderContractKey BIGINT not null,
RIFContractStartDate DATE,
RIFContractEndDate DATE,
CreatedBy VARCHAR(150) not null,
CreatedDateTime TIMESTAMP not null,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING,
RIFId VARCHAR(50),
ProviderContractId VARCHAR(50)
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/rif/curated/RIFProviderContract'"""

# COMMAND ----------

tbl_mapping = {
"rif_RIF" : RIF,
"rif_RIFSchedule" : RIF_Schedule,
"rif_RIFScheduleDate": RIF_Schedule_Date,
"rif_RIFProviderContract": RIF_ProviderContract,
"rif_RIFRiderDetail":RIF_RiderDetail
}


# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
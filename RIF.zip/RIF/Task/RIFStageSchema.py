# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,  
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "rif/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|",
            "multiline":"true"
        },
        "SourceFileFormat" : "csv"
    },
    "RIF_TRERIF":{
        "FileRegex" : "RIF_TRERIF.TXT",
        "StagePathSuffix" : "rif/stage/StageTRERIF"
    },
    "RIF_TRERSCH":{
        "FileRegex" : "RIF_TRERSCH.TXT",
        "StagePathSuffix" : "rif/stage/StageTRERSCH"
    },
    "RIF_TRERFCT":{
        "FileRegex" : "RIF_TRERFCT.TXT",
        "StagePathSuffix" : "rif/stage/StageTRERFCT"
    },
    "RIF_TRERFEF":{
        "FileRegex" : "RIF_TRERFEF.TXT",
        "StagePathSuffix" : "rif/stage/StageTRERFEF"
    },
    "RIF_TRERDTL":{
        "FileRegex" : "RIF_TRERDTL.TXT",
        "StagePathSuffix" : "rif/stage/StageTRERDTL"
    }
   
   
   
}


# COMMAND ----------

trerif_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'AFFIL_TY_CD':'STRING',
'AFFIL_GEN_KEY':'INTEGER',
'RIF_TBL_ID':'STRING',  
'RIF_DESC':'STRING',    
'REC_UPDT_DATE':'DATE',  
'REC_UPDT_ID':'STRING', 
'REC_UPDT_FAC_ID':'STRING'
}

# COMMAND ----------

trersch_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'AFFIL_GEN_KEY':'INTEGER',
'SCH_GEN_KEY':'INTEGER',
'SCH_LEDGER_NBR':'STRING',
'SCH_PLAN_NBR':'STRING',
'SCH_OPT_NBR':'STRING'  
} 


# COMMAND ----------

trerfef_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'SCH_GEN_KEY':'INTEGER',
'EFF_GEN_KEY':'INTEGER',
'EFF_DATE':'DATE', 
'END_DATE':'DATE'
}   

# COMMAND ----------

trerfct_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'AFFIL_TY_CD':'STRING',
'AFFIL_GEN_KEY':'INTEGER',
'CTRCT_KEY':'STRING'
} 

# COMMAND ----------

trerdtl_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'EFF_GEN_KEY':'INTEGER',
'DTL_GEN_KEY':'INTEGER',      
'DTL_RIDER_CD':'STRING',      
'DTL_RIDER_PLAN_NBR':'STRING',
'DTL_RIDER_OPT_NBR':'STRING',
'DTL_BEGIN_AGE':'DECIMAL(3,0)',    
'DTL_END_AGE':'DECIMAL(3,0)',   
'DTL_GENDER_CD':'STRING',  
'DTL_CUST_ID':'STRING',      
'DTL_GRP_NBR':'STRING',     
'DTL_STATE_CD':'STRING',    
'DTL_CNTY_CD':'STRING'    
}  
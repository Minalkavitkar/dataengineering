# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRERSCH
# MAGIC ##### Curated Tables
# MAGIC - RIF.RIFSchedule
# MAGIC ##### Target Table
# MAGIC - RIF.RIFSchedule

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "RIF_TRERSCH"
buz_keys = ['SchGenKey']
not_null_col_lst = ['RIFKey']
table_code = "RIF_RIFSchedule" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Rif')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('RIF', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'RIF', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./RIFStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    rif_tbl_name = table_name_selector(tbl_conf_df,'RIF_RIF')
    stage_trerif_full_tbl_name = table_name_selector(tbl_conf_df, "RIF_TRERIF_FULL")
    stage_trersch_full_tbl_name = table_name_selector(tbl_conf_df, "RIF_TRERSCH_FULL")
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trersch_schema, buz_keys,stage_full="StageFull")
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    trersch_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    rif_name_df = read_table_to_df(rif_tbl_name).select('RIFId','RIFKey')
    trerif_stage_full_df = read_table_to_df(stage_trerif_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,Replace Null
col_map = {
    'SchOptNbr': when(col('SchOptNbr').isNull(),lit("   "))
                        .otherwise(col('SchOptNbr'))}
            
null_removed_df = trersch_stage_df.withColumns(col_map)

# updating full table without nulls
spark.sql(f"update {stage_trersch_full_tbl_name} set SchOptNbr ='   ' where SchOptNbr is null")

# COMMAND ----------

# DBTITLE 1,Join with RIF Stage Full to get AffailGenKey. 
# RIFId

try:
    trerif_keys_added_df = null_removed_df.alias('LH')\
        .join(trerif_stage_full_df.alias('RH'),\
            (col('LH.AffilGenKey')== col('RH.AffilGenKey')),\
                'left')\
        .select('LH.*','RH.RifTblId')
except Exception as e:
    raise Exception('joining with RIF failed: ',str(e)) 

# COMMAND ----------

# DBTITLE 1,Joining with RIF table
#joining trersch_stage_df with RIF to get RIFKey
try:
    joined_df=trerif_keys_added_df.alias('LH').join(rif_name_df.alias('RH'),\
                            (col('LH.RifTblId') == col('RH.RIFId')),'left')\
                            .select('LH.*', 'RH.RIFKey')
except Exception as e:
    raise Exception('joining failed',str(e))

# COMMAND ----------

# DBTITLE 1,column mapping 
#column mapping with domain tables
col_mapping = {
'RifTblId':'RIFId',
'RIFKey':'RIFKey',
'SchLedgerNbr':'ScheduleLedgerNumber',
'SchOptNbr':'ScheduleOPTNumber',
'SchPlanNbr':'SchedulePlanNumber',
'StgUnqId':'StgUnqId',
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,adding audit columns
try:
    audit_col_added_df = add_tgt_audit_column(col_name_mapping(joined_df,col_mapping), PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
try:
    final_df = remove_invalid_records(audit_col_added_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./RIFDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        RIF_Schedule_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','RIFId')
        load_df_to_sf_sql_db_spark(RIF_Schedule_df, 'RIF.RIFSchedule')
        exit_notebook(run_id, "RIF", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
    elif LOAD_TYPE == 'DeltaLoad':
        conditions =['RIFId', 'ScheduleLedgerNumber', 'SchedulePlanNumber', 'ScheduleOPTNumber']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"RIFScheduleKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'RIFScheduleKey': lit(None).cast("BIGINT"),
        'RIFKey' : lit(None).cast('BIGINT'),
        'DeltaStatus': lit(None).cast('STRING')
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'RIF.StageRIFSchedule')
        
        exit_notebook(run_id, "RIF", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
        raise Exception ('load failed: ',str(e))

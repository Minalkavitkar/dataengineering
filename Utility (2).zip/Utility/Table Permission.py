# Databricks notebook source
# DBTITLE 1,Read the environmental variables
# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Get catalog and schema name
main_catalog_name = databricks_catalog_name
stage_catalog_name = databricks_stage_catalog_name
schema_name      = databricks_schema_suf
write_role = write_owner_role
read_role = read_owner_role

# COMMAND ----------

# DBTITLE 1,Get all curated tables in main catalog
curated_tables= [
    f"{main_catalog_name}.{schema_name}.{row['tableName']}"
    for db_rows in[spark.sql(f'show tables in {main_catalog_name}.{schema_name}').collect()]
    for row in db_rows
]

# COMMAND ----------

# DBTITLE 1,Get all stage tables in staging catalog
staging_tables= [
    f"{stage_catalog_name}.{schema_name}.{row['tableName']}"
    for db_rows in[spark.sql(f'show tables in {stage_catalog_name}.{schema_name}').collect()]
    for row in db_rows
]

# COMMAND ----------

# DBTITLE 1,Assign owner and grant permission on curated tables.
for i in curated_tables:
    try:
        spark.sql(f"ALTER table {i} owner to {write_role}".format(i))
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {i} TO {write_role}".format(i))
        spark.sql(f"GRANT SELECT ON TABLE {i} TO {read_role}".format(i))
    except Exception as e:
        print("Permission denied on changing ownership or granting permission")

# COMMAND ----------

# DBTITLE 1,Assign owner and grant permission on staging tables.
for i in staging_tables:
    try:
        spark.sql(f"ALTER table {i} owner to {write_role}".format(i))
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {i} TO {write_role}".format(i))
        spark.sql(f"GRANT SELECT ON TABLE {i} TO {read_role}".format(i))
    except Exception as e:
        print("Permission denied on changing ownership or granting permission")
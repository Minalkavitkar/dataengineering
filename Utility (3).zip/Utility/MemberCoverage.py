# Databricks notebook source
from pyspark.sql.functions import input_file_name, current_date, current_timestamp, lit, col, row_number, lpad, sha1, concat_ws, concat, when, rank, dense_rank, count, coalesce,lag, lead
from delta.tables import DeltaTable
from pyspark.sql.window import Window
from datetime import datetime
import uuid
import json
import re

# COMMAND ----------

# DBTITLE 1,data_type_conversion
def data_type_conversion(df, schema):
    try:   
        '''
        Description:
        This function is used to convert the data type of each column.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
        :param schema: [Type: dictionary] contains column name as key and column value as data type.
        :param df: [Type: pyspark.sql.dataframe.Dataframe]converted data type dataframe
        '''
        lst = []
        for col_name, dtype in schema.items():
            alias_name = col_name.replace("_", " ").title().replace(" ", "")
            if dtype.lower() == 'date':
                lst.append(f"CAST(to_date({col_name}, 'yyyyMMdd') AS {dtype}) AS {alias_name}")
            else:
                lst.append(f"CAST({col_name} AS {dtype}) AS {alias_name}")

        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("JobFailed dtype_conversion: ", str(e))

# COMMAND ----------

# DBTITLE 1,identify_duplicates_records_on_buz_keys
def identify_duplicates_records_on_buz_keys(df, buz_keys):
    '''
    Description:
    This function is used to identify duplicate records based on business key and create seperate dataframe for duplicates records..
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param buz_keys: [Type: list].
    :returns dup_df, cleansed_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        dup_buz_key_df = df.groupBy(*buz_keys).count()
        joined_df = df.join(dup_buz_key_df, buz_keys)

        dup_df = joined_df.filter(col('count') > 1).drop('count')
        cleansed_df = joined_df.filter(col('count') == 1).drop('count')
        return dup_df, cleansed_df
    except Exception as e:
        raise Exception("identify_duplicates_records_on_buz_keys failed:" + str(e))

# COMMAND ----------

# DBTITLE 1,switchable_gh_ci_conversion
def switchable_gh_ci_conversion(source_df, cust_df, conv_type = 'GH_to_CI'):
    try:
        if conv_type == 'GH_to_CI':
            condition = ((col('SRC.GHGroupIdentifier') == col('TGT.GHGroupIdentifier')) 
                        & (col('SRC.EmployerGroupNumber') == col('TGT.EmployerGroupNumber')))            
            col_map = {
                "IsCustomerFound" : when((col('TGT.GHGroupIdentifier').isNull()) 
                                        & (col('TGT.EmployerGroupNumber').isNull()), lit('N'))\
                                        .otherwise(lit('Y'))
            }
            select_lst = ["SRC.*","TGT.CIGroupIdentifier", "TGT.BenefitSequence", "TGT.CIClassNumber", "IsCustomerFound"]
            


        elif conv_type == 'CI_to_GH':
            condition = ((col('SRC.CIGroupIdentifier') == col('TGT.CIGroupIdentifier')) 
                        & (col('SRC.BenefitSequence') == col('TGT.BenefitSequence'))
                        & (col('SRC.CIClassNumber') == col('TGT.CIClassNumber')))
            
            col_map = {
                "IsCustomerFound" : when((col('TGT.CIGroupIdentifier').isNull()) 
                                        & (col('TGT.BenefitSequence').isNull())
                                        & (col('TGT.CIClassNumber').isNull()), lit('N'))\
                                        .otherwise(lit('Y'))
            }

            select_lst = ["SRC.*","TGT.GHGroupIdentifier", "TGT.EmployerGroupNumber", "IsCustomerFound"]

        else:
            raise Exception("Invalid Conversion Type")

        joined_df = source_df.alias('SRC')\
                    .join(cust_df.alias('TGT'), condition, 'left')\
                    .withColumns(col_map)\
                    .selectExpr(*select_lst)
        
        return joined_df

    except Exception as e:
        execp = str(e)
        raise Exception("switchable_gh_ci_conversion failed: ", execp)



# COMMAND ----------

# DBTITLE 1,add_comment_error_cols_to_df
def add_comment_error_cols_to_df(df, comment, error_code):
    '''
        Description:
        This function is used to add comment and error code column to dataframe.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param comment: [Type: String].
        :param error_code: [Type: String].
    '''
    try:
        cols_dict = {
                "Comment" :lit(comment),
                "ErrorCode" : lit(error_code),
                "IsRejected" : lit('Y')
            }
        
        return df.withColumns(cols_dict)
    except Exception as e:
        raise Exception("add_comment_error_cols_to_df failed:", str(e))

# COMMAND ----------

# DBTITLE 1,union_by_name, are_all_elements_preset, create_sql_tbl_name_from_dbk_stage_tbl_name
def union_by_name(dfs):
    '''
        Description:
        This function is used to union by name multiple dataframe.
        :param dfs: [Type: list].
    '''
    try:
        if len(dfs) == 0:
            raise Exception("Input list is empty. Please check!")
        elif len(dfs) > 1:
            return dfs[0].unionByName(union_by_name(dfs[1:]), allowMissingColumns=True)
        else:
            return dfs[0]
    except Exception as e:
        raise Exception("union_by_name failed:", str(e))
    
def are_all_elements_preset(list_to_check, reference_list):
    return all(element in reference_list for element in list_to_check)

def create_sql_tbl_name_from_dbk_stage_tbl_name(dbk_stage_table_name):
    return re.sub(r'(_[sS]tage)', '.', dbk_stage_table_name.split('.')[2])

# COMMAND ----------

# DBTITLE 1,identify_customer_product_split_records
def identify_customer_product_split_records(df):
    '''
        Description:
        This function is used to identify and split records that undergo customer product split and do not required customer product split.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :return cust_split_df: [Type: pyspark.sql.dataframe.Dataframe] Contains records where customer product split required.
        :return split_not_req_df: [Type: pyspark.sql.dataframe.Dataframe] Contains records where customer product split not required.
    '''
    
    try:
        cols = ["MemberCustomerNumber", "MemberGroupNumber","CIClassNumber","MemberKey", "CoverageStartDate"]
        count_calc_df = df.groupBy(*cols)\
                        .agg(countDistinct('ProductKey').alias('count')).filter(col('count') > 1)

        #Group the dataframe by customer and member_key, and count the number of products and filter the records where the product_count is greater than 1.
        grouped_df = df.join(count_calc_df, cols, 'left')

        cust_split_df = grouped_df.filter(col('count').isNotNull())
        split_not_req_df = grouped_df.filter(col('count').isNull())

        return cust_split_df, split_not_req_df
    except Exception as e:
        raise Exception("identify_customer_product_split_records failed:", str(e))

# COMMAND ----------

# DBTITLE 1,split_member_coverage_by_customer_product
def split_member_coverage_by_customer_product(df):
    try:
        # Columns required for the customer product split process.
        req_cols = ['MemberKey', 'MemberCustomerNumber', 'MemberGroupNumber', 'CIClassNumber', 'ProductKey', 'ExtProdSeqNo', 'CoverageStartDate', 'CoverageEndDate', 'CustomerProductStartDate', 'CustomerProductEndDate', 'DerivedIndicator']
        
        # Check all required columns are present in input df.
        if are_all_elements_preset(req_cols, df.columns):
            
            # Split customer product split required and not required df.
            cust_prd_split_df, split_not_req_df = identify_customer_product_split_records(df)
            
            #Join the original dataframe with the filtered dataframe on customer and member_key
            joined_df = cust_prd_split_df\
                        .selectExpr("*"
                                    ,"rank() over(partition by MemberCustomerNumber, MemberGroupNumber, CIClassNumber, MemberKey order by CustomerProductStartDate asc) AS AscRank"
                                    ,"rank() over(partition by MemberCustomerNumber, MemberGroupNumber, CIClassNumber, MemberKey order by CustomerProductStartDate desc) AS DescRank")
            # Add DerivedCoverageStartDate, DerivedCoverageEndDate and CalcDerivedIndicator columns.
            derived_coverage_dates_df = joined_df\
                        .selectExpr("*"
                                    ,"CASE WHEN AscRank > 1 THEN CustomerProductStartDate ELSE CoverageStartDate END AS DerivedCoverageStartDate"
                                    ,"CASE WHEN DescRank = 1 THEN CoverageEndDate ELSE CustomerProductEndDate END AS DerivedCoverageEndDate"
                                    ,"CASE WHEN AscRank = 1 THEN DerivedIndicator ELSE 'INSERT' END AS CalcDerivedIndicator")\
                        .drop("DescRank", "CoverageStartDate","CoverageEndDate", "DerivedIndicator")\
                        .withColumnRenamed("DerivedCoverageStartDate","CoverageStartDate")\
                        .withColumnRenamed("DerivedCoverageEndDate","CoverageEndDate")\
                        .withColumnRenamed("CalcDerivedIndicator","DerivedIndicator")

            # Union df ad remove unwanted columns.                
            cust_prd_splitted_df = derived_coverage_dates_df.unionByName(split_not_req_df.drop_duplicates(), allowMissingColumns = True)\
                        .withColumn('MemberCoverageKey', when(col('DerivedIndicator') == 'UPDATE', col('MemberCoverageKey'))\
                                                        .otherwise(lit(None)))\
                        .withColumn('ProviderContractKey', when(col('DerivedIndicator') == 'UPDATE', col('ProviderContractKey'))\
                                                        .otherwise(lit(None)))\
                        .drop('CustomerProductStartDate', 'CustomerProductEndDate', 'count', 'AscRank', 'ProductCategoryCode', 'IsNewCoverage')
            
            return cust_prd_splitted_df
        else:
            raise Exception(f"To use this function all mandatory columns({req_cols}) are required, but some of them are missing. Please check!")
    except Exception as e:
        raise Exception("split_member_coverage_by_customer_product failed:", str(e))

# COMMAND ----------

# DBTITLE 1,validate_providercontract
def validate_providercontract(input_df, pc_df, pcpa_df, psaff_df, psass_df):
    
    # 1.Filter out records where ProviderContractKey from input_df is NULL(Provider Key cannot be null for the records with Derived Indicator with UPDATE).
    pc_key_null_df = input_df.filter(col('ProviderContractKey').isNull())\
                        .selectExpr("*","'ProviderContract Key is not Available in Input' AS Comment", "'E14' AS ErrorCode")
    
    input_df = input_df.filter(col('ProviderContractKey').isNotNull())

    
    # 2.Join PC & input_df on ProviderContractKey.
    inp_pc_join_df = input_df.alias('inp').join(pc_df.alias('pc'), (col('inp.ProviderContractKey') == col('pc.ProviderContractKey_pc')), 'left')\
                                .select("inp.*", "pc.ContractStartDate", "pc.ContractEndDate")

    pc_valid_df = inp_pc_join_df.alias('INP')\
                .join(pcpa_df.alias('PCPA'), col('INP.ProviderContractKey') == col('PCPA.ProviderContractKey'), 'inner')\
                .join(psaff_df.alias('PSAFF'),col('PCPA.ProductAffiliationKey') == col('PSAFF.ProductAffiliationKey') ,'inner')\
                .join(psass_df.alias('PSASS'), (col('PSAFF.ProductSetKey') == col('PSASS.ProductSetKey')) & (col('INP.ProductKey') == col('PSASS.ProductKey')), 'inner')\
                .selectExpr("INP.*").drop_duplicates()
    
    inp_pc_lkp_join_condition = ((col('inp.ProductKey') == col('lkp.ProductKey')) 
                                & (col('inp.ProviderContractKey') == col('lkp.ProviderContractKey')))
    # 3.Filter out records where ProductKey, ProviderContractKey combination in input_df is not present in Affiliation & Association tables
    pc_rejected_df = inp_pc_join_df.alias('inp')\
                        .join(pc_valid_df.alias('lkp'), inp_pc_lkp_join_condition, 'leftAnti')\
                        .selectExpr('*', "'Contract does not have the Member Product' AS Comment", "'E11' AS ErrorCode")

     # 4.Filter out records where date condition is not met and combine all error msg columns into one reject_reason columns & add reject_flag
    date_condition = (((col('ContractStartDate') <= col('CoverageStartDate')) 
                        & (col('ContractEndDate') >= col('CoverageEndDate'))))
    
    date_rejected_df = pc_valid_df.filter(~date_condition)\
                                .selectExpr("*"
                                    ,"'Coverage Start & End Dates do not lie within the Contract Start and End dates' AS Comment"
                                    ,"'E15' AS ErrorCode")

    valid_df = pc_valid_df.filter(date_condition).drop("ContractStartDate", "ContractEndDate")
    # 5. Append all the rejected rejected into a single dataframe
    rejected_df = union_by_name([pc_key_null_df,pc_rejected_df, date_rejected_df])
    
    return valid_df, rejected_df

# COMMAND ----------

# DBTITLE 1,assign_providercontract
def assign_providercontract(input_df, pc_df, pcpa_df, psaff_df, psass_df, pc_table_name):

    # 1.Filter out records where ProviderKey from input_df is NULL
    prv_not_found_df = input_df.filter(col('ProviderKey').isNull())\
                        .select('*', lit('Provider Key is not available in input').alias('Comment'),  lit('E9').alias('ErrorCode'))

    input_df = input_df.filter(col('ProviderKey').isNotNull()).drop('ProviderContractKey')


    # 2. join with contract and check contract is available or not.
    inp_pc_join_condition = ((col('pc.ProviderKey_pc') == col('inp.ProviderKey')) 
                             & (col('inp.CoverageStartDate') <= col('pc.ContractEndDate'))  
                             & (col('inp.CoverageEndDate') >= col('pc.ContractStartDate')))
    
    ctrt_joined_df = input_df.alias('inp')\
                    .join(pc_df.alias('pc'),inp_pc_join_condition, 'left')\
                    .select('inp.*', 'pc.ProviderContractKey_pc', 'pc.ContractStartDate', 'pc.ContractEndDate', 'pc.ProviderSequenceNumber')

    # Split transaction for contract found and contract not found
    ctrt_found_df = ctrt_joined_df.filter(col('ProviderContractKey_pc').isNotNull())
    ctrt_not_fount_df = ctrt_joined_df.filter(col('ProviderContractKey_pc').isNull())\
                        .select('*', lit(f'ProviderContract not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(pc_table_name)}').alias('Comment'),  lit('E10').alias('ErrorCode'))

    # Join ProviderContractProductAffiliation, ProductSetAffiliation and ProductSetAssociation to identify active contract and product.
    pc_pcpa_join_condition = (col('pcpa.ProviderContractKey') == col('ctrt.ProviderContractKey_pc'))

    pcpa_psaff_join_condition = (col('pcpa.ProductAffiliationKey') == col('psaff.ProductAffiliationKey'))

    inp_psaff_psass_join_condition = ((col('psass.ProductSetKey') == col('psaff.ProductSetKey')) 
                                      & (col('ctrt.ProductKey') == col('psass.ProductKey')))
    
    view_df = ctrt_found_df.alias('ctrt')\
                .join(pcpa_df.alias('pcpa'), pc_pcpa_join_condition, 'inner')\
                .join(psaff_df.alias('psaff'), pcpa_psaff_join_condition, 'inner')\
                .join(psass_df.alias('psass'), inp_psaff_psass_join_condition, 'inner')\
                .selectExpr('ctrt.*', "lag(ctrt.ContractEndDate,1) OVER(PARTITION BY ctrt.MemberCustomerNumber, ctrt.MemberGroupNumber,ctrt.CIClassNumber, ctrt.MemberKey, ctrt.ProductKey, ctrt.ProviderKey, ctrt.CoverageStartDate ORDER BY ctrt.ContractStartDate, ctrt.ProviderSequenceNumber) AS LagCtrtEndDate", "lag(ctrt.ContractStartDate,1) OVER(PARTITION BY ctrt.MemberCustomerNumber, ctrt.MemberGroupNumber,ctrt.CIClassNumber, ctrt.MemberKey, ctrt.ProductKey, ctrt.ProviderKey, ctrt.CoverageStartDate ORDER BY ctrt.ContractStartDate, ctrt.ProviderSequenceNumber) AS LagCtrtStartDate")

    filtered_dup_overlap_df = view_df\
                        .withColumn('IsOverlap', when(((col('ContractStartDate') <= col('LagCtrtEndDate')) & (col('ContractEndDate') >= col('LagCtrtStartDate'))), 1).otherwise(0)).filter(col('IsOverlap') == 0).drop('IsOverlap', 'LagCtrtEndDate', 'ProviderSequenceNumber', 'LagCtrtStartDate')
                

    # 3. Filter out coverages where provider contract and product relationship not found.
    inp_vw_join_condition = ((col('inp.MemberCustomerNumber') == col('vw.MemberCustomerNumber')) 
                             & (col('inp.MemberGroupNumber') == col('vw.MemberGroupNumber')) 
                             & (col('inp.CIClassNumber') == col('vw.CIClassNumber')) 
                             & (col('inp.MemberKey') == col('vw.MemberKey')) 
                             & (col('inp.ProviderKey') == col('vw.ProviderKey')) 
                             & (col('inp.ProductKey') == col('vw.ProductKey')))
    
    filtered_invalid_cov_df = input_df.alias('inp').join(filtered_dup_overlap_df.alias('vw'), inp_vw_join_condition, 'leftanti')

    removed_ctrt_not_found_records_df = filtered_invalid_cov_df.alias('inp')\
                            .join(ctrt_not_fount_df.alias('vw'), inp_vw_join_condition, 'leftanti')\
                            .select('inp.*'
                                ,lit(f'Contract does not have the Member Product').alias('Comment')
                                ,lit('E11').alias('ErrorCode'))  

    # 4. Applying rank partitioning by MemberKey,ProductKey,ProviderKey and order by ContractStartDate
    wspec = Window.partitionBy('MemberCustomerNumber','MemberGroupNumber','CIClassNumber', 'MemberKey','ProductKey','ProviderKey', 'CoverageStartDate').orderBy(asc('ContractStartDate'))

    count_df = filtered_dup_overlap_df.groupBy('MemberCustomerNumber','MemberGroupNumber','CIClassNumber', 'MemberKey','ProductKey','ProviderKey', 'CoverageStartDate').agg(countDistinct('ProviderContractKey_pc').alias('ContractCount'))

    valid_df = filtered_dup_overlap_df.join(count_df, ['MemberCustomerNumber','MemberGroupNumber','CIClassNumber', 'MemberKey','ProductKey','ProviderKey', 'CoverageStartDate'])\
                .select('*',rank().over(wspec).alias('rank'))\
                    .withColumnRenamed('ProviderContractKey_vw','ProviderContractKey')

    rejected_df = union_by_name([prv_not_found_df, removed_ctrt_not_found_records_df, ctrt_not_fount_df])
    
    # 5. New Derived Coverage Start Date Column & New Derived Coverage End Date Column
    valid_df = valid_df\
                .select('*'
                ,when((col('ContractCount')>1) & (col('rank') == 1), col('CoverageStartDate'))\
                    .when((col('ContractCount')>1) & (col('rank') > 1), col('ContractStartDate'))\
                    .when((col('ContractCount')==1), col('CoverageStartDate')).alias("CoverageStartDate_derived")
                ,when(((col('ContractCount')>1) & (col('rank') == col('ContractCount'))), col('CoverageEndDate'))\
                    .when(((col('ContractCount')>1) & (col('rank') < col('ContractCount'))), col('ContractEndDate'))\
                    .when((col('ContractCount')==1), col('CoverageEndDate')).alias('CoverageEndDate_derived'))\
                .withColumn('DerivedIndicator',when((col('rank') == 1), col('DerivedIndicator')).otherwise(lit('INSERT')))\
                .withColumn('MemberCoverageKey', when(col('DerivedIndicator') == 'UPDATE', col('MemberCoverageKey'))\
                                                        .otherwise(lit(None)))
                
    valid_df = valid_df.drop('CoverageStartDate','CoverageEndDate')\
                .select('*',col('CoverageStartDate_derived').alias('CoverageStartDate'), col('CoverageEndDate_derived').alias('CoverageEndDate'), col('ProviderContractKey_pc').alias('ProviderContractKey'))

    # 6. Drop unwanted columns
    drop_cols = ['ContractCount', 'rank', 'ErrorMsg1', 'ErrorMsg2', 'CoverageStartDate_derived', 'CoverageEndDate_derived', 'ContractStartDate', 'ContractEndDate', 'ProviderContractKey_pc']
    valid_df = valid_df.drop(*drop_cols)
    rejected_df = rejected_df.drop(*drop_cols)

    return valid_df, rejected_df

# COMMAND ----------

# DBTITLE 1,time_travel_to_specific_delta_version
def time_travel_to_specific_delta_version(version_num, table_name):
    '''
        Description:
        This function is used to time travel delta table to specify version.
        :param version_num: [Type: String].
        :param table_name: [Type: String].
    '''
    try:
        hist_tbl_df = spark.sql(f"DESCRIBE HISTORY {table_name} LIMIT 1")
        hist_version_num = hist_tbl_df.select('version').collect()[0][0]
        if hist_version_num > version_num:
            spark.sql(f"RESTORE TABLE {table_name} TO VERSION AS OF {version_num}")
        else:
            pass
    except Exception as e:
        raise Exception("time_travel_to_specific_delta_version failed:", str(e))

# COMMAND ----------

# DBTITLE 1,member_validation
def member_validation(df, member_table_name):
    '''
        Description:
        This function is used to valid the members present in service fund member.member table or not.
        :param df: [Type:  pyspark.sql.dataframe.Dataframe].
        :param member_table_name: [Type: String].
        :return valid_member_df, invalid_member_df: [pyspark.sql.dataframe.Dataframe].
    '''
    try:
        # Read member stage table and select only the required the columns.
        member_df = read_table_to_df(member_table_name)\
                    .selectExpr('MemberKey'
                                ,'MemberId'
                                ,'SubscriberId'
                                ,'MemberCustomerNumber')

        mem_join_condition = ((col('LH.MemberId') == col('RH.MemberId')) 
                            & (col('LH.CIGroupIdentifier') == col('RH.MemberCustomerNumber'))
                            & (col('LH.SubscriberId') == col('RH.SubscriberId')))

        # Join the delta data frame with member dateframe on above condition.            
        member_validation_df = df.alias('LH')\
                                .join(member_df.alias('RH'),mem_join_condition,'left')\
                                .selectExpr('LH.*', "RH.MemberKey")
                                
        # Filter only the coverage where member found.
        valid_member_df = member_validation_df.filter(col('MemberKey').isNotNull())
        
        # Filter the coverage where member not found.
        invalid_member_df = member_validation_df.filter(col('MemberKey').isNull())

        return valid_member_df, invalid_member_df
    except Exception as e:
        excep = 'member_validation failed: ' + str(e)
        raise Exception(excep)
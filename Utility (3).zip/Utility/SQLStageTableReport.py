# Databricks notebook source
# MAGIC %md
# MAGIC This is a general notebook to generate pipe "|" separated Reports based on the delta status of the SQL stage tables, which is updated after the store procedure is executed.
# MAGIC Below are the conditions of the reports.
# MAGIC
# MAGIC Below are the steps:
# MAGIC   - Job notebook
# MAGIC   - Stored procedure
# MAGIC   - Report notebook
# MAGIC
# MAGIC delta_status can be PROCESSED, ORPHAN, MISSING, IGNORED
# MAGIC
# MAGIC Based on the above delta status the reports will be generated as below.
# MAGIC - if PROCESSED
# MAGIC   - JobNameSucessReport.txt 
# MAGIC - else
# MAGIC   - JobNameErrorReport.txt - else

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','pl_CustomerCoverage')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_NAME','CustomerFeedCoverageRE0016')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('LOAD_TYPE','')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook.
# MAGIC %run ./Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ./Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ./Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run transform notebook.
# MAGIC %run ./Utility/Transform

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ./Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up local variables
audit_start_date_time = datetime.now()
job_type = 'DailyJobs'

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name

except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from File Config.
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)

    default_config = config_dict["DEFAULT"]
    config_dict_job = config_dict[job_name]
    
    container_name = default_config["ContainerName"]
    default_out_config = default_config["Outbound"]
    audit_table_name = default_config['AuditTableName']

    file_path_prefix = default_out_config["FilePathPrefix"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    config = default_out_config["Config"]
    
    # Reporting Table
    StageSQL = config_dict_job['Report']['StageSQL']
    ReportName = config_dict_job['Report']['ReportName']
    temp_path_suffix = config_dict_job['Report']['temp_path_suffix']
    
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,ADLS Path creation
try:
  temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
  outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
  excep = "Path creation for Stage and Curated failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Report generation based on delta status
try:
    delta_status = ['PROCESSED','OTHERS']
    msg = ''

    for i in delta_status:
        if i == 'PROCESSED':
            df_report_success = read_sf_sql_tbl_to_df_spark(query=func_report_query(StageSQL, i))
            if df_report_success.rdd.isEmpty():
                msg = msg + 'No processed records'
            else:
                generate_report(df_report_success, temp_csv_path+'SuccessReport/', outbnd_csv_path, ReportName.replace('.txt','SuccessReport.txt'))
        
        else:
            df_report_error = read_sf_sql_tbl_to_df_spark(query=func_report_query(StageSQL))
            if df_report_error.rdd.isEmpty():
                msg = msg + 'No Error records'
            else:
                generate_report(df_report_error, temp_csv_path+'ErrorReport/', outbnd_csv_path, ReportName.replace('.txt','ErrorReport.txt'))

except Exception as e:
    excep = 'Report generation failed: ' + msg + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)
else:
    excep = "All reports generated successfully"
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, excep)
    dbutils.notebook.exit(excep)
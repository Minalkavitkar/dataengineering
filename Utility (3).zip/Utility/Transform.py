# Databricks notebook source
# DBTITLE 1,Import AdlsHelper notebook
# MAGIC %run ./Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.window import Window
from pyspark.sql.functions import *
from datetime import datetime, date, timedelta
from delta.tables import *
import pandas as pd
import json as js
import uuid
import pyspark.sql.functions as f

# COMMAND ----------

write_role = write_owner_role
read_role  = read_owner_role 

# COMMAND ----------

# DBTITLE 1,Azure blob file system path builder.
def abfss_path_builder(container, storage_account, path_prefix = "", path_suffix="", file_name_regex=""):
    '''
    Description:
    This function is used to build the path.
    :param path_suffix: [Type: string].
    :param regex: [Type: string].
    :returns path: [Type: path] complete path.
    '''
    root_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/"
    path = f"{root_path}{path_prefix}{path_suffix}{file_name_regex}"
    return path

# COMMAND ----------

def col_name_mapping(df, col_mapping_dict):
    '''
    Description:
    This function is used to perform columns between source and target.
    :param df: [Type: string] source dataframe.
    :param col_mapping_dict: [Type: string] column mapping dictionary.
    :returns df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    lst = []
    for src_col_name, trg_col_name in col_mapping_dict.items():
        lst.append(f"`{src_col_name}` AS {trg_col_name}")
    return df.selectExpr(*lst)

# COMMAND ----------

#old
def add_tgt_audit_column(df, pipeline_name,LOAD_TYPE=None,fileDate =None):
    '''
    Description:
    This function is used to audit columns.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param pipeline_name: [Type: string].
    :returns df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    if fileDate is None:
        df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", "current_timestamp() CreatedDateTime"
                        , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
    else:
        df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", f"cast('{fileDate}' as TIMESTAMP) as CreatedDateTime"
                        , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
    return df

# COMMAND ----------

def add_tgt_audit_column(df, pipeline_name,load_type=None,fileDate =None):
    '''
    Description:
    This function is used to audit columns.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param pipeline_name: [Type: string].
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    if load_type is None:
        if fileDate is None:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", "current_timestamp() CreatedDateTime"
                        , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        else:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", f"cast('{fileDate}' as TIMESTAMP) as CreatedDateTime"
                        , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        return df
    elif load_type == 'FullLoad': 
        if fileDate is None:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", "current_timestamp() CreatedDateTime"
                            , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        else:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", f"cast('{fileDate}' as TIMESTAMP) as CreatedDateTime"
                            , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        return df
    elif load_type == 'DeltaLoad':
        audit_cols = {
        "CreatedBy": lit(f'{pipeline_name}'),

        "CreatedDateTime":current_timestamp(),

        "ModifiedBy": when(col('DerivedIndicator')=='UPDATE',f'{pipeline_name}')\
        .when(col('DerivedIndicator')=='INSERT',None)\
        .when(col('DerivedIndicator')=='DELETE',None),

        "ModifiedDateTime": when(col('DerivedIndicator')=='UPDATE',current_timestamp())\
        .when(col('DerivedIndicator')=='INSERT',None)\
        .when(col('DerivedIndicator')=='DELETE',None)
        }
        df = df.withColumns(audit_cols)
        return df

# COMMAND ----------

def dtype_tgt_conversion(df, schema):
    '''
    Description:
    This function is used to convert the data type of each column.
    :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
    :param schema: [Type: dictionary] contains column name as key and column value as data type.
    :returns df: [Type: pyspark.sql.dataframe.Dataframe]converted data type dataframe
    '''

    lst = []
    keys = schema.keys()
    for col_name in df.columns:
        if col_name in keys:
            lst.append(f"CAST({col_name} as {schema[col_name]}) as {col_name}")
        else:
            lst.append(col_name)
    return df.selectExpr(*lst)

# COMMAND ----------

def prioritize_prv_type2Code(df):
    prv_trans_df = df.withColumn('Type2Code', when(trim(col('Type2Code')).isNull(), lit('ZZZ'))\
                                    .otherwise(trim(col('Type2Code'))))

    window_spec = Window.partitionBy('ProviderId', 'SuffixCode').orderBy('Type2Code')
    prv_trans_df = prv_trans_df.withColumn('RN', row_number().over(window_spec))\
                        .filter(col('RN') == 1).drop('RN')
    return prv_trans_df

# COMMAND ----------

#function used to convert yyMMdd to spark date format.
def date_format_conversion(df, lst, inp_dt_format):
    for col_name in lst:
        if inp_dt_format == 'yyMMdd':  
            cmonth = substring(col(col_name), 3, 2)
            cday = substring(col(col_name), -2, 2)
            cyear = substring(col(col_name), 1, 2)
        elif inp_dt_format == 'MMddyy':
            cmonth = substring(col(col_name), 1, 2)
            cday = substring(col(col_name), 3, 2)
            cyear = substring(col(col_name), -2, 2)

        df = df.withColumn(col_name, to_date(\
            when(col(col_name) == '999999', lit('9999-12-31'))\
            .when(col(col_name)=='000000', lit('1900-01-01'))\
            .when((cyear.cast('int') >= 80) & (cyear.cast('int') <= 99), \
                concat(lit('19'),cyear, lit('-'),cmonth, lit('-'), cday))\
            .otherwise(concat(lit('20'),cyear, lit('-'),cmonth, lit('-'), cday)), 'yyyy-MM-dd'))
    return df

# COMMAND ----------

def dt_format_cym(df, convert_date_col,day = 'start'):
    try:
        if day == 'start':
            for col_name in convert_date_col:
                df = df.withColumn(col_name, when((col(col_name)%100 == 0), to_date(concat((col(col_name)/100).cast('int'), lit("1231")), 'yyyyMMdd')).otherwise(to_date(concat(col_name, lit("01")), 'yyyyMMdd')))
        elif day == 'end':
            for col_name in convert_date_col:
                df = df.withColumn(col_name, last_day(to_date(concat(col_name, lit("01")), 'yyyyMMdd')))
        return df
    except Exception as e:
        raise Exception ("date format converstion failed", str(e))

# COMMAND ----------

# DBTITLE 1,Read delta table as dataframe.
def read_table_to_df(tablename):
    '''
    Description:
    This function is used to read delta table as dataframe.
    :param tablename: [Type: string].
    :returns df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        df = spark.read.table(tablename)
        return df
    except Exception as e:
        raise Exception("not able to read the table",str(e))

# COMMAND ----------

def cur_table_creation(mapping, tbl_lst):
    try:
        for tbl_name in tbl_lst:
            tbl_name = tbl_name.strip()
            spark.sql(mapping[tbl_name])
            print(tbl_name + ": Created")
    except Exception as e:
        raise Exception(f"table_creation: {e}")

# COMMAND ----------

def updtAudit(dataDict,ctrl_table_name):
    try:
        df = spark.createDataFrame(data=dataDict, schema = ["RunId", "ProcessName", "RunDate", "Status", "StartDateTime","EndDateTime", "ErrorDescription"])

        df = df.withColumn('Message',f.struct(f.col('RunId').alias('PipelineRunId'),f.col('ErrorDescription').cast('string').alias('ErrorDescription')))

        tgt = DeltaTable.forName(spark, ctrl_table_name)


        tgt.alias('LH')\
            .merge(df.alias('RH'), 'LH.ProcessName = RH.ProcessName and LH.RunDate = RH.RunDate')\
            .whenMatchedUpdate(set = {
                'LH.RunId':col('RH.RunId'),
                'LH.Status':col('RH.Status'),
                'LH.StartDateTime':col('RH.StartDateTime'),
                'LH.EndDateTime':col('RH.EndDateTime'),
                'LH.Message':col('RH.Message')
            })\
            .whenNotMatchedInsert(values = {
                'LH.RunId':col('RH.RunId'),
                'LH.ProcessName':col('RH.ProcessName'),
                'LH.RunDate':col('RH.RunDate'),
                'LH.Status':col('RH.Status'),
                'LH.StartDateTime':col('RH.StartDateTime'),
                'LH.EndDateTime':col('RH.EndDateTime'),
                'LH.Message':col('RH.Message')
            })\
            .execute()

    except Exception as e:
        raise Exception('updtAudit: ', str(e))


# COMMAND ----------

def returnLastSuccessdate(ProcessName,ctrl_table_name):
    try:
        delta = timedelta(days=1)
        dd = spark.sql(f"select * from {ctrl_table_name} ")
        LatestSuccessDate = dd.filter(f"ProcessName == '{ProcessName}' ")

        if LatestSuccessDate.rdd.isEmpty():
            return date.today()
        else:
            if dd.filter(f"ProcessName == '{ProcessName}' and Status == 'Success' ").rdd.isEmpty():
                return LatestSuccessDate.filter(" Status == 'Failure' ").select(min(LatestSuccessDate.RunDate).alias('RunDate')).rdd.map(lambda x : x.RunDate).collect()[0]
            else:
                return LatestSuccessDate.filter(" Status == 'Success' ").select(max(LatestSuccessDate.RunDate).alias('RunDate')).rdd.map(lambda x : x.RunDate).collect()[0] + delta
    except Exception as e:
        raise Exception("returnLastSuccessdate: ", str(e))

# COMMAND ----------

# DBTITLE 1,Create control table entry.
def create_control_table_entry(run_id, proc_name, pipeline_run_id):
    '''
    Description:
    This function is used to create a entry in control table.
    :param run_id: [Type: string] It is a 36 character alphanumeric string(UUID).
    :param proc_name: [Type: string] contain process name.
    :param pipeline_run_id: [Type: string].
    :returns ctrl_df: [Type: pyspark.sql.dataframe.Dataframe] It contain control table entry for current run.
    '''
    col_map = {
    "RunId" : lit(run_id),
    "ProcessName" : lit(proc_name),
    "RunDate" : lit(current_date()),
    "Status" : lit("Inprogress"),
    "StartDateTime" : lit(current_timestamp()),
    "EndDateTime" : lit(None).cast('timestamp'),
    "Message" : struct(lit(pipeline_run_id).alias('PipelineRunId'),lit('null').cast('string').alias('ErrorDescription'))
    }
    ctrl_df = spark.range(1).withColumns(col_map).drop('id')
    return ctrl_df


# COMMAND ----------

# DBTITLE 1,Update control table.
def update_audit_table(audit_tbl_name, task_id, status, proc_name, msg = None):
    '''
    Description:
    This function is used to update the status and error message column in control table based on the run_id and proc_name.
    :param run_id: [Type: string] It is a 36 character alphanumeric string(UUID).
    :param status: [Type: string].
    :param proc_name: [Type: string] contain process name.
    :param msg : [Type: string] contain error details.
    '''
    try:
        # Create a dictonary with required columns.
        col_map = {
                "TaskId" : lit(task_id),
                "ProcessName" : lit(proc_name),
                "Status" : lit(status),
                "EndDateTime" : lit(current_timestamp()).cast('timestamp'),
                "Message" : lit(msg)
                }
        # Create a dataframe and add column based on above dictonary to perform merge operation.
        ctrl_df = spark.range(1).withColumns(col_map).drop('id')
        dt_tbl = DeltaTable.forName(spark, audit_tbl_name)
        dt_tbl.alias('target')\
        .merge(ctrl_df.alias('source') , 'target.ProcessName = source.ProcessName and target.TaskId = source.TaskId and target.EndDateTime is null')\
        .whenMatchedUpdate(
            set = {'EndDateTime' : "source.EndDateTime",
                'Status' : "source.Status",
                'Message' : "source.Message"}
        ).execute()
    except Exception as e:
        excep = "An exception occured :"+ str(e)
        raise Exception(excep)


# COMMAND ----------

# DBTITLE 1,Pivot columns.

def pvt_cols(df,grpBy_cols,pivot_col,agg_col):
    '''
    Description:
    This function is used to pivot dataframe.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param grpBy_cols: [Type: list].
    :param pivot_col: [Type: string].
    :param agg_col : [Type: string].
    :returns df_pivot : It returns pivoted dataframe.
    '''
    try:
        df_pivot = df.groupBy(grpBy_cols).pivot(pivot_col).agg(first((col(agg_col))))
        return df_pivot
    except Exception as e:
        raise Exception ('Pivoting columns',str(e))

# COMMAND ----------

# DBTITLE 1,Job starts process check.
def start_process_check(ctrl_tbl_name, sync_process_names, job_type = 'DailyJob',process_name = 'DBP'):
    try:
        modified_sync_process_names = [process_name+"#"+job_type+"#"+name for name in sync_process_names]        
        window_spec = Window.partitionBy('ProcessName').orderBy(desc('StartDateTime'))
        ctrl_df = spark.read.table(ctrl_tbl_name)\
                    .filter((col("ProcessName").isin(modified_sync_process_names)))\
                    .select('ProcessName', 'Status', 'StartDateTime')
        cnt = ctrl_df.withColumn('RN', row_number().over(window_spec))\
                    .filter((col("Status") != "Success") & (col("RN") == 1))\
                    .count()
        if cnt == 0:
            return True
        else:
            return False
    except Exception as e:
        return False

# COMMAND ----------

# DBTITLE 1,Check delta file exists.
def check_delta_file_exists(path):
    """
        Description:
        This function is used to delta file exists or not for the given input path.
        :param path: [Type: string].
        :returns : [Type: boolean].
    """
    try:
        path = path + "_delta_log"
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        return False

# COMMAND ----------

# DBTITLE 1,Get config file as dictionary.
def get_file_config(path):
    """
        Description:
        This function is used to read FileConfig json from repo and convert it to a Dictonary.
        :param path: [Type: string].
        :returns config_dict: [Type: dictonary].
    """
    try:
        with open(file_conf_path) as json_file:
            config_dict = js.load(json_file)
        return config_dict
    except Exception as e:
        raise Exception("get_file_config failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Write dataframe as delta table.
def write_df_as_delta_table(df, tbl_name, part_col=None, format_type='delta', mode = 'overwrite'):
    """
        Description:
        This function is used to write dataframe as delta table.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string] table name.
        :param path: [Type: string].
        :param part_col: [Type: string] partition column.
        :default param format_type: [Type: string].
        :default param mode: [Type: string].
    """
    try:
        if part_col is not None:
            part_col = [item.replace(" ", "") for item in part_col.split(',')]
            df.write.format(format_type).mode(mode).partitionBy(*part_col)\
                .option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        elif part_col is None:
            df.write.format(format_type).mode(mode).option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        else:
            df.write.format(format_type).mode(mode)\
                .option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        spark.sql(f"AlTER table {tbl_name} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tbl_name} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tbl_name} TO {read_role}")
    except Exception as e:
        raise Exception("JobFailed write_df_as_delta_table: ", str(e))

# COMMAND ----------

# DBTITLE 1,Parse fixed width file config as dataframe.
def get_fixed_width_file_config(path):
    """
        Description:
        This function is used to read FixedWidthFileConfig json from repo and convert it to a spark dataframe.
        :param path: [Type: string].
        :returns fixed_config_df: [Type: string] Converted df.
    """
    try:
        with open(path) as json_file:
            fixed_config_dict = js.load(json_file)
        # parsing table table details json to pandas data frame.
        fxd_dtl_df = pd.json_normalize(fixed_config_dict, record_path = ['FileDetails'], meta = ['JobName'])
        # Converting pandas dataframe to spark dataframe.
        fixed_config_df = spark.createDataFrame(fxd_dtl_df)
        return fixed_config_df
    except Exception as e:
        raise Exception("get_fixed_width_file_config", str(e))

# COMMAND ----------

# DBTITLE 1,Parse sync process config file as dataframe.
def get_sync_process_config(path):
    """
        Description:
        This function is used to read SyncProcessConfig json from repo and convert it to a spark dataframe.
        :param path: [Type: string].
        :returns spark_config_df: [Type: string] Converted df.
    """
    try:
        with open(path) as json_file:
            config_dict = js.load(json_file)
        # parsing table table details json to pandas data frame.
        conf_prsed_df = pd.json_normalize(config_dict, record_path = ['StageSyncDetails'], meta = ['SubjectArea'])
        # Converting pandas dataframe to spark dataframe.
        spark_config_df = spark.createDataFrame(conf_prsed_df)
        return spark_config_df
    except Exception as e:
        raise Exception("get_fixed_width_file_config", str(e))


# COMMAND ----------

# DBTITLE 1,Convert sync config dataframe to list.
def convert_sync_config_df_to_lst(df):
    """
        Description:
        This function is used to filter records for specific subject area and convert it to a list.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] SyncConfig file.
        :returns df: [Type: string] Converted list.
    """
    try:
        rows = df.collect()
        conf_lst = [[row.SqlTableName, row.StageTableName, row.MergeKey, row.ProcessName, row.CtrlTableName, row.ReadNumPartition]for row in rows]
        return conf_lst
    except Exception as e:
        raise Exception("convert_sync_config_df_to_lst failed:", str(e))

# COMMAND ----------

def select_required_tables_from_sync_config(df, subject_area, table_names):
    """
        Description:
        This function is used to filter records for specific subject area and select only the required tables.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] Sync Config df.
        :param suject_area: [Type: string].
        :param table_names: [Type: string].
        :returns df: [Type: string] Filtered df.
    """
    try:
        filtered_df = df.filter(col('SubjectArea') == subject_area)
        filtered_df.cache()
        if table_names == 'All':
            return filtered_df
        else:
            table_names = [table_name.strip() for table_name in table_names.split(',')]
            col_added_df  = filtered_df.withColumn('TableName', split(col('SqlTableName'), '\\.')[1])
            sync_conf_table_names = [row.TableName for row in col_added_df.select('TableName').collect()]
            table_not_present_list = list(set(table_names) - set(sync_conf_table_names))
            if not table_not_present_list:
                req_tables_df = col_added_df\
                                    .filter((col('TableName').isin(table_names)))\
                                    .drop('TableName')
                return req_tables_df
            else:
                raise Exception(f"Table names are not found in sync config - {table_not_present_list}")
    except Exception as e:
        raise Exception("select_required_tables_from_sync_config failed:", str(e))

# COMMAND ----------

# DBTITLE 1,Convert column values to fixed width.
def convert_col_to_fixed_width(config_df, df):
    """
        Description:
        This function is used to convert column values to fixed width value using Fixed Width configuration file.
        :param config_df: [Type: pyspark.sql.dataframe.Dataframe] Fixed Width configuration file dataframe.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] df to convert Fixed width value.
        :returns df: [Type: string] Converted dataframe.
    """
    try:
        counter = 1
        slt_lst = []
        if config_df.count() == 0:
            raise Exception("Config Dataframe is empty")
        config_df = config_df.orderBy(col('SequenceNo').cast('int'))
        rdd = config_df.rdd.map(lambda x : [x[0], x[1], x[2], x[3]]).collect()
        for col_name, seq_no, col_len, d_type in rdd:
            if col_name.strip() not in df.columns:
                raise Exception(f"{col_name} not found in given dataframe")
            elif counter != int(seq_no):
                raise Exception("Column Sequence is missing. Please check")
            if d_type.lower() == 'string':
                slt_lst.append(f"substring(rpad(coalesce({col_name}, ''), {col_len}, ' '),1,{col_len}) as {col_name}")
            elif d_type.lower() == 'numeric':
                slt_lst.append(f"substring(CASE WHEN {col_name} < 0 then concat('-', lpad(abs(coalesce({col_name}, 0)),{col_len} - 1, '0')) else lpad(coalesce({col_name}, 0), {col_len}, '0') end, 1, {col_len}) as {col_name}")
            elif d_type.lower() == 'date':
                slt_lst.append(f"substring(case when {col_name} is null then lpad('', {col_len}, ' ') else replace({col_name}, '-', '') end,1,{col_len}) as {col_name}")
            elif d_type.lower() == 'timestamp':
                slt_lst.append(f"substring(case when {col_name} is null then lpad('', {col_len}, ' ') else replace({col_name}, 'T', '-') end, 1, {col_len}) as {col_name}")
            else:
                raise Exception(f"Incorrect datatype - {d_type}")
            counter += 1
        return df.selectExpr(*slt_lst)
    except Exception as e:
        raise Exception("convert_col_to_fixed_width", str(e))

# COMMAND ----------

# DBTITLE 1,Write outbound file to Adls.
def write_outbnd_file_to_adls(df, path, config, write_mode='overwrite'):
    """
        Description:
        This function is used to write dataframe as single text file to ADLS for the given input path.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param path: [Type: string].
        :param config: [Type: string].
        :param write_mode: [Type: string].
    """
    try:
        if df.rdd.isEmpty():
            dbutils.fs.put(f"{path}/EmptyFile.txt","")
        else:
            concated_df = df.withColumn("data", concat_ws("", *[col(c) for c in df.columns])).select('data')
            dbutils.fs.rm(path, True)
            concated_df.coalesce(1).write.mode(write_mode).format("text")\
                .options(**config).save(path)
    except Exception as e:
        raise Exception("write_outbnd_file_to_adls", str(e))

# COMMAND ----------

# DBTITLE 1,Check file exists in ADLS location.
def file_exists(path):
    """
        Description:
        This function is used to check the file exists or not for the given input path.
        :param path: [Type: string].
        :returns [Type: bool].
    """
    try:
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        return False

# COMMAND ----------

# DBTITLE 1,Move file to traget location and rename it.
def copy_file_to_outbnd_with_new_name(temp_path, outbnd_path, outbnd_file_name,Rundate=None):
    """
        Description:
        This function is used to move file from one path to another, and during the move, it will also rename the file according to provided input.
        :param temp_path: [Type: string] Source path.
        :param outbnd_path: [Type: string] Target path.
        :param outbnd_file_name: [Type: string].
    """
    try:
        counter = 0
        for file_info in dbutils.fs.ls(temp_path):
            if file_info.name.endswith('.txt'):
                counter += 1
                temp_file_name = file_info.name
        if counter == 0:
            raise Exception(f"{temp_path} directory doesn't have txt file.")
        elif counter == 1:
            dbutils.fs.cp(temp_path + temp_file_name, outbnd_path + outbnd_file_name)
            dbutils.fs.rm(temp_path, True)
        else:
            raise Exception(f"{temp_path} directory contain more than one txt file.")
    except Exception as e:
        raise Exception("copy_file_to_outbnd_with_new_name", str(e))

# COMMAND ----------

# DBTITLE 1,Read inbound file as dataframe.
def read_inbound_csv_file(path):
    """
        Description:
        This function is used to read file from ADLS with these options(header=true, delimiter = |).
        :param path: [Type: string] abfss(Azure blob file system) path.
        :param path: [Type: string].
        :param config: [Type: string].
        :returns read_csv : [Type: pyspark.sql.dataframe.Dataframe].
    """
    try:
        read_csv =spark.read.options(header=True, delimiter ='|').csv(path)
        return read_csv
    except Exception as e:
        raise Exception("read_inbound_csv_file", str(e))

# COMMAND ----------

def set_df_columns_not_nullable(spark, df, column_list, nullable=False):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

# DBTITLE 1,Read delta table to dataframe
def read_table_to_df(tablename):
    try:
        df = spark.read.table(tablename)
        return df
    except Exception as e:
        raise Exception("not able to read the table",str(e))

# COMMAND ----------

def insert_entry_to_audit_table(run_id, module, job_name, job_type, start_date_time, status ,audit_table_name, error_message, process ="DBP", end_date_time = None, task_id =None):
    '''
        Description:
        This function is used to create a df which matches audit table schema and insert it to audit table.
        :param run_id: [Type: String] Pipeline run id.
        :param module: [Type: String].
        :param job_name: [Type: String].
        :param job_type: [Type: String].
        :param start_date_time: [Type: String].
        :param status: [Type: String].
        :param audit_table_name: [Type: String].
        :param error_message: [Type: String].
        :param process: [Type: String].
    '''
    try:
        if task_id == None:
            task_id = str(uuid.uuid4())
        if end_date_time == None:
            end_date_time = current_timestamp()
        
        col_map = {
            "TaskId":lit(task_id),
            "RunId" : lit(run_id),
            "PipelineGroupName":lit(module),
            "ProcessName" : concat(lit(process),lit("#"),lit(job_type),lit("#"),lit(job_name)),
            "RunDate":lit(current_date()).cast('Date'),
            "SequenceNumber":lit(None).cast('int'),
            "Message":lit(error_message).cast('string'),
            "ErrorCode" : lit(None).cast('String'),
            "Status" : lit(status),
            "StartDateTime":lit(start_date_time).cast('timestamp'),
            "EndDateTime" : lit(end_date_time).cast('timestamp')
            }
        ctrl_df = spark.range(1).withColumns(col_map).drop('id')
        ctrl_df.write.format("delta").mode("append").saveAsTable(audit_table_name)
    except Exception as e:
        raise Exception("insert_entry_to_audit_table failed:", str(e))

# COMMAND ----------

# DBTITLE 1,Set DF to Null Column
def set_df_columns_nullable(spark, df, column_list, nullable=True):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

# DBTITLE 1,Set DF to Not Null Column
def set_df_columns_not_nullable(spark, df, column_list, nullable=False):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

def write_report_file_to_adls(df, path, config, write_mode='overwrite'):
    """
        Description:
        This function is used to write dataframe as single text file to ADLS for the given input path.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param path: [Type: string].
        :param config: [Type: string].
        :param write_mode: [Type: string].
    """
    try:
        if df.rdd.isEmpty():
            dbutils.fs.put(f"{path}/EmptyFile.txt","")
        else:
            dbutils.fs.rm(path, True)
            df.coalesce(1).write.mode(write_mode).format("text")\
                .options(**config).save(path)
    except Exception as e:
        raise Exception("write_outbnd_file_to_adls", str(e))

# COMMAND ----------

def generate_report(df, outbound_temp_path, outbnd_path, file_name):
    try:
        file_config = {
            'emptyValue': '\\u0000',
            'lineSep': '\r\n'
        }
        select_list = [f"cast({colm} as string) as {colm}" for colm in df.columns]
        dtype_converted_df = df.selectExpr(*select_list)
        column_name = "|".join(dtype_converted_df.columns)
        col_name_df = spark.range(1).withColumn('data', lit(column_name)).drop('id')
        trans_df = dtype_converted_df.na.fill('').select(concat_ws('|', *dtype_converted_df.columns).alias('data'))
        write_report_file_to_adls(col_name_df.union(trans_df), outbound_temp_path,file_config)
        copy_file_to_outbnd_with_new_name(outbound_temp_path, outbnd_path, file_name)
    except Exception as e:
        excep = 'Report generation failed: ' + str(e)
        raise Exception(excep)

# COMMAND ----------

def ci_member_distinct(df):
    window_spec = Window.partitionBy("MbrPid", "CiGrpId",'MbrsubPid').orderBy(desc('MbrUmidEffDate'), desc('MbrUmid'))
    rn_clac_df = df.withColumn('RN', row_number().over(window_spec))
    valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN')
    return(valid_df)

# COMMAND ----------

def remove_dup_records_simple(input_df, uniq_keys, order_by, ordering = 'desc'):
    try:
        if ordering == 'desc':
            window_spec = Window.partitionBy(uniq_keys)\
                            .orderBy(desc(order_by))
        else:
            window_spec = Window.partitionBy(uniq_keys).orderBy(order_by)
        rn_clac_df = input_df.withColumn('RN', row_number().over(window_spec))
        final_df = rn_clac_df.filter(col('RN') == 1).drop('RN')
        return final_df
    except Exception as e:
        raise Exception('removing duplicate records failed: ',str(e))

# COMMAND ----------

def query_re0017():
    qury = """
    select t2.MarketNumber, t2.MemberCustomerNumber, t2.MemberGroupNumber,t2.CIClassNumber,
    t2.MemberId, t2.SubscriberId, t2.ProviderId, t2.ProviderSuffixCode, t2.ProviderServiceTypeCode,
    t2.CoverageStartDate, t2.CoverageEndDate,
    t2.CoverageEndReasonCode, t2.WokerCompensationOccurenceId 
    from member.StageDBPCustomerProduct t1
    inner join (
    select tt2.MarketNumber, tt1.MemberCustomerNumber, tt1.MemberGroupNumber,tt1.CIClassNumber,
    tt3.MemberId, tt3.SubscriberId, tt4.ProviderId, tt4.ProviderSuffixCode, tt4.ProviderServiceTypeCode,
    tt1.CoverageStartDate, tt1.CoverageEndDate,
    tt1.CoverageEndReasonCode, tt1.WokerCompensationOccurenceId
    from Member.MemberCoverage tt1
    inner join product.product tt2
    on tt1.ProductKey = tt2.ProductKey
    inner join member.member tt3
    on tt1.MemberKey = tt3.MemberKey
    inner join ProviderContract.ProviderContract tt4
    on tt1.ProviderContractKey = tt4.ProviderContractKey) t2
    on t1.MemberCustomerNumber = t2.MemberCustomerNumber
    and t1.MemberGroupNumber = t2.MemberGroupNumber
    and t1.CIClassNumber = t2.CIClassNumber
    and t1.MarketNumber = t2.MarketNumber
    and t1.CustomerProductStartDate > t2.CoverageStartDate and t1.CustomerProductStartDate < t2.CoverageEndDate
    """
    return qury

# COMMAND ----------

def func_report_query(table_name, delta_status=''):
    if delta_status == '':
        qry = f"""select * from {table_name} where DeltaStatus != 'PROCESSED' """
    else:
        qry = f"""select * from {table_name} where DeltaStatus = '{delta_status}' """
    return qry

# COMMAND ----------

def delta_processing_with_cascade_delete(tbl_name, ins_upd_df, ins_upd_cond, not_update_lst=None, delete_df=None, child_tbl_detail_config=None):
    # this function will process for INSERT, UPDATE & DELETE
    # DELETE will peform cascade delte based on child_tbl_detail_config

    if not_update_lst != None:
            col_list = ins_upd_df.columns
            updt_list = [x  for x in col_list if x not in not_update_lst]

            updt_dict = {}
            for element in updt_list:
                updt_dict[element] = 'Stage.'+element

            insrt_dict = {}
            for element in col_list:
                insrt_dict[element] = 'Stage.'+element
    else: 
            col_list = ins_upd_df.columns

            updt_dict = {}
            for element in col_list:
                updt_dict[element] = 'Stage.'+element

            insrt_dict = {}
            for element in col_list:
                insrt_dict[element] = 'Stage.'+element

    # Processing delete with cascade
    if child_tbl_detail_config != None:
        view_name = child_tbl_detail_config["view_name"]
        child_tbl_config = child_tbl_detail_config["child_tbl_lst"]
        delete_df.createOrReplaceTempView(view_name)

        for tbl, qry in child_tbl_config.items():
            delete_selected_df = spark.sql(qry)
            del_cond_list = []
            for colm in delete_selected_df.columns:
                del_cond_list.append('curated.'+colm+'='+'stage.'+colm)   
            del_cond = ' and '.join(del_cond_list)

            deltaTableCurated= DeltaTable.forName(spark,tbl)
            deltaTableCurated.alias('Curated')\
                    .merge(delete_selected_df.alias('Stage'),del_cond)\
                    .whenMatchedDelete()\
                    .execute()

    # Processing insert and update
    ins_upd_cond_lst = []
    for colm in ins_upd_cond:
        ins_upd_cond_lst.append('curated.'+colm+'='+'stage.'+colm)
    ins_upd_cond_str = ' and '.join(ins_upd_cond_lst)
    
    deltaTableCurated= DeltaTable.forName(spark,tbl_name)
    deltaTableCurated.alias('Curated')\
        .merge(ins_upd_df.alias('Stage'),ins_upd_cond_str)\
                    .whenMatchedUpdate(condition ="Stage.DerivedIndicator='UPDATE'", set = updt_dict)\
                    .whenNotMatchedInsert(condition = "Stage.DerivedIndicator='INSERT'", values = insrt_dict)\
                    .execute()
# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DecimalType
from pyspark.sql.functions import col, lit, to_timestamp, split, input_file_name, current_date, current_timestamp,size,desc
from datetime import datetime, date, timedelta
from delta.tables import *
import pandas as pd

# COMMAND ----------

# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

write_role = write_owner_role
read_role  = read_owner_role 

# COMMAND ----------

def path_builder(container, storage_account, path_suffix="", regex="", path_prefix = ""):
    '''
    Description:
    This function is used to build the path.
    :param path_suffix: [Type: string].
    :param regex: [Type: string].
    :returns path: [Type: path] complete path.
    '''
    root_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/"
    path = f"{root_path}{path_prefix}{path_suffix}{regex}"
    return path

# COMMAND ----------

def read_csv(path, config, format_type = 'csv'):
    try:
        df = spark.read.format(format_type)\
            .options(**config).load(path)
        return df
    except Exception as e:
        raise Exception("read_csv: ",str(e))

# COMMAND ----------

def validate_fullload(df,load_type):
    try:
        if load_type == 'FullLoad':
            lst = df.select('IND1').distinct().rdd.map(lambda x : x.IND1).collect()
            lst.remove('ADD')
            if len(lst) > 0:
                raise Exception('File rejected, because it is not FullLoad')
            else:
                return(df)
        elif load_type == 'DeltaLoad':
            return(df)
        else:
            return(df)
    except Exception as e:
        raise Exception("validate_fullload",str(e))

# COMMAND ----------

def table_name_selector(df, table_code):
    table_name = df.filter(col('table_code') == table_code)\
        .select('table_name').rdd.flatMap(lambda x : x).collect()
    if len(table_name) == 0:
        raise Exception("Table_name_selector : Table not found")
    elif len(table_name) > 1:
        raise Exception("Table_name_selector : More than one table found for the Table Code")
    return table_name[0]


# COMMAND ----------

def ts_format_conversion(df, column_list):
    '''
    Description:
    This function is used to convert the Mainframe timestamp to standart timestamp.
    :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
    :param column_list: [Type: list] contains column name to convert as standard timestamp.
    :returns df: [Type: pyspark.sql.dataframe.Dataframe]converted dataframe
    '''
    try:
        for col_name in column_list:
            df = df.withColumn(col_name, to_timestamp(col(col_name), 'yyyy-MM-dd-HH.mm.ss.SSSSSS'))
        return df
    except Exception as e:
        raise Exception("ts_format_conversion: ", str(e))

# COMMAND ----------

def non_string_col_builder(schema):
    ts_list, non_string_list = [], []
    for col, dtype in schema.items():
        if dtype != 'STRING':
            non_string_list.append(col)
            if dtype == 'TIMESTAMP':
                ts_list.append(col)
    return ts_list, non_string_list

def trim_leading_trailing_space(df):
    try:
        lst = [f"CASE WHEN trim(`{col}`) = '' THEN `{col}` ELSE trim(`{col}`) END AS `{col}`" for col in df.columns]
        # df.   select([trim(col(c)).alias(c) if c in lst else col(c) for c in df.columns])
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("trim_leading_trailing_space: ", str(e))

# COMMAND ----------

def add_audit_columns(df):
    '''
    Description:
    This function is used to audit columns.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :returns df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        split_col = split(input_file_name(),'/')
        cols_map = {
                'LoadDate' : lit(current_date()).cast('date'),
                'LoadTimestamp' : lit(current_timestamp()).cast('timestamp'),
                'FileName' : split_col[(size(split_col) - 1)].cast('string'),
                'RunId' : lit(None).cast('String')
        }
        return df.withColumns(cols_map)
    except Exception as e:
        raise Exception("add_audit_columns: ", str(e))

# COMMAND ----------

#Add Exception
def add_calc_column(df, keys, load_type):
    agg_df = df.groupBy(*keys).count()
    joined_df = df.join(agg_df, keys)
    if load_type == 'DeltaLoad':
        cols_map = {
                'DerivedIndicator' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('INSERT'))\
                        .when((col('count') == 1) & (col('Ind1') == 'DEL'), lit('DELETE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'ADD'), lit('UPDATE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'DEL'), lit('IGNORE'))\
                        .when((col('count') >= 3) , lit('IGNORE')),
                'Status' : when(col('count') >= 3, lit('E')).otherwise(lit('S')),
                'RejectReason' : when(col('count') >= 3, lit('Incorrect record')).otherwise(lit('NA'))
        }
    elif load_type == 'FullLoad':   
        cols_map = {
                'DerivedIndicator' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('INSERT'))\
                                    .otherwise(lit('IGNORE')),
                'Status' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('S'))\
                    .otherwise(lit('E')),
                'RejectReason' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('NA'))\
                    .otherwise(lit('Incorrect Record'))
        }
    else:
        raise Exception("Please check the load_type. Its not valid")
    df = joined_df.withColumns(cols_map).drop('count')
    return df

# COMMAND ----------

def dtype_conversion(df, schema):
    try:   
        '''
        Description:
        This function is used to convert the data type of each column.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
        :param schema: [Type: dictionary] contains column name as key and column value as data type.
        :param df: [Type: pyspark.sql.dataframe.Dataframe]converted data type dataframe
        '''
        lst = []
        for col_name, dtype in schema.items():
            alias_name = col_name.replace("_", " ").title().replace(" ", "")
            lst.append(f"CAST({col_name} AS {dtype}) AS {alias_name}")
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("JobFailed dtype_conversion: ", str(e))

# COMMAND ----------

def defPartDate(final_df,partCol,DtFormat):
    try:
        final_df = final_df.withColumn('YYYY', date_format(partCol,DtFormat))
        return final_df
    except Exception as e:
        raise Exception("defPartDate: ", str(e))

# COMMAND ----------

def write_as_table(df, tbl_name, partCol=None, format_type='delta', mode = 'overwrite'):
    try:
        if partCol is not None:
            df.write.format(format_type).mode(mode).partitionBy(f'{partCol}').saveAsTable(f'{tbl_name}')
            
        elif partCol is None:
            df.write.format(format_type).mode(mode).saveAsTable(f'{tbl_name}')
        else:
            df.write.format(format_type)\
                .mode(mode).saveAsTable(f'{tbl_name}')
        spark.sql(f"AlTER table {tbl_name} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tbl_name} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tbl_name} TO {read_role}")
    except Exception as e:
        raise Exception("JobFailed write_as_table: ", str(e))

# COMMAND ----------

def add_StgUnqId(input_df):
    windowSpec = Window().orderBy(lit('A'))
    return input_df.withColumn('StgUnqId', row_number().over(windowSpec))

# COMMAND ----------

def main_function(file_config, load_type, table_name, schema, buz_keys, reject_dup="Yes",stage_full="NoStageFull"):
    try:
        container_name = file_config['ContainerName'] if 'ContainerName' in file_config.keys() else ""
        storage_account = file_config['StorageAccountName'] if 'StorageAccountName' in file_config.keys() else ""
        src_path_suffix = file_config['FilePathSuffix'] if 'FilePathSuffix' in file_config.keys() else ""
        stg_path_suffix = file_config['StagePathSuffix'] if 'StagePathSuffix' in file_config.keys() else ""        
        src_regex = file_config['FileRegex'] if 'FileRegex' in file_config.keys() else ""
        config = file_config['Config'] if 'Config' in file_config.keys() else ""
        source_file_format = file_config['SourceFileFormat'] if 'SourceFileFormat' in file_config.keys() else ""
        partCol = file_config['partCol'] if 'partCol' in file_config.keys() else None
        DtFormat = file_config['DtFormat'] if 'DtFormat' in file_config.keys() else None


        source_path = path_builder(container_name, storage_account, src_path_suffix, src_regex)
        stage_path = path_builder(container_name, storage_account, stg_path_suffix)
        df = read_csv(path= source_path, format_type = source_file_format, config = config)

        validated_df = validate_fullload(df,load_type)
        ts_lst, non_str_lst = non_string_col_builder(schema)
        ts_trans_df = ts_format_conversion(trim_leading_trailing_space(validated_df) ,ts_lst)
        dtype_transd_df= dtype_conversion(ts_trans_df, schema)
        col_added_df = add_audit_columns(dtype_transd_df)

        if stage_full == "StageFull":
            load_stage_full_df = col_added_df.drop("LoadDate","FileName","RunId")
            stage_full_table_name = stg_full_name_from_stage(table_name)
            write_stage_full(load_stage_full_df, stage_full_table_name, load_type, buz_keys)

        stg_unique_id_added_df = add_StgUnqId(col_added_df)

        # duplicate check & deriving indicator
        if reject_dup == "Yes":
            final_df = add_calc_column(stg_unique_id_added_df, buz_keys, load_type)
        elif reject_dup == "KeepOne":
            final_df = add_calc_column_keep_one(stg_unique_id_added_df, buz_keys, load_type)

        # writing into stagetable
        if DtFormat is None or partCol is None:
            write_as_table(df=final_df, tbl_name = table_name)
        else:
            final_df = defPartDate(final_df, partCol, DtFormat)
            write_as_table(df=final_df, tbl_name = table_name, partCol=DtFormat)
        
    except Exception as e:
        raise Exception("JobFailed stage main function: ", str(e))

# COMMAND ----------

# DBTITLE 1,main function to ingest the CI files without ADD, DEL info
def main_function_dp_ci(file_config, table_name, schema):
    try:
        container_name = file_config['ContainerName'] if 'ContainerName' in file_config.keys() else ""
        storage_account = file_config['StorageAccountName'] if 'StorageAccountName' in file_config.keys() else ""
        src_path_suffix = file_config['FilePathSuffix'] if 'FilePathSuffix' in file_config.keys() else ""
        stg_path_suffix = file_config['StagePathSuffix'] if 'StagePathSuffix' in file_config.keys() else ""        
        src_regex = file_config['FileRegex'] if 'FileRegex' in file_config.keys() else ""
        config = file_config['Config'] if 'Config' in file_config.keys() else ""
        source_file_format = file_config['SourceFileFormat'] if 'SourceFileFormat' in file_config.keys() else ""
        partCol = file_config['partCol'] if 'partCol' in file_config.keys() else None
        DtFormat = file_config['DtFormat'] if 'DtFormat' in file_config.keys() else None


        source_path = path_builder(container_name, storage_account, src_path_suffix, src_regex)
        stage_path = path_builder(container_name, storage_account, stg_path_suffix)
        df = read_csv(path= source_path, format_type = source_file_format, config = config)

        #validated_df = validate_fullload(df,load_type)

        ts_lst, non_str_lst = non_string_col_builder(schema)
        ts_trans_df = ts_format_conversion(trim_leading_trailing_space(df) ,ts_lst)
       
        dtype_transd_df= dtype_conversion(ts_trans_df, schema)

        final_df = add_audit_columns(dtype_transd_df)

        if DtFormat is None or partCol is None:
            write_as_table(df=final_df, tbl_name = table_name, partCol=DtFormat)
        else:
            final_df = defPartDate(final_df, partCol, DtFormat)
            write_as_table(df=final_df, tbl_name = table_name, partCol=DtFormat)

    except Exception as e:
        raise Exception("JobFailed stage main function: ", str(e))

# COMMAND ----------

def get_table_config(path):
    try:
        with open(path) as f:
            src_file = json.load(f)
        tbl_dtl_df = pd.json_normalize(src_file, record_path = ['table_details'], meta = ['subject_area'])
        spark_df = spark.createDataFrame(tbl_dtl_df).cache()
        return spark_df
    except Exception as e:
        raise Exception("Table details config file not found. Please check...", str(e))

# COMMAND ----------

def write_stage_full(final_df, table_name, stage_full_table_name, load_type, buz_keys, format_type = "delta"):
    try:
        if load_type == "FullLoad":
            df = read_table_to_df(table_name)
            df.write.format(format_type).mode("overwrite").saveAsTable(f'{stage_full_table_name}')

        elif load_type == "DeltaLoad":
            final_add_df = final_df.filter(col('IND1')=="ADD")
            final_del_df = final_df.filter(col('IND1')=="DEL")

            StageFullTable= DeltaTable.forName(spark, stage_full_table_name)
    
            cond_list = []
            for key in buz_keys:
                cond_list.append('Tgt.'+key+'='+'Src.'+key)
            conditions = ' and '.join(cond_list)

            StageFullTable.alias('Tgt')\
                .merge(final_del_df.alias('Src'), conditions)\
                .whenMatchedDelete(condition = "Src.IND1='DEL'")\
                .execute()

            StageFullTable.alias('Tgt')\
                .merge(final_add_df.alias('Src'), conditions)\
                .whenNotMatchedInsertAll(condition = "Src.IND1='ADD'")\
                .execute()


    except Exception as e:
        raise Exception("stage table update failed: ", str(e))
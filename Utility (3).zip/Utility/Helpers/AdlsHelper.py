# Databricks notebook source
# DBTITLE 1,Run EnvironmentVariableHelper notebook.
# MAGIC %run ./EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Configuration cell.
application_id = dbutils.secrets.get(scope = env_scope, key = env_app_id_key)
service_credential = dbutils.secrets.get(scope=env_scope, key=env_secret_key)
directory_id = env_directory_id
storage_account_name = env_storage_account_name

# COMMAND ----------

# DBTITLE 1,Set spark configuration.
spark.conf.set(f"fs.azure.account.auth.type.{storage_account_name}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account_name}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account_name}.dfs.core.windows.net", application_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account_name}.dfs.core.windows.net", service_credential)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account_name}.dfs.core.windows.net", f"https://login.microsoftonline.com/{directory_id}/oauth2/token")
# Databricks notebook source
# DBTITLE 1,Import ADLS connection notebook
# MAGIC %run ./AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook.
# MAGIC %run ../Load

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import col, max 
from delta.tables import DeltaTable

# COMMAND ----------

# DBTITLE 1,Create variable to get parameter values.
dbutils.widgets.text('SQL_TABLE_NAME','')
dbutils.widgets.text('STAGE_TABLE_NAME','')
dbutils.widgets.text('MERGE_KEY','')
dbutils.widgets.text('PROCESS_NAME','')
dbutils.widgets.text('CONTROL_TABLE_NAME','')
dbutils.widgets.text('READ_NUM_PARTITION','')
dbutils.widgets.text('PIPELINE_RUN_ID','')

sql_tbl_name = dbutils.widgets.get('SQL_TABLE_NAME')
stg_tbl_name = dbutils.widgets.get('STAGE_TABLE_NAME')
merge_key = dbutils.widgets.get('MERGE_KEY')
proc_name = dbutils.widgets.get('PROCESS_NAME')
ctrl_tbl_name = dbutils.widgets.get('CONTROL_TABLE_NAME')
read_num_part = dbutils.widgets.get('READ_NUM_PARTITION')
pipeline_run_id = dbutils.widgets.get('PIPELINE_RUN_ID')

# COMMAND ----------

# DBTITLE 1,Read control table and filter max StartDateTime.
try:
    # Read control table and filter records when ProcessName = current process name and status = success.
    static_tbl_df = read_table_to_df(ctrl_tbl_name)\
                    .filter((col("ProcessName") == proc_name) & (col('Status') == 'Success'))
    # Get last sucess run max StartDateTime for current process from above dataframe and assign it to a variable.
    max_start_date = (
        static_tbl_df
        .select(max("StartDatetime").alias('StartDatetime'))
        .collect()[0]["StartDatetime"]
    )
except Exception as e:
    excep = "Read control table and filter max StartDateTime failed :"+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Read stage table.
try:
    # Read data from stage table.
    stg_df = read_table_to_df(stg_tbl_name)
except Exception as e:
    excep = "Read stage table failed :"+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,This function used to compute count, min and max of a input column in a SQL table.
def compute_aggr_metrics_from_sql_table(tbl_name, col_name):
    try:
        query = f"SELECT COUNT(1) as TotalCount, MIN({col_name}) as MinValue, MAX({col_name}) as MaxValue FROM {tbl_name}"
        aggr_df = read_sf_sql_tbl_to_df_spark(query = query).collect()
        # Get total count, min value and max value from dataframe and assign to variables.
        tot_cnt, min_val, max_val = aggr_df[0].TotalCount, aggr_df[0].MinValue, aggr_df[0].MaxValue
        return tot_cnt, min_val, max_val
    except Exception as e:
        excep = "compute_aggr_metrics_from_sql_table failed: "+ str(e)
        dbutils.notebook.exit(excep)


# COMMAND ----------

# DBTITLE 1,compute count, min and max from SQL table.
try:
    # Calcuate total count, min value and max value of the surroget key to utilize distributed processing.
    tbl_tot_count, min_val, max_val = compute_aggr_metrics_from_sql_table(sql_tbl_name, merge_key)
except Exception as e:
    excep = "Read data from SQL table failed :"+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Read data from SQL table.
try:
    is_delta_load = False
    # if max date for the last success run is present and stage table is not empty. then it is going to be a delta load
    if max_start_date and len(stg_df.head(1)) != 0:
        proc_date = max_start_date
        # Create a query to retrive records that have been modified and newly inserted since the previous run.
        query = f"""SELECT * FROM {sql_tbl_name} WHERE CreatedDateTime > '{proc_date}'
                UNION
                SELECT * FROM {sql_tbl_name} WHERE ModifiedDateTime > '{proc_date}'
                """

        src_df = read_sf_sql_tbl_to_df_spark(query = query)
        is_delta_load = True
        # Since multiple action are going to be performed on the same dataframe, cache it
        src_df.cache()
    else:
        # If previous run entry is not exists then fetch all the data from the SQL table.
        src_df = read_sf_sql_tbl_to_df_spark(tbl_name = sql_tbl_name, part_col = merge_key, low_bnd = min_val, upp_bnd = max_val, num_part = read_num_part)
except Exception as e:
    excep = "Read data from SQL table failed :"+ str(e)
    dbutils.notebook.exit(excep)


# COMMAND ----------

# DBTITLE 1,Merge data to stage table.
try:
    # If previous run entry exists and there is no data to merge stage table then skip the write process. 
    if is_delta_load and (max_start_date and len(src_df.head(1)) == 0):
        print(f"Data is up to date in {stg_tbl_name}")
    # If the delta data is present then merge to stage table.
    elif max_start_date and len(stg_df.head(1)) != 0:
        trgt_dlt_tbl = DeltaTable.forName(spark, stg_tbl_name)
        (trgt_dlt_tbl.alias('target').merge(src_df.alias('source'), f"source.{merge_key} = target.{merge_key}")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute())
    # If it is first run copy all data from SQL table and merge it to Stage table.
    else:
        write_df_as_delta_table(src_df, stg_tbl_name)
except Exception as e:
    excep = "Merge data to stage table failed :"+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Removing deleted records from Stage tables.
try:
    # If it's a full load or if no records are deleted in the SQL table, then skip the deletion process.
    if (is_delta_load == False) or (tbl_tot_count == stg_df.count() and len(src_df.head(1)) == 0):
        print(f"No records to be deleted in stage table")
    else:
        # Create query to fetch surroget key of a table.
        prm_key_query = f"""(SELECT {merge_key} FROM {sql_tbl_name}) as subq"""
        prm_key_df = read_sf_sql_tbl_to_df_spark(tbl_name = prm_key_query, part_col = merge_key, low_bnd = min_val, upp_bnd = max_val, num_part = read_num_part)

        # Target keys which are not matched by source then delete it from stage table.
        trgt_dlt_tbl = DeltaTable.forName(spark, stg_tbl_name)
        (trgt_dlt_tbl.alias('target').merge(prm_key_df.alias('source'), f"source.{merge_key} = target.{merge_key}")
        .whenNotMatchedBySourceDelete()
        .execute())
except Exception as e:
    excep = "Merge data to stage table failed :"+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Unpersist Dataframe.
src_df.unpersist()

# COMMAND ----------

# DBTITLE 1,Exit notebook with success status.
dbutils.notebook.exit('Success')
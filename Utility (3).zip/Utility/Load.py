# Databricks notebook source
# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import required packages.
import json
import pandas as pd

# COMMAND ----------

# DBTITLE 1,Configuration cell.
#config for servicefund sql database
sf_user = dbutils.secrets.get(scope = env_scope , key = env_app_id_key)
sf_password = dbutils.secrets.get(scope = env_scope , key = env_secret_key)
sf_db_host = env_sf_server_address
sf_db_name = env_sf_db_name
server_address = env_sf_server_address
server_name = "jdbc:sqlserver://" + server_address
sf_url = server_name + ";" + "databaseName=" + sf_db_name + ";"

# COMMAND ----------

# DBTITLE 1,Write dataframe to service fund SQL table using jdbc connector.
def load_df_to_sf_sql_db_jdbc(df, tbl_name, writeMode = 'append', auth = "ActiveDirectoryServicePrincipal", batch_size = "10000"):
    try:
        """
        Description:
        This function writes dataframe into Azure SQL using JDBC Connector.  
        JDBC connector doesn't capable of keep identity on while loading.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string].
        :param write_mode: [Type: string].
        :param auth: [Type: string].
        :param batch_size: [Type: string] Number of rows in each batch. At the end of each batch, the rows in the batch are sent to the server.
        """
        (df.write
            .format("sqlserver")
            .mode(writeMode)
            .option("host", sf_host)
            .option("authentication", auth)
            .option("user", sf_user)
            .option("batchsize", batch_size)
            .option("password", sf_password)
            .option("database", sf_db_name)
            .option("dbtable", tbl_name) # (if schemaName not provided, default to "dbo")
            .save())
    except Exception as e:
        raise Exception ('loadSQL failed',str(e))

# COMMAND ----------

# DBTITLE 1,Write dataframe to service fund SQL table using spark connector.
def load_df_to_sf_sql_db_spark(df, tbl_name, write_mode = 'append', auth = "ActiveDirectoryServicePrincipal", keep_iden = True, tab_lock = True, relbty_level = 'BEST_EFFORT'):
    try:
        """
        Description:
        This function writes dataframe into Azure SQL using SPARK Connector.  
        Spark connector capable of keep identity on while loading.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string].
        :param write_mode (optional): [Type: string].
        :param auth (optional): [Type: string].
        :param keep_iden (optional): [Type: string] This one used to turn on the identity_insert of the respective table.
        :param tab_lock (optional): [Type: string] Implements an insert with TABLOCK option to improve write performance.
        :param relbty_level (optional): [Type: string] implements an reliable insert in executor restart scenarios.
        """
        df.write\
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .mode(write_mode) \
            .option("url", sf_url) \
            .option("authentication", auth)\
            .option("user", sf_user) \
            .option("password", sf_password) \
            .option("dbtable", tbl_name) \
            .option("KeepIdentity", keep_iden) \
            .option("TableLock", tab_lock) \
            .option("reliabilityLevel", relbty_level)\
            .save()
    except Exception as e:
        raise Exception ('loadSQL failed ',str(e))

# COMMAND ----------

# DBTITLE 1,Read service fund SQL table to dataframe using spark connector.
# port is optional, can use default port 1433 if omittedpor
def read_sf_sql_tbl_to_df_spark(tbl_name=None, query=None, part_col = None, low_bnd = None, upp_bnd = None, num_part = None,auth="ActiveDirectoryServicePrincipal"):
    """
        Description:
        This function used to read data from Azure SQL table using SPARK Connector.
        :param tbl_name (optional): [Type: string] 	The table that should be read from.
        :param query (optional): [Type: string] A query that will be used to read data into Spark.

        partitionColumn, lowerBound, upperBound - These options must all be specified if any of them is specified. In addition, numPartitions must be specified.

        :param part_col (optional): [Type: string] partitionColumn must be a numeric, date, or timestamp column from the table.
        :param low_bnd (optional): [Type: string].
        :param upp_bnd (optional): [Type: string].
        :param num_part (optional): [Type: string] The maximum number of partitions that can be used for parallelism in table reading.
        :param auth (optional): [Type: string].
        :return 
        """
    try:
        config = {"url":sf_url , "authentication":auth, "user":sf_user, "password":sf_password}
        if tbl_name:
            config["dbtable"] = tbl_name
            if low_bnd and upp_bnd and part_col and num_part:
                config["partitionColumn"], config["lowerBound"], config["upperBound"], config["numPartitions"] = part_col, int(low_bnd), int(upp_bnd), int(num_part)
        elif query:
            config["query"] = query
            if num_part:
                config["numPartitions"] = int(num_part)
            if low_bnd and upp_bnd and part_col:
                raise Exception("The part_Col, low_bnd and upp_bnd cannot be passed along with the query argument.")
        else:
            raise Exception("Invalid SQL table details")
        remote_table = (
            spark.read.format("com.microsoft.sqlserver.jdbc.spark")
            .options(**config).load()
        )
        return remote_table
    except Exception as e:
        raise Exception("read_table_spark: ", str(e))

# COMMAND ----------

def write_to_curated(df,tablename, format="delta", write_mode="overwrite"):
    try:
        df.write.format(format).mode(write_mode).saveAsTable(tablename)
    except Exception as e:
        raise Exception("write_to_curated ",str(e))

# COMMAND ----------

# DBTITLE 1,Write data to stage layer
def write_to_stage(df,tablename, format="delta", write_mode="overwrite"):
    try:
        df.write.format(format).mode(write_mode).saveAsTable(tablename)
    except Exception as e:
        raise Exception("write_to_stage ",str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2443
# MAGIC ##### Curated Tables
# MAGIC - Accounting.StoplossFund
# MAGIC ##### Target Table
# MAGIC - Accounting.StoplossFund

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRE2443"
buz_keys = ['RuleTyCd','RuleTblTyCd','RuleTblId','StoplsFundTyCd','StoplsEndCymDt','StoplsBegCymDt']
not_null_col_lst = ['StoplossDetailKey']
table_code = 'Accounting_StoplossFund'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Accounting_StoplossFund')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    stop_loss_detail_tbl_name = table_name_selector(tbl_conf_df, 'Accounting_StoplossDetail')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2443_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    tre2443_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    stoploss_df = read_table_to_df(stop_loss_detail_tbl_name)\
        .select('StoplossDetailKey','StoplossId','StoplossRuleTypeCode','StoplossRuleCategoryCode')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,column mapping db2 to cloud columns
#column mapping db2 to cloud columns
col_mapping = {
'ProvBreakInd' : 'ProviderBreakIndicator',
'StoplsBasisCd' : 'StoplossBasisCode',
'StoplsEndCymDt' : 'StoplossEffectiveEndDate',
'StoplsBegCymDt' : 'StoplossEffectiveStartDate',
'StoplsFundTyCd' : 'StoplossFundTypeCode',
'StoplsLimAmt' : 'StoplossLimitAmount',
'StoplsLimPct' : 'StoplossLimitPercent',
'UnifyFundTyCd1' : 'UnifyFundType1Code',
'UnifyFundTyCd2' : 'UnifyFundType2Code',
'UnifyFundTyCd3' : 'UnifyFundType3Code',
'StoplsSortCd' : 'StoplossSortCode',
'RedirFundTyCd' : 'RiderFundTypeCode',
'RuleTblId' : 'StoplossId',
'RuleTyCd' : 'StoplossRuleTypeCode',
'RuleTblTyCd' : 'StoplossRuleCategoryCode',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Data type conversion
schema = {
          'StoplossLimitAmount':'DECIMAL(20,6)',
          'StoplossLimitPercent':'DECIMAL(10,5)'
          }

# COMMAND ----------

# DBTITLE 1,Column mapping, adding audit columns and joining with StoplossDetail
# adding audit columns and joining with StoplossDetail
try:
    col_mapped_df = col_name_mapping(tre2443_stage_df, col_mapping)
    tre2443_joined_df = col_mapped_df.alias('LH').join(stoploss_df.alias('RH'),\
        (col('LH.StoplossId') == col('RH.StoplossId')) & (col('LH.StoplossRuleTypeCode') == col('RH.StoplossRuleTypeCode')) & (col('LH.StoplossRuleCategoryCode') == col('RH.StoplossRuleCategoryCode')),'inner')\
    .select('LH.*','RH.StoplossDetailKey')
    col_added_df = add_tgt_audit_column(tre2443_joined_df, PIPELINE_NAME, LOAD_TYPE)
    dtype_chng_df = dtype_tgt_conversion(col_added_df, schema)
except Exception as e:
    raise Exception('joining or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Date format conversion
# Convert CYM to date
start_date_df = dt_format_cym(dtype_chng_df, ['StoplossEffectiveStartDate'], 'start')
end_date_df = dt_format_cym(start_date_df, ['StoplossEffectiveEndDate'], 'end')

# COMMAND ----------

# DBTITLE 1,filtering valid records
try:
    final_stage_df = remove_invalid_records(end_date_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('StoplossId','StoplossRuleTypeCode','StoplossRuleCategoryCode')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Load data into curated layer and SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        Stoploss_Fund_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(Stoploss_Fund_df, 'Accounting.StoplossFund')

        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['StoplossDetailKey', 'StoplossEffectiveStartDate', 'StoplossEffectiveEndDate', 'StoplossFundTypeCode']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "StoplossFundKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'StoplossFundKey':lit(None).cast("BIGINT"),
        'StoplossDetailKey':lit(None).cast("BIGINT"),
        'DeltaStatus':lit(None).cast('STRING')
        }
        mapped_df= final_stage_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageStoplossFund')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e)) 
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2395
# MAGIC ##### Curated Tables
# MAGIC - Accounting.SettlementDetail
# MAGIC ##### Target Table
# MAGIC - Accounting.SettlementDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRE2395"
buz_keys = ['SetlTblId']
table_code = 'Accounting_SettlementDetail'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_SettlementDetail')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2395_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load tables into data frames
#Reading data from stage table & filtering the valid records
try:
    tre2395_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Column mapping between stage and curated tables
#column mapping with domain tables
col_mapping={
'SetlAnnChkCd':'AnnCheckCode'
,'SetlDefcBfwdInd':'DeficitBroughtForwardIndicator'
,'SetlTblDelInd':'DeleteIndicator'
,'SetlFreqCd':'FrequencyCode'
,'FundDefcRiskPct':'FundDeficitRiskPercent'
,'FundProvRiskPct':'FundProviderRiskPercent'
,'SetlXferFundCd':'FundTransferCode'
,'SetlXferSeqNbr':'FundXRefSequenceNumber'
,'LagAnnMoCnt':'LagAnnMonthCount'
,'LimPayFundTyCd':'LimitPayFundTypeCode'
,'SetlLimPayInd':'LimitPayIndicator'
,'LimPayMaxAmt':'LimitPayMaximumAmount'
,'LimPayMthdCd':'LimitPayMethodCode'
,'LimPayMinAmt':'LimitPayMinimumAmount'
,'SetlLimPayPct':'LimitPayPercent'
,'OrdShrGrpActCd':'OrdShrGroupActCode'
,'SetlPayChkCd':'PayCheckCode'
,'SetlTblId':'SettlementId'
,'SetlLagMoCnt':'SettlementLagMonthCount'
,'SetlMthdCd':'SettlementMethodCode'
,'SetlTmRiskCd':'TMRiskCode'
,'DerivedIndicator':'DerivedIndicator'
}

# COMMAND ----------

# DBTITLE 1,Schema Definition for unmatched columns
# Some decimal columns have a different precision than what is expected in the curated layer. Delta columns need to have the same precision or it complains about it. This is the schema definition for the columns which don't match up.
dtype_mapping = {
          'LagAnnMonthCount' : 'INTEGER',
          'FundDeficitRiskPercent' : 'decimal(10,5)',
          'FundProviderRiskPercent' : 'decimal(10,5)',
          'FundXRefSequenceNumber' : 'INTEGER',
          'LimitPayMaximumAmount' : 'decimal(20,6)',
          'LimitPayMinimumAmount' : 'decimal(20,6)',
          'LimitPayPercent' : 'decimal(10,5)',
          'SettlementLagMonthCount' : 'INTEGER'
}

# COMMAND ----------

# DBTITLE 1,data type converstion and adding audit columns
#data type converstion and adding audit columns
try:
    col_mapped_df = add_tgt_audit_column(col_name_mapping(tre2395_stage_df,col_mapping), PIPELINE_NAME,LOAD_TYPE)
    dtype_converted_df1 = dtype_tgt_conversion(col_mapped_df, dtype_mapping)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(dtype_converted_df1,cur_tbl_name)
        cur_loaded_time = datetime.now()

        Settlement_Detail_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(Settlement_Detail_df, 'Accounting.SettlementDetail')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['SettlementId']
        delta_operate(cur_tbl_name,dtype_converted_df1,conditions, table_code, tbl_conf_df, child_tbl_config_path, "SettlementDetailKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'SettlementDetailKey':lit(None).cast("BIGINT"),
        'DeltaStatus':lit(None).cast('STRING')
        }
        mapped_df= dtype_converted_df1.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageSettlementDetail')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed: ',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates Accounting Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Adls connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transformation functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Accounting{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementHeaderFrequency

# COMMAND ----------

settlement_header_frequency = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementHeaderFrequency(
SettlementHeaderFrequencyKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
FrequencyId STRING NOT NULL,
FrequencyName STRING,
LagMonthCount INTEGER,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL, 
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementHeaderFrequency'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementDetail

# COMMAND ----------

settlement_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementDetail(
SettlementDetailKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null
,SettlementId STRING
,DeleteIndicator STRING
,SettlementLagMonthCount INTEGER
,SettlementMethodCode STRING
,DeficitBroughtForwardIndicator STRING
,FundTransferCode STRING
,FundXRefSequenceNumber INTEGER
,FundProviderRiskPercent Decimal(10,5)
,OrdShrGroupActCode STRING
,LimitPayIndicator STRING
,LimitPayMethodCode STRING
,LimitPayFundTypeCode STRING
,LimitPayPercent Decimal(10,5)
,LimitPayMinimumAmount Decimal(20,6)
,LagAnnMonthCount INTEGER
,PayCheckCode STRING
,AnnCheckCode STRING
,TMRiskCode STRING
,FrequencyCode STRING
,FundDeficitRiskPercent Decimal(10,5)
,LimitPayMaximumAmount Decimal(20,6)
,DerivedIndicator STRING
,CreatedBy STRING NOT NULL
,CreatedDateTime TIMESTAMP NOT NULL
,ModifiedBy STRING
,ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### FinanceLedgerHeader

# COMMAND ----------

finance_ledger_header = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_FinanceLedgerHeader(
FinanceLedgerHeaderKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) not null,
CASLineOfBusinessCode STRING,
CASMarketNumber STRING,
CASNetworkNumber INT,
CASProviderNetworkNumber INT,
FinanceLedgerGeographicCode STRING,
FinanceLedgerName STRING,
FinancialLedgerCode STRING,
HMPVsNonHMPIndicator STRING,
LedgerApproverName STRING,
LedgerDescription STRING,
LedgerNumber INT,
LedgerStatusCode STRING,
LineOfBusinessCode STRING,
WithholdPerGrouperIndicator STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
LedgerStatusDate DATE,
FinanceNetVsGrossCode STRING,
GateKeeperLedgerIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/FinanceLedgerHeader'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementLedger

# COMMAND ----------

settlement_ledger = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementLedger(
SettlementLedgerKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
FinanceLedgerGeoCode STRING,
SettlementLedgerNumber INT,
SettlementContractId STRING,
SettlementLedgerRunCode STRING,
SettlementAnnualTypeCode STRING,
SettlementPeriodTypeCode STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementLedger'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### StoplossRule

# COMMAND ----------

stop_loss_rule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_StoplossRule(
	StoplossRuleKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) ,
	StoplossRuleTypeCode STRING,
	StoplossRuleCategoryCode STRING,
    DerivedIndicator STRING,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP
  )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/StoplossRule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### AdjustmentControl

# COMMAND ----------

adjustment_control = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_AdjustmentControl(
AdjustmentControlKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
AdjustmentDate DATE,
AdjustmentSequenceNumber INT,
AdjustmentStatusCode STRING,
AdjustmentTotalAmount DECIMAL(20,6),
AdjustmentStatusDate DATE,
AdjustmentUpdatedBy STRING,
AdjustmentApprovedBy STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/AdjustmentControl'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### MemberStoploss

# COMMAND ----------

member_stop_loss= f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_MemberStoploss(
MemberStoplossKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
MemberId VARCHAR(50),
SourceSystemCode VARCHAR(20),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/MemberStoploss'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementRule

# COMMAND ----------

settlement_rule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementRule(
SettlementRuleKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementRuleId STRING,
SettlementRuleName STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementRule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementControlDetail

# COMMAND ----------

settlement_control_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementControlDetail(
SettlementControlDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementControlId	STRING,
SettlementControlName	STRING,
SettlementHeaderFrequencyKey BIGINT NOT NULL,
SettlementRuleKey BIGINT NOT NULL,
ContractCategoryCode	STRING,
DerivedIndicator STRING,
CreatedBy	STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
EndDate	DATE,
LagMonthCount	STRING,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
NextTrailIndicator	STRING,
NextTrailRuleCode	STRING,
StartDate	DATE,
FrequencyId STRING NOT NULL,
SettlementRuleId STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementControlDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementSchedule

# COMMAND ----------

settlement_schedule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementSchedule(
SettlementScheduleKey	BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementRuleKey	BIGINT NOT NULL,
ContractLineOfBusinessCode STRING,
ContractTypeCode STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
SettlementRuleId STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementSchedule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementProviderContract

# COMMAND ----------

settlement_provider_contract = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementProviderContract(
SettlementProviderContractKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementControlDetailKey BIGINT NOT NULL,
PaymentContractKey BIGINT NOT NULL, 
FinanceLedgerGeoMarketCode STRING,
FinanceLedgerNumber INT,
PaymentContractId STRING,
PaymentContractName STRING,
ProductLineOfBusinessCode STRING,
ProviderContractDescription STRING,
ProviderContractId STRING,
ProviderContractKey BIGINT NOT NULL,
ProviderGrouperId STRING,
ProviderGrouperName STRING,
SettlementContractId STRING,
SettlementContractKey BIGINT NOT NULL,
SettlementControlId STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementProviderContract'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementContractFund

# COMMAND ----------

settlement_contract_fund = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementContractFund(
SettlementContractFundKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementProviderContractKey BIGINT NOT NULL,
CatastrophicWithholdAmount Decimal(20,6),
ExpenseMemberMonthCount	INT,
FinalPaymentAmount	Decimal(20,6),
FundAmount Decimal(20,6),
FundBeginDate DATE,
FundBroughtForwardAmount Decimal(20,6),
FundCapitationAmount Decimal(20,6),
FundCapitationExpenseAmount Decimal(20,6),
FundClaimBenefitAmount Decimal(20,6),
FundClaimDiscountAmount Decimal(20,6),
FundClaimExpenseAmount Decimal(20,6),
FundCloseDate DATE,
FundDirectPaymentAmount Decimal(20,6),
FundEndDate DATE,
FundIBNRAmount Decimal(20,6),
FundLateClaimAmount Decimal(20,6),
FundMemberMonthCount INT,
FundNetAccountAmount Decimal(20,6),
FundPriorBroughtForwardAmount Decimal(20,6),
FundProviderRiskAmount Decimal(20,6),
FundReconciliationAmount Decimal(20,6),
FundSettlementAmount Decimal(20,6),
FundStatusCode STRING,
FundStatusDate DATE,
FundTransferInAmount Decimal(20,6),
FundTransferOutAmount Decimal(20,6),
FundTypeCode STRING,
FundWithholdClaimAmount Decimal(20,6),
OtherFundAmount Decimal(20,6),
StoplossExcessAmount Decimal(20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementContractFund'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementLimitGuarantee

# COMMAND ----------

settlement_limit_guarantee = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementLimitGuarantee(
SettlementLimitGuaranteeKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementRuleCodeDetailKey BIGINT NOT NULL,
FlipIndicator STRING,
FundMethodCode STRING,
FundPercentNumber DECIMAL(10,5),
FundTypeCode STRING,
LimitGuaranteeAmount DECIMAL(20,6),
LimitGuaranteeIndicator STRING,
RuleCodeLineNumber INT,
SurplusDeficitIndicator STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
SrdtFundTypeCode STRING,
FundSequenceNumber INTEGER,
SettlementRuleCode STRING,
SettlementRuleId STRING,
ContractLineOfBusinessCode STRING,
ContractTypeCode STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementLimitGuarantee'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ManualAdjustment

# COMMAND ----------

manual_adjustment = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_ManualAdjustment(
ManualAdjustmentKey	BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
AdjustmentControlKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
ContractExpenseKey BIGINT,
AdjustmentSequenceNumber INT,
FundAdjustmentReferenceNumber INT,
FundTypeCode STRING,
FundMonthDate STRING,
FundAdjustmentStatusCode STRING,
FundAdjustmentStatusDate DATE,
FundAdjustmentTypeCode STRING,
FundAdjustmentReasonCode STRING,
FundManualAdjustmentAmount DECIMAL(20,6),
FundIMMCKIndicator STRING,
FundAdjustmentGLIndicator STRING,
AdjustmentDebitAccountNumber INT,
AdjustmentCreditAccountNumber INT,
FundAdjustmentReasonComment STRING,
TransactionTypeCode STRING,
ClaimIncuredDate DATE,
CASClaimNumber STRING,
AutoExpOvIndicator STRING,
AdverseUnmatchCode STRING,
CostAllocationAccountCode STRING,
ICSNumber STRING,
ICSSuffixCode STRING,
SourceSystemCode STRING NOT NULL,
MemberId STRING NOT NULL,
MemberCustomerNumber STRING NOT NULL,
ProgramCode STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
SettlementRuleId STRING,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/ManualAdjustment'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### FinanceLedgerFundPeriod

# COMMAND ----------

finance_ledger_fund_period= f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_FinanceLedgerFundPeriod(
FinanceLedgerFundPeriodKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
FinanceLedgerHeaderKey BIGINT NOT NULL,
ApproverFullName STRING,
FundExpenseCode STRING,
FundPeriodBeginDate DATE,
FundPeriodEndDate DATE,
FundPeriodStatusCode STRING,
FundStatusChangeDate DATE,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
FundPeriodAccountCode STRING,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/FinanceLedgerFundPeriod'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementLineFrequency

# COMMAND ----------

settlement_line_frequency = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementLineFrequency(
SettlementLineFrequencyKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementHeaderFrequencyKey BIGINT NOT NULL,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
FrequencyMonthCount INT,
FrequencyPaymentIndicator STRING,
FrequencyRuleCode STRING,
DerivedIndicator STRING,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementLineFrequency'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### StoplossDetail

# COMMAND ----------

stop_loss_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_StoplossDetail(
StoplossDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
StoplossRuleKey BIGINT NOT NULL,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
StoplossDescription STRING,
StoplossId STRING,
StoplossRuleTypeCode STRING,
StoplossRuleCategoryCode STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/StoplossDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### StoplossFund

# COMMAND ----------

stop_loss_fund = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_StoplossFund(
StoplossFundKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
StoplossDetailKey BIGINT NOT NULL,
CreatedBy STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
ProviderBreakIndicator STRING,
StoplossBasisCode STRING,
StoplossEffectiveEndDate DATE,
StoplossEffectiveStartDate DATE,
StoplossFundTypeCode STRING,
StoplossLimitAmount	DECIMAL(20,6),
StoplossLimitPercent DECIMAL(10,5),
UnifyFundType1Code STRING,
UnifyFundType2Code STRING,
UnifyFundType3Code STRING,
StoplossSortCode STRING,
RiderFundTypeCode STRING,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/StoplossFund'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### StoplossException

# COMMAND ----------

stop_loss_exception = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_StoplossException(
StoplossExceptionKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
StoplossDetailKey BIGINT NOT NULL,
MemberStoplossKey BIGINT NOT NULL,
ExceptionStartDate DATE,
ExceptionEndDate DATE,
CauseCategoryCode STRING,	
RiderFundTypeCode STRING,	
ICDVersion STRING,
ICDDiagnosisFromCode STRING,
ICDDiagnosisToCode STRING,
CASClaimNumber STRING,
ExceptionComment STRING,
ExceptionUsageIndicator STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
MemberCustomerNumber STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/StoplossException'"""

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ### SettlementRuleCode

# COMMAND ----------

settlement_rule_code = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementRuleCode(
SettlementRuleCodeKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementScheduleKey BIGINT NOT NULL,
SettlementRuleCode STRING,
SettlementRuleCodeLabel STRING,
SettlementRuleId STRING,
ContractLineOfBusinessCode STRING,
ContractTypeCode STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementRuleCode'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ClaimStoploss

# COMMAND ----------

claim_stop_loss = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_ClaimStoploss(
ClaimStoplossKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
MemberStoplossKey BIGINT NOT NULL,
CASClaimNumber STRING,
StoplossClaimAmount DECIMAL(20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/ClaimStoploss'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementRuleCodeDetail

# COMMAND ----------

settlement_rule_code_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementRuleCodeDetail(
SettlementRuleCodeDetailKey	BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementRuleCodeKey BIGINT NOT NULL,
DeficitCarryForwardIndicator STRING,
FundPeriod1Code STRING,
FundPeriod2Code STRING,
FundPeriod3Code STRING,
FundSequenceNumber INTEGER,
FundTypeCode STRING,
LimitGuaranteeOrderNumber INTEGER,
PeriodUnifyOrderNumber INTEGER,
RiskDeficitPercentNumber DECIMAL(10,5),
RiskSurplusPercentNumber DECIMAL(10,5),
SettlementMethodCode STRING,
WorkerFundIndicator STRING,
TransferFundTypeCode STRING,
SettlementRuleCode STRING,
SettlementRuleId STRING,
ContractLineOfBusinessCode STRING,
ContractTypeCode STRING,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementRuleCodeDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderStoploss
# MAGIC

# COMMAND ----------

ProviderStoploss = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_ProviderStoploss(
	ProviderStoplossKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
	ProviderContractId STRING,
	ProviderId STRING,
	ProviderSuffixCode STRING,
	ProviderServiceTypeCode STRING,
	ProviderSequenceNumber STRING,
    DerivedIndicator STRING,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/ProviderStoploss' """

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementScheduleControl

# COMMAND ----------

settlement_schedule_control = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementScheduleControl(
SettlementScheduleControlKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementControlDetailKey BIGINT NOT NULL,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
ScheduleControlId STRING,
ScheduleControlName STRING,
ControlStatusActivityCode STRING,
SettlementControlId STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementScheduleControl'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### FundStoploss

# COMMAND ----------

FundStoploss = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_FundStoploss(
	FundStoplossKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
	ProviderStoplossKey BIGINT NOT NULL,
	MemberStoplossKey BIGINT NOT NULL,
	StoplossBeginDate DATE NOT NULL,
	FundTypeCode STRING,
	StoplossClaimAmount DECIMAL(20, 6),
	UnifyFundIndicator STRING,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP NOT NULL,
	DerivedIndicator STRING
 )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/FundStoploss' """

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementTaxIdentifier

# COMMAND ----------

settlement_tax_identifier = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementTaxIdentifier(
SettlementTaxIdKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
SettlementLimitGuaranteeKey BIGINT NOT NULL,
TaxId STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING,
FundTypeCode STRING,
RuleCodeLineNumber INT
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementTaxIdentifier'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementSchedulePayment

# COMMAND ----------

settlement_schedule_payment = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.accounting_SettlementSchedulePayment(
    SettlementSchedulePaymentKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
    SettlementScheduleControlKey BIGINT NOT NULL,
    DerivedIndicator STRING,
    SchedulePaymentContractId STRING,
    SchedulePaymentContractName STRING,
    ContractActionCode STRING,
    CreatedBy STRING NOT NULL,
    CreatedDateTime TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/accounting/curated/SettlementSchedulePayment' """

# COMMAND ----------

tbl_mapping = {
"accounting_SettlementHeaderFrequency" : settlement_header_frequency,
"accounting_SettlementDetail": settlement_detail,
"accounting_FinanceLedgerHeader": finance_ledger_header,
"accounting_SettlementLedger": settlement_ledger,
"accounting_StoplossRule": stop_loss_rule,
"accounting_AdjustmentControl": adjustment_control,
"accounting_MemberStoploss": member_stop_loss,
"accounting_SettlementRule": settlement_rule,
"accounting_SettlementControlDetail": settlement_control_detail,
"accounting_SettlementSchedule": settlement_schedule,
"accounting_FinanceLedgerFundPeriod": finance_ledger_fund_period,
"accounting_SettlementLineFrequency": settlement_line_frequency,
"accounting_StoplossDetail": stop_loss_detail,
"accounting_StoplossFund": stop_loss_fund,
"accounting_StoplossException": stop_loss_exception,
"accounting_SettlementRuleCode": settlement_rule_code,
"accounting_ClaimStoploss": claim_stop_loss,
"accounting_SettlementRuleCodeDetail": settlement_rule_code_detail,
"accounting_ProviderStoploss": ProviderStoploss,
"accounting_FundStoploss":FundStoploss,
"accounting_SettlementProviderContract": settlement_provider_contract,
"accounting_SettlementContractFund": settlement_contract_fund,
"accounting_SettlementLimitGuarantee":settlement_limit_guarantee,
"accounting_ManualAdjustment": manual_adjustment,
"accounting_SettlementScheduleControl": settlement_schedule_control,
"accounting_SettlementTaxIdentifier" : settlement_tax_identifier,
"accounting_SettlementSchedulePayment": settlement_schedule_payment
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
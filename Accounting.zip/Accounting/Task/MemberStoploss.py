# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2365
# MAGIC ##### Curated Tables
# MAGIC - Accounting.MemberStoploss
# MAGIC ##### Target Table
# MAGIC - Accounting.MemberStoploss

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRE2365"
buz_keys = ['MbrPid']
table_code = 'Accounting_MemberStoploss'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_MemberStoploss')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("Table Not Found",str(e))


# COMMAND ----------

#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2365_schema, buz_keys,reject_dup="KeepOne")
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

#Reading data from stage table & filtering the valid records
try:
    tre2365_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')\
        .filter(trim(col('MbrPid'))!='')
except Exception as e:
    raise Exception("validation failed",str(e))  

# COMMAND ----------

#column mapping db2 to cloud columns
MemberStoploss_schema = {
   'MbrPid':'MemberId',
   'PltfmCd':'SourceSystemCode',
   'DerivedIndicator':'DerivedIndicator'
}

# COMMAND ----------

#data type converstion and adding audit columns
try:
    col_mapped_df = add_tgt_audit_column(col_name_mapping(tre2365_df,MemberStoploss_schema), PIPELINE_NAME ,LOAD_TYPE)
except Exception as e:
    raise Exception('adding audit col or col mapping failed: ',str(e))

# COMMAND ----------

#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(col_mapped_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        member_stoploss_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(member_stoploss_df, 'Accounting.MemberStoploss')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['SourceSystemCode', 'MemberId']
        delta_operate(cur_tbl_name,col_mapped_df,conditions, table_code, tbl_conf_df,child_tbl_config_path, "MemberStoplossKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'MemberStoplossKey':lit(None).cast("BIGINT"),
        'DeltaStatus':lit(None).cast('STRING')
        }
        mapped_df= col_mapped_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageMemberStoploss')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
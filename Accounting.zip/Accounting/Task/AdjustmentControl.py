# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2350
# MAGIC ##### Curated Tables
# MAGIC - Accounting.AdjustmentControl
# MAGIC ##### Target Table
# MAGIC - Accounting.AdjustmentControl

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRE2350"
buz_keys = ['AdjBtchSeqNbr']
table_code = 'Accounting_AdjustmentControl'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_AdjustmentControl')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,loading into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2350_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    tre2350_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Column mapping
#column mapping with domain tables
col_mapping = {
'AdjBtchCymdDt' : 'AdjustmentDate',
'AdjBtchSeqNbr' : 'AdjustmentSequenceNumber',
'AdjBtchStatCd' : 'AdjustmentStatusCode',
'AdjBtchTotAmt' : 'AdjustmentTotalAmount',
'AdjBtchStatDt' : 'AdjustmentStatusDate',
'UpdtOperInitNm' : 'AdjustmentUpdatedBy',
'ApprOperInitNm' : 'AdjustmentApprovedBy',
'DerivedIndicator':'DerivedIndicator'
}

# COMMAND ----------

# DBTITLE 1,data type conversion
# Some decimal columns have a different precision than what is expected in the curated layer. Delta columns need to have the same precision or it complains about it. This is the schema definition for the columns which don't match up.
dtype_mapping = {
          'AdjustmentTotalAmount' : 'DECIMAL(20,6)'
}

# COMMAND ----------

# DBTITLE 1,data type conversion and adding audit columns
#data type converstion and adding audit columns
try:
    col_mapped_df = add_tgt_audit_column(col_name_mapping(tre2350_stage_df,col_mapping), PIPELINE_NAME,LOAD_TYPE)
    dtype_trans_df = dtype_tgt_conversion(col_mapped_df, dtype_mapping)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(dtype_trans_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        adjustment_control_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(adjustment_control_df, 'Accounting.AdjustmentControl')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['AdjustmentSequenceNumber']
        delta_operate(cur_tbl_name,dtype_trans_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "AdjustmentControlKey")

        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'AdjustmentControlKey':lit(None).cast("BIGINT")
        }
        mapped_df= dtype_trans_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageAdjustmentControl')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
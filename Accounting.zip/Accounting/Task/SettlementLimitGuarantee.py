# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRESPLG
# MAGIC ##### Curated Tables
# MAGIC - Accounting.SettlementLimitGuarantee
# MAGIC ##### Target Table
# MAGIC - Accounting.SettlementLimitGuarantee

# COMMAND ----------

# DBTITLE 1,Running the validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRESPLG"
buz_keys = ['LimGuarGenKey']
not_null_col_lst = ['SettlementRuleCodeDetailKey']
table_code = 'Accounting_SettlementLimitGuarantee'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Accounting_SettlementLimitGuarantee')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions 
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    SettlementRuleCodeDetail_tb1_name = table_name_selector(tbl_conf_df, 'Accounting_SettlementRuleCodeDetail')
    stage_tresrdt_full_tbl_name = table_name_selector(tbl_conf_df, "ACCOUNTING_TRESRDT_FULL")
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading into stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tresplg_schema, buz_keys,stage_full="StageFull")
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage, curated tables
try:
    tresplg_stage_df = spark.table(stage_tbl_name).filter(col('Status') == 'S')
    SettlementRuleCodeDetail_df=read_table_to_df(SettlementRuleCodeDetail_tb1_name)
    tresrdt_stage_full_df = read_table_to_df(stage_tresrdt_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e))


# COMMAND ----------

# DBTITLE 1,Join with SettlementLimitGuarantee Stage Full to get LimGuarGenKey. 
# FundTypeCode, FundSequenceNumber, SettlementRuleCodeKey ( 'SettlementRuleCode','SettlementRuleId','ContractTypeCode','ContractLineOfBusinessCode')
try:
    tresrdt_keys_added_df = tresplg_stage_df.alias('LH')\
        .join(tresrdt_stage_full_df.alias('RH'),\
            (col('LH.RuleDetlGenKey')== col('RH.RuleDetlGenKey')),\
                'left')\
        .select('LH.*',col("RH.FundTyCd").alias("SrdtFundTyCd"),'RH.RuleFundSeqNbr','RH.RuleId','RH.CtrctTyCd','RH.CtrctLobCd','RH.RuleCd')
except Exception as e:
    raise Exception('joining with SettlementLimitGuarantee Set failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with SettlementRuleCodeDetail to get SettlementRuleCodeDetailKey
#Join with SettlementRuleCodeDetail to get SettlementRuleCodeDetailKey
try:
    joined_df = (
        tresrdt_keys_added_df.alias("LH")
        .join(
            SettlementRuleCodeDetail_df.alias("RH"),
            (col('LH.RuleFundSeqNbr')== col('RH.FundSequenceNumber')) 
            & (col('LH.SrdtFundTyCd')== col('RH.FundTypeCode'))
            & (col('LH.RuleId')== col('RH.SettlementRuleId'))
            & (col('LH.CtrctTyCd')== col('RH.ContractTypeCode'))
            & (col('LH.CtrctLobCd')== col('RH.ContractLineOfBusinessCode')) 
            & (col('LH.RuleCd')== col('RH.SettlementRuleCode')),
            'left',
        )
                .select("LH.*",col("RH.SettlementRuleCodeDetailKey"))
        ) 
except Exception as e:
    raise Exception("join with SettlementLimitGuarantee failed", str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping db2 to cloud columns
col_mapping = {
"RuleFundSeqNbr":"FundSequenceNumber",
'RuleCd':'SettlementRuleCode',
'RuleId':'SettlementRuleId',
'CtrctTyCd':'ContractTypeCode',
'CtrctLobCd':'ContractLineOfBusinessCode',
"FlipInd":"FlipIndicator",
"FundMthdCd":"FundMethodCode",
"FundPct":"FundPercentNumber",
"FundTyCd":"FundTypeCode",
"SrdtFundTyCd":"SrdtFundTypeCode",
"LimGuarAmt":"LimitGuaranteeAmount", # *
"LimGuarInd":"LimitGuaranteeIndicator",
"RuleCdLnNbr":"RuleCodeLineNumber",
"SettlementRuleCodeDetailKey":"SettlementRuleCodeDetailKey", # *
"SurplDefcInd":"SurplusDeficitIndicator",
"StgUnqId":"StgUnqId",
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Call the function to map the columns as per SQL
try:
    col_mapped_df = col_name_mapping(joined_df, col_mapping)
except Exception as e:
    raise Exception("column mapping failed", str(e))

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
schema={
    "FundPercentNumber":"DECIMAL(10,5)",
    "LimitGuaranteeAmount":"DECIMAL(20,6)",
    "FundSequenceNumber":"INTEGER"
}

# COMMAND ----------

# DBTITLE 1,Datatype conversion
try:
    dtype_chng_df = dtype_tgt_conversion(col_mapped_df, schema)
except Exception as e:
    raise Exception("datatype convertion failed", str(e))

# COMMAND ----------

# DBTITLE 1,Add audit columns to dataframe and filtering valid records
try:
    adding_audit_df = add_tgt_audit_column(dtype_chng_df, PIPELINE_NAME,LOAD_TYPE)
    final_df = remove_invalid_records(adding_audit_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception ('Adding audit columns or filtering valid records failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        
        SettlementLimitGuarantee_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','SrdtFundTypeCode','FundSequenceNumber','SettlementRuleCode','SettlementRuleId','ContractTypeCode','ContractLineOfBusinessCode')
        load_df_to_sf_sql_db_spark(SettlementLimitGuarantee_df, 'Accounting.SettlementLimitGuarantee')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['RuleCodeLineNumber','FundTypeCode']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "SettlementLimitGuaranteeKey")
        cur_loaded_time = datetime.now()


        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus': lit(None).cast('STRING'),
        'SettlementLimitGuaranteeKey':lit(None).cast("BIGINT"),
        'SettlementRuleCodeDetailKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageSettlementLimitGuarantee')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('Load to curated, SQL failed: ',str(e)) 
    
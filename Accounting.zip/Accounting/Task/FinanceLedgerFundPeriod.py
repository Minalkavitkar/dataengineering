# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2356
# MAGIC ##### Curated Tables
# MAGIC - Accounting.FinanceLedgerFundPeriod
# MAGIC ##### Target Table
# MAGIC - Accounting.FinanceLedgerFundPeriod

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRE2356"
buz_keys = ['FinRptLedgrNbr','FundPerBegDt','FundPerEndDt']
not_null_col_lst = ['FinanceLedgerHeaderKey']
table_code = 'Accounting_FinanceLedgerFundPeriod'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Accounting_FinanceLedgerFundPeriod')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    finance_ledger_tbl_name = table_name_selector(tbl_conf_df, 'Accounting_FinanceLedgerHeader')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2356_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#Reading data from stage table & filtering the valid records
try:
    tre2356_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    finance_ledger_df = read_table_to_df(finance_ledger_tbl_name)\
        .select('FinanceLedgerHeaderKey','LedgerNumber')
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping db2 to cloud columns
#column mapping db2 to cloud columns
col_mapping = {
'ApprInitNm' : 'ApproverFullName',
'NetVsGrsExpInd' : 'FundExpenseCode',
'FundPerBegDt' : 'FundPeriodBeginDate',
'FundPerEndDt' : 'FundPeriodEndDate',
'FundPerStatInd' : 'FundPeriodStatusCode',
'FundStatChgDt' : 'FundStatusChangeDate',
'FundPerActCd' : 'FundPeriodAccountCode',
'FinRptLedgrNbr' : 'LedgerNumber',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Column mapping, Joining the tables and adding audit columns
# adding audit columns and joining with FinanceLedgerHeader
try:
    col_mapped_df = col_name_mapping(tre2356_stage_df, col_mapping)
    tre2356_joined_df = col_mapped_df.alias('LH').join(finance_ledger_df.alias('RH'),\
        (col('LH.LedgerNumber') == col('RH.LedgerNumber')),'left')\
    .select('LH.*','RH.FinanceLedgerHeaderKey')
    col_added_df = add_tgt_audit_column(tre2356_joined_df, PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('joining or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Date format conversion
# Converting YYYYMM dates into YYYY-MM-DD (1st for start/open dates, end of month day for end/close dates)
start_date_transformed_df = dt_format_cym(col_added_df, ['FundPeriodBeginDate'],'start')
end_date_transformed_df = dt_format_cym(start_date_transformed_df, ['FundPeriodEndDate'],'end')

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_stage_df = remove_invalid_records(end_date_transformed_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('LedgerNumber')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Load data into curated layer and SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        finance_ledger_fund_period_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(finance_ledger_fund_period_df, 'Accounting.FinanceLedgerFundPeriod')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['FundPeriodBeginDate', 'FundPeriodEndDate', 'FinanceLedgerHeaderKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "FinanceLedgerFundPeriodKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'FinanceLedgerFundPeriodKey':lit(None).cast("BIGINT"),
        'FinanceLedgerHeaderKey': lit(None).cast("BIGINT"),
        'LedgerNumber':col('LedgerNumber').cast("INT")
        }
        mapped_df= final_stage_df.withColumns(mapping)
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageFinanceLedgerFundPeriod')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)    
except Exception as e:
    raise Exception ('load failed: ',str(e))
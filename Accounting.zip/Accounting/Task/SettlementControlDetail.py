# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRESCTL
# MAGIC ##### Curated Tables
# MAGIC - Accounting.SettlementControlDetail
# MAGIC ##### Target Table
# MAGIC - Accounting.SettlementControlDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "ACCOUNTING_TRESCTL"
buz_keys = ['SetlCtrlId']
not_null_col_lst = ['SettlementHeaderFrequencyKey','SettlementRuleKey']
table_code = "Accounting_SettlementControlDetail"

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Accounting_SettlementControlDetail')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Accounting', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Accounting', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./AccountingStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions 
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    SettlementHeaderFrequency_tb1_name = table_name_selector(tbl_conf_df, 'Accounting_SettlementHeaderFrequency')
    SettlementRule_tb1_name = table_name_selector(tbl_conf_df, 'Accounting_SettlementRule')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tresctl_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load tables into data frames
#Reading data from stage table & filtering the valid records
try:
    tresctl_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    SettlementHeaderFrequency_df = read_table_to_df(SettlementHeaderFrequency_tb1_name).select('SettlementHeaderFrequencykey' , 'FrequencyId')
    SettlementRule_df = read_table_to_df(SettlementRule_tb1_name).select('SettlementRuleKey' , 'SettlementRuleId')
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,Column mapping between stage and curated tables
#column mapping with domain tables
col_mapping={
'CtrctCatCd':'ContractCategoryCode',
'EndCymDate':'EndDate',
'LagMoCnt':'LagMonthCount',
'NxtTrailInd':'NextTrailIndicator',
'NxtTrailRuleCd':'NextTrailRuleCode',
'SetlCtrlId':'SettlementControlId',
'CtrlIdNm':'SettlementControlName',
'BegCymDate':'StartDate',
'FreqTblId':'FrequencyId',
'RuleId':'SettlementRuleId',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Column mapping and data type conversion, CYM to date conversion
#data type converstion and CYM to date conversion
try:
    col_mapped_df = col_name_mapping(tresctl_stage_df, col_mapping)
    start_date_df = dt_format_cym(col_mapped_df, ['StartDate'], 'start')
    end_date_df = dt_format_cym(start_date_df, ['EndDate'], 'end')    
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Joining the tables and adding audit columns and filtering valid records
#Joining and adding audit columns and filtering valid records
try:
    sfrq_tresctl_joined_df = end_date_df.alias('LH').join(SettlementHeaderFrequency_df.alias('RH'),\
            (col('LH.FrequencyId') == col('RH.FrequencyId')),'left')\
       .select('LH.*','RH.SettlementHeaderFrequencyKey')

    srle_sfrq_tresctl_joined_df = sfrq_tresctl_joined_df.alias('LH').join(SettlementRule_df.alias('RH'),\
            (col('LH.SettlementRuleId') == col('RH.SettlementRuleId')),'left')\
        .select('LH.*','RH.SettlementRuleKey')

    col_added_df = add_tgt_audit_column(srle_sfrq_tresctl_joined_df, PIPELINE_NAME,LOAD_TYPE)

    final_df = remove_invalid_records(col_added_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')

except Exception as e:
    raise Exception('Joining failed or adding audit columns or filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Load data into curated layer and SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./AccountingDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        Settlement_ControlDetail_df = read_table_to_df(cur_tbl_name).drop('FrequencyId','SettlementRuleId','DerivedIndicator')
        load_df_to_sf_sql_db_spark(Settlement_ControlDetail_df, 'Accounting.SettlementControlDetail')
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['SettlementControlId']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "SettlementControlDetailKey")
        cur_loaded_time = datetime.now()


        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus':lit(None).cast('STRING'),
        'SettlementControlDetailKey':lit(None).cast("BIGINT"),
        'SettlementHeaderFrequencyKey':lit(None).cast("BIGINT"),
        'SettlementRuleKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','FrequencyId'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Accounting.StageSettlementControlDetail')
        
        exit_notebook(run_id, "Accounting", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed: ',str(e))
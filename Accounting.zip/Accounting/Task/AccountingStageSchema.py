# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "accounting/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|",
            "multiline":"true" 
        },
        "SourceFileFormat" : "csv"
    },
    "ACCOUNTING_TRE2355":{
        "FileRegex" : "ACCOUNTING_TRE2355.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2355"

    },
    "ACCOUNTING_TRESCTR":{
        "FileRegex" : "ACCOUNTING_TRESCTR.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESCTR"

    },
    "ACCOUNTING_TRESFND":{
        "FileRegex" : "ACCOUNTING_TRESFND.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESFND"

    },

    "ACCOUNTING_TRESPLG":{
        "FileRegex" : "ACCOUNTING_TRESPLG.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESPLG"

    },
    "ACCOUNTING_TRE2351":{
        "FileRegex" : "ACCOUNTING_TRE2351.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2351"

    },
    "ACCOUNTING_TRE2396":{
        "FileRegex" : "ACCOUNTING_TRE2396.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2396"

    },
    "ACCOUNTING_TRE2440":{
        "FileRegex" : "ACCOUNTING_TRE2440.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2440"
    },
    "ACCOUNTING_TRE2395":{
        "FileRegex" : "ACCOUNTING_TRE2395.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2395"
       
    },
    "ACCOUNTING_TRE2365":{
        "FileRegex" : "ACCOUNTING_TRE2365.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2365"
         
    },
    "ACCOUNTING_TRESFRQ":{
        "FileRegex" : "ACCOUNTING_TRESFRQ.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESFRQ"
        
    },
    "ACCOUNTING_TRE2350":{
        "FileRegex" : "ACCOUNTING_TRE2350.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2350"
    },
     "ACCOUNTING_TRESRLE":{
        "FileRegex" : "ACCOUNTING_TRESRLE.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESRLE"
    },
     "ACCOUNTING_TRESSCH":{
        "FileRegex" : "ACCOUNTING_TRESSCH.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESSCH"
    },
     "ACCOUNTING_TRESCTL":{
        "FileRegex" : "ACCOUNTING_TRESCTL.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESCTL"
    }, 
     "ACCOUNTING_TRE2356":{
        "FileRegex" : "ACCOUNTING_TRE2356.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2356"
    },
     "ACCOUNTING_TRESFDT":{
        "FileRegex" : "ACCOUNTING_TRESFDT.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESFDT"
    },
     "ACCOUNTING_TRE2366":{
        "FileRegex" : "ACCOUNTING_TRE2366.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2366"
    },
     "ACCOUNTING_TRE2367":{
        "FileRegex" : "ACCOUNTING_TRE2367.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2367"
    },
     "ACCOUNTING_TRE2368":{
        "FileRegex" : "ACCOUNTING_TRE2368.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2368"
    },
     "ACCOUNTING_TRESRCD":{
        "FileRegex" : "ACCOUNTING_TRESRCD.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESRCD"
    },
     "ACCOUNTING_TRESRDT":{
        "FileRegex" : "ACCOUNTING_TRESRDT.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESRDT"
    },
     "ACCOUNTING_TRE2441":{
        "FileRegex" : "ACCOUNTING_TRE2441.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2441" 
    },
     "ACCOUNTING_TRE2443":{
        "FileRegex" : "ACCOUNTING_TRE2443.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2443"
     },
     "ACCOUNTING_TRE2442":{
        "FileRegex" : "ACCOUNTING_TRE2442.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRE2442"
     },
     "ACCOUNTING_TRESSCT":{
        "FileRegex" : "ACCOUNTING_TRESSCT.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESSCT"
     },
      "ACCOUNTING_TRESTAX":{
        "FileRegex" : "ACCOUNTING_TRESTAX.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESTAX"
     },
     "ACCOUNTING_TRESSCN":{
        "FileRegex" : "ACCOUNTING_TRESSCN.TXT",
        "StagePathSuffix" : "accounting/stage/StageTRESSCN"
     }
}


# COMMAND ----------

tresctr_schema = {
'IND1': 'STRING'
,'TIMESTAMP':'TIMESTAMP'
,'PCA_PROV_ID_NBR':'STRING'
,'PCA_PROV_SUFX_CD':'STRING'
,'PCA_SERV_TY_CD':'STRING'
,'PCA_CTRCT_SEQ_NBR':'STRING'
,'SETL_CTRCT_KEY':'STRING'
,'PYMT_CTRCT_KEY':'STRING'
,'PYMT_CTRCT_NM':'STRING'
,'SETL_CTRL_ID':'STRING'
,'PCA_PROD_LOB_CD':'STRING'
,'RPT_DEST_CTR_ID':'STRING'
,'FIN_LEDGR_GEO_CD':'STRING'
,'PCA_CTRCT_DESC':'STRING'
,'DISTR_USER_NM':'STRING'
,'FIN_RPT_LEDGR_NBR':'STRING'
,'UPDT_ID':'STRING'
,'UPDT_DT':'DATE'
}

# COMMAND ----------

tresfnd_schema = {
"IND1":"STRING"
,"TIMESTAMP":"TIMESTAMP"
,"PCA_PROV_ID_NBR ":"STRING"
,"PCA_PROV_SUFX_CD":"STRING"
,"PCA_SERV_TY_CD":"STRING"
,"PCA_CTRCT_SEQ_NBR":"STRING"
,"FUND_BEG_DT":"DATE"
,"FUND_TY_CD":"STRING"
,"FUND_END_DT":"DATE"
,"FUND_CLOSE_DT":"DATE"
,"FUND_STAT_CD":"STRING"
,"FUND_STAT_DT":"DATE"
,"FUND_PRI_BFWD_AMT":"DECIMAL(11,2)"
,"FUND_LATE_CLM_AMT":"DECIMAL(11,2)"
,"FUND_FUND_AMT":"DECIMAL(11,2)"
,"FUND_CAP_FUND_AMT":"DECIMAL(11,2)"
,"FUND_MBR_MO_CNT":"DECIMAL(7,0)"
,"FUND_WHLD_CLM_AMT":"DECIMAL(11,2)"
,"FUND_OTH_FUND_AMT":"DECIMAL(11,2)"
,"FUND_CAP_EXPS_AMT":"DECIMAL(11,2)"
,"EXPS_MBR_MO_CNT":"DECIMAL(7,0)"
,"FUND_CLM_BEN_AMT":"DECIMAL(11,2)"
,"FUND_CLM_EXPS_AMT":"DECIMAL(11,2)"
,"FUND_CLM_DISC_AMT":"DECIMAL(11,2)"
,"STLS_EXCESS_AMT":"DECIMAL(11,2)"
,"FUND_DIR_PYMT_AMT":"DECIMAL(11,2)"
,"FUND_MAN_ADJ_AMT":"DECIMAL(11,2)"
,"FUND_NET_ACT_AMT":"DECIMAL(11,2)"
,"FUND_PROV_RISK_AMT":"DECIMAL(11,2)"
,"FUND_SHR_CONTB_AMT":"DECIMAL(11,2)"
,"FUND_SHR_CONTB_PCT":"DECIMAL(11,8)"
,"FUND_SHR_ALLOC_AMT":"DECIMAL(11,2)"
,"FUND_SHR_ALLOC_PCT":"DECIMAL(11,8)"
,"FUND_XFER_OUT_AMT":"DECIMAL(11,2)"
,"FUND_XFER_IN_AMT":"DECIMAL(11,2)"
,"FUND_SETL_AMT":"DECIMAL(11,2)"
,"FUND_RECON_AMT":"DECIMAL(11,2)"
,"FINAL_PYMT_AMT":"DECIMAL(11,2)"
,"FUND_BFWD_AMT":"DECIMAL(11,2)"
,"DEFC_ABSORB_AMT":"DECIMAL(11,2)"
,"FUND_IBNR_AMT":"DECIMAL(11,2)"
,"SHR_BASIS_AMT":"DECIMAL(11,2)"
,"SHR_PAR_IND":"STRING"
,"FUND_IBNR_SETL_IND":"STRING"
,"CATAST_WHLD_AMT":"DECIMAL(11,2)"
,"WHLD_ADJ_AMT":"DECIMAL(11,2)"
,"RET_LIM_MO_CNT":"DECIMAL(7,0)"
,"FUND_RET_LIM_AMT":"DECIMAL(11,2)"
,"FUND_DEF_FWD1_AMT":"DECIMAL(11,2)"
,"FUND_DEF_FWD2_AMT":"DECIMAL(11,2)"
,"FUND_DEF_FWD3_AMT":"DECIMAL(11,2)"
,"UPDT_ID":"STRING"
,"UPDT_DT":"DATE"
}

# COMMAND ----------

tresplg_schema={
"IND1":"STRING",
"TIMESTAMP":"TIMESTAMP",
"LIM_GUAR_GEN_KEY":"INT",
"RULE_DETL_GEN_KEY":"INT",
"RULE_CD_LN_NBR":"INT",
"SURPL_DEFC_IND":"STRING",
"LIM_GUAR_IND":"STRING",
"FUND_TY_CD":"STRING",
"FUND_MTHD_CD":"STRING",
"FUND_PCT":"INT",
"LIM_GUAR_AMT":"INT",
"FLIP_IND":"STRING",
"UPDT_ID":"STRING",
"UPDT_DT":"DATE",
"CALC_CONTROL_IND":"STRING"
}

# COMMAND ----------

tre2351_schema = {
"IND1":"STRING",
"TIMESTAMP":"TIMESTAMP"	,
"ADJ_BTCH_SEQ_NBR ":"INT",
"FUND_ADJ_REF_NBR ":"INT",
"PROV_ID_NBR":"INT"	,
"PROV_SUFF_CD":"STRING ",
"PCA_SERV_TY_CD":"STRING",
"PCA_SEQ_NBR":"SMALLINT",
"FUND_TY_CD":"STRING",
"FUND_MO_CYM_DT":"INT",
"FUND_ADJ_STAT_CD":"STRING",
"FUND_ADJ_STAT_DT":"DATE",
"FUND_ADJ_TY_CD":"STRING",
"FUND_ADJ_REAS_CD":"STRING",
"CST_ALOC_ACC_CD":"STRING",
"PGM_CD":"STRING",
"FUND_MAN_ADJ_AMT":"DECIMAL(9,2)",
"FUND_IMM_CK_IND":"STRING",
"FUND_ADJ_GL_IND":"STRING",
"ADJ_DBT_ACCT_NBR":"STRING",
"ADJ_CR_ACCT_NBR":"STRING",
"FUND_ADJ_REAS_DESC":"STRING",
"ADV_UNMATCH_IND":"STRING",
"ADJ_TRAN_TY_CD":"STRING",
"MBR_PID":"STRING",
"MBR_ENRL_CUST_NBR":"STRING",
"CAS_CLM_NBR":"BIGINT",
"ICS_NBR":"STRING",
"ICS_SUFX_CD":"STRING",
"CLM_INCRD_CYMD_DT":"DATE",
"AUTO_EXP_OV_IND":"STRING",
"EXPS_PROV_ID_NBR":"STRING",
"EXPS_PROV_SUFF_CD":"STRING",
"EXPS_SERV_TY_CD":"STRING",
"EXPS_SEQ_NBR":"STRING",
"PLTFM_CD":"STRING"
}

# COMMAND ----------

tresfrq_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'FREQ_TBL_ID':'STRING',    
'FREQ_TBL_ID_NM':'STRING',
'FREQ_LAG_MO_CNT':'STRING',
'UPDT_ID':'STRING',        
'UPDT_DT':'DATE'  
 }  

# COMMAND ----------

tre2395_schema = {
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP',
    'SETL_TBL_ID':'STRING',
    'SETL_TBL_DEL_IND':'STRING',
    'SETL_LAG_MO_CNT':'DECIMAL(3,0)',
    'SETL_MTHD_CD':'STRING',
    'SETL_DEFC_BFWD_IND':'STRING',
    'SETL_XFER_FUND_CD':'STRING',
    'SETL_XFER_SEQ_NBR':'SMALLINT', 
    'FUND_PROV_RISK_PCT':'DECIMAL(5,2)',
    'ORD_SHR_GRP_ACT_CD':'STRING',
    'SETL_LIM_PAY_IND':'STRING',
    'LIM_PAY_MTHD_CD':'STRING',
    'LIM_PAY_FUND_TY_CD':'STRING',
    'SETL_LIM_PAY_PCT':'DECIMAL(5,2)',
    'LIM_PAY_MIN_AMT':'DECIMAL(11,2)',
    'LAG_ANN_MO_CNT':'DECIMAL(3,0)',
    'SETL_PAY_CHK_CD':'STRING',
    'SETL_ANN_CHK_CD':'STRING',
    'SETL_TM_RISK_CD':'STRING',
    'SETL_FREQ_CD':'STRING',
    'FUND_DEFC_RISK_PCT':'DECIMAL(5,2)',
    'LIM_PAY_MAX_AMT':'DECIMAL(5,2)',
    'PLTFM_CD':'STRING'
}

# COMMAND ----------

tre2355_schema = {
    'IND1':'STRING',
    'TIMESTAMP':'TIMESTAMP',
    'FIN_RPT_LEDGR_NBR':'STRING',
    'HMP_VS_NON_HMP_IND':'STRING',
    'FIN_RPT_LEDGR_DESC':'STRING',
    'FIN_LEDGR_STAT_IND':'STRING',
    'FIN_LEDGR_STAT_DT':'DATE',
    'APPR_INIT_NM':'STRING',
    'FIN_NET_VS_GRS_IND':'STRING',
    'FIN_LEDGR_NM':'STRING',
    'FIN_LEDGR_LOB_CD':'STRING',
    'FIN_LEDGR_GEO_CD':'STRING',
    'CAS_NTWK_NBR':'INTEGER',
    'CAS_LOB_CD':'STRING',
    'CAS_PROV_NTWK_NBR':'INTEGER',
    'CAS_MKT_NBR':'INTEGER',
    'GK_LEDGR_IND':'STRING',
    'WHLD_PER_GRPR_IND':'STRING',
    'PLTFM_CD':'STRING'
}

# COMMAND ----------

tre2396_schema = {
         'IND1':'STRING'
        ,'IND2':'STRING'
        ,'TIMESTAMP':'TIMESTAMP'
        ,'FIN_LEDGR_GEO_CD':'STRING'
        ,'SETL_LEDGR_NBR':'STRING' 
        ,'SETL_CTRCT_KEY':'STRING'   
        ,'UPDT_INIT_NM':'STRING'    
        ,'UPDT_DT':'INT'        
        ,'SETL_LEDGR_RUN_CD':'STRING'
        ,'SETL_ANN_TY_CD':'STRING'   
        ,'SETL_PER_TY_CD':'STRING'   
        ,'PLTFM_CD'   :'STRING'      
}

# COMMAND ----------

tre2440_schema={
'RULE_TY_CD':'STRING',   
'RULE_TBL_TY_CD':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2365_schema={
'MBR_PID':'STRING',
'PLTFM_CD':'STRING',         
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2350_schema={
'ADJ_BTCH_SEQ_NBR':'INT',       
'ADJ_BTCH_CYMD_DT':'DATE', 
'UPDT_OPER_INIT_NM':'STRING',  
'APPR_OPER_INIT_NM':'STRING', 
'ADJ_BTCH_TOT_AMT':'DECIMAL(9,2)', 
'ADJ_BTCH_STAT_CD':'STRING', 
'ADJ_BTCH_STAT_DT':'DATE',          
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tresrle_schema={
'RULE_ID':'STRING',
'RULE_ID_NM':'STRING',
'UPDT_ID':'STRING',
'UPDT_DT':'DATE',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tressch_schema={
'RULE_ID' : 'STRING',
'CTRCT_TY_CD' : 'STRING',
'CTRCT_LOB_CD' : 'STRING',
'UPDT_ID' : 'STRING',
'UPDT_DT' : 'DATE',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tresctl_schema={
'SETL_CTRL_ID':'STRING',     
'CTRL_ID_NM':'STRING',  
'RULE_ID':'STRING',   
'FREQ_TBL_ID':'STRING',    
'NXT_TRAIL_IND':'STRING',    
'NXT_TRAIL_RULE_CD':'STRING',     
'LAG_MO_CNT':'STRING',    
'UPDT_ID':'STRING',  
'UPDT_DT':'DATE',         
'BEG_CYM_DATE':'STRING',  
'END_CYM_DATE':'STRING',  
'CTRCT_CAT_CD':'STRING', 
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2356_schema={
'FIN_RPT_LEDGR_NBR':'STRING',
'FUND_PER_BEG_DT':'INT',   
'FUND_PER_END_DT':'INT',     
'FUND_PER_STAT_IND':'STRING',
'FUND_STAT_CHG_DT':'DATE',       
'APPR_INIT_NM':'STRING',
'FUND_PER_ACT_CD':'STRING',
'NET_VS_GRS_EXP_IND':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tresfdt_schema = {
'FREQ_TBL_ID' : 'STRING',
'FREQ_MO_CNT' : 'STRING',
'FREQ_RULE_CD' : 'STRING',
'FREQ_PYMT_IND' : 'STRING',
'UPDT_ID' : 'STRING',
'UPDT_DT' : 'DATE',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'       
}

# COMMAND ----------

tre2366_schema ={
'IND1': 'STRING',
 'TIMESTAMP': 'TIMESTAMP',
 'MBR_PID': 'STRING',
 'STOPLS_BEG_CYM_DT': 'STRING',
 'FUND_TY_CD': 'STRING',
 'RE2366_FNDSTL_TS': 'STRING',
 'STOPLS_CLM_AMT': 'DECIMAL(9,2)',
 'UNIFY_FUND_IND': 'STRING',
 'EXPS_PROV_ID_NBR': 'STRING',
 'EXPS_PROV_SUFF_CD': 'STRING',
 'EXPS_SERV_TY_CD': 'STRING',
 'EXPS_SEQ_NBR': 'STRING',
 'PLTFM_CD': 'STRING'
 }

# COMMAND ----------

tre2367_schema ={'IND1': 'STRING',
 'TIMESTAMP': 'TIMESTAMP',
 'EXPS_PROV_ID_NBR': 'STRING',
 'EXPS_PROV_SUFF_CD': 'STRING',
 'EXPS_SERV_TY_CD': 'STRING',
 'EXPS_SEQ_NBR': 'STRING',
 'PLTFM_CD': 'STRING'}

# COMMAND ----------

tre2368_schema = {'IND1': 'STRING',
 'TIMESTAMP': 'TIMESTAMP',
 'MBR_PID': 'STRING',
 'CAS_CLM_NBR': 'BIGINT',
 'STOPLS_CLM_AMT': 'DECIMAL(9,2)',
 'PLTFM_CD': 'STRING'}

# COMMAND ----------

tresrcd_schema = {'IND1': 'STRING',
 'RULE_ID': 'STRING',
 'CTRCT_TY_CD': 'STRING',
 'CTRCT_LOB_CD': 'STRING',
 'RULE_CD': 'STRING',
 'RULE_CD_NM': 'STRING',
 'UPDT_ID': 'STRING',
 'UPDT_DT': 'DATE'}

# COMMAND ----------

tresrdt_schema ={'IND1': 'STRING',
 'TIMESTAMP': 'TIMESTAMP',
 'RULE_DETL_GEN_KEY': 'INTEGER',
 'RULE_ID': 'STRING',
 'CTRCT_TY_CD': 'STRING',
 'CTRCT_LOB_CD': 'STRING',
 'RULE_CD': 'STRING',
 'RULE_FUND_SEQ_NBR': 'STRING',
 'WRK_FUND_IND': 'STRING',
 'FUND_TY_CD': 'STRING',
 'SETL_MTHD_CD': 'STRING',
 'XFR_FUND_TY_CD': 'STRING',
 'RSK_SHR_ORD_NBR': 'STRING',
 'RSK_SURPL_PCT': 'DECIMAL(5,2)',
 'RSK_DEFC_PCT': 'DECIMAL(5,2)',
 'DEFC_CARR_FWD_IND': 'STRING',
 'LIM_GUAR_ORD_NBR': 'STRING',
 'PERD_UNIFY_ORD_NBR': 'STRING',
 'FUND_PERD_1_CD': 'STRING',
 'FUND_PERD_2_CD': 'STRING',
 'FUND_PERD_3_CD': 'STRING',
 'SHR_GRP_ORD_NBR': 'STRING',
 'SHR_GRP_ID': 'STRING',
 'UPDT_ID': 'STRING',
 'UPDT_DT': 'DATE'}

# COMMAND ----------

tre2441_schema={
'RULE_TY_CD':'STRING',
'RULE_TBL_TY_CD':'STRING',
'RULE_TBL_ID':'STRING',
'RULE_TBL_DESC':'STRING',
'UPDT_INIT_NM':'STRING',
'UPDT_CYMD_DT':'DATE',
'TBL_KEY_IND':'STRING',
'MKT_AREA_TBL_ID':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2443_schema={
'RULE_TY_CD':'STRING',
'RULE_TBL_TY_CD':'STRING',
'RULE_TBL_ID':'STRING',
'STOPLS_FUND_TY_CD':'STRING',
'STOPLS_END_CYM_DT':'INTEGER',
'STOPLS_BEG_CYM_DT':'INTEGER',
'STOPLS_BASIS_CD':'STRING',
'STOPLS_LIM_AMT':'DECIMAL(7,0)',
'STOPLS_LIM_PCT':'DECIMAL(5,2)',
'UNIFY_FUND_TY_CD1':'STRING',
'UNIFY_FUND_TY_CD2':'STRING',
'UNIFY_FUND_TY_CD3':'STRING',
'PROV_BREAK_IND':'STRING',
'STOPLS_SORT_CD':'STRING',
'REDIR_FUND_TY_CD':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tre2442_schema={
'RULE_TY_CD': 'STRING',
'RULE_TBL_TY_CD':'STRING',
'RULE_TBL_ID':'STRING',
'MBR_PID':'STRING',
'MBR_ENRL_CUST_NBR':'STRING',
'EXCP_EFF_CYMD_DT':'DATE',
'EXCP_END_CYMD_DT':'DATE',
'CAUSE_CAT_CD':'STRING',
'ICD9_ICD10_IND':'STRING',
'ICD_DIAG_FROM_CD':'STRING',
'ICD_DIAG_TO_CD':'STRING',
'CAS_CLM_NBR':'BIGINT',
'REDIR_FUND_TY_CD':'STRING',
'UPDT_CYMD_DT':'DATE',
'UPDT_INIT_NM':'STRING',
'EXCP_TBL_CMT':'STRING',
'EXCP_USAGE_IND':'STRING',
'PLTFM_CD':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tressct_schema={
'SCHD_SETL_CTRL_ID':'STRING',
'CTRL_ID_NM':'STRING',
'CTRL_STAT_ACT_CD':'STRING',
'UPDT_ID':'STRING',         
'UPDT_DT':'DATE',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

trestax_schema = {
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP',
'LIM_GUAR_GEN_KEY':'INTEGER',
'TAX_ID':'STRING',         
'UPD_USER_ID':'STRING',   
'UPD_DATE':'STRING'         
}  

# COMMAND ----------




# COMMAND ----------

tresscn_schema={
'SCHD_SETL_CTRL_ID':'STRING', 
'SCHD_PYMT_CTRCT_ID':'STRING',
'SCHD_PYMT_CTRCT_NM':'STRING',
'CTRCT_STAT_ACT_CD':'STRING', 
'UPDT_ID':'STRING',         
'UPDT_DT':'DATE',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

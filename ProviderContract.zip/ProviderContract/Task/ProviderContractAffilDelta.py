# Databricks notebook source
# DBTITLE 1,Preparing Stage Table For DeltaLoad
try:
    if LOAD_TYPE == "DeltaLoad":
        
        # Joining with Ctrt Stage full table and getting the Provider Contract Unique columns --> ProvIdNbr, ProvSuffCd, ServTyCd, CtrctSeqNbr
        xact_with_ctrt_df = trexact_df.alias('LH')\
                                        .join(trectrt_stage_full_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left')\
                                        .select('LH.*','RH.ProvIdNbr','RH.ProvSuffCd','RH.ServTyCd','RH.CtrctSeqNbr')\
                                        .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))

        ctrt_with_xactfull_df = trectrt_stage_df.alias('LH')\
                                        .join(trexact_stage_full_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'inner')\
                                        .select('LH.*','RH.AffilGenKey','RH.AffilTyCd')\
                                        .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                        .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))

        ctrt_rejected_df = trectrt_stage_df.alias('LH')\
                                        .join(trexact_stage_full_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left_anti')\
                                        .select('StgUnqId','Status','RejectReason')

        
        #this join is required to avoid the duplicate delta formation
        ctrt_with_xact_df = ctrt_with_xactfull_df.alias('LH')\
                                            .join(xact_with_ctrt_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left_anti')\
                                            .drop('StgUnqId')

        

        #union all constructed dataframes
        xact_ctrt_without_del_df = xact_with_ctrt_df.unionByName(ctrt_with_xact_df, allowMissingColumns=True)

        update_rej_records(ctrt_rejected_df, "Child Not Found", stage_trectrt_tbl_name)

except Exception as e:
    raise Exception("preparing stage table failed for DeltaLoad: ",str(e)) 

# COMMAND ----------

try:
    if LOAD_TYPE == "DeltaLoad":

        # Joining with Ctrt Stage table and getting the Provider Contract Unique columns --> ProvIdNbr, ProvSuffCd, ServTyCd, CtrctSeqNbr.
        # This step is completed already, even though for delete records not able to get providercontract columns from full table because delete will happen while staging.


        providercontract_null_df = xact_ctrt_without_del_df.filter(col("ProvIdNbr").isNull()).drop("ProvIdNbr","ProvSuffCd","ServTyCd","CtrctSeqNbr")
        providercontract_not_null_df = xact_ctrt_without_del_df.filter(col("ProvIdNbr").isNotNull())

        procon_fillnull_df  = providercontract_null_df.alias("LH").join(trectrt_stage_df.alias("RH"), "CtrctGenKey")\
                                            .select("LH.*","RH.ProvIdNbr","RH.ProvSuffCd","RH.ServTyCd","RH.CtrctSeqNbr")

        xact_ctrt_df = procon_fillnull_df.unionByName(providercontract_not_null_df, allowMissingColumns=True)

except Exception as e:
    raise Exception("preparing stage table failed for FullLoad: ",str(e))        


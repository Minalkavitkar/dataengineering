# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2341
# MAGIC - TRE2481
# MAGIC - TREPRVJ
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContract
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContract

# COMMAND ----------

# DBTITLE 1,Orchestration Check: Loads Validate function
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Prepare Environment: Setting up local parameters.
tre2341_file_conf_key = 'PROVIDER_CONTRACT_TRE2341'
tre2481_file_conf_key = 'PROVIDER_CONTRACT_TRE2481'
treprvj_file_conf_key = 'PROVIDER_CONTRACT_TREPRVJ'
not_null_col_lst = ['ProviderKey']
table_code = 'ProviderContract_ProviderContract'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_Contract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Orchestration Check: Validate the run , ensures idempotency and helps enable checkpoint
try:
## exists the notebook if the notebook is needed to be run for this run. If not required or already run exists the notebook.
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Fetch the schema definition. 
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Importing ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Importing Load functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import neccessary libraries
from pyspark.sql.window import Window 
from pyspark.sql.functions import row_number

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]


    stage_tre2341_tbl_name = table_name_selector(tbl_conf_df, tre2341_file_conf_key)
    stage_tre2481_tbl_name = table_name_selector(tbl_conf_df, tre2481_file_conf_key)
    stage_treprvj_tbl_name = table_name_selector(tbl_conf_df, treprvj_file_conf_key)
    stage_tre2341_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2341_FULL")
    stage_tre2481_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2481_FULL")
    stage_treprvj_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TREPRVJ_FULL")
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_cur_tbl_name = table_name_selector(tbl_conf_df, 'Provider_Provider')

    file_list = [
        [tre2341_file_conf_key, stage_tre2341_tbl_name, tre2341_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd',  'PcaSeqNbr'],"StageFull"],
        [tre2481_file_conf_key, stage_tre2481_tbl_name, tre2481_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd', 'PcaSeqNbr'],"StageFull"],
        [treprvj_file_conf_key, stage_treprvj_tbl_name, treprvj_schema, ['ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd', 'PcaSeqNbr'],"StageFull"]
        ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Ingestion: Load into stage table
try:
    for key, tbl_name, schema, buz_keys, stage_condition in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]} 
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full=stage_condition)
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read data from stage tables
#Read data from stage tables and renaming the column according to the domain tables
try:
    tre2341_stage_df = read_table_to_df(stage_tre2341_tbl_name).filter(col('Status') == 'S')
    tre2481_stage_df = read_table_to_df(stage_tre2481_tbl_name).filter(col('Status') == 'S')
    treprvj_stage_df = read_table_to_df(stage_treprvj_tbl_name).filter(col('Status') == 'S')
    provider_curated = prioritize_prv_type2Code(read_table_to_df(prov_cur_tbl_name))
    tre2341_stage_full_df = read_table_to_df(stage_tre2341_full_tbl_name)
    tre2481_stage_full_df = read_table_to_df(stage_tre2481_full_tbl_name)
    treprvj_stage_full_df = read_table_to_df(stage_treprvj_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
# MAGIC %run ./ProviderContractStagePrepare

# COMMAND ----------

# DBTITLE 1,Column mapping
column_mapping = {
        #buz_keys
            "ProvIdNbr" : "ProviderId"
            ,"ProvSuffCd" : "ProviderSuffixCode"
            ,"PcaServTyCd" : "ProviderServiceTypeCode"
            ,"PcaSeqNbr" : "ProviderSequenceNumber"

        #column mapping for tre2341
            ,"PcaGrpId" : "PcaGrpId"
            ,"PcaAddMaxCnt" : "AdditionalMaximumCount"
            ,"PcaCapBegCd" : "CapitationBeginCode"
            ,"PcaCapEndCd" : "CapitationEndCode"
            ,"PcaCtrctCatCd" : "CategoryCode"
            ,"EverPymtCd" : "EverPaymentCode"
            ,"PcaFundClasfCd" : "FundClassCode"
            ,"PcaEndCymdDt" : "ContractEndDate"
            ,"PcaStatCd" : "StatusCode"
            ,"PcaTyCd" : "ContractProgramTypeCode"
            ,"PcaBegCymdDt" : "ContractStartDate"
            ,"Re2341CtrctTs" : "Re2341CtrctTs"
            ,"PcaDefltStatInd" : "DefaultStatusIndicator"
            ,"PcaLateClmCd" : "LateClaimCode"
            ,"PcaMbrLimCd" : "MemberLimitCode"
            ,"PcaMbrTyCd" : "MemberTypeCode"
            ,"PcaPymtAcctNbr" : "PaymentAccountNumber"
            ,"PcaPymtDdDt" : "PaymentDateNumber"
            ,"PcaPymtOptCd" : "PaymentOptionCode"
            ,"ProdLobCd" : "ProductLineOfBusinessCode"
            ,"PcaDesc" : "ProviderContractDescription"
            ,"RptDestCntrId" : "ProviderGrouperId"
            ,"PcaMbrCnt" : "ProviderMemberCount"
            ,"PcaRecovFundCd" : "RecoveryFundTypeCode"
            ,"PcaRecovMoCnt" : "RecoveryMonthCount"
            ,"PcaRecovPymtAmt" : "RecoveryPaymentAmount"
            ,"PcaRecovPct" : "RecoveryPercent"
            ,"PcaRnwlCymdDt" : "RenewalDate"
            ,"RprocIndCymdDt" : "ReprocessDate"
            ,"PcaStatCymdDt" : "StatusDate"
            ,"PcaTermMaxCnt" : "TerminationMaximumCount"
            ,"RptPkgCtrlId" : "ReportPackageControlId"
            ,"PcaExpsTblId" : "ExpenseId"
            ,"PcaRptCtrlId" : "ReportControlId"
            ,"RptDtlInd" : "ReportDetailIndicator"
            ,"ReRptdesIxInd" : "ReportIndicator"

        #column mapping for tre2481
            ,"BegFundPerdCd" : "FundPeriodBeginCode"
            ,"CtrctCntyCd" : "ContractCountyCode"
            ,"CtrctLagAnnCnt" : "ContractLagAnnualCount"
            ,"CtrctLagPerCnt" : "ContractLagPeriodCount"
            ,"DistCalcInd" : "DistanceCalculatedIndicator"
            ,"DistLenNbr" : "DistanceLengthNumber"
            ,"IndivSetlRuleCd" : "IndividualSettlementRuleCode"
            ,"CtrctSetlDesc" : "Settlement1Description"
            ,"SetlLn2Desc" : "Settlement2Description"
            ,"SetlAnnPayCd" : "SettlementAnnualPaymentCode"
            ,"SetlByFundInd" : "SettlementByFundIndicator"
            ,"CtrctSetlFreqCd" : "SettlementFrequencyCode"
            ,"SetlPerdPayCd" : "SettlementPeriodPaymentCode"
            ,"MstrMassMoveInd" : "MassMoveInd"
            ,"RprocInd" : "ReprocessIndicator"
        
        #column mapping for treprvj

            ,"PprovProvSeqCd" : "PCPSequenceNumber"
            ,"GrpPrac" : "IPAIndicator"
            ,"RptOptCd" : "ReportOptionCode"
            ,"PprovPlanYrCd": "PCPPlanYearCode"
            ,"GrpPrac": "IPAIndicator"
            ,"RptOptCd": "ReportOptionCode"


        #derived columns
            ,'StgUnqId':'StgUnqId'
            ,"RunId":"RunId"
            ,"DerivedIndicator":"DerivedIndicator"
            ,"Status":"Status"
            ,"RejectReason":"RejectReason"
}

try:
    col_mapped_df = col_name_mapping(tre2341_treprvj_tre2481_df,column_mapping)\
        .withColumn('ContractEndReasonCode',lit(None))
except Exception as e:
    raise Exception("column name renaming failed : ",str(e))

# COMMAND ----------

# DBTITLE 1,Datatype Conversion mapping
schema = {"ProviderSequenceNumber" : "STRING"
            ,"ProviderId" : "STRING"
            ,"RecoveryPercent" : "DECIMAL(20,6)"
            ,"RecoveryPaymentAmount" : "DECIMAL(20,6)"
            ,"PCPSequenceNumber" : "DECIMAL(10,5)"
            ,"ContractEndReasonCode":"STRING"}

# COMMAND ----------

# DBTITLE 1,Adding Audit Columns and ProviderContractId
try:
    prov_id_added_df = col_mapped_df.withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))

    pc_cols = [
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber"
    ]
    add_pc_id_df = create_provider_contract_id(prov_id_added_df, pc_cols)

    calc_df = add_pc_id_df.withColumn('ReportIndicator', when(col('ReportIndicator') == 'Y', lit(True))\
                                    .when(col('ReportIndicator') == 'N', lit(False)))
    
    dtype_chng_df = dtype_tgt_conversion(calc_df, schema)
except Exception as e:
    raise Exception ('Adding Audit Columns and data type change  failed',str(e))

# COMMAND ----------

# DBTITLE 1,Adding Audit Columns
col_maps = {
            'CreatedBy'         : lit(PIPELINE_NAME),
            'CreatedDateTime'   : col('Re2341CtrctTs'),
            'ModifiedBy'        : lit(PIPELINE_NAME),
            'ModifiedDateTime'  : col('Re2341CtrctTs')
            }
    
try:
    audit_col_added_df = dtype_chng_df.withColumns(col_maps).drop('Re2341CtrctTs')
except Exception as e:
    raise Exception("aduit col updation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with prv_trans_df dataframe
try:
    prv_joined_df = audit_col_added_df.alias('LH')\
            .join(provider_curated.alias('RH'), (col('LH.ProviderId') == col('RH.ProviderId')) \
                        & (col('LH.ProviderSuffixCode') == col('RH.SuffixCode')), 'left')\
            .select('LH.*', 'RH.ProviderKey')
except Exception as e:
    raise Exception('joining failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    final_df = remove_invalid_records(prv_joined_df, stage_tre2341_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

def delete_multijoin_table(df):
    provconttransfer_name = table_name_selector(tbl_conf_df, "ProviderContract_ProviderContractTransfer")
    provcontassc_name = table_name_selector(tbl_conf_df, "ProviderContract_ProviderContractAssociation")

    cur_df = read_table_to_df(cur_tbl_name)
    delete_df = df.alias("LH").join(cur_df.alias("RH"), ['ProviderContractId']).select("LH.*","ProviderContractKey")

    cond = ("Curated.FromProviderContractKey = Stage.ProviderContractKey or Curated.ToProviderContractKey = Stage.ProviderContractKey")
    target_tbl = DeltaTable.forName(spark, provconttransfer_name)
    target_tbl.alias('Curated')\
                .merge(delete_df.alias('Stage'),cond)\
                .whenMatchedDelete(condition= "Stage.DerivedIndicator='DELETE'")\
                .execute()
    
    cond = ("Curated.PCPContractKey = Stage.ProviderContractKey or Curated.SpecialistContractKey = Stage.ProviderContractKey")
    target_tbl = DeltaTable.forName(spark, provcontassc_name)
    target_tbl.alias('Curated')\
                .merge(delete_df.alias('Stage'),cond)\
                .whenMatchedDelete(condition= "Stage.DerivedIndicator='DELETE'")\
                .execute()

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        provider_contract_df = read_table_to_df(cur_tbl_name).drop('PcaGrpId','DerivedIndicator')
        load_df_to_sf_sql_db_spark(provider_contract_df, 'ProviderContract.ProviderContract')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderContractId']
        delete_multijoin_table(final_df)
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractKey':lit(None).cast("BIGINT"),
        'ProviderKey': lit(None).cast("BIGINT")
        }
        
        delta_cols_updated_df = final_df.withColumns(mapping)
        nullable_set_df = set_df_columns_nullable(spark, set_df_columns_not_nullable(spark,delta_cols_updated_df,['CreatedDateTime']), ['ModifiedBy'])
        provider_contract_df = nullable_set_df.filter(col('DerivedIndicator')!='IGNORE').drop('PcaGrpId')

        load_df_to_sf_sql_db_spark(provider_contract_df, 'ProviderContract.StageProviderContract')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
except Exception as e:
    raise Exception ('load failed',str(e))
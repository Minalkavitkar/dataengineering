# Databricks notebook source
# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition = (col('LH.ProvIdNbr')==col('RH.ProvIdNbr')) & \
                        (col('LH.ProvSuffCd')==col('RH.ProvSuffCd')) & \
                        (col('LH.PcaServTyCd')==col('RH.PcaServTyCd')) & \
                        (col('LH.PcaSeqNbr')==col('RH.PcaSeqNbr'))

    #Building the select list 
    common_columns = set(tre2341_stage_df.columns).intersection(treprvj_stage_df.columns)
    tre2341_columns = list(set(tre2341_stage_df.columns) - set(["ProvIdNbr","ProvSuffCd","PcaServTyCd","PcaSeqNbr","PltfmCd","Ind1","Timestamp","LoadDate","LoadTimestamp","FileName","RunId","StgUnqId","DerivedIndicator","Status","RejectReason"]))
    treprvj_columns = list(set(treprvj_stage_df.columns) - set(common_columns))
    tre2481_columns = list(set(tre2481_stage_df.columns) - set(common_columns))


    if LOAD_TYPE == "FullLoad":
        #Joining TRE2341 with TREPRVJ to build the common structure
        tre2341_treprvj_cols_lst = ['LH.' + col for col in tre2341_stage_df.columns] + ['RH.' + col for col in treprvj_columns]
        tre2341_treprvj_df = tre2341_stage_df.alias('LH').join(treprvj_stage_df.alias('RH'), joining_condition,'left')\
                                            .select(*tre2341_treprvj_cols_lst)
        
        #Joining TRE2341+TREPRVJ with TRE2481 to build the common structure
        tre2341_treprvj__tre2481_cols_lst  = ['LH.' + col for col in tre2341_treprvj_df.columns] + ['RH.' + col for col in tre2481_columns]
        tre2341_treprvj_tre2481_df = tre2341_treprvj_df.alias('LH').join(tre2481_stage_df.alias('RH'), joining_condition, 'left')\
                                            .select(*tre2341_treprvj__tre2481_cols_lst)

        tre2341_treprvj_rej_df = treprvj_stage_df.alias('LH').join(tre2341_stage_df.alias('RH'), joining_condition,'left_anti')\
                                                .select('StgUnqId','Status','RejectReason')

        update_rej_records(tre2341_treprvj_rej_df, "Parent Not Found", stage_treprvj_tbl_name)

        tre2341_treprvj_tre2481_rej_df  = tre2481_stage_df.alias('LH').join(tre2341_treprvj_df.alias('RH'), joining_condition,'left_anti')\
                                                .select('StgUnqId','Status','RejectReason')

        update_rej_records(tre2341_treprvj_tre2481_rej_df, "Parent Not Found", stage_tre2481_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        #Constructing tre2341 dataframe
        tre2341_treprvj_cols_lst = ['LH.' + col for col in tre2341_stage_df.columns] + ['RH.' + col for col in treprvj_columns]
        tre2341_with_treprvj_df = tre2341_stage_df.alias('LH')\
                                            .join(treprvj_stage_full_df.alias('RH'), joining_condition,'left')\
                                            .select(*tre2341_treprvj_cols_lst)

        tre2341_construct_cols_lst =  ['LH.' + col for col in  tre2341_with_treprvj_df.columns] + ['RH.' + col for col in tre2481_columns]
        tre2341_construct_df =  tre2341_with_treprvj_df.alias('LH')\
                                            .join(tre2481_stage_full_df.alias('RH'), joining_condition,'left')\
                                            .select(*tre2341_construct_cols_lst)\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))


        #Constructing treprvj dataframe
        treprvj_filtered_df = treprvj_stage_df.alias('LH')\
                                            .join(tre2341_stage_df.alias('RH'),joining_condition,'left_anti')
        
        treprvj_with_tre2341_cols_lst =  ['LH.' + col for col in  treprvj_filtered_df.columns] +  ['RH.' + col for col in tre2341_columns]
        treprvj_with_tre2341_df = treprvj_filtered_df.alias('LH')\
                                            .join(tre2341_stage_full_df.alias('RH'), joining_condition,'inner')\
                                            .select(*treprvj_with_tre2341_cols_lst)

        treprvj_rej_df           =    treprvj_filtered_df.alias('LH').join(tre2341_stage_full_df.alias('RH'), joining_condition,'left_anti')\
                                                .select('StgUnqId','Status','RejectReason')   

        update_rej_records(treprvj_rej_df, "Parent Not Found", stage_treprvj_tbl_name)
                                           
        treprvj_construct_cols_lst = ['LH.' + col for col in  treprvj_with_tre2341_df.columns] +  ['RH.' + col for col in tre2481_columns]
        treprvj_construct_df = treprvj_with_tre2341_df.alias('LH')\
                                            .join(tre2481_stage_full_df.alias('RH'), joining_condition,'left')\
                                            .select(*treprvj_construct_cols_lst)\
                                            .drop('StgUnqId')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))


        #Constructing tre2481 dataframe
        tre2481_filtered_with_tre2341_df = tre2481_stage_df.alias('LH')\
                                            .join(tre2341_stage_df.alias('RH'),joining_condition,'left_anti')

        tre2481_filtered_df              = tre2481_filtered_with_tre2341_df.alias('LH')\
                                            .join(treprvj_stage_df.alias('RH'),joining_condition,'left_anti')

        tre2481_tre2341_cols_lst        =  ['LH.' + col for col in  tre2481_filtered_df.columns] + ['RH.' + col for col in tre2341_columns]
        tre2481_tre2341_df              = tre2481_filtered_df.alias('LH')\
                                                .join(tre2341_stage_full_df.alias('RH'), joining_condition,'inner')\
                                                .select(*tre2481_tre2341_cols_lst)

        tre2481_rej_df                  =    tre2481_filtered_df.alias('LH').join(tre2341_stage_full_df.alias('RH'), joining_condition,'left_anti')\
                                                .select('StgUnqId','Status','RejectReason')   

        update_rej_records(tre2481_rej_df , "Parent Not Found", stage_tre2481_tbl_name)

        tre2481_construct_cols_lst      = ['LH.' + col for col in  tre2481_tre2341_df.columns] +  ['RH.' + col for col in treprvj_columns]
        tre2481_construct_df            = tre2481_tre2341_df .alias('LH')\
                                                    .join(treprvj_stage_full_df.alias('RH'), joining_condition,'left')\
                                                    .select(*tre2481_construct_cols_lst)\
                                                    .drop('StgUnqId')\
                                                    .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                                    .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))
    

        #union all constructed dataframes
        tre2341_treprvj_tre2481_df =  tre2341_construct_df.unionByName(tre2481_construct_df, allowMissingColumns=True)\
                                            .unionByName(treprvj_construct_df, allowMissingColumns=True)

        
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))

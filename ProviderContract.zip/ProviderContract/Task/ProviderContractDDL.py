# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates ProviderContract Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Adls connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"ProviderContract{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### MandateSpecialist

# COMMAND ----------

Mandate_Specialist = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_MandateSpecialist(
MandateSpecialistKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY 
,ProviderContractKey BIGINT NOT NULL
,MandateSpecialistId VARCHAR(50)
,LineOfBusinessCode VARCHAR(20)
,MandateSpecialistDescription VARCHAR(256)
,ProviderContractName VARCHAR(55)
,MandateSpecialistStartDate DATE
,MandateSpecialistEndDate DATE
,ProductMatchIndicator CHAR(1)
,FinanceLedgerIndicator CHAR(1)
,CopyFromId VARCHAR(20)
,CopyIndicator BOOLEAN
,NotifyEmailId VARCHAR(30)
,DerivedIndicator STRING
,CreatedBy STRING NOT NULL
,CreatedDateTime TIMESTAMP NOT NULL
,ModifiedBy STRING
,ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/MandateSpecialist'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractPaymentTerm

# COMMAND ----------

Provider_Contract_PaymentTerm = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractPaymentTerm(
  ProviderContractPaymentTermKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
  ,ProviderContractKey BIGINT NOT NULL
  ,PDAInitName VARCHAR(55)
  ,PaymentStatusCode VARCHAR(20)
  ,ClaimDeductibleIndicator CHAR(1)
  ,ClaimPaymentDefaultIndicator CHAR(1)
  ,StartDate DATE NOT NULL
  ,EndDate DATE
  ,FundMethodCode VARCHAR(20)
  ,FundNumber VARCHAR(10)
  ,FundPrepayIndicator CHAR(1)
  ,HumanaClaimPaymentCode VARCHAR(20)
  ,DerivedIndicator STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP NOT NULL
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractPaymentTerm'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContract

# COMMAND ----------

Provider_Contract = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContract(
  ProviderContractKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
  ,ProviderKey BIGINT NOT NULL 
  ,ProviderId VARCHAR(50)
  ,ProviderSuffixCode VARCHAR(20)
  ,ProviderServiceTypeCode VARCHAR(20)
  ,ProviderSequenceNumber VARCHAR(50)
  ,PcaGrpId CHAR(8) 
  ,AdditionalMaximumCount INTEGER
  ,FundPeriodBeginCode VARCHAR(20)
  ,CapitationBeginCode VARCHAR(20)
  ,CapitationEndCode VARCHAR(20)
  ,CategoryCode VARCHAR(20)
  ,ContractCountyCode VARCHAR(55)
  ,ContractStartDate DATE
  ,ContractEndDate DATE
  ,ContractEndReasonCode VARCHAR(20)
  ,ContractLagAnnualCount INT
  ,ContractLagPeriodCount INT
  ,ContractProgramTypeCode VARCHAR(20)
  ,DefaultStatusIndicator CHAR(1)
  ,DistanceCalculatedIndicator CHAR(1)
  ,DistanceLengthNumber VARCHAR(50)
  ,EverPaymentCode VARCHAR(20)
  ,FundClassCode VARCHAR(20)
  ,IndividualSettlementRuleCode VARCHAR(20)
  ,LateClaimCode VARCHAR(20)
  ,MemberLimitCode VARCHAR(20)
  ,MemberTypeCode VARCHAR(20)
  ,PaymentAccountNumber VARCHAR(50)
  ,PaymentDateNumber INTEGER
  ,PaymentOptionCode VARCHAR(20)
  ,ProductLineOfBusinessCode VARCHAR(20)
  ,ProviderContractDescription VARCHAR(128)
  ,ProviderContractId VARCHAR(50)
  ,ProviderGrouperId VARCHAR(50)
  ,ProviderMemberCount INTEGER
  ,RecoveryFundTypeCode VARCHAR(20)
  ,RecoveryMonthCount INTEGER
  ,RecoveryPaymentAmount DECIMAL(20,6)
  ,RecoveryPercent DECIMAL(20,6)
  ,RenewalDate DATE
  ,ReprocessIndicator CHAR(1)
  ,ReprocessDate DATE
  ,Settlement1Description VARCHAR(128)
  ,Settlement2Description VARCHAR(128)
  ,SettlementAnnualPaymentCode VARCHAR(20)
  ,SettlementByFundIndicator CHAR(1)
  ,SettlementFrequencyCode VARCHAR(20)
  ,SettlementPeriodPaymentCode VARCHAR(20)
  ,StatusCode VARCHAR(20)
  ,StatusDate DATE
  ,TerminationMaximumCount INTEGER
  ,ReportPackageControlId VARCHAR(50)
  ,ExpenseId VARCHAR(20)
  ,ReportControlId VARCHAR(50)
  ,ReportDetailIndicator CHAR(1)
  ,ReportIndicator BOOLEAN
  ,PCPSequenceNumber DECIMAL(10,5)
  ,PCPPlanYearCode VARCHAR(5)
  ,IPAIndicator CHAR(1)
  ,ReportOptionCode CHAR(1)
  ,MassMoveInd CHAR(1)
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContract'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractAssociation

# COMMAND ----------

Provider_Contract_Association = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractAssociation(
ProviderContractAssociationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderId VARCHAR(50),
ProviderSuffixCode VARCHAR(20),
ProviderServiceTypeCode VARCHAR(20),
ProviderSequenceNumber VARCHAR(50),
AssociationCode VARCHAR(20),
ContractAssociationEndDate DATE,
ContractAssociationStartDate DATE NOT NULL,
ExpenseCode VARCHAR(20),
PCPContractId VARCHAR(50),
PCPContractKey BIGINT NOT NULL,
SpecialistContractKey BIGINT NOT NULL,
SpecialistContractId STRING,
TypeCode STRING,
SubordinateCtrctIndicator boolean,
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractAssociation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### CostAllocationProgramCode

# COMMAND ----------

Cost_Allocation_Program_Code = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_CostAllocationProgramCode(
  CostAllocationProgramCodeKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,CostAllocationProgramId STRING
  ,CostAllocationProgramName STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,HcsServiceTypeCode STRING
  ,ManualAdjustmentCode STRING
  ,DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/CostAllocationProgramCode'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### CostAllocationProgram
# MAGIC

# COMMAND ----------

Cost_Allocation_Program = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_CostAllocationProgram(
  CostAllocationProgramKey	BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
  ,CostAllocationKey	BIGINT NOT NULL
  ,CostAllocationAccountCode	VARCHAR(20)
  ,CostAllocationAccountIndicator CHAR(1)
  ,CostAllocationPercentIndicator	INTEGER
  ,CostAllocationProgramId	VARCHAR(50)
  ,CostAllocationProgramName	VARCHAR(55)
  ,CostFundEndDate	DATE
  ,CostFundStartDate	DATE
  ,CostAllocationFundType VARCHAR(20)
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime	TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime	TIMESTAMP
  ,DerivedIndicator STRING
  )"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/CostAllocationProgram'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractGrouperAssc

# COMMAND ----------

Provider_Contract_Grouper_Assc = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractGrouperAssc(
ProviderContractGrouperAsscKey BIGINT GENERATED ALWAYS AS IDENTITY NOT NULL,
ProviderGrouperKey BIGINT NOT NULL,
ProviderContractId STRING,
ProviderGrouperId STRING,
ProviderGrouperTypeCode STRING,
DataSourceCode STRING,
StartDate DATE,
EndDate DATE,
TempusStatusIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractGrouperAssc'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractFund

# COMMAND ----------

Provider_Contract_Fund = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractFund(
ProviderContractFundKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractKey BIGINT NOT NULL,
FundAccountKey BIGINT NOT NULL,
ProviderId VARCHAR(50),
ProviderSuffixCode VARCHAR(20),
ProviderServiceTypeCode VARCHAR(20),
ProviderSequenceNumber VARCHAR(50),
CompletionFactorId varchar(50),
ExpensedFundTypeCode varchar(20),
FundClaimCalculatedMethodCode varchar(20),
FundClaimRecoverIndicator CHAR(1),
FundExpenseMethodCode varchar(20),
FundIBNRMethodCode varchar(20),
FundIBNRPercent Decimal(10,5),
FundMethodCode varchar(20),
FundPeriodMonthCount INTEGER,
FundPlanClaimPaymentIndicator CHAR(1),
FundSequenceNumber INTEGER,
FundTypeCode varchar(20),
IBNRPeriodMonthCount INTEGER,
PartAEligibileIndicator CHAR(1),
PaymentLastDate DATE,
PeriodSettlementPayIndicator CHAR(1),
PeriodPaymentBasisCode varchar(20),
PeriodPaymentDirectPayPercent Decimal(10,5),
PeriodPaymentFrequencyCount INTEGER,
PrePaymentServiceIndicator CHAR(1),
ProviderDiscountKey BIGINT,
CapitationPaymentDate INT,
CapitationPaymentCode varchar(20),
CatastrophHoldBackIndicator CHAR(1),
ContnAdmnDayCount INTEGER,
FinalSettlementId varchar(50),
PaymentContractId varchar(50),
FundedAcountId varchar(50),
PeriodSettlementId varchar(50),
SharedFundGroupId VARCHAR(20),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractFund'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### OutOfAreaNetwork

# COMMAND ----------

Out_Of_Area_Network = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_OutOfAreaNetwork(
  OutOfAreaNetworkKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
  OutOfAreaNetworkId VARCHAR(50),
  OutOfAreaNetworkIndicator CHAR(1),
  OutOfAreaNetworkTypeCode VARCHAR(20),
  OutOfAreaNetworkValueCode VARCHAR(20),
  RuleMileageNumber INT,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedDateTime TIMESTAMP,
  CreatedBy STRING NOT NULL,
  DerivedIndicator STRING,
  ModifiedBy STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/OutOfAreaNetwork'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractTransfer

# COMMAND ----------

Provider_Contract_Transfer = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractTransfer(
ProviderContractTransferKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
ContractTransferEndDate	DATE,
ContractTransferStartDate DATE,
TransferStatusCode VARCHAR(30),
ContractTransferCode VARCHAR(20),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
FromProviderId VARCHAR(50),
FromProviderSequenceNumber VARCHAR(50),
FromProviderServiceTypeCode VARCHAR(20),
FromProviderSuffixCode VARCHAR(20),
IdCardRequestIndicator CHAR(1),
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP NOT NULL,
FromProviderContractKey BIGINT NOT NULL,
ToProviderContractKey BIGINT NOT NULL,
ToProviderId VARCHAR(50),
ToProviderSequenceNumber VARCHAR(50),
ToProviderServiceTypeCode VARCHAR(20),
ToProviderSuffixCode VARCHAR(20),
FromProviderContractId VARCHAR(50),
ToProviderContractId VARCHAR(50),
OperatorName VARCHAR(30),
DerivedIndicator STRING,
ProviderChangeProcessDate DATE
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractTransfer'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractGeoMktAffiliation

# COMMAND ----------

Provider_Contract_GeoMktAffiliation = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractGeoMktAffiliation(
ProviderContractGeoMktAffilKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractKey BIGINT NOT NULL,
GeoMarketAffiliationKey BIGINT NOT NULL,
GeoMarketId VARCHAR(50),
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
ProviderContractId VARCHAR(50),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
StartDate Date,
EndDate Date,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractGeoMktAffiliation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractProductAffiliation

# COMMAND ----------

Provider_Contract_ProductAffiliation = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractProductAffiliation(
ProviderContractProductAffiliationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractKey BIGINT NOT NULL,
ProductAffiliationKey BIGINT NOT NULL,
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
LineOfBusinessCode STRING,
LocationId STRING,
ProviderContractId VARCHAR(50),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractProductAffiliation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractTransferZipCode

# COMMAND ----------

Provider_Contract_TransferZipCode = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractTransferZipCode(
ProviderContractTransferZipCodeKey BIGINT GENERATED ALWAYS AS IDENTITY NOT NULL,
FromProviderContractKey BIGINT NOT NULL,
FromProviderId VARCHAR(50),
FromProviderSequenceNumber VARCHAR(50),
FromProviderServiceTypeCode VARCHAR(20),
FromProviderSuffixCode VARCHAR(20),
ProviderChangeProcessDate DATE,
ZipCode VARCHAR(5),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP NOT NULL,
DerivedIndicator STRING,
PcaChgStatCd STRING,
UpdtDt INT
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractTransferZipCode'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### CostAllocation

# COMMAND ----------

Cost_Allocation = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_CostAllocation(
CostAllocationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
CostAllocationId VARCHAR(50),
CostAllocationName VARCHAR(55),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/CostAllocation'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### FundAccount

# COMMAND ----------

Fund_Account = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_FundAccount(
FundAccountKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
FundAccountId VARCHAR(50),
LiabilityAccountNumber INTEGER,
LiabilityOffsetAccountNumber INTEGER,
ExpenseAccountNumber INTEGER,
StoplossAccountNumber INTEGER,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
DerivedIndicator STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/FundAccount'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractPaymentHeader

# COMMAND ----------

Provider_Contract_PaymentHeader = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractPaymentHeader(
ProviderContractPymtHdrKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractKey BIGINT NOT NULL,
PaymentTypeCode VARCHAR(20) NOT NULL,
PaymentDate DATE NOT NULL
,ProviderId VARCHAR(50) 
,ProviderSuffixCode VARCHAR(20) 
,ProviderServiceTypeCode VARCHAR(20) 
,ProviderSequenceNumber VARCHAR(50), 
PaymentStatusCode VARCHAR(30),
PaymentStatusDate DATE,
PrimaryBroughtFrwrdPymtAmt DECIMAL(20,6),
CapitationPaymentAmount DECIMAL(20,6),
IMMCKPaymentAmount DECIMAL(20,6),
SettlementPaymentAmount DECIMAL(20,6),
ManualAdjustmentPaymentAmount DECIMAL(20,6),
NetPaymentAmount DECIMAL(20,6),
ProviderBroughtFrwrdPymtAmt DECIMAL(20,6),
PaymentApproverName VARCHAR(55),
PaymentUpdaterName VARCHAR(55),
PaymentContractId VARCHAR(50),
PaymentDDDate INTEGER,
FrozenPaymentAmount DECIMAL (20,6),
FrozenIndividualAmount DECIMAL (20,6),
ContractPaymentIndicator CHAR (1),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING,
part_col double
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractPaymentHeader'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractPaymentDetail

# COMMAND ----------

Provider_Contract_PaymentDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractPaymentDetail(
ProviderContractPymtDtlKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractPymtHdrKey BIGINT NOT NULL,
PaymentAccountDate DATE NOT NULL,
AccountStatusDate DATE,
FundPeriodBeginDate DATE,
FundPeriodEndDate DATE,
FundTypeCode VARCHAR(20),
PaymentAccountAmount DECIMAL(20,6),
PaymentAccountCode VARCHAR(20),
PaymentAccountDescription VARCHAR(128),
PaymentAccountGenLdgrIndicator CHAR(1),
PaymentAccountLineDescription VARCHAR(128),
PaymentAccountNetAmount DECIMAL(20,6),
PaymentAccountPercentage DECIMAL(10,5),
PaymentAccountStatusCode VARCHAR(30),
PaymentCreditAccountNumber VARCHAR(50),
PaymentDate DATE,
PaymentDebitAccountNumber VARCHAR(50),
PaymentDirectPercent DECIMAL(10,5),
PaymentPayaIndicator CHAR(1),
PaymentReportSequenceNumber INT,
PaymentTypeCode VARCHAR(20),
PerPaymentBasisCode VARCHAR(20),
PreviousPaymentAmount DECIMAL(20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP NOT NULL,
DerivedIndicator STRING,
part_col double
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractPaymentDetail'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractFundPayment

# COMMAND ----------

Provider_Contract_FundPayment = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractFundPayment(
ProviderContractFundPaymentKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractFundKey BIGINT NOT NULL,
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
FundSequenceNumber INTEGER,
CapitationFundAmount DECIMAL(20,6),
CatastrophWiithholdAdjstmntAmt DECIMAL(20,6),
CatastrophicWiithholdAmount DECIMAL(20,6),
DeficitAbsorbAmount DECIMAL(20,6),
ExpensedMemberMonthCount INTEGER,
FundAmount DECIMAL(20,6),
FundBroughtForwardAmount DECIMAL(20,6),
FundCapitationExpenseAmount DECIMAL(20,6),
FundClaimBenefitAmount DECIMAL(20,6),
FundClaimDiscountAmount DECIMAL(20,6),
FundClaimExpenseAmount DECIMAL(20,6),
FundClosedDate DATE,
FundDirectPaymentAmount DECIMAL(20,6),
FundFinalPaymentAmount DECIMAL(20,6),
FundIBNRAmount DECIMAL(20,6),
FundIBNRSettledIndicator CHAR (1),
FundLateClaimAmount DECIMAL(20,6),
FundManualAdjustmentAmount DECIMAL(20,6),
FundMemberMonthCount INTEGER,
FundNetACTAmount DECIMAL(20,6),
FundOtherAmount DECIMAL(20,6),
FundProviderRiskAmount DECIMAL(20,6),
FundReconciliationAmount DECIMAL(20,6),
FundReturnLimitAmount DECIMAL(20,6),
FundSettlementAmount DECIMAL(20,6),
FundStatusCode VARCHAR(30),
FundStatusDate DATE,
FundTransferInAmount DECIMAL(20,6),
FundTransferOutAmount DECIMAL(20,6),
FundTypeCode VARCHAR(20),
FundWithholdClaimAmount DECIMAL(20,6),
PeriodBeginDate DATE NOT NULL,
PeriodEndDate DATE,
PrimaryPeriodBroughtFrwrdAmt DECIMAL(20,6),
ReturnLimitMonthCount INTEGER,
StoplossExcessAmount DECIMAL(20,6),
OpenFundIndicator CHAR(1),
FundComment VARCHAR(128),
DerivedIndicator STRING,
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractFundPayment'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### FundMonthPaymentDetail

# COMMAND ----------

Fund_Month_Payment_Detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_FundMonthPaymentDetail(
FundMonthPaymentDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractFundPaymentKey BIGINT NOT NULL,
PeriodBeginDate DATE,
ProviderId VARCHAR(50),
ProviderSuffixCode VARCHAR(20),
ProviderServiceTypeCode VARCHAR(20),
ProviderSequenceNumber VARCHAR(50),
DerivedIndicator STRING,
FundSequenceNumber INTEGER,
MonthDate INTEGER,
MonthCapitationFundAmount DECIMAL(20,6),
MemberMonthCount INTEGER,
MonthWithholdClaimAmount DECIMAL(20,6),
MonthOtherFundAmount DECIMAL(20,6),
MonthCapitationExpenseAmount DECIMAL(20,6),
MonthExpenseMemberCount INTEGER,
MonthClaimExpenseAmount DECIMAL(20,6),
MonthClaimDiscountAmount DECIMAL(20,6),
StoplossExcessAmount DECIMAL(20,6),
MonthManualAdjustmentAmount DECIMAL(20,6),
MonthIBNRAmount DECIMAL(20,6),
MonthFundAdjustmentAmount DECIMAL(20,6),
MonthExpenseAdjustmentAmount DECIMAL(20,6),
MonthClaimBenefitAmount DECIMAL(20,6),
MonthStoplossExpenseAmount DECIMAL(20,6),
MonthReturnLimitCount INTEGER,
MonthReturnLimitAmount DECIMAL(20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
part_col double
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/FundMonthPaymentDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### FundHistoryPaymentDetail

# COMMAND ----------

FundHistory_PaymentDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_FundHistoryPaymentDetail(
FundHistoryPaymentDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
ProviderContractFundPaymentKey BIGINT NOT NULL,
DerivedIndicator STRING,
HistoryMonthDate DATE NOT NULL,
ProviderId VARCHAR(50),
ProviderSuffixCode VARCHAR(20),
ProviderServiceTypeCode VARCHAR(20),
ProviderSequenceNumber VARCHAR(50),
PeriodBeginDate DATE,
FundSequenceNumber INTEGER,
HistoryCapitationFundAmount DECIMAL (20,6),
HistoryCapitationCurrentAmount DECIMAL (20,6),
HistoryCapitationAdjstmntAmt DECIMAL (20,6),
HistoryMemberMonthCount INTEGER,
HistoryWithholdClaimAmount DECIMAL (20,6),
HistoryOtherFundAmount DECIMAL (20,6),
HistoryCapitationExpenseAmount DECIMAL (20,6),
HistoryExpenseMemberCount INTEGER,
HistoryClaimExpenseAmount DECIMAL (20,6),
HistoryClaimDiscountAmount DECIMAL (20,6),
StoplossExcessAmount DECIMAL (20,6),
HistoryDirectPaymentAmount DECIMAL (20,6),
HistoryPeriodPaymentAmount DECIMAL (20,6),
CurrentCapitationPaymentAmount DECIMAL (20,6),
CapitationAdjustmentPaymentAmt DECIMAL (20,6),
IMMCKPaymentAmount DECIMAL (20,6),
HistoryManualAdjustmentAmount DECIMAL (20,6),
HistoryIBNRAmount DECIMAL (20,6),
ReturnLimitCount INTEGER,
HistoryReturnLimitAmount DECIMAL (20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
part_col double
)PARTITIONED BY (part_col)"""
# USING DELTA
# PARTITIONED BY (part_col)
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/FundHistoryPaymentDetail'"""



# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractAccrue

# COMMAND ----------

Provider_Contract_Accrue = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractAccrue(
ProviderContractAccrueKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
AccrueMonthAmount DECIMAL (20,6),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
FundTypeCode VARCHAR (20),
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP,
PerMonthDate DATE NOT NULL,
PeriodBeginDate DATE,
PeriodEndDate DATE,
ProviderContractKey BIGINT NOT NULL,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractAccrue'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### CompletionFactor
# MAGIC

# COMMAND ----------

Completion_Factor = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_CompletionFactor(
CompletionFactorKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
CompletionFactorId	VARCHAR(50),
CompletionFactorIndicator	CHAR(1),
CompletionFactorLockDate	DATE,
CompletionFactorLockName VARCHAR(55),
CompletionFactorPOSCount	INTEGER,
CompletionFactorPercent	DECIMAL(20,6),
CreatedBy	STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
ModifiedBy	STRING,
ModifiedDateTime TIMESTAMP,
CompletionFactorDeleteIndicator	CHAR(1),
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/CompletionFactor'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractControl
# MAGIC

# COMMAND ----------

Provider_Contract_Control = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractControl(
ProviderContractControlKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
ProviderContractKey	BIGINT NOT NULL,
ProviderContractId VARCHAR(50),
ControlTypeCode	VARCHAR(20),
ControlTypeId VARCHAR(50),
CreatedBy	STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
ModifiedBy	STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractControl'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractType
# MAGIC

# COMMAND ----------

Provider_Contract_Type = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.providerContract_ProviderContractType(
ProviderContractTypeKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
ProviderContractKey	BIGINT NOT NULL,
ProviderContractId VARCHAR(50),
ContractTypeCode VARCHAR(20),
ContractlTypeId VARCHAR(50),
CreatedBy	STRING NOT NULL,
CreatedDateTime	TIMESTAMP NOT NULL,
ModifiedBy	STRING,
ModifiedDateTime TIMESTAMP,
DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/providercontract/curated/ProviderContractType'"""

# COMMAND ----------

tbl_mapping = {
"providerContract_MandateSpecialist" : Mandate_Specialist,
"providerContract_ProviderContractPaymentTerm" : Provider_Contract_PaymentTerm,
"providerContract_ProviderContract" : Provider_Contract,
"providerContract_ProviderContractAssociation" : Provider_Contract_Association,
"providerContract_CostAllocationProgramCode" : Cost_Allocation_Program_Code,
"providerContract_CostAllocationProgram" : Cost_Allocation_Program,
"providerContract_ProviderContractGrouperAssc" : Provider_Contract_Grouper_Assc,
"providerContract_ProviderContractFund" : Provider_Contract_Fund,
"providerContract_OutOfAreaNetwork" : Out_Of_Area_Network,
"providerContract_ProviderContractTransfer" : Provider_Contract_Transfer,
"providerContract_ProviderContractGeoMktAffiliation" : Provider_Contract_GeoMktAffiliation,
"providerContract_ProviderContractProductAffiliation" : Provider_Contract_ProductAffiliation,
"providerContract_ProviderContractTransferZipCode" : Provider_Contract_TransferZipCode,
"providerContract_CostAllocation" : Cost_Allocation,
"providerContract_FundAccount" : Fund_Account,
"providerContract_ProviderContractPaymentHeader" : Provider_Contract_PaymentHeader,
"providerContract_ProviderContractPaymentDetail" : Provider_Contract_PaymentDetail,
"providerContract_ProviderContractFundPayment" : Provider_Contract_FundPayment,
"providerContract_FundMonthPaymentDetail" : Fund_Month_Payment_Detail,
"providerContract_FundHistoryPaymentDetail" : FundHistory_PaymentDetail,
"providerContract_ProviderContractAccrue" : Provider_Contract_Accrue,
"providerContract_CompletionFactor" : Completion_Factor,
"providerContract_ProviderContractControl" : Provider_Contract_Control,
"providerContract_ProviderContractType" : Provider_Contract_Type
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
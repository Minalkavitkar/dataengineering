# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2352
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.FundHistoryPaymentDetail
# MAGIC ##### Target Table
# MAGIC - ProviderContract.FundHistoryPaymentDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2352'
buz_keys = ["ProvIdNbr","ProvSuffCd","PcaServTyCd","PcaSeqNbr","FundRptSeqNbr","PerBegCymDt","HistMoCymDt"]
not_null_col_lst = ['ProviderContractFundPaymentKey'] 
table_code = 'ProviderContract_FundHistoryPaymentDetail'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_FundHistoryPaymentDetail')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE') 
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Importing necessary libraries
from pyspark.sql.functions import cast, col, lit, length, rand


# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    cur_pc_fundpymnt_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContractFundPayment')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load into Stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2352_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table, curated & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    tre2352_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    pc_fundpymnt_df = read_table_to_df(cur_pc_fundpymnt_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Column mapping as per SQL
column_mapping = {'ProvIdNbr': 'ProviderId',
 'ProvSuffCd': 'ProviderSuffixCode',
 'PcaServTyCd': 'ProviderServiceTypeCode',
 'PcaSeqNbr': 'ProviderSequenceNumber',
 'FundRptSeqNbr': 'FundSequenceNumber',
 'PerBegCymDt': 'PeriodBeginDate',
 'HistMoCymDt': 'HistoryMonthDate',
 'HistCapFundAmt': 'HistoryCapitationFundAmount',
 'HistCapCurrAmt': 'HistoryCapitationCurrentAmount',
 'HistCapAdjAmt': 'HistoryCapitationAdjstmntAmt',
 'HistMbrMoCnt': 'HistoryMemberMonthCount',
 'HistWhldClmAmt': 'HistoryWithholdClaimAmount',
 'HistOthFundAmt': 'HistoryOtherFundAmount',
 'HistCapExpsAmt': 'HistoryCapitationExpenseAmount',
 'HistExpsMbrCnt': 'HistoryExpenseMemberCount',
 'HistClmExpsAmt': 'HistoryClaimExpenseAmount',
 'HistClmDiscAmt': 'HistoryClaimDiscountAmount',
 'StoplsExcessAmt': 'StoplossExcessAmount',
 'HistDirPymtAmt': 'HistoryDirectPaymentAmount',
 'HistPerPymtAmt': 'HistoryPeriodPaymentAmount',
 'CurrCapPymtAmt': 'CurrentCapitationPaymentAmount',
 'CapAdjPymtAmt': 'CapitationAdjustmentPaymentAmt',
 'ImmCkPymtAmt': 'IMMCKPaymentAmount',
 'HistManAdjAmt': 'HistoryManualAdjustmentAmount',
 'HistIbnrAmt': 'HistoryIBNRAmount',
 'RetLimMoCnt': 'ReturnLimitCount',
 'HistRetLimAmt': 'HistoryReturnLimitAmount',
 'StgUnqId':'StgUnqId',
 'RunId':'RunId',
 'DerivedIndicator':'DerivedIndicator',
 'Status':'Status',
 'RejectReason':'RejectReason'}

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
FundHistoryPaymentDetail_schema = {'HistoryCapitationFundAmount': 'DECIMAL(20,6)',
 'HistoryCapitationCurrentAmount': 'DECIMAL(20,6)',
 'HistoryCapitationAdjstmntAmt': 'DECIMAL(20,6)',
 'HistoryMemberMonthCount': 'INT',
 'HistoryWithholdClaimAmount': 'DECIMAL(20,6)',
 'HistoryOtherFundAmount': 'DECIMAL(20,6)',
 'HistoryCapitationExpenseAmount': 'DECIMAL(20,6)',
 'HistoryExpenseMemberCount': 'INT',
 'HistoryClaimExpenseAmount': 'DECIMAL(20,6)',
 'HistoryClaimDiscountAmount': 'DECIMAL(20,6)',
 'StoplossExcessAmount': 'DECIMAL(20,6)',
 'HistoryDirectPaymentAmount': 'DECIMAL(20,6)',
 'HistoryPeriodPaymentAmount': 'DECIMAL(20,6)',
 'CurrentCapitationPaymentAmount': 'DECIMAL(20,6)',
 'CapitationAdjustmentPaymentAmt': 'DECIMAL(20,6)',
 'IMMCKPaymentAmount': 'DECIMAL(20,6)',
 'HistoryManualAdjustmentAmount': 'DECIMAL(20,6)',
 'HistoryIBNRAmount': 'DECIMAL(20,6)',
 'ReturnLimitCount': 'INT',
 'HistoryReturnLimitAmount': 'DECIMAL(20,6)',
 "ProviderSequenceNumber" : "VARCHAR(50)",
"ProviderId" : "VARCHAR(50)"}

# COMMAND ----------

# DBTITLE 1,Data type converstion and adding audit columns
#data type converstion and adding audit columns
try:
   col_mapped_df = col_name_mapping(tre2352_stage_df,column_mapping)
   audit_col_added_df = add_tgt_audit_column(col_mapped_df, pipeline_name, LOAD_TYPE)
   datatype_converted_df = dtype_tgt_conversion(audit_col_added_df, FundHistoryPaymentDetail_schema).withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
   date_convereted_df = dt_format_cym(datatype_converted_df, ['HistoryMonthDate','PeriodBeginDate'])
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join with FundPayment to get PeriodBeginDate, ProviderContractFundPaymentKey
#Joining pc_fundpymnt_df
try:
    joined_df = date_convereted_df.alias('LH')\
    .join(pc_fundpymnt_df.alias('RH'),\
        (col('LH.ProviderId') == col('RH.ProviderId')) & 
        (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & 
        (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & 
        (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')) & 
        (col('LH.FundSequenceNumber') == col('RH.FundSequenceNumber')) &
        (col('LH.PeriodBeginDate') == col('RH.PeriodBeginDate')) ,
        'left')\
    .select('LH.*','RH.ProviderContractFundPaymentKey')
except Exception as e:
        raise Exception('joining failed',str(e))


# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_df = remove_invalid_records(joined_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')\
                        .withColumn("part_col", round(rand() * 69 + 1,0))
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        lst = sorted(spark.sql(f'SHOW PARTITIONS {cur_tbl_name}').rdd.map(lambda x : x.part_col).collect())
        for part_id in lst:
            df = read_table_to_df(cur_tbl_name).filter(col('part_col') == part_id).drop('part_col','DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')  
            load_df_to_sf_sql_db_spark(df, 'ProviderContract.FundHistoryPaymentDetail')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions =['ProviderContractFundPaymentKey', 'HistoryMonthDate']
        delta_operate(cur_tbl_name, final_df ,conditions, table_code, tbl_conf_df, child_tbl_config_path,"FundHistoryPaymentDetailKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus':lit(None).cast('STRING'),
        'FundHistoryPaymentDetailKey':lit(None).cast("BIGINT"),
        'ProviderContractFundPaymentKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping).drop('part_col')  

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','HistoryMonthDate'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageFundHistoryPaymentDetail')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
            
except Exception as e:
    raise Exception ('load failed',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC  # Databricks notebook source
# MAGIC ##### Source Files 
# MAGIC - TRE2328
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractPaymentTerm
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractPaymentTerm

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2328'
buz_keys = ["ProvIdNbr", "ProvSuffCd", "PcaServTyCd", "PcaSeqNbr", "ReProvJctTs", "FundNbr", "Re2328PayoptTs"]
not_null_col_lst = ['ProviderContractKey','StartDate','ModifiedDateTime']
table_code = 'ProviderContract_ProviderContractPaymentTerm'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_Contract_Payment_term')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stg_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_ctrt_cur_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load data into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stg_tbl_name, tre2328_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping DB2 column to cloud columns
#column mapping db2 to cloud columns
tre2328_column_mapping = {
    "ClmDedInd" : "ClaimDeductibleIndicator"
    ,"ClmPymtDefltInd" : "ClaimPaymentDefaultIndicator"
    ,"InactDt" : "EndDate"
    ,"Re2328PayoptTs" : "CreatedDateTime"
    ,"FundMthdCd" : "FundMethodCode"
    ,"FundNbr" : "FundNumber"
    ,"FundPrepayInd" : "FundPrepayIndicator"
    ,"HumClmPymtInd" : "HumanaClaimPaymentCode"
    ,"PdatInitName" : "PDAInitName" 
    ,"EffDt" : "StartDate"
    ,"RecStatInd" : "PaymentStatusCode"
    ,"ProvIdNbr" : "ProvIdNbr"
    ,"ProvSuffCd" : "ProvSuffCd"
    ,"PcaServTyCd" : "PcaServTyCd"
    ,"PcaSeqNbr" : "PcaSeqNbr"
    ,"StgUnqId":"StgUnqId"
    ,"RunId":"RunId"
    ,"DerivedIndicator":"DerivedIndicator"
    ,"Status":"Status"
    ,"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table  & filtering the valid records
try:
    tre2328_stage_df = read_table_to_df(stg_tbl_name)\
        .filter(col('Status') == 'S')
    
    prov_ctrt_df = read_table_to_df(prov_ctrt_cur_tbl_name)\
        .select('ProviderContractKey', 'ProviderContractId')                
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column value mapping
col_map = {
    'ProvIdNbr':lpad(col('ProvIdNbr'), 9, '0')
    ,'StartDate':lpad(col('StartDate'), 6, '0')
    ,'EndDate':lpad(col('EndDate'), 6, '0')
    ,"ModifiedDateTime" : col('CreatedDateTime')
    ,"CreatedBy" : lit(PIPELINE_NAME)
    ,"ModifiedBy" : lit(PIPELINE_NAME)
}

# COMMAND ----------

# DBTITLE 1,column mapping and data format conversion and adding audit columns and joining with provider contract
#column mapping and data format converstion and adding audit columns and joining with provider contract
try:
    col_mapped_df = col_name_mapping(tre2328_stage_df, tre2328_column_mapping)\
                        .withColumns(col_map)

    dt_trans_df = date_format_conversion(col_mapped_df, ['StartDate', 'EndDate'], 'yyMMdd')

    pc_cols = [
        "ProvIdNbr",
        "ProvSuffCd",
        "PcaServTyCd",
        "PcaSeqNbr"]
    audit_added_df = create_provider_contract_id(dt_trans_df, pc_cols, "ProviderContractId")\
               .drop('ProvIdNbr', 'ProvSuffCd', 'PcaServTyCd', 'PcaSeqNbr')

    joined_df = audit_added_df.alias('LH').join(prov_ctrt_df.alias('RH'),\
        (col('LH.ProviderContractId') == col('RH.ProviderContractId')), 'left')\
            .select('LH.*', 'RH.ProviderContractKey')
except Exception as e:
    raise Exception('data format conversion or adding columns or joining failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_stage_df = remove_invalid_records(joined_df, stg_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderContractId')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        prv_ctrt_pymt_trm_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(prv_ctrt_pymt_trm_df,'ProviderContract.ProviderContractPaymentTerm')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['ProviderContractKey','FundNumber','ModifiedDateTime','StartDate']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractPaymentTermKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus':lit(None).cast('STRING'),
        'ProviderContractPaymentTermKey':lit(None).cast("BIGINT"),
        'ProviderContractKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_stage_df.withColumns(mapping)

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','StartDate','ModifiedDateTime'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractPaymentTerm')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREACCR
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractAccrue
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractAccrue

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TREACCR'
buz_keys = ['ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr','FundTyCd','PerMoCymDt']
not_null_col_lst = ['ProviderContractKey']
table_code = 'ProviderContract_ProviderContractAccrue'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContractAccrue')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import library functions
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    #getting keys, stage table names & destination table names

    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_ctrt_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treaccr_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    treaccr_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    prov_df = read_table_to_df(prv_ctrt_tbl_name).select('ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber', 'ProviderContractKey')
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Column mapping dictionary 
#Column mapping dictionary for hive_metastore.ProviderContract.StageTREACCR to hive_metastore.ProviderContract.ProviderContractAccrue
column_mapping = {
    'AccrMoAmt' : 'AccrueMonthAmount',
    'FundTyCd' : 'FundTypeCode',
    'PerMoCymDt' : 'PerMonthDate',
    'PerBegCymDt' : 'PeriodBeginDate',
    'PerEndCymDt' : 'PeriodEndDate',
    'ProvIdNbr' : 'ProviderId',
    'ProvSuffCd' : 'ProviderSuffixCode',
    'PcaServTyCd' : 'ProviderServiceTypeCode',
    'PcaSeqNbr' : 'ProviderSequenceNumber',
    'StgUnqId':'StgUnqId',
    'RunId':'RunId',
    'DerivedIndicator':'DerivedIndicator',
    'Status':'Status',
    'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Data type mapping dictionary 
# Some decimal columns have a different precision than what is expected in the curated layer. Delta columns need to have the same precision or it complains about it. This is the schema definition for the columns which don't match up.
datatype_change_schema = {
    'AccrMoAmt' : 'DECIMAL(20,6)',
    'ProvIdNbr' : 'String',
    'PcaSeqNbr' : 'String'
}

# COMMAND ----------

# DBTITLE 1,Adding audit columns and datatype conversion
#data type converstion and adding audit columns
try:
    data_type_converted_df = dtype_tgt_conversion(treaccr_stage_df, datatype_change_schema).withColumn('ProvIdNbr', lpad(col('ProvIdNbr'), 9, '0'))
    audit_col_added_df = add_tgt_audit_column(col_name_mapping(data_type_converted_df,column_mapping), PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Converting CYM dates into YYYY-MM-DD
try:
    # Converting YYYYMM dates into YYYY-MM-DD (1st for start/open dates, end of month day for end/close dates)
    start_date_transformed_df = dt_format_cym(audit_col_added_df, ['PeriodBeginDate', 'PerMonthDate'],'start')
    end_date_transformed_df = dt_format_cym(start_date_transformed_df, ['PeriodEndDate'],'end')
except Exception as e:
    raise Exception('CYM date conversion failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join to ProviderContract to get ProviderContractKey and filtering valid records
try:
    joined_df = end_date_transformed_df.alias('LH').join(prov_df.alias('RH'),\
        (col('LH.ProviderId') == col('RH.ProviderId')) & \
        (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & \
        (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & \
        (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')),'left') \
            .select('LH.*', 'RH.ProviderContractKey')
            
    final_stage_df = remove_invalid_records(joined_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber')
except Exception as e:
    raise Exception('Get ProviderContractKey or filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        provider_contract_accrue_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(provider_contract_accrue_df, 'ProviderContract.ProviderContractAccrue')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        
        conditions = ['FundTypeCode','PerMonthDate','ProviderContractKey']
        delta_operate(cur_tbl_name, final_df ,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractAccrueKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractAccrueKey' : lit(None).cast("BIGINT"),
        'ProviderContractKey' : lit(None).cast("BIGINT")
        }
        mapped_df= final_stage_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','PerMonthDate'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractAccrue')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed: ',str(e))
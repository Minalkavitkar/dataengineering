# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2344
# MAGIC - TRE2349
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractAssociation
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractAssociation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
tre2344_file_conf_key = 'PROVIDER_CONTRACT_TRE2344'
tre2349_file_conf_key = 'PROVIDER_CONTRACT_TRE2349'
not_null_col_lst = ['PCPContractKey','SpecialistContractKey','ContractAssociationStartDate'] 
table_code = 'ProviderContract_ProviderContractAssociation'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContractAssociation')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run "./ProviderContractStageSchema"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]

    # stage table to be loaded
    stage_tre2344_tbl_name = table_name_selector(tbl_conf_df, tre2344_file_conf_key)
    stage_tre2349_tbl_name = table_name_selector(tbl_conf_df, tre2349_file_conf_key)

    stage_tre2344_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2344_FULL")
    stage_tre2349_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2349_FULL")

    # required curated and SQL tables for transformation
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_grp_tbl_name = table_name_selector(tbl_conf_df, 'Provider_ProviderGrouper')
    cur_prov_contract = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
    # print(cur_tbl_name, prv_grp_tbl_name, cur_prov_contract)

    file_list = [
    [tre2344_file_conf_key, stage_tre2344_tbl_name, tre2344_schema, ['ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr','CtrctSubordKey']],
    [tre2349_file_conf_key, stage_tre2349_tbl_name, tre2349_schema, ['ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr','CtrctSubordKey','AsscBegCymdDt']]
            ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Load into stage table
try:
    for key, tbl_name, schema, buz_keys in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]}
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys , stage_full="StageFull")
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read data from stage and curated table 
#Reading data from stage table & filtering the valid records
try:
    tre2344_stage_df = read_table_to_df(stage_tre2344_tbl_name).filter(col('Status') == 'S')
    tre2349_stage_df = read_table_to_df(stage_tre2349_tbl_name).filter(col('Status') == 'S')
    ProvContrCur = read_table_to_df(cur_prov_contract)
    tre2344_stage_full_df = read_table_to_df(stage_tre2344_full_tbl_name)
    tre2349_stage_full_df = read_table_to_df(stage_tre2349_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition_tre2344 = (
        (col("LH.ProvIdNbr") == col("RH.ProvIdNbr"))
        & (col("LH.ProvSuffCd") == col("RH.ProvSuffCd"))
        & (col("LH.PcaServTyCd") == col("RH.PcaServTyCd"))
        & (col("LH.PcaSeqNbr") == col("RH.PcaSeqNbr"))
        & (col("LH.CtrctSubordKey") == col("RH.CtrctSubordKey"))
    )

    joining_condition_tre2349 = (
        (col("LH.ProvIdNbr") == col("RH.ProvIdNbr"))
        & (col("LH.ProvSuffCd") == col("RH.ProvSuffCd"))
        & (col("LH.PcaServTyCd") == col("RH.PcaServTyCd"))
        & (col("LH.PcaSeqNbr") == col("RH.PcaSeqNbr"))
        & (col("LH.CtrctSubordKey") == col("RH.CtrctSubordKey"))
        & (col("LH.AsscBegCymdDt") == col("RH.AsscBegCymdDt"))
    )

    # joining column of TRE2344 and TRE2349
    # joining tre2344_tre2349_df to get PCPContractKey

    if LOAD_TYPE == "FullLoad":
        tre2344_tre2349_df = tre2349_stage_df.alias('LH').join(tre2344_stage_df.alias('RH'), joining_condition_tre2344 , 'left').select("LH.*", "RH.AsscCtrctSupKey", "RH.ReSubordCtrcInd"
            )
        

        tre2344_rejc_df = (
            tre2344_stage_df.alias("LH")
            .join(tre2349_stage_df.alias("RH"), joining_condition_tre2344, "left_anti")
            .select("LH.StgUnqId", "LH.Status", "LH.RejectReason")
        )

        update_rej_records(tre2344_rejc_df, "Child Not Found", stage_tre2344_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        tre2349_with_tre2344_df = tre2349_stage_df.alias('LH')\
                                            .join(tre2344_stage_full_df.alias('RH'),joining_condition_tre2344,'left')\
                                            .select("LH.*", "RH.AsscCtrctSupKey", "RH.ReSubordCtrcInd")\
                                            .drop('ProdSeqNbr')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))
															
                
        tre2344_with_tre2349full_df = tre2344_stage_df.alias('LH')\
                                            .join(tre2349_stage_full_df.alias('RH'),joining_condition_tre2344,'inner')\
                                            .select('LH.*','RH.AsscBegCymdDt','RH.AsscEndCymdDt','RH.AsscCtrctTyCd','RH.AsscCtrctInd')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))
		
        tre2344_rejected_df = tre2344_stage_df.alias('LH')\
                                            .join(tre2349_stage_full_df.alias('RH') , joining_condition_tre2344,'left_anti').\
                                            select('StgUnqId','Status','RejectReason')
		

        #this join is required to avoid the duplicate delta formation
        tre2344_with_tre2349_df = tre2344_with_tre2349full_df.alias('LH')\
                                            .join(tre2349_with_tre2344_df.alias('RH'),joining_condition_tre2349,'left_anti')\
                                            .drop('StgUnqId')
		

       
        #union all constructed dataframes
        tre2344_tre2349_df =  tre2349_with_tre2344_df.unionByName(tre2344_with_tre2349_df, allowMissingColumns=True)
		

        update_rej_records(tre2344_rejected_df, "Child Not Found", stage_tre2344_tbl_name)
        


except Exception as e:
    raise Exception("preparing stage table failed: ", str(e))

# COMMAND ----------

# Converting column names according to doamin tables and adding audit columns to dataframe
try:
    tre2344_tre2349_df = tre2344_tre2349_df.withColumn('ProvIdNbr', lpad(col('ProvIdNbr'), 9, '0')).withColumn('PcaSeqNbr' , col('PcaSeqNbr').cast("string"))
    
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProviderContract to get PCPContractKey and ProviderContractKey2
try:
    tre2344_tre2349_provcon_df = (
        tre2344_tre2349_df.alias("LH1")
        .join(
            ProvContrCur.alias("RH1"),
            (col("LH1.PcaSeqNbr") == col("RH1.ProviderSequenceNumber"))
            & (col("LH1.PcaServTyCd") == col("RH1.ProviderServiceTypeCode"))
            & (col("LH1.ProvIdNbr") == col("RH1.ProviderId"))
            & (col("LH1.ProvSuffCd") == col("RH1.ProviderSuffixCode")),
            "left",
        )
        .select("LH1.*", "RH1.ProviderContractKey")
        .alias("PCPContractKey")
    )

    joined_df = (
        tre2344_tre2349_provcon_df.alias("LH3")
        .join(
            ProvContrCur.alias("RH3"),
            (col("LH3.CtrctSubordKey") == col("RH3.ProviderContractId")),
            "left",
        )
        .select("LH3.*", col("RH3.ProviderContractKey").alias("ProviderContractKey2"))
    )

except Exception as e:
    raise Exception("joining failed", str(e))

# COMMAND ----------

# DBTITLE 1,Column Mapping as per SQL
col_mapping = {
    "AsscCtrctInd": "AssociationCode",
    "AsscEndCymdDt": "ContractAssociationEndDate",
    "AsscBegCymdDt": "ContractAssociationStartDate",
    "AsscCtrctExpsCd": "ExpenseCode",
    "PcaSeqNbr": "ProviderSequenceNumber",
    "PcaServTyCd": "ProviderServiceTypeCode",
    "ProvIdNbr": "ProviderId",
    "ProvSuffCd": "ProviderSuffixCode",
    "AsscCtrctSupKey": "PCPContractId",
    "CtrctSubordKey": "SpecialistContractId",
    "AsscCtrctTyCd": "TypeCode",
    "ReSubordCtrcInd": "SubordinateCtrctIndicator",
    "ProviderContractKey": "PCPContractKey",
    "ProviderContractKey2": "SpecialistContractKey",
    "StgUnqId": "StgUnqId",
    "RunId": "RunId",
    "DerivedIndicator": "DerivedIndicator",
    "Status": "Status",
    "RejectReason": "RejectReason",
}


try:
    col_mapped_df = col_name_mapping(joined_df, col_mapping)
except Exception as e:
    raise Exception("preparing stage table failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
# data type converstion and adding audit columns
try:
    col_mapped_df = add_tgt_audit_column(
        col_name_mapping(joined_df, col_mapping), pipeline_name, LOAD_TYPE
    )
except Exception as e:
    raise Exception(
        "Column mapping and addition of audit columns  failed with error: ", str(e)
    )

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
dtype_mapping = {
            "SubordinateCtrctIndicator":"Boolean"
}

# COMMAND ----------

# DBTITLE 1,Datatype conversion
try:
    dtype_converted_df = dtype_tgt_conversion(col_mapped_df, dtype_mapping)
except Exception as e:
    raise Exception('datatype conversion failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_df = remove_invalid_records(dtype_converted_df, stage_tre2349_tbl_name, not_null_col_lst).drop('RunId' ,'Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
# curated load & Azure SQL load
try:
    if LOAD_TYPE == "FullLoad":
        TABLE_NAMES = cur_tbl_name.split(".")[-1]
        dbutils.notebook.run("./ProviderContractDDL", 0, {"TABLE_NAMES": TABLE_NAMES})

        write_to_curated(final_df, cur_tbl_name)
        cur_loaded_time = datetime.now()

        Provider_Contract_Association_df = read_table_to_df(cur_tbl_name).drop(
            "DerivedIndicator","ProviderSequenceNumber","ProviderServiceTypeCode","ProviderId","ProviderSuffixCode"
        )

        load_df_to_sf_sql_db_spark(
            Provider_Contract_Association_df,
            "ProviderContract.ProviderContractAssociation",
        )

        exit_notebook(
            run_id,
            "ProviderContract",
            LOAD_TYPE,
            table_code,
            seq_num,
            nb_start_time,
            cur_loaded_time,
            audit_table_name,
        )
    elif LOAD_TYPE == "DeltaLoad":
        conditions = [
            "ContractAssociationStartDate",
            "SpecialistContractKey",
            "PCPContractKey",
            "ExpenseCode",
        ]

        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractAssociationKey")
        cur_loaded_time = datetime.now()

        mapping = {
            "ProcessName": lit(None).cast("STRING"),
            "DeltaStatus": lit(None).cast("STRING"),
            "ProviderContractAssociationKey": lit(None).cast("BIGINT"),
            "PCPContractKey": lit(None).cast("BIGINT"),
            "SpecialistContractKey": lit(None).cast("BIGINT"),
        }

        delta_cols_updated_df = final_df.withColumns(mapping)
        delta_df= set_df_columns_not_nullable(spark,delta_cols_updated_df,['CreatedBy','CreatedDateTime','ContractAssociationStartDate'])
        
        provider_contract_df = delta_df.filter(
            col("DerivedIndicator") != "IGNORE"
        )

        load_df_to_sf_sql_db_spark(
            provider_contract_df, "ProviderContract.StageProviderContractAssociation"
        )

        exit_notebook(
            run_id,
            "ProviderContract",
            LOAD_TYPE,
            table_code,
            seq_num,
            nb_start_time,
            cur_loaded_time,
            audit_table_name,
        )
except Exception as e:
    raise Exception("load failed", str(e))
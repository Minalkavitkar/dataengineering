# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source table 
# MAGIC - ProviderContract.ProviderContractPaymentTerm
# MAGIC ##### Foreign Key Tables
# MAGIC - ProviderContract
# MAGIC ##### Outbound File
# MAGIC - TRE2328

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','ReverseSync')
dbutils.widgets.text('PIPELINE_NAME','Nb_ReverSyncProviderContract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SubjectArea','')
dbutils.widgets.text('DB2TableName','')
dbutils.widgets.text('END_DATE_TIME','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
SubjectArea = dbutils.widgets.get('SubjectArea')
DB2TableName = dbutils.widgets.get('DB2TableName')
end_date_time = dbutils.widgets.get('END_DATE_TIME')

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run "../../Utility/Validate"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
try:
    #Getting local parameter file path from environment variable helper
    local_parameter_file_path = env_local_parameter_config_path
    
    #Call function "get_table_information" to retrieve the information for respective subjectarea and db2tablename
    getLocalParameter = get_table_information(SubjectArea, DB2TableName)
    
    # Assigning the corresponding value to its variable
    table_code, src_table_name, JOB_NAME, AreaSequence, TableSequence = getLocalParameter
except Exception as e:
    raise Exception("unable to retrieve local parameter information: ",str(e))

# COMMAND ----------

# DBTITLE 1,Check the table run and get the startDateTime
try:
    start_date_time = notebook_run_check('ProviderContract', table_code, None, audit_table_name)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception('Get required details from environment variable helper notebook failed:',Message)

# COMMAND ----------

# DBTITLE 1,get the table names and config info
try:
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == JOB_NAME)
    ProviderContractTre2328 = config_dict[JOB_NAME]
    
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]

    container_name = default_config["ContainerName"]
    created_by = default_config["CreatedBy"]
    modified_by = default_config["ModifiedBy"]
    config = default_out_config["Config"]
    temp_path_suffix = ProviderContractTre2328["Outbound"]["TempFilePathSuffix"]
    outbnd_file_name = ProviderContractTre2328["Outbound"]["FileName"]
    outbnd_table_name = f'{databricks_catalog_name}.{databricks_schema_suf}.{ProviderContractTre2328["Outbound"]["TableName"]}'
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    file_path_prefix = default_out_config["FilePathPrefix"]

except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Table configuration failed: ",Message)


# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )

except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Path Creation failed:",Message)

# COMMAND ----------

# DBTITLE 1,Collect info for the source table from which the data will be retrieved
try:
    dict_of_cols = {
        'src_table_col_list': [  
        'ClaimDeductibleIndicator',
        'ClaimPaymentDefaultIndicator',
        'CreatedDateTime',
        'EndDate',
        'FundMethodCode',
        'FundNumber',
        'FundPrepayIndicator',
        'HumanaClaimPaymentCode'
        ,'PDAInitName'
        ,'StartDate'
        ,'PaymentStatusCode'
        ,'ModifiedBy'
        ,'CreatedBy'
    ],
        'foreignkey_list':[
            'ProviderContractKey'
        ],
        'ProviderContract_list': [
            'ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber'
        ]
    }

    fk_detail_list = get_foreign_key_table_detail_lst(dict_of_cols)
  

    src_table_qry = func_to_create_query(src_table_name, dict_of_cols, start_date_time, end_date_time,fk_detail_list)

    df_src_output = read_sf_sql_tbl_to_df_spark(query=src_table_qry)
    df_src_result = df_src_output.filter((~col('ModifiedBy').ilike(f'{modified_by}%')) &\
        (~col('CreatedBy').ilike(f'{created_by}%')))
    
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("All Details collection failed:",Message)

# COMMAND ----------

# DBTITLE 1,Column mapping for the ingested data from SQL
col_mapping ={
    'Indicator':'Indicator',
    'ProviderId':'ProvIdNbr',
    'ProviderSuffixCode':'ProvSuffCd',
    'ProviderServiceTypeCode':'PcaServTyCd',
    'ProviderSequenceNumber':'PcaSeqNbr',
    'CreatedDateTime':'Re2328PayoptTs',
    'FundNumber' : 'FundNbr',
    'StartDate' : 'EffDt',
    'EndDate':'InactDt',
    'HumanaClaimPaymentCode' : 'HumClmPymtInd',
    'FundPrepayIndicator' : 'FundPrepayInd',
    'FundMethodCode':'FundMthdCd',
    'ClaimPaymentDefaultIndicator':'ClmPymtDefltInd',
    'ClaimDeductibleIndicator':'ClmDedInd',
    'PaymentStatusCode' : 'RecStatInd',
    'PDAInitName' : 'PdatInitName' 
}

# COMMAND ----------

# DBTITLE 1,Add the columns which were not migrted to Azure
try:
    if df_src_result.isEmpty():
        df = df_src_result
        Message = f"{table_code} empty data exported successfully from {start_date_time} to {end_date_time}"
    else:
        withCols1 = {
            'AreaSequence':lit(AreaSequence),
            'TableSequence':lit(TableSequence),
            'SubjectArea':lit(SubjectArea),
            'DB2TableName':lit(DB2TableName),
            'ReProvJctTs':lit(None).cast('String'),
            'PltfmCd':lit(None).cast('String'),
            'LastChgCymdDt':lit(None).cast('Date'),
            'InactDt':lit(col('InactDt')).cast('Integer'),
            'EffDt':lit(col('EffDt')).cast('Integer')
        }

        df_mapped = col_name_mapping(df_src_result,col_mapping)
        df_final = df_mapped.withColumns(withCols1)

        #write to delta table
        write_df_as_delta_table(df_final,outbnd_table_name)

        #Read outbound table to df
        outbnd_df = read_table_to_df(outbnd_table_name)
        
        # Convert dataframe to fixed width length column.
        df = convert_col_to_fixed_width(fixed_config_df, outbnd_df)

        Message = f"{table_code} data exported successfully from {start_date_time} to {end_date_time}"
            
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Create data as per outbound file failed:",Message)

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(df, temp_csv_path, config)

    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
    
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Run failed with error:",Message)
else:
    exit_notebook(run_id,'ProviderContract',LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name, Message,'Success')
    dbutils.notebook.exit(Message)
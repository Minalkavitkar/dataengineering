# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2377, ProviderContract.ProviderContract
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractTransferZipCode
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractTransferZipCode

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2377'
buz_keys = ['OldProvIdNbr','OldProvSuffCd','OldPcaServTyCd','OldPcaSeqNbr','PcaChgStatCd','UpdtDt','Re2376CntnewTs','PcaTranZipCd']
not_null_col_lst = ['FromProviderContractKey']
table_code = 'ProviderContract_ProviderContractTransferZipCode'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])  
    child_tbl_config_path = conf["ChildTblConfigPath"]  
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_ctrt_tbt_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
#Loading Stage Table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2377_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# DBTITLE 1,Reading valid records from Stage Table
#Reading valid records from Stage Table
try:    
    tre2377_stage_df = spark.read.table(stage_tbl_name)\
                    .filter(col('Status') == 'S')
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Column mapping DB2 column to cloud columns
col_mapping ={
'OldProvIdNbr':'FromProviderId'
,'OldPcaSeqNbr':'FromProviderSequenceNumber'
,'OldPcaServTyCd':'FromProviderServiceTypeCode'
,'OldProvSuffCd':'FromProviderSuffixCode'
,'Re2376CntnewTs':'ProviderChangeProcessDate'
,'PcaTranZipCd':'ZipCode'
,'StgUnqId':'StgUnqId'
,'RunId':'RunId'
,'DerivedIndicator':'DerivedIndicator'
,'Status':'Status'
,'RejectReason':'RejectReason'
,'PcaChgStatCd':'PcaChgStatCd'
,'UpdtDt':'UpdtDt'
 }

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
#column mapping and adding audit columns
try:
    audit_col_df = add_tgt_audit_column(col_name_mapping(tre2377_stage_df,col_mapping),pipeline_name)
    audit_mod_col_df = audit_col_df.withColumn('ModifiedDateTime',col('ProviderChangeProcessDate'))\
                            .withColumn('CreatedDateTime',col('ProviderChangeProcessDate'))\
                            .withColumn('ModifiedBy',col('CreatedBy'))
except Exception as e:
    raise Exception('adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Changing Datatypes and adding leading zeros to column FromProviderId value
#Changing Datatypes and adding leading zeros to column FromProviderId value
try:
    schema = {"FromProviderSequenceNumber" : "STRING"
                ,"FromProviderId" : "STRING"
                ,'ProviderChangeProcessDate': "DATE"}
    dtype_chng_df = dtype_tgt_conversion(audit_mod_col_df, schema)\
                    .withColumn('FromProviderId', lpad(col('FromProviderId'), 9, '0'))
except Exception as e:
    raise Exception('Changing Datatypes and adding leading zeros to column FromProviderId value failed',str(e))                    

# COMMAND ----------

# DBTITLE 1,Reading ProviderContract table from curated
#Reading ProviderContract table from curated
try:
    provider_contract_df=read_table_to_df(prv_ctrt_tbt_name)
except Exception as e:
    raise Exception("Reading ProviderContract Failed",str(e))

# COMMAND ----------

# DBTITLE 1,Joining stage with ProviderContract to get ProviderContractKey
#Joining dtype_chng_df with ProviderContract to get ProviderContractKey
try:
    cond = (col('LH.FromProviderSequenceNumber') == col('RH.ProviderSequenceNumber')) &\
        (col('LH.FromProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) &\
        (col('LH.FromProviderId') == col('RH.ProviderId')) &\
        (col('LH.FromProviderSuffixCode') == col('RH.ProviderSuffixCode'))
    df_join = dtype_chng_df.alias('LH').join(provider_contract_df.alias('RH'), cond,'left').select('LH.*',col('RH.ProviderContractKey').alias('FromProviderContractKey'))
except Exception as e:
    raise Exception('joining failed',str(e))


# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_df = remove_invalid_records(df_join, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#Loading to curated and Azure SQL
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        
        ProviderContractTransferZipCode_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','PcaChgStatCd','UpdtDt')
        load_df_to_sf_sql_db_spark(ProviderContractTransferZipCode_df,'ProviderContract.ProviderContractTransferZipCode')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        
        conditions = ['FromProviderContractKey','ProviderChangeProcessDate','ZipCode','ModifiedDateTime','PcaChgStatCd','UpdtDt']
        delta_operate(cur_tbl_name, final_df ,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractTransferZipCodeKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractTransferZipCodeKey' : lit(None).cast("BIGINT"),
        'FromProviderContractKey' : lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','ModifiedDateTime'])
        delta_df1 = set_df_columns_not_nullable(spark,delta_df,['ModifiedBy'], True)

        df = delta_df1.filter(col('DerivedIndicator')!='IGNORE').drop('PcaChgStatCd','UpdtDt')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractTransferZipCode')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed: ',str(e))

# COMMAND ----------


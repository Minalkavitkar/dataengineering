# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2381
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractGrouperAssc
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractGrouperAssc

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2381'
buz_keys = ['DistUserId','DistUserUseCd','ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr','DataSrcCd']
not_null_col_lst = ['ProviderGrouperKey'] 
table_code = 'ProviderContract_ProviderContractGrouperAssc'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContractGrouperAssc')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run "./ProviderContractStageSchema"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_grp_tbl_name = table_name_selector(tbl_conf_df, 'Provider_ProviderGrouper')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load to stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2381_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed",str(e))

# COMMAND ----------

# DBTITLE 1,Read data from stage and curated table 
#Reading data from stage table & filtering the valid records
try:
    tre2381_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    provider_Grouper_df = read_table_to_df(prv_grp_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Join with provider Grouper
#joining with provider Grouper
try:
    Grouper_join_df = tre2381_stage_df.alias('LH')\
                    .join(provider_Grouper_df.alias('RH'), (col('LH.DistUserId') == col('RH.ProviderGrouperId')) & (col('LH.DistUserUseCd') == col('RH.TypeCode')), 'left')\
                        .select('LH.*', 'ProviderGrouperKey')
    pc_cols = [
        "ProvIdNbr",
        "ProvSuffCd",
        "PcaServTyCd",
        "PcaSeqNbr"
    ]
    join_df = create_provider_contract_id(Grouper_join_df, pc_cols)\
        .drop('ProvIdNbr','ProvSuffCd','PcaServTyCd','PcaSeqNbr')
except Exception as e:
    raise Exception('joining columns failed',str(e))


# COMMAND ----------

# DBTITLE 1,Column mapping dictionary as cloud columns
column_mapping ={
    'ProviderGrouperKey':'ProviderGrouperKey',
    'ProviderContractId':'ProviderContractId'
    ,'DistUserId':'ProviderGrouperId'
    ,'DistUserUseCd':'ProviderGrouperTypeCode'
    ,'DataSrcCd':'DataSourceCode'
    ,'DataEffCymdDt':'StartDate'
    ,'DataEndCymdDt':'EndDate'
    ,'TempusStatInd':'TempusStatusIndicator'
    ,"Re2381DatasgTs" : "ModifiedDateTime"
    ,'StgUnqId':'StgUnqId'
    ,'RunId':'RunId'
    ,'DerivedIndicator':'DerivedIndicator'
    ,'Status':'Status'
    ,'RejectReason':'RejectReason'
 }

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
# column mapping and adding audit columns
try:
    col_mapped_df = col_name_mapping(join_df,column_mapping)
    audit_col_added_df = col_mapped_df.withColumn('CreatedDateTime', col('ModifiedDateTime'))\
        .withColumn('CreatedBy', lit(PIPELINE_NAME))\
            .withColumn('ModifiedBy', lit(PIPELINE_NAME))
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_df = remove_invalid_records(audit_col_added_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        prv_ctct_grp_asssc_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(prv_ctct_grp_asssc_df, 'ProviderContract.ProviderContractGrouperAssc')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
      
        conditions = ['DataSourceCode', 'ProviderContractId', 'ProviderGrouperId', 'ProviderGrouperTypeCode']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractGrouperAsscKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractGrouperAsscKey' : lit(None).cast("BIGINT"),
        'ProviderGrouperKey' : lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)
        
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
        delta_df1 = set_df_columns_not_nullable(spark,delta_df,['ModifiedBy'], True)

        df = delta_df1.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractGrouperAssc')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed: ',str(e))
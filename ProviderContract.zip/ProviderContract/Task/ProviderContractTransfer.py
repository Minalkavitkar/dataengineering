# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2375
# MAGIC - TRE2376
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractTransfer
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractTransfer

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
tre2375_file_conf_key = 'PROVIDER_CONTRACT_TRE2375'
tre2376_file_conf_key = 'PROVIDER_CONTRACT_TRE2376'
not_null_col_lst = ['FromProviderContractKey','ToProviderContractKey'] 
table_code = 'ProviderContract_ProviderContractTransfer'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContractTransfer')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform/

# COMMAND ----------

# DBTITLE 1,Importing necessary libraries
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, lit

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]
    stage_tre2375_tbl_name = table_name_selector(tbl_conf_df, tre2375_file_conf_key)
    stage_tre2376_tbl_name = table_name_selector(tbl_conf_df, tre2376_file_conf_key)
    stage_tre2375_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2375_FULL")
    stage_tre2376_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2376_FULL")
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_ctrt_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')

    file_list = [
    [tre2376_file_conf_key, stage_tre2376_tbl_name, tre2376_schema, ['OldProvIdNbr','OldProvSuffCd','OldPcaServTyCd','OldPcaSeqNbr','PcaChgStatCd','UpdtDt','Re2376CntnewTs']],
    [tre2375_file_conf_key, stage_tre2375_tbl_name, tre2375_schema, ['OldProvIdNbr','OldProvSuffCd','OldPcaServTyCd','OldPcaSeqNbr']]]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Load data into stage table
try:
    for key, tbl_name, schema, buz_keys in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]}
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full="StageFull")
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read data from stage tables and renaming the column according to the domain tables
try:
    #Read data from stage tables and renaming the column according to the domain tables
    tre2375_stage_df = read_table_to_df(stage_tre2375_tbl_name).filter(col('Status') == 'S')
    tre2376_stage_df = read_table_to_df(stage_tre2376_tbl_name).filter(col('Status') == 'S')
    provider_contract_curated=read_table_to_df(prov_ctrt_tbl_name)
    tre2375_stage_full_df = read_table_to_df(stage_tre2375_full_tbl_name)
    tre2376_stage_full_df = read_table_to_df(stage_tre2376_full_tbl_name)
except Exception as e:
    raise Exception ("column mapping Failed or source table joining failed : ",str(e))

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition_tre2375 = (col('LH.OldProvIdNbr')==col('RH.OldProvIdNbr')) & \
                                    (col('LH.OldProvSuffCd')==col('RH.OldProvSuffCd')) & \
                                    (col('LH.OldPcaServTyCd')==col('RH.OldPcaServTyCd')) & \
                                    (col('LH.OldPcaSeqNbr')==col('RH.OldPcaSeqNbr'))

    joining_condition_tre2376  = (col('LH.OldProvIdNbr')==col('RH.OldProvIdNbr')) & \
                                    (col('LH.OldProvSuffCd')==col('RH.OldProvSuffCd')) & \
                                    (col('LH.OldPcaServTyCd')==col('RH.OldPcaServTyCd')) & \
                                    (col('LH.OldPcaSeqNbr')==col('RH.OldPcaSeqNbr'))  & \
                                    (col('LH.PcaChgStatCd')==col('RH.PcaChgStatCd'))  & \
                                    (col('LH.UpdtDt')==col('RH.UpdtDt')) & \
                                    (col('LH.Re2376CntnewTs')==col('RH.Re2376CntnewTs'))

    if LOAD_TYPE == "FullLoad":
        tre2376_tre2375_df              = tre2376_stage_df.alias('LH')\
                                            .join(tre2375_stage_df.alias('RH'),joining_condition_tre2375,'left')\
                                            .select('LH.*')

        tre2375_rejc_df                 = tre2375_stage_df.alias('LH')\
                                            .join(tre2376_stage_df.alias('RH'),joining_condition_tre2375,'left_anti')\
                                            .select('LH.StgUnqId','LH.Status','LH.RejectReason')

        update_rej_records(tre2375_rejc_df , "Child Not Found", stage_tre2375_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        tre2376_with_tre2375_df = tre2376_stage_df.alias('LH')\
                                            .join(tre2375_stage_full_df.alias('RH'),joining_condition_tre2375,'left')\
                                            .select('LH.*')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))
                
        tre2375_with_tre2376full_df = tre2375_stage_df.alias('LH')\
                                            .join(tre2376_stage_full_df.alias('RH'),joining_condition_tre2375,'inner')\
                                            .select('LH.*','RH.OperInitNm','RH.PcaChgProcDt', 
                                                    'RH.PcaChgStatCd','RH.UpdtDt','RH.Re2376CntnewTs','RH.NewProvIdNbr','RH.NewProvSuffCd','RH.NewPcaServTyCd','RH.NewPcaSeqNbr','RH.NewPcaBegDt','RH.NewPcaEndDt','RH.IdCardReqstInd','RH.PcaChgTranCd')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))

        tre2375_rejected_df         = tre2375_stage_df.alias('LH')\
                                            .join(tre2376_stage_full_df.alias('RH'),joining_condition_tre2375,'left_anti')\
                                            .select('StgUnqId','Status','RejectReason')


        #this join is required to avoid the duplicate delta formation
        tre2375_with_tre2376_df = tre2375_with_tre2376full_df.alias('LH')\
                                            .join(tre2376_with_tre2375_df.alias('RH'),joining_condition_tre2376,'left_anti')\
                                            .drop('StgUnqId')

       
        #union all constructed dataframes
        tre2376_tre2375_df =  tre2376_with_tre2375_df.unionByName(tre2375_with_tre2376_df, allowMissingColumns=True)

        update_rej_records(tre2375_rejected_df, "Child Not Found", stage_tre2375_tbl_name)
        
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Column mapping DB2 column to cloud columns
#Column mapping dictionary for Stage Table
column_mapping = {
    'NewPcaEndDt':'ContractTransferEndDate',
    'NewPcaBegDt':'ContractTransferStartDate',
    'PcaChgStatCd':'TransferStatusCode',
    'PcaChgTranCd':'ContractTransferCode',
    'OldProvIdNbr':'FromProviderId',
    'OldPcaSeqNbr':'FromProviderSequenceNumber',
    'OldPcaServTyCd':'FromProviderServiceTypeCode',
    'OldProvSuffCd':'FromProviderSuffixCode',
    'IdCardReqstInd':'IdCardRequestIndicator',
    'NewProvIdNbr':'ToProviderId',
    'NewPcaSeqNbr':'ToProviderSequenceNumber',
    'NewPcaServTyCd':'ToProviderServiceTypeCode',
    'NewProvSuffCd':'ToProviderSuffixCode',
    'OperInitNm':'OperatorName',
    'PcaChgProcDt':'ProviderChangeProcessDate',
    'Re2376CntnewTs' : 'ModifiedDateTime',
    'StgUnqId':'StgUnqId',
    'RunId':'RunId',
    'DerivedIndicator':'DerivedIndicator',
    'Status':'Status',
    'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Column mapping
try:
    #Read data from stage tables and renaming the column according to the domain tables
    col_mapped_df = col_name_mapping(tre2376_tre2375_df, column_mapping)

    col_map = {
        'FromProviderId' : lpad(col('FromProviderId'), 9, '0'),
        'ToProviderId' : lpad(col('ToProviderId'), 9, '0'),
        'ProviderChangeProcessDate' : lpad(col('ProviderChangeProcessDate'), 6, '0')
    }

    col_added_df = col_mapped_df .withColumns(col_map)

except Exception as e:
    raise Exception ("column mapping Failed or source table joining failed : ",str(e))

# COMMAND ----------

# DBTITLE 1,Date format conversion
try:
    dt_conv_df = date_format_conversion(col_added_df, ["ProviderChangeProcessDate"], "yyMMdd")
except Exception as e:
    raise Exception ("Data conversion Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Data type mapping
dtype_mapping = {
    "FromProviderSequenceNumber":"STRING",
    "ToProviderSequenceNumber":"STRING"
}

# COMMAND ----------

# DBTITLE 1,Data type conversion
try:
    dtype_converted_df = dtype_tgt_conversion(dt_conv_df, dtype_mapping)
except Exception as e:
    raise Exception ("Data conversion Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Create FromProviderContractId column
try:
    pc_cols = [
        "FromProviderId",
        "FromProviderSuffixCode",
        "FromProviderServiceTypeCode",
        "FromProviderSequenceNumber"]
    FromProvConId_formed_df = create_provider_contract_id(dtype_converted_df, pc_cols, "FromProviderContractId")
except Exception as e:
    raise Exception ("Forming FromProviderContractId Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Create ToProviderContractId column
try:
    pc_cols = [
        "ToProviderId",
        "ToProviderSuffixCode",
        "ToProviderServiceTypeCode",
        "ToProviderSequenceNumber"]
    ToProvConId_formed_df = create_provider_contract_id(FromProvConId_formed_df, pc_cols, "ToProviderContractId")
except Exception as e:
    raise Exception ("Forming ToProviderContractId Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join stage table with curated table
try:
    cond = (col('LH.FromProviderContractId') == col('RH.ProviderContractId'))    

    FromProvConKey_loaded_df = ToProvConId_formed_df.alias('LH').join(provider_contract_curated.alias('RH'), cond,'left')\
        .select('LH.*',col('RH.ProviderContractKey').alias('FromProviderContractKey'))
except Exception as e:
    raise Exception ("Join Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join stage table with curated table
try:
    cond = (col('LH.ToProviderContractId') == col('RH.ProviderContractId'))     

    ToProvConKey_loaded_df = FromProvConKey_loaded_df.alias('LH').join(provider_contract_curated.alias('RH'), cond,'left')\
        .select('LH.*',col('RH.ProviderContractKey').alias('ToProviderContractKey'))
except Exception as e:
    raise Exception ("Join Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Add auditing columns
try:
    audit_col_added_df = ToProvConKey_loaded_df.withColumn('CreatedDateTime', col('ModifiedDateTime'))\
            .withColumn('CreatedBy', lit(PIPELINE_NAME))\
            .withColumn('ModifiedBy', lit(PIPELINE_NAME))
except Exception as e:
    raise Exception("Adding audit fields failed",str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_df = remove_invalid_records(audit_col_added_df, stage_tre2376_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        provider_contract_transfer_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(provider_contract_transfer_df, 'ProviderContract.ProviderContractTransfer')

        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderChangeProcessDate', 'ModifiedDateTime', 'TransferStatusCode', 'FromProviderContractKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractTransferKey")
        
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractTransferKey' : lit(None).cast("BIGINT"),
        'FromProviderContractKey':lit(None).cast("BIGINT"),
        'ToProviderContractKey': lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)
       
        not_nullable_df = set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','ModifiedDateTime'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractTransfer')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)


except Exception as e:
    raise Exception ('load failed',str(e))
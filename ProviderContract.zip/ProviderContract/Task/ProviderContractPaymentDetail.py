# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2343
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractPaymentDetail
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractPaymentDetail

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2343'
buz_keys = ['ProvIdNbr', 'ProvSuffCd','PcaServTyCd','PcaSeqNbr','PcaPymtCymDt','PcaPymtTyCd','PymtRptSeqNbr','PymtActCymdDt','Re2343PayactTs']
not_null_col_lst = ['ProviderContractPymtHdrKey']
table_code = 'ProviderContract_ProviderContractPaymentDetail'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_Contract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Importing necessary libraries
from pyspark.sql.functions import cast, col, lit, length, rand

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Get Stage and Curated Table Names 
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    cur_provcont_paymentheader_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContractPaymentHeader')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load data into stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2343_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records.
#Reading data from stage table & filtering the valid records
try:
    tre2343_stage_df = read_table_to_df(stage_tbl_name)
    provcontpymntheader_df = read_table_to_df(cur_provcont_paymentheader_name)
    validated_df = tre2343_stage_df.filter("Status == 'S'")
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping DB2 column to cloud columns
#column mapping db2 to cloud columns
column_mapping = {'ProvIdNbr': 'ProviderId',
 'ProvSuffCd': 'ProviderSuffixCode',
 'PcaServTyCd': 'ProviderServiceTypeCode',
 'PcaSeqNbr': 'ProviderSequenceNumber',
 'PcaPymtCymDt': 'PcaPymtCymDt',
 'PcaPymtTyCd': 'PaymentTypeCode',
 'PymtRptSeqNbr': 'PaymentReportSequenceNumber',
 'PymtActCymdDt': 'PaymentAccountDate',
 'PcaPymtActCd': 'PaymentAccountCode',
 'PcaPymtActDesc': 'PaymentAccountDescription',
 'FundTyCd': 'FundTypeCode',
 'FundPerBegDt': 'FundPeriodBeginDate',
 'FundPerEndDt': 'FundPeriodEndDate',
 'PymtActStatCd': 'PaymentAccountStatusCode',
 'ActStatCymdDt': 'AccountStatusDate',
 'PcaPymtActAmt': 'PaymentAccountAmount',
 'PymtActGlInd': 'PaymentAccountGenLdgrIndicator',
 'PymtDbtAcctNbr': 'PaymentDebitAccountNumber',
 'PymtCrAcctNbr': 'PaymentCreditAccountNumber',
 'PcaPymtActPct': 'PaymentAccountPercentage',
 'PymtActNetAmt': 'PaymentAccountNetAmount',
 'PcaPymtPrevAmt': 'PreviousPaymentAmount',
 'PerPymtBasisCd': 'PerPaymentBasisCode',
 'PerPymtDirPct': 'PaymentDirectPercent',
 'PymtActLn2Desc': 'PaymentAccountLineDescription',
 'RePaymntPayaInd': 'PaymentPayaIndicator',
 'Re2343PayactTs':'CreatedDateTime',
 'StgUnqId':'StgUnqId',
 'RunId':'RunId',
 'DerivedIndicator':'DerivedIndicator',
 'Status':'Status',
 'RejectReason':'RejectReason'
 }

# COMMAND ----------

# DBTITLE 1,Data type conversion and adding audit columns
#data type converstion and adding audit columns
try:
    col_mapped_df = col_name_mapping(validated_df,column_mapping).withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
    add_audit_col_df = col_mapped_df.selectExpr("*", f"'{pipeline_name}' as CreatedBy")\
            .withColumn('ModifiedBy',col('CreatedBy'))\
        .withColumn('ModifiedDateTime',col('CreatedDateTime'))

    start_date_convrtd_df = dt_format_cym(add_audit_col_df, ['FundPeriodBeginDate','PcaPymtCymDt'])
    end_date_converted_df = dt_format_cym(start_date_convrtd_df,['FundPeriodEndDate'],'end')   
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Data type conversion
ProviderContractPaymentDetail_schema = {'PaymentAccountAmount': 'DECIMAL(20,6)',
 'PaymentAccountPercentage': 'DECIMAL(10,5)',
 'PaymentAccountNetAmount': 'DECIMAL(20,6)',
 'PreviousPaymentAmount': 'DECIMAL(20,6)',
 'PaymentDirectPercent': 'DECIMAL(10,5)',
 'ProviderSequenceNumber': 'string'}

# COMMAND ----------

# DBTITLE 1,Joining with ProviderContractPaymentHeader
#Joining with Product Affilication,ProviderContractProductAffilication
try:
    datatype_converted_df = dtype_tgt_conversion(end_date_converted_df, 
                                                  ProviderContractPaymentDetail_schema)

    joined_df = datatype_converted_df.alias('LH')\
        .join(provcontpymntheader_df.alias('RH'),\
            (col('LH.ProviderId') == col('RH.ProviderId')) & 
            (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & 
            (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & 
            (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')) &
            (col('LH.PcaPymtCymDt') == col('RH.PaymentDate')) & 
            (col('LH.PaymentTypeCode') == col('RH.PaymentTypeCode')), 
            'left')\
        .select('LH.*','RH.ProviderContractPymtHdrKey','RH.PaymentDate')

    selected_df = joined_df.drop('PcaPymtCymDt')
except Exception as e:
    raise Exception("datatype conversion or joining failed",str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_stage_df = remove_invalid_records(selected_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')\
                        .withColumn("part_col", round(rand() * (70 - 1) + 1,0))
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        
        lst = sorted(spark.sql(f'SHOW PARTITIONS {cur_tbl_name}').rdd.map(lambda x : x.part_col).collect())
        for part_id in lst:
            df = read_table_to_df(cur_tbl_name).filter(col('part_col') == part_id).drop('part_col','DerivedIndicator')  
            load_df_to_sf_sql_db_spark(df, 'providercontract.providercontractpaymentdetail')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':  
        conditions = ['ProviderContractPymtHdrKey', 'PaymentReportSequenceNumber', 'PaymentAccountDate','ModifiedDateTime'] 
        delta_operate(cur_tbl_name, final_df ,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractPymtDtlKey")
        cur_loaded_time = datetime.now() 

        mapping = { 
        'ProcessName' : lit(None).cast('STRING'), 
        'DeltaStatus' : lit(None).cast('STRING'), 
        'ProviderContractPymtDtlKey' : lit(None).cast("BIGINT"), 
        'ProviderContractPymtHdrKey' : lit(None).cast("BIGINT") 
        } 
        mapped_df= final_stage_df.withColumns(mapping).drop('part_col')  

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime','PaymentAccountDate','ModifiedDateTime']) 
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['ModifiedBy'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE') 
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractPaymentDetail') 
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)      
except Exception as e:
    raise Exception ('load failed',str(e))
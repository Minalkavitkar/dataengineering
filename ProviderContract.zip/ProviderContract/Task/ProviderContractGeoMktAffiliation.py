# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRECTRT,TREXACT
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractGeoMktAffiliation
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractGeoMktAffiliation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
trectrt_file_conf_key = 'PROVIDER_CONTRACT_TRECTRT'
trexact_file_conf_key = 'PROVIDER_CONTRACT_TREXACT'
not_null_col_lst = ['GeoMarketAffiliationKey','ProviderContractKey']
table_code = 'ProviderContract_ProviderContractGeoMktAffiliation'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE') 
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]

    stage_trectrt_tbl_name = table_name_selector(tbl_conf_df, trectrt_file_conf_key)
    stage_trexact_tbl_name = table_name_selector(tbl_conf_df, trexact_file_conf_key)
    stage_trectrt_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRECTRT_FULL")
    stage_trexact_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TREXACT_FULL")
    cur_providercontract_tbl_name =  table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
    cur_geomktaffil_tbl_name =  table_name_selector(tbl_conf_df, 'Product_GeoMarketAffiliation')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    stage_tregoaf_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREGOAF_FULL")

    file_list = [
        [trectrt_file_conf_key, stage_trectrt_tbl_name, trectrt_schema, ['CtrctGenKey'],"StageFull"],
        [trexact_file_conf_key, stage_trexact_tbl_name, trexact_schema, ['AffilGenKey','CtrctGenKey'],"StageFull"]
        ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    trectrt_stage_df = read_table_to_df(stage_trectrt_tbl_name)
    trexact_stage_df = read_table_to_df(stage_trexact_tbl_name)
    trectrt_stage_full_df = read_table_to_df(stage_trectrt_full_tbl_name)
    trexact_stage_full_df = read_table_to_df(stage_trexact_full_tbl_name).filter(col('AffilTyCd')=="GEO")
    providercontract_cur_df = read_table_to_df(cur_providercontract_tbl_name)
    geomktaffil_cur_df = read_table_to_df(cur_geomktaffil_tbl_name)
    tregoaf_stage_full_df= read_table_to_df(stage_tregoaf_full_tbl_name)

    trectrt_df = trectrt_stage_df.filter(trectrt_stage_df["Status"] == 'S')
    trexact_geo_df = trexact_stage_df.filter(trexact_stage_df["Status"] == 'S').filter(col('AffilTyCd')=="GEO")
    
except Exception as e:
    raise Exception("validation failed",str(e))  

# COMMAND ----------

# DBTITLE 1,Join with Tregoaf Stage Full to get GeoMarketId
#join with product Affiliation table
try:
    trexact_df = trexact_geo_df.alias('LH')\
        .join(tregoaf_stage_full_df.alias('RH'),\
            (col('LH.AffilGenKey')== col('RH.GeoAffilGenKey')),\
                'left')\
        .select('LH.*','RH.GeoMktId')
except Exception as e:
    raise Exception('joining with Product Affiliation failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For FullLoad
try:
    if LOAD_TYPE == "FullLoad":
        xact_ctrt_df =   trexact_df.alias('LH')\
                                        .join(trectrt_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left')\
                                        .select('LH.*','RH.ProvIdNbr','RH.ProvSuffCd','RH.ServTyCd','RH.CtrctSeqNbr')\

        ctrt_rej_df         =   trectrt_df.alias('LH')\
                                        .join(trectrt_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left_anti')

        update_rej_records(ctrt_rej_df, "Child Not Found", stage_trectrt_tbl_name)
      
except Exception as e:
    raise Exception("preparing stage table failed for FullLoad: ",str(e))        

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For DeltaLoad
# MAGIC %run ./ProviderContractAffilDelta

# COMMAND ----------

# DBTITLE 1,Joining with ProviderContract, GeoMarketAffiliation
try:
    ctrt_xact_procon_join_df = xact_ctrt_df.alias('LH')\
        .join(providercontract_cur_df.alias('RH'),\
            (col('LH.ProvIdNbr') == col('RH.ProviderId')) & 
            (col('LH.ProvSuffCd') == col('RH.ProviderSuffixCode')) & 
            (col('LH.ServTyCd') == col('RH.ProviderServiceTypeCode')) & 
            (col('LH.CtrctSeqNbr') == col('RH.ProviderSequenceNumber')),
            'left')\
        .select('LH.*','RH.ProviderContractKey','RH.ProviderContractId')

    joined_df =ctrt_xact_procon_join_df.alias('LH')\
        .join(geomktaffil_cur_df.alias('RH'),\
            (col('LH.GeoMktId') == col('RH.GeographicMarketId')),
            'left')\
        .select('LH.*','RH.GeoMarketAffiliationKey')    
except Exception as e:
    raise Exception("joining failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column Mapping as per cloud columns
#column mapping db2 to cloud columns
column_mapping ={
'ProvIdNbr':'ProviderId',
'ProvSuffCd':'ProviderSuffixCode',
'ServTyCd':'ProviderServiceTypeCode',
'CtrctSeqNbr':'ProviderSequenceNumber',
'GeoMktId':'GeoMarketId',
'ProviderContractKey': 'ProviderContractKey',
'ProviderContractId': 'ProviderContractId',
'GeoMarketAffiliationKey': 'GeoMarketAffiliationKey',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason',
}

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
schema = {
    "ProviderSequenceNumber" : "VARCHAR(50)",
    "ProviderId" : "VARCHAR(50)",
    'StartDate':'Date',
    'EndDate':'Date'
}

# COMMAND ----------

# DBTITLE 1,Datatype conversion and adding audit columns
#data type converstion and adding audit columns
try:
    col_mapped_df = col_name_mapping(joined_df,column_mapping)
    tgt_audit_col_added_df = add_tgt_audit_column(col_mapped_df, pipeline_name, LOAD_TYPE)
    cnst_added_df = tgt_audit_col_added_df\
        .withColumn('StartDate',lit('1990-01-01'))\
        .withColumn('EndDate',lit('9999-12-31'))
        
    data_type_convereted_df = dtype_tgt_conversion(cnst_added_df, schema).withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filter Valid records
try:
    final_df = remove_invalid_records(data_type_convereted_df, stage_trexact_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#load the processed data into curated layer
#load the data into Azure SQL after droping the unwnated columns
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        ProviderContractGeoMktAffil_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')
        load_df_to_sf_sql_db_spark(ProviderContractGeoMktAffil_df, 'ProviderContract.ProviderContractGeoMktAffiliation')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
    
    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderContractKey', 'GeoMarketAffiliationKey'] 
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractGeoMktAffilKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractGeoMktAffilKey':lit(None).cast("BIGINT"),
        'GeoMarketAffiliationKey':lit(None).cast("BIGINT"),
        'ProviderContractKey': lit(None).cast("BIGINT")
        }
        
        delta_cols_updated_df = final_df.withColumns(mapping)
        providercontract_geomktaffiliation_stage_df = delta_cols_updated_df.filter(col('DerivedIndicator')!='IGNORE')

        load_df_to_sf_sql_db_spark(providercontract_geomktaffiliation_stage_df, 'ProviderContract.StageProviderContractGeoMktAffiliation')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception("not able to load the table", str(e))
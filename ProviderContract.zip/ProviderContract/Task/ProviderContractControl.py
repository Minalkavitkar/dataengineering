# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2341, TRE2481, TREPRVJ
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractControl
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractControl

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
tre2341_file_conf_key = 'PROVIDER_CONTRACT_TRE2341'
tre2481_file_conf_key = 'PROVIDER_CONTRACT_TRE2481'
treprvj_file_conf_key = 'PROVIDER_CONTRACT_TREPRVJ'
table_code = 'ProviderContract_ProviderContractControl'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContractControl')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]
    
    stage_tre2341_tbl_name = table_name_selector(tbl_conf_df, tre2341_file_conf_key)
    stage_tre2481_tbl_name = table_name_selector(tbl_conf_df, tre2481_file_conf_key)
    stage_treprvj_tbl_name = table_name_selector(tbl_conf_df, treprvj_file_conf_key)

    stage_tre2341_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2341_FULL")
    stage_tre2481_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2481_FULL")
    stage_treprvj_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TREPRVJ_FULL")
    
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prov_cont_cur_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read data from stage tables
#Reading data from stage table & filtering the valid records
try:
    tre2341_stage_df = read_table_to_df(stage_tre2341_tbl_name).filter(col('Status') == 'S')
    tre2481_stage_df = read_table_to_df(stage_tre2481_tbl_name).filter(col('Status') == 'S')
    treprvj_stage_df = read_table_to_df(stage_treprvj_tbl_name).filter(col('Status') == 'S')
    tre2341_stage_full_df = read_table_to_df(stage_tre2341_full_tbl_name)
    tre2481_stage_full_df = read_table_to_df(stage_tre2481_full_tbl_name)
    treprvj_stage_full_df = read_table_to_df(stage_treprvj_full_tbl_name)
    
    #Reading data from provider contract table
    prov_cont_df = read_table_to_df(prov_cont_cur_tbl_name)\
       .select('ProviderContractKey', 'ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber', 'ProviderContractId')
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
# MAGIC %run ./ProviderContractStagePrepare

# COMMAND ----------

# DBTITLE 1,Column mapping
column_mapping = {
        #buz_keys
            "ProvIdNbr" : "ProviderId"
            ,"ProvSuffCd" : "ProviderSuffixCode"
            ,"PcaServTyCd" : "ProviderServiceTypeCode"
            ,"PcaSeqNbr" : "ProviderSequenceNumber"

        #column mapping for tre2341
            ,"PcaGrpId" : "GeoMkt"
            ,"RtTblId" : "CapitationRate"
            ,"StoplsTblId" : "Stoploss"
            ,"PcaFinLedgrNbr" : "LedgerNumber"

        #column mapping for tre2481
            ,"MndtSpcTblId" : "MandateSpecialist"
            ,"OoaOonTblId" : "OutOfAreaNetwork"
            ,"CostAlcTblId" : "CostAllocation"
        
        #column mapping for treprvj
            ,"GrpPracId" : "ClaimRule"

        #derived columns
            ,"DerivedIndicator":"DerivedIndicator"
}

try:
    col_mapped_df = col_name_mapping(tre2341_treprvj_tre2481_df,column_mapping)
except Exception as e:
    raise Exception("column name renaming failed : ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProviderContract and get ProviderContract and ProviderContractId
joined_df = col_mapped_df.alias('LH')\
    .join(prov_cont_df.alias('RH'),\
    (col('LH.ProviderId') == col('RH.ProviderId')) & \
    (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & \
    (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & \
    (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')), 'left')\
        .select('LH.*', 'RH.ProviderContractKey', 'RH.ProviderContractId')


# COMMAND ----------

# DBTITLE 1,Pivoting the table to get the ControlTypeCode & ControlTypeId
common_col_list = ['ProviderContractKey','ProviderContractId','DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber']

mand_spec_df = joined_df.select(*common_col_list, lit('MandateSpecialist').alias('ControlTypeCode'),col('MandateSpecialist').alias('ControlTypeId'))
claim_rule_df = joined_df.select(*common_col_list, lit('ClaimRule').alias('ControlTypeCode'),col('ClaimRule').alias('ControlTypeId'))
cap_rate_df = joined_df.select(*common_col_list, lit('Capitation/Rate').alias('ControlTypeCode'),col('CapitationRate').alias('ControlTypeId'))
ooa_oon_df = joined_df.select(*common_col_list, lit('OutOfAreaNetwork').alias('ControlTypeCode'),col('OutOfAreaNetwork').alias('ControlTypeId'))
cost_alloc_df = joined_df.select(*common_col_list, lit('CostAllocation').alias('ControlTypeCode'), col('CostAllocation').alias('ControlTypeId'))
stop_loss_df = joined_df.select(*common_col_list, lit('Stoploss').alias('ControlTypeCode'), col('Stoploss').alias('ControlTypeId'))
ledg_num_df = joined_df.select(*common_col_list, lit('LedgerNumber').alias('ControlTypeCode'), col('LedgerNumber').alias('ControlTypeId'))
geo_mkt_df = joined_df.select(*common_col_list, lit('GeoMkt').alias('ControlTypeCode'),col('GeoMkt').alias('ControlTypeId'))

# COMMAND ----------

# DBTITLE 1,Union the pivoted table
union_df = mand_spec_df.union(claim_rule_df).union(cap_rate_df).union(ooa_oon_df).union(cost_alloc_df).union(stop_loss_df).union(ledg_num_df).union(geo_mkt_df)

# COMMAND ----------

# DBTITLE 1,Adding audit columns
try:
    final_stage_df = add_tgt_audit_column(union_df, PIPELINE_NAME, LOAD_TYPE)
    final_df = final_stage_df.drop('ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        
        provider_contract_control_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(provider_contract_control_df, 'ProviderContract.ProviderContractControl')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderContractId','ProviderContractKey','ControlTypeCode','ControlTypeId']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractControlKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractControlKey':lit(None).cast("BIGINT"),
        'ProviderContractKey': lit(None).cast("BIGINT"),
        'ProviderId':col('ProviderId').cast('STRING'),
        'ProviderSequenceNumber':col('ProviderSequenceNumber').cast('STRING')
        }
        
        delta_cols_updated_df = final_stage_df.withColumns(mapping)
        providercontractcontrol_stage_df = delta_cols_updated_df.filter(col('DerivedIndicator')!='IGNORE')

        nullable_set_df = set_df_columns_nullable(spark, providercontractcontrol_stage_df,['ControlTypeCode'])

        load_df_to_sf_sql_db_spark(nullable_set_df, 'ProviderContract.StageProviderContractControl')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed',str(e))
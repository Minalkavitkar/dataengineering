# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2393
# MAGIC - TRE2394
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.CompletionFactor
# MAGIC ##### Target Table
# MAGIC - ProviderContract.CompletionFactor

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
tre2393_file_conf_key = 'PROVIDER_CONTRACT_TRE2393'
tre2394_file_conf_key = 'PROVIDER_CONTRACT_TRE2394'
table_code = 'ProviderContract_CompletionFactor'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_CompletionFactor')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper
# MAGIC

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform/

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]


    stage_tre2393_tbl_name = table_name_selector(tbl_conf_df, tre2393_file_conf_key)
    stage_tre2394_tbl_name = table_name_selector(tbl_conf_df, tre2394_file_conf_key)
    stage_tre2393_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2393_FULL")
    stage_tre2394_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRE2394_FULL")
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)

        
    file_list = [
        [tre2393_file_conf_key, stage_tre2393_tbl_name, tre2393_schema, ['CmpltFactTblId']], 
        [tre2394_file_conf_key, stage_tre2394_tbl_name, tre2394_schema, ['CmpltFactTblId','CmpltFactPosCnt']]
        ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Loading Stage Table
try:
    for key, tbl_name, schema, buz_keys in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]} 
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full="StageFull")
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Filtering Valid Records
#Reading data from stage table & filtering the valid records
try:
    tre2393_stage_df = read_table_to_df(stage_tre2393_tbl_name).filter(col('Status') == 'S')
    tre2394_stage_df = read_table_to_df(stage_tre2394_tbl_name).filter(col('Status') == 'S')
    tre2393_stage_full_df = read_table_to_df(stage_tre2393_full_tbl_name)
    tre2394_stage_full_df = read_table_to_df(stage_tre2394_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition_tre2393 = (col('LH.CmpltFactTblId')==col('RH.CmpltFactTblId'))
                                
    joining_condition_tre2394  = (col('LH.CmpltFactTblId')==col('RH.CmpltFactTblId')) &\
                                 (col('LH.CmpltFactPosCnt')==col('RH.CmpltFactPosCnt'))

    if LOAD_TYPE == "FullLoad":
        tre2394_tre2393_df              = tre2394_stage_df.alias('LH')\
                                            .join(tre2393_stage_df.alias('RH'),joining_condition_tre2393,'left')\
                                            .select('LH.*',"RH.CmpltFactInd","RH.CmpltFactLockNm","RH.CmpltFactLockDt","RH.CmpltFactDelInd","RH.PltfmCd")

        tre2393_rejc_df                 = tre2393_stage_df.alias('LH')\
                                            .join(tre2394_stage_df.alias('RH'),joining_condition_tre2393,'left_anti')\
                                            .select('LH.StgUnqId','LH.Status','LH.RejectReason')

        update_rej_records(tre2393_rejc_df , "Child Not Found", stage_tre2393_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        tre2394_with_tre2393_df = tre2394_stage_df.alias('LH')\
                                            .join(tre2393_stage_full_df.alias('RH'),joining_condition_tre2393,'left')\
                                            .select('LH.*',"RH.CmpltFactInd","RH.CmpltFactLockNm","RH.CmpltFactLockDt","RH.CmpltFactDelInd")\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))
                
        tre2393_with_tre2394full_df = tre2393_stage_df.alias('LH')\
                                            .join(tre2394_stage_full_df.alias('RH'),joining_condition_tre2393,'inner')\
                                            .select('LH.*','RH.CmpltFactPosCnt','RH.CmpltFactPct')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))

        tre2393_rejected_df         = tre2393_stage_df.alias('LH')\
                                            .join(tre2394_stage_full_df.alias('RH'),joining_condition_tre2393,'left_anti')\
                                            .select('StgUnqId','Status','RejectReason')


        #this join is required to avoid the duplicate delta formation
        tre2393_with_tre2394_df = tre2393_with_tre2394full_df.alias('LH')\
                                            .join(tre2394_with_tre2393_df.alias('RH'),joining_condition_tre2394,'left_anti')\
                                            .drop('StgUnqId')

       
        #union all constructed dataframes
        tre2394_tre2393_df =  tre2394_with_tre2393_df.unionByName(tre2393_with_tre2394_df, allowMissingColumns=True)

        update_rej_records(tre2393_rejected_df, "Child Not Found", stage_tre2393_tbl_name)
        
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Column Mapping
column_mapping={
"CmpltFactTblId":"CompletionFactorId"
,"CmpltFactInd":"CompletionFactorIndicator"
,"CmpltFactLockDt":"CompletionFactorLockDate"
,"CmpltFactLockNm":"CompletionFactorLockName"
,"CmpltFactPosCnt":"CompletionFactorPOSCount"
,"CmpltFActPct":"CompletionFactorPercent"
,"CmpltFactDelInd":"CompletionFactorDeleteIndicator"
,"StgUnqId":"StgUnqId"
,"RunId":"RunId"
,"DerivedIndicator":"DerivedIndicator"
,"Status":"Status"
,"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Adding Audit Columns
try:
    col_mapped_df = add_tgt_audit_column(col_name_mapping(tre2394_tre2393_df,column_mapping), PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception("adding audit column failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Adding Column 
col_map = {
  
    'CompletionFactorLockDate' : lpad(col('CompletionFactorLockDate'), 6, '0')
}
try:
    col_added_df = col_mapped_df.withColumns(col_map).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("adding column failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Data Type Conversion
dtype_mapping = {
            "CompletionFactorPOSCount":"INT",
            "CompletionFactorPercent":"DECIMAL(20,6)"

}

# COMMAND ----------

# DBTITLE 1,date format conversion
#date format conversion and data type conversion and adding audit columns
try:
    dt_conv_df = date_format_conversion(col_added_df, ["CompletionFactorLockDate"], "yyMMdd")

    dtype_converted_df = dtype_tgt_conversion(dt_conv_df, dtype_mapping)
except Exception as e:
    raise Exception("date format conversion or data type conversion failed",str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(dtype_converted_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        CompletitionFactor_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(CompletitionFactor_df, 'ProviderContract.CompletionFactor')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['CompletionFactorId','CompletionFactorPOSCount']
        delta_operate(cur_tbl_name,dtype_converted_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"CompletionFactorKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'CompletionFactorKey':lit(None).cast("BIGINT")
        }
        mapped_df= dtype_converted_df.withColumns(mapping)
    
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageCompletionFactor')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
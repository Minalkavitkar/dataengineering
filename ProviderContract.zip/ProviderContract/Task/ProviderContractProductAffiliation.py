# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRECTRT,TREXACT
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractProductAffiliation
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractProductAffiliation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
trectrt_file_conf_key = 'PROVIDER_CONTRACT_TRECTRT' 
trexact_file_conf_key = 'PROVIDER_CONTRACT_TREXACT'
not_null_col_lst = ['ProductAffiliationKey','ProviderContractKey']
table_code = 'ProviderContract_ProviderContractProductAffiliation'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProviderContract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE') 
pipeline_name = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]

    stage_trectrt_tbl_name = table_name_selector(tbl_conf_df, trectrt_file_conf_key)
    stage_trexact_tbl_name = table_name_selector(tbl_conf_df, trexact_file_conf_key)
    stage_trectrt_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRECTRT_FULL")
    stage_trexact_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TREXACT_FULL")
    cur_providercontract_tbl_name =  table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
    cur_prodaffil_tbl_name =  table_name_selector(tbl_conf_df, 'Product_ProductAffiliation')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    stage_trepdaf_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREPDAF_FULL")


    file_list = [
        [trectrt_file_conf_key, stage_trectrt_tbl_name, trectrt_schema, ['CtrctGenKey'],"StageFull"],
        [trexact_file_conf_key, stage_trexact_tbl_name, trexact_schema, ['AffilGenKey','CtrctGenKey'],"StageFull"]
        ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Ingestion: Load into stage table
try:
    for key, tbl_name, schema, buz_keys, stage_condition in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]} 
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full=stage_condition)
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & filtering the valid records
#Reading data from stage table & filtering the valid records
try:
    trectrt_stage_df = read_table_to_df(stage_trectrt_tbl_name)
    trexact_stage_df = read_table_to_df(stage_trexact_tbl_name)
    trectrt_stage_full_df = read_table_to_df(stage_trectrt_full_tbl_name)
    trexact_stage_full_df = read_table_to_df(stage_trexact_full_tbl_name).filter(col('AffilTyCd')=="PRD")
    providercontract_cur_df = read_table_to_df(cur_providercontract_tbl_name)
    prodaffil_cur_df = read_table_to_df(cur_prodaffil_tbl_name)
    trepdaf_stage_full_df = read_table_to_df(stage_trepdaf_full_tbl_name)

    trectrt_df = trectrt_stage_df.filter(trectrt_stage_df["Status"] == 'S')
    trexact_prd_df = trexact_stage_df.filter(trexact_stage_df["Status"] == 'S').filter(col('AffilTyCd')=="PRD")

except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Join with Trepdaf Stage Full to get PrdTableId and ReLob
#join with product Affiliation table
try:
    trexact_df = trexact_prd_df.alias('LH')\
        .join(trepdaf_stage_full_df.alias('RH'),\
            (col('LH.AffilGenKey')== col('RH.PrdAffilGenKey')),\
                'left')\
        .select('LH.*','RH.PrdTableId',col("RH.ReLob").alias("PrdAffReLob"))
except Exception as e:
    raise Exception('joining with Product Affiliation failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For FullLoad
try:
    if LOAD_TYPE == "FullLoad":
        xact_ctrt_df =   trexact_df.alias('LH')\
                                        .join(trectrt_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left')\
                                        .select('LH.*','RH.ProvIdNbr','RH.ProvSuffCd','RH.ServTyCd','RH.CtrctSeqNbr')\

        ctrt_rej_df         =   trectrt_df.alias('LH')\
                                        .join(trectrt_df.alias('RH'),(col('LH.CtrctGenKey')==col('RH.CtrctGenKey')),'left_anti')

        update_rej_records(ctrt_rej_df, "Child Not Found", stage_trectrt_tbl_name)
      
except Exception as e:
    raise Exception("preparing stage table failed for FullLoad: ",str(e))        

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For DeltaLoad
# MAGIC %run ./ProviderContractAffilDelta

# COMMAND ----------

# DBTITLE 1,Joining with ProviderContract, ProductAffiliation
#Joining with Product Affilication,ProviderContractProductAffilication
try:
    ctrt_xact_procon_join_df = xact_ctrt_df.alias('LH')\
        .join(providercontract_cur_df.alias('RH'),\
            (col('LH.ProvIdNbr') == col('RH.ProviderId')) & 
            (col('LH.ProvSuffCd') == col('RH.ProviderSuffixCode')) & 
            (col('LH.ServTyCd') == col('RH.ProviderServiceTypeCode')) & 
            (col('LH.CtrctSeqNbr') == col('RH.ProviderSequenceNumber')),
            'left')\
        .select('LH.*','RH.ProviderContractKey','RH.ProviderContractId')

    joined_df =ctrt_xact_procon_join_df.alias('LH')\
        .join(prodaffil_cur_df.alias('RH'),\
            ((col('LH.PrdTableId') == col('RH.LocationId')) &
             (col('LH.PrdAffReLob') == col('RH.LineOfBusinessCode'))),
            'left')\
        .select('LH.*','RH.ProductAffiliationKey')
except Exception as e:
    raise Exception("joining failed",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping db2 to cloud columns
#column mapping db2 to cloud columns
column_mapping ={
'ProvIdNbr':'ProviderId',
'ProvSuffCd':'ProviderSuffixCode',
'ServTyCd':'ProviderServiceTypeCode',
'CtrctSeqNbr':'ProviderSequenceNumber',
'ProviderContractKey': 'ProviderContractKey',
'ProviderContractId': 'ProviderContractId',
'ProductAffiliationKey': 'ProductAffiliationKey',
'PrdTableId':'LocationId',
'PrdAffReLob':'LineOfBusinessCode',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason',
}

# COMMAND ----------

# DBTITLE 1,DataType Conversion Schema
schema = {
    "ProviderSequenceNumber" : "VARCHAR(50)",
    "ProviderId" : "VARCHAR(50)"
}

# COMMAND ----------

# DBTITLE 1,Data type conversion and adding audit columns  
#data type converstion and adding audit columns  
try:
    col_mapped_df = col_name_mapping(joined_df,column_mapping)
    tgt_audit_col_added_df = add_tgt_audit_column(col_mapped_df, pipeline_name, LOAD_TYPE)

    datatype_converted_df = dtype_tgt_conversion(tgt_audit_col_added_df, schema).withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))

except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    final_df = remove_invalid_records(datatype_converted_df, stage_trexact_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalide records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Curated table data load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        ProviderContractProductAffiliat_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber','LocationId','LineOfBusinessCode')
        load_df_to_sf_sql_db_spark(ProviderContractProductAffiliat_df, 'ProviderContract.ProviderContractProductAffiliation')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)


    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderContractKey', 'ProductAffiliationKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractProductAffiliationKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProviderContractProductAffiliationKey':lit(None).cast("BIGINT"),
        'ProductAffiliationKey':lit(None).cast("BIGINT"),
        'ProviderContractKey': lit(None).cast("BIGINT")
        }
        
        delta_cols_updated_df = final_df.withColumns(mapping)
        provider_contract_df = delta_cols_updated_df.filter(col('DerivedIndicator')!='IGNORE')

        load_df_to_sf_sql_db_spark(provider_contract_df, 'ProviderContract.StageProviderContractProductAffiliation')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRESPCP,TRESPCD
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.MandateSpecialist
# MAGIC ##### Target Table
# MAGIC - ProviderContract.MandateSpecialist

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
trespcp_file_conf_key = 'PROVIDER_CONTRACT_TRESPCP'
trespcd_file_conf_key = 'PROVIDER_CONTRACT_TRESPCD'
not_null_col_lst = ['ProviderContractKey'] 
table_code = 'ProviderContract_MandateSpecialist'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
#get load type & pipeline name

dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_MandateSpecialist')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    default_conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
    child_tbl_config_path = default_conf["ChildTblConfigPath"]

    stage_trespcp_tbl_name = table_name_selector(tbl_conf_df, trespcp_file_conf_key)
    stage_trespcd_tbl_name = table_name_selector(tbl_conf_df, trespcd_file_conf_key)
    stage_trespcp_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRESPCP_FULL")
    stage_trespcd_full_tbl_name = table_name_selector(tbl_conf_df, "PROVIDER_CONTRACT_TRESPCD_FULL")
    
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prv_ctrt_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')

    file_list = [
        [trespcp_file_conf_key, stage_trespcp_tbl_name, trespcp_schema, ['PcaCtrctId','PcaTyCd','PcaSeqCd','PcaLobCd','MndtSpecTblId']],
        [trespcd_file_conf_key, stage_trespcd_tbl_name, trespcd_schema, ['MndtSpecTblId']]
        ]
except Exception as e:
    raise Exception ("Table Configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Loading into stage table
try:
    for key, tbl_name, schema, buz_keys in file_list:
        conf = {**file_config["DEFAULT"],**file_config[key]} 
        main_function(conf, LOAD_TYPE, tbl_name, schema, buz_keys, stage_full="StageFull")
        print(tbl_name, " - Load Completed")
except Exception as e:
    raise Exception ("Stage Load Failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table 
#Reading data from stage table & filtering the valid records
try:
    trespcp_stage_df = read_table_to_df(stage_trespcp_tbl_name).filter(col('Status') == 'S')
    trespcd_stage_df = read_table_to_df(stage_trespcd_tbl_name).filter(col('Status') == 'S')
    trespcp_stage_full_df = read_table_to_df(stage_trespcp_full_tbl_name)
    trespcd_stage_full_df = read_table_to_df(stage_trespcd_full_tbl_name)
    prov_df =  read_table_to_df(prv_ctrt_tbl_name).select('ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber', 'ProviderContractKey')
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Preparing Stage Table For Transformation
try:
    joining_condition_trespcd = (col('LH.MndtSpecTblId')==col('RH.MndtSpecTblId'))

    joining_condition_trespcp  = (col('LH.PcaCtrctId')==col('RH.PcaCtrctId')) & \
                                    (col('LH.PcaTyCd')==col('RH.PcaTyCd')) & \
                                    (col('LH.PcaSeqCd')==col('RH.PcaSeqCd')) & \
                                    (col('LH.PcaLobCd')==col('RH.PcaLobCd')) & \
                                    (col('LH.MndtSpecTblId')==col('RH.MndtSpecTblId'))

    if LOAD_TYPE == "FullLoad":
        trespcp_trespcd_df              = trespcp_stage_df.alias('LH')\
                                            .join(trespcd_stage_df.alias('RH'),joining_condition_trespcd,'left')\
                                            .select('LH.*','RH.TblDesc','RH.CopyFromTblId','RH.CopyInd','RH.NotifyEmailId')

        trespcd_rejc_df                 = trespcd_stage_df.alias('LH')\
                                            .join(trespcd_stage_df.alias('RH'),joining_condition_trespcd,'left_anti')\
                                            .select('LH.StgUnqId','LH.Status','LH.RejectReason')

        update_rej_records(trespcd_rejc_df , "Child Not Found", stage_trespcd_tbl_name)

    elif LOAD_TYPE == "DeltaLoad":
        trespcp_with_trespcd_df = trespcp_stage_df.alias('LH')\
                                            .join(trespcd_stage_full_df.alias('RH'),joining_condition_trespcd,'left')\
                                            .select('LH.*','RH.TblDesc','RH.CopyFromTblId','RH.CopyInd','RH.NotifyEmailId')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))
                
        trespcd_with_trespcpfull_df = trespcd_stage_df.alias('LH')\
                                            .join(trespcp_stage_full_df.alias('RH'),joining_condition_trespcd,'inner')\
                                            .select('LH.*','RH.PcaCtrctId','RH.PcaTyCd','RH.PcaSeqCd','RH.PcaLobCd','RH.PcaNm','RH.PcaEffDt','RH.PcaEndDt','RH.PrdTblMatchInd','RH.FinLdgrInd')\
                                            .filter(col('DerivedIndicator').isin('UPDATE','INSERT','DELETE'))\
                                            .withColumn('DerivedIndicator', when(col('DerivedIndicator')=='INSERT', lit('UPDATE')).otherwise(col('DerivedIndicator')))

        trespcd_rejected_df         = trespcd_stage_df.alias('LH')\
                                            .join(trespcp_stage_full_df.alias('RH'),joining_condition_trespcd,'left_anti')\
                                            .select('StgUnqId','Status','RejectReason')


        #this join is required to avoid the duplicate delta formation
        trespcd_with_trespcp_df = trespcd_with_trespcpfull_df.alias('LH')\
                                            .join(trespcp_with_trespcd_df.alias('RH'),joining_condition_trespcp,'left_anti')\
                                            .drop('StgUnqId')

       
        #union all constructed dataframes
        trespcp_trespcd_df =  trespcp_with_trespcd_df.unionByName(trespcd_with_trespcp_df, allowMissingColumns=True)

        update_rej_records(trespcd_rejected_df, "Child Not Found", stage_trespcd_tbl_name)
        
except Exception as e:
    raise Exception("preparing stage table failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Column mapping
col_mapping={
'PcaLobCd':'LineOfBusinessCode'
,'MndtSpecTblId':'MandateSpecialistId'
,'PcaNm':'ProviderContractName'
,'PcaEffDt':'MandateSpecialistStartDate'
,'PcaEndDt':'MandateSpecialistEndDate'
,'PrdTblMatchInd':'ProductMatchIndicator'
,'TblDesc':'MandateSpecialistDescription'
,'FinLdgrInd':'FinanceLedgerIndicator'
,'CopyFromTblId':'CopyFromId'
,'CopyInd':'CopyIndicator'
,'NotifyEmailId':'NotifyEmailId'
,'PcaCtrctId' : 'ProviderContractId'
,'PcaSeqCd' : 'ProviderSequenceNumber'
,'PcaTyCd' : 'ProviderServiceTypeCode'
,'StgUnqId':'StgUnqId'
,'RunId':'RunId'
,'DerivedIndicator':'DerivedIndicator'
,'Status':'Status'
,'RejectReason':'RejectReason'
}


# COMMAND ----------

# DBTITLE 1,adding audit columns
# adding audit columns
try:
    audit_col_added_df = add_tgt_audit_column(col_name_mapping(trespcp_trespcd_df,col_mapping), PIPELINE_NAME, LOAD_TYPE)
except Exception as e:
    raise Exception('adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Joining with ProviderContract
try:
    trans_df = audit_col_added_df.selectExpr("*", "(substring(ProviderContractId, 1,9)) as ProviderId", "case when substring(ProviderContractId, 10) = '' then '  ' else substring(ProviderContractId, 10) end as ProviderSuffixCode")
    
    calc_df = trans_df.withColumn("ProviderSequenceNumber", col("ProviderSequenceNumber").cast('int'))
                                                                                  
    valid_df = calc_df.alias('LH').join(prov_df.alias('RH'),\
                                (col('LH.ProviderId') == col('RH.ProviderId')) & \
                                (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & \
                                (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & \
                                (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')),'left')\
                                    .select('LH.*','RH.ProviderContractKey').drop('ProviderContractId')

                                                            
except Exception as e:
    raise Exception("joining failed: ",str(e))                                                                  

# COMMAND ----------

# DBTITLE 1,Data type conversion
datatype_change_schema = {
            'CopyFromId':'STRING',
            'CopyIndicator':'BOOLEAN',
            'NotifyEmailId':'STRING',
            'ProviderSequenceNumber':'STRING'
}

# COMMAND ----------

# DBTITLE 1,Data type conversion
# Data type conversion
try:
    data_type_converted_df = dtype_tgt_conversion(valid_df, datatype_change_schema)
except Exception as e:
    raise Exception('data type conversion failed',str(e))

# COMMAND ----------

# DBTITLE 1,filtering valid records
#filtering valid records
try:
    final_stage_df = remove_invalid_records(data_type_converted_df, stage_trespcp_tbl_name , not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
    final_df = final_stage_df.drop('ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')
except Exception as e:
    raise Exception('filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        MandateSpecialist_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(MandateSpecialist_df, 'ProviderContract.MandateSpecialist')

        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
  
    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProviderContractKey', 'LineOfBusinessCode', 'MandateSpecialistId', 'MandateSpecialistStartDate', 'MandateSpecialistEndDate']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"MandateSpecialistKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'MandateSpecialistKey':lit(None).cast("BIGINT"),
        'ProviderContractKey': lit(None).cast("BIGINT")
        }
        mapped_df= final_stage_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageMandateSpecialist')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
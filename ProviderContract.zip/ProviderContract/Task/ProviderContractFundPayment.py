# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TRE2346
# MAGIC ##### Curated Tables
# MAGIC - ProviderContract.ProviderContractFundPayment
# MAGIC ##### Target Table
# MAGIC - ProviderContract.ProviderContractFundPayment

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PROVIDER_CONTRACT_TRE2346'
buz_keys = ['ProvIdNbr', 'ProvSuffCd','PcaServTyCd','PcaSeqNbr','FundRptSeqNbr','PerBegCymDt']
not_null_col_lst = ['ProviderContractFundKey'] 
table_code = 'ProviderContract_ProviderContractFundPayment'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Provider_Contract')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('ProviderContract', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'ProviderContract', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    child_tbl_config_path = conf["ChildTblConfigPath"]
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    prov_ctrt_fund_cur_tbl_name = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContractFund')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2346_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ###Table - ProviderContractFund TRE2346

# COMMAND ----------

# DBTITLE 1,Read data from stage and curated table 
#Reading data from stage table & filtering the valid records
try:
    tre2346_stage_df = read_table_to_df(stage_tbl_name)\
        .filter(col('Status') == 'S')
    audit_col_added_df = add_tgt_audit_column(tre2346_stage_df , PIPELINE_NAME, LOAD_TYPE)
    prov_ctrt_fund_df = read_table_to_df(prov_ctrt_fund_cur_tbl_name) 
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,Column mapping dictionary 
#Column mapping dictionary for hive_metastore.ProviderContract.StageTRE2346 to hive_metastore.ProviderContract.ProviderContractFundPayment
col_mapping = {
    "ProvIdNbr" : "ProviderId"
    ,"ProvSuffCd" : "ProviderSuffixCode"
    ,"PcaServTyCd" : "ProviderServiceTypeCode"
    ,"PcaSeqNbr" : "ProviderSequenceNumber"
    ,"FundRptSeqNbr" : "FundSequenceNumber"
    ,"PerBegCymDt" : "PeriodBeginDate"
    ,"FundTyCd" : "FundTypeCode"
    ,"PerEndCymDt" : "PeriodEndDate"
    ,"FundCloseCymDt" : "FundClosedDate"
    ,"FundStatCd" : "FundStatusCode"
    ,"FundStatCymdDt" : "FundStatusDate"
    ,"PriPerBfwdAmt" : "PrimaryPeriodBroughtFrwrdAmt"
    ,"FundLateClmAmt" : "FundLateClaimAmount"
    ,"FundFundAmt" : "FundAmount"
    ,"FundCapFundAmt" : "CapitationFundAmount"
    ,"FundMbrMoCnt" : "FundMemberMonthCount"
    ,"FundWhldClmAmt" : "FundWithholdClaimAmount"
    ,"FundOthFundAmt" : "FundOtherAmount"
    ,"FundCapExpsAmt" : "FundCapitationExpenseAmount"
    ,"ExpsMbrMoCnt" : "ExpensedMemberMonthCount"
    ,"FundClmBenAmt" : "FundClaimBenefitAmount"
    ,"FundClmExpsAmt" : "FundClaimExpenseAmount"
    ,"FundClmDiscAmt" : "FundClaimDiscountAmount"
    ,"StoplsExcessAmt" : "StoplossExcessAmount"
    ,"FundDirPymtAmt" : "FundDirectPaymentAmount"
    ,"FundManAdjAmt" : "FundManualAdjustmentAmount"
    ,"FundNetActAmt" : "FundNetACTAmount"
    ,"FundProvRiskAmt" : "FundProviderRiskAmount"
    ,"FundXferOutAmt" : "FundTransferOutAmount"
    ,"FundXferInAmt" : "FundTransferInAmount"
    ,"FundSetlAmt" : "FundSettlementAmount"
    ,"FundReconAmt" : "FundReconciliationAmount"
    ,"FinalPymtAmt" : "FundFinalPaymentAmount"
    ,"FundBfwdAmt" : "FundBroughtForwardAmount"
    ,"DefcAbsorbAmt" : "DeficitAbsorbAmount"
    ,"FundIbnrAmt" : "FundIBNRAmount"
    ,"FundIbnrSetlInd" : "FundIBNRSettledIndicator"
    ,"CatastWhldAmt" : "CatastrophicWiithholdAmount"
    ,"CatWhldAdjAmt" : "CatastrophWiithholdAdjstmntAmt"
    ,"RetLimMoCnt" : "ReturnLimitMonthCount"
    ,"FundRetLimAmt" : "FundReturnLimitAmount"
    ,"Re2346X0032Fill" : "FundComment"
    ,"Re2346FundTs" : "ModifiedDateTime"
    ,"ReOpenIxInd" : "OpenFundIndicator"
    ,"CreatedBy" : "CreatedBy"
    ,"CreatedDateTime" : "CreatedDateTime"
    ,"ModifiedBy" : "ModifiedBy"
    ,"StgUnqId":"StgUnqId"
    ,"RunId":"RunId"
    ,"DerivedIndicator":"DerivedIndicator"
    ,"Status":"Status"
    ,"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Column mapping and adding audit columns
# Converting column names according to doamin tables and adding audit columns to dataframe
try:
    col_mapped_df = col_name_mapping(audit_col_added_df,col_mapping).withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
except Exception as e:
    raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
# Some decimal columns have a different precision than what is expected in the curated layer. Delta columns need to have the same precision or it complains about it. This is the schema definition for the columns which don't match up.
dtype_mapping = {
    "ProviderId" : "VARCHAR(50)",
    "ProviderSequenceNumber" : "VARCHAR(50)",
    "CapitationFundAmount" : "DECIMAL(20,6)",
    "CatastrophWiithholdAdjstmntAmt" : "DECIMAL(20,6)",
    "CatastrophicWiithholdAmount" : "DECIMAL(20,6)",
    "DeficitAbsorbAmount" : "DECIMAL(20,6)",
    "ExpensedMemberMonthCount" : "INTEGER",
    "FundAmount" : "DECIMAL(20,6)",
    "FundBroughtForwardAmount" : "DECIMAL(20,6)",
    "FundCapitationExpenseAmount" : "DECIMAL(20,6)",
    "FundClaimBenefitAmount" : "DECIMAL(20,6)",
    "FundClaimDiscountAmount" : "DECIMAL(20,6)",
    "FundClaimExpenseAmount" : "DECIMAL(20,6)",
    "FundDirectPaymentAmount" : "DECIMAL(20,6)",
    "FundFinalPaymentAmount" : "DECIMAL(20,6)",
    "FundIBNRAmount" : "DECIMAL(20,6)",
    "FundLateClaimAmount" : "DECIMAL(20,6)",
    "FundManualAdjustmentAmount" : "DECIMAL(20,6)",
    "FundMemberMonthCount" : "INTEGER",
    "FundNetACTAmount" : "DECIMAL(20,6)",
    "FundOtherAmount" : "DECIMAL(20,6)",
    "FundProviderRiskAmount" : "DECIMAL(20,6)",
    "FundReconciliationAmount" : "DECIMAL(20,6)",
    "FundReturnLimitAmount" : "DECIMAL(20,6)",
    "FundSettlementAmount" : "DECIMAL(20,6)",
    "FundTransferInAmount" : "DECIMAL(20,6)",
    "FundTransferOutAmount" : "DECIMAL(20,6)",
    "FundWithholdClaimAmount" : "DECIMAL(20,6)",
    "PrimaryPeriodBroughtFrwrdAmt" : "DECIMAL(20,6)",
    "StoplossExcessAmount" : "DECIMAL(20,6)",
    "ReturnLimitMonthCount" : "INTEGER"
}

# COMMAND ----------

# DBTITLE 1,Converting YYYYMM dates into YYYY-MM-DD and Datatype conversion
# Converting YYYYMM dates into YYYY-MM-DD (1st for start/open dates, end of month day for end/close dates)
# Change the precision of all the columns that don't match the curated layer precision.
try:
    start_date_transformed_df = dt_format_cym(col_mapped_df, ['PeriodBeginDate'],'start')
    end_date_transformed_df = dt_format_cym(start_date_transformed_df, ['PeriodEndDate', 'FundClosedDate'],'end')
    dtype_trans_df = dtype_tgt_conversion(end_date_transformed_df, dtype_mapping)
except Exception as e:
    raise Exception("validation failed",str(e))

# COMMAND ----------

# DBTITLE 1,Join TRE2346 with TRE2345 and filtering valid records
#Joining TRE2346 with TRE2345 to build the common structure
try:
    tre2346_joined_tre2345_df = dtype_trans_df.alias('LH').join(prov_ctrt_fund_df.alias('RH'),\
        (col('LH.ProviderId') == col('RH.ProviderId')) & \
        (col('LH.ProviderSuffixCode') == col('RH.ProviderSuffixCode')) & \
        (col('LH.ProviderServiceTypeCode') == col('RH.ProviderServiceTypeCode')) & \
        (col('LH.ProviderSequenceNumber') == col('RH.ProviderSequenceNumber')) & \
        (col('LH.FundSequenceNumber') == col('RH.FundSequenceNumber')), 'left')\
            .select('LH.*', 'RH.ProviderContractFundKey')
    final_df = remove_invalid_records(tre2346_joined_tre2345_df, stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception('Joining or filtering valid records failed',str(e))   

# COMMAND ----------

# DBTITLE 1,Curated load & Azure SQL load
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProviderContractDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        provider_contract_fund_payment_df = read_table_to_df(cur_tbl_name)\
                        .drop('DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber')
        load_df_to_sf_sql_db_spark(provider_contract_fund_payment_df, 'ProviderContract.ProviderContractFundPayment')
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions =['ProviderContractFundKey', 'PeriodBeginDate']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProviderContractFundPaymentKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'ProviderContractFundPaymentKey':lit(None).cast("BIGINT"),
        'ProviderContractFundKey':lit(None).cast("BIGINT"),
        'DeltaStatus' : lit(None).cast('STRING')
        }
        mapped_df= final_df.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,mapped_df,['PeriodBeginDate','CreatedBy','CreatedDateTime'])

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'ProviderContract.StageProviderContractFundPayment')
        
        exit_notebook(run_id, "ProviderContract", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
     
except Exception as e:
    raise Exception ('load failed',str(e))
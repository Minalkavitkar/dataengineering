# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Product unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"RIF{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIF

# COMMAND ----------

# DBTITLE 0,Product table script.
rif = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.RIF_StageRIF(
  RIFKey BIGINT not null,
  AffiliationCode VARCHAR(20),
  RIFId VARCHAR(50),
  RIFDescription VARCHAR(128),
  CreatedBy VARCHAR(150) not null,
  CreatedDateTime TIMESTAMP not null,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP,
  DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/rif/stage/RIF'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### RIFProviderContract

# COMMAND ----------

# DBTITLE 0,ProductAffiliation table script.
rif_providercontract = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.RIF_StageRIFProviderContract(
        RIFProviderContractKey BIGINT NOT NULL,
        RIFKey BIGINT not null,
        ProviderContractKey BIGINT not null,
        RIFContractStartDate DATE,
        RIFContractEndDate DATE,
        CreatedBy VARCHAR(150) not null,
        CreatedDateTime TIMESTAMP not null,
        ModifiedBy VARCHAR(150),
        ModifiedDateTime TIMESTAMP,
        DerivedIndicator STRING
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/rif/stage/RIFProviderContract'"""

# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
    "RIF_StageRIF" : rif
    ,"RIF_StageRIFProviderContract" : rif_providercontract
}

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    # Logic to create table based on the input parameter.
    # If 'All' is provided as parameter then it will create all table in the notebook.
    # If specific table names are provided in parameter then only those will run.
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
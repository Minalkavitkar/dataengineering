# Databricks notebook source
# DBTITLE 1,Importing libraries
from pyspark.sql.functions import col,split
from pyspark.sql import functions as F
import json
from datetime import datetime, timedelta

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('Module','')
Module = dbutils.widgets.get('Module')

# COMMAND ----------

# DBTITLE 1,Setup environment variables
# MAGIC %run "../Utility/Helpers/EnvironmentVariableHelper"

# COMMAND ----------

# DBTITLE 1,Establish ingest functions
# MAGIC %run "../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Module wise current run list
# MAGIC %run "../Utility/Validate"

# COMMAND ----------

# DBTITLE 1,Extracting required table list
try:
  tbl_name_lst = validate_notebook()[Module]
  table_names=[table_code.split('_')[-1] for table_code in tbl_name_lst]
  req_table_name = ",".join(table_names)
  dbutils.notebook.exit(req_table_name)
except Exception as e:
  raise Exception("getting table list to run failed: ",str(e)) 
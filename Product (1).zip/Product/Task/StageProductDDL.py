# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Product unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product

# COMMAND ----------

# DBTITLE 0,Product table script.
product = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Product_StageProduct(
  ProductKey BIGINT NOT NULL
  ,ExtProdSeqNo INT
  ,ProductId VARCHAR(50)
  ,ExpenseAccountPrefixNumber INT
  ,LineOfBusinessCode VARCHAR(20)
  ,MarketNumber VARCHAR(50)
  ,OptNumber VARCHAR(10)
  ,PlanNumber VARCHAR(10)
  ,ProductComment1Text VARCHAR(128)
  ,ProductComment2Text VARCHAR(128)
  ,ProductPlanDate DATE
  ,ProductEndDate DATE
  ,ProductStartDate DATE
  ,SourceSystemCode VARCHAR(10)
  ,AdjustmentYearNumber SMALLINT
  ,AdjustmentSequenceNumber SMALLINT
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductAffiliation

# COMMAND ----------

# DBTITLE 0,ProductAffiliation table script.
product_affiliation = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Product_StageProductAffiliation(
        ProductAffiliationKey BIGINT NOT NULL,
        AffiliationCode VARCHAR(20),
        HMPCode VARCHAR(20),
        LineOfBusinessCode VARCHAR(20),
        LocationDescription VARCHAR(128),
        LocationId VARCHAR(50),
        DerivedIndicator STRING,
        CreatedBy STRING NOT NULL,
        CreatedDateTime TIMESTAMP NOT NULL,
        ModifiedBy STRING,
        ModifiedDateTime TIMESTAMP
        )"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductSetAssociation

# COMMAND ----------

product_set_association = f"""CREATE or REPLACE TABLE {stage_catalog_name}.{schema_name}.Product_StageProductSetAssociation
        (
        ProductSetAssociationKey BIGINT NOT NULL,
        ProductSetKey BIGINT NOT NULL,
        ProductKey BIGINT NOT NULL,
        CreatedBy STRING NOT NULL,
        CreatedDateTime TIMESTAMP NOT NULL,
        ModifiedBy STRING,
        ModifiedDateTime TIMESTAMP
        )"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductSetAffiliation

# COMMAND ----------

product_set_affiliation = f"""CREATE or REPLACE TABLE {stage_catalog_name}.{schema_name}.Product_StageProductSetAffiliation(
        ProductSetAffiliationKey BIGINT NOT NULL
        ,ProductSetKey BIGINT NOT NULL
        ,ProductAffiliationKey BIGINT NOT NULL
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###ProductGeoMarketAffiliation

# COMMAND ----------

product_geo_market_affiliation = f"""CREATE or REPLACE TABLE {stage_catalog_name}.{schema_name}.Product_StageProductGeoMarketAffiliation(
        ProductGeoMarketAffiliationKey BIGINT NOT NULL
        ,GeoMarketAffiliationKey BIGINT NOT NULL
        ,ProductAffiliationKey BIGINT NOT NULL
        ,DerivedIndicator STRING
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""

# COMMAND ----------

# MAGIC %md 
# MAGIC ###GeoMarketAffiliation

# COMMAND ----------

print( stage_catalog_name,schema_name)

# COMMAND ----------

geo_market_affiliation =  f"""CREATE or REPLACE TABLE {stage_catalog_name}.{schema_name}.Product_StageGeoMarketAffiliation(
        GeoMarketAffiliationKey BIGINT NOT NULL 
        ,GeographicMarketId VARCHAR(50)
        ,AffiliationCode VARCHAR(20)
        ,DerivedIndicator STRING
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""


# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
    "Product_StageProduct" : product
    ,"Product_StageProductAffiliation" : product_affiliation
    ,"Product_StageProductSetAssociation" : product_set_association
    ,"Product_StageProductSetAffiliation" : product_set_affiliation
    ,"Product_StageProductGeoMarketAffiliation" : product_geo_market_affiliation
    ,"Product_StageGeoMarketAffiliation" : geo_market_affiliation
}

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    # Logic to create table based on the input parameter.
    # If 'All' is provided as parameter then it will create all table in the notebook.
    # If specific table names are provided in parameter then only those will run.
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Job RE0797 - This process will update the Provider Service address information from PIMS feed to Service Fund Provider address table and generate the Provider address file to CAS.
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - Provider.ProviderVendor
# MAGIC - Provider.Provider
# MAGIC - IN_PIMS_PCP_ADDR_CCYYMMDD.TXT
# MAGIC
# MAGIC ###### Intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - Provider.Re0797ProviderPIMSUpdate
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenCasPcpAddressFile.txt 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import *
from datetime import date
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run Transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Job name Assignment
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0797ProviderPIMSUpdateInbound')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
try:  
    job_name = JOB_NAME.replace("Inbound", "")
    config_dict =  get_file_config(file_conf_path)

except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    default_in_config = default_config["Inbound"]
    Re0797_config = config_dict[job_name]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config['FilePathPrefix']
    file_path_prefix_in = default_in_config["FilePathSuffix"]
    config = default_out_config["Config"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = Re0797_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = Re0797_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = Re0797_config["Outbound"]["TableName"]
    outbnd_file_name = Re0797_config["Outbound"]["FileName"]
    cur_tbl_name = Re0797_config['Outbound']['TableName']
    stg_prv_vnd_tbl_name = Re0797_config["Inbound"]["StageProviderVendor"]
    stg_prv_tbl_name = Re0797_config["Inbound"]["StageProvider"]
    sync_process_names = Re0797_config["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
    pcp_addr = Re0797_config["Inbound"]["PcpAddrFilePath"]
    stg_tbl_name = Re0797_config['Inbound']['StageTableName']
    
except Exception as e:
    excep = "Variable assignment from FileConfig: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Curated and temp.
try:
    temp_csv_path = abfss_path_builder(container_name,storage_account,prc_file_path_prefix,temp_path_suffix)
    pcp_addr_path = abfss_path_builder(container_name, storage_account, file_path_prefix_in, pcp_addr)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read data from Stage(ADLS) and Azure SQL table.
try:
    # Read ProviderVendor from ADLS curated table
    ProviderVendor_df = read_table_to_df(stg_prv_vnd_tbl_name)

    # Read Provider from ADLS curated table
    Provider_df = read_table_to_df(stg_prv_tbl_name).select("ProviderKey", "ProviderId", "SuffixCode","Type2Code")

    # Read IN_PIMS_PCP_ADDR_CCYYMMDD.TXT (sorted) file from ADLS inbound folder
    df_pcp_addr = read_inbound_csv_file(pcp_addr_path)
    df_pcp_addr_seq = df_pcp_addr.withColumn('SeqNo',row_number().over(Window.orderBy(monotonically_increasing_id())))
    
except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column Mapping Dictionary
# Datatype mapping dictionary as per SQL ProviderServiceAddress table
col_schema={
"PROV_CAS_ID":"String",
"PROV_CAS_SUFFIX":"String",
"PROV_ADDR_LINE1":"String",
"PROV_ADDR_LINE2":"String",
"PROV_ADDR_CITY":"String",
"PROV_ADDR_ST":"String",
"PROV_ADDR_ZIP":"String",
"PROV_ADDR_ZIP_PLUS":"String",
"PROV_COUNTY_FIPS":"String",
"PROV_PRIMARY_IND":"String", 
"PROV_LATITUDE_12B":"integer",
"PROV_LATITUDE_34B":"integer",
"PROV_LONGITUD_13B":"integer",
"PROV_LONGITUD_45B":"integer",
"PROV_LATITUDE_DIR":"String",
"PROV_LONGITUD_DIR":"String",
"PROV_VENDOR_NBR":"String",
"PROV_CENTER_NBR":"String",
"PROV_CENTER_SUFFIX":"String",
"SeqNo":"Integer"
}

# column mapping as per SQL ProviderServiceAddress table
col_mapping={
"ProvCasId":"ProviderId",
"ProvCasSuffix":"SuffixCode",
"ProvAddrLine1":"AddressLine1Text",
"ProvAddrLine2":"AddressLine2Text",
"ProvAddrCity":"CityName",
"ProvAddrSt":"StateCode",
"ProvAddrZip":"ZipCode",
"ProvAddrZipPlus":"ZipPlusCode",
"ProvCountyFips":"CountyFIPSCode",
"ProvPrimaryInd":"ProvPrimaryInd", 
"ProvLatitude12B":"12BLatitudeNumber",
"ProvLatitude34B":"34BLatitudeNumber",
"ProvLongitud13B":"13BLongitudeNumber",
"ProvLongitud45B":"45BLongitudeNumber",
"ProvLatitudeDir":"LatitudeDirectionIndicator",
"ProvLongitudDir":"LongitudeDirectionIndicator",
"ProvVendorNbr":"ProvVendorNbr", 
"ProvCenterNbr":"ProvCenterNbr", 
"ProvCenterSuffix":"ProvCenterSuffix",
"SeqNo":"SeqNo"
}

# COMMAND ----------

# DBTITLE 1,Column mapping conversion
try:
    df_pcp_addr_trim = trim_leading_trailing_space(df_pcp_addr_seq)
    pcp_dtype_trans_df = dtype_conversion(df_pcp_addr_trim, col_schema)
    final_col_map_df = col_name_mapping(pcp_dtype_trans_df, col_mapping)    
except Exception as e:
    excep = 'Datatype and column mapping failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Adding separate comment columns for null values in 4 columns and replacing it with 0
# adding comment columns for null values in 12BLatitudeNumber, 34BLatitudeNumber, 13BLongitudeNumber,45BLongitudeNumber to use it as lookup in outbound notebook
try:
    col_maps = {
        "Comment12B": (when(col("12BLatitudeNumber").isNull(), lit('12BLatitudeNumber is null'))),
        "Comment34B": (when(col("34BLatitudeNumber").isNull(), lit('34BLatitudeNumber is null'))),
        "Comment13B": (when(col("13BLongitudeNumber").isNull(), lit('13BLongitudeNumber is null'))),
        "Comment45B": (when(col("45BLongitudeNumber").isNull(), lit('45BLongitudeNumber is null')))
    }
    df_cmnts = final_col_map_df.withColumns(col_maps)
#Replacing nulls with 0 for these 4 integer columns:
    pcp_addr_trans_df = df_cmnts.na.fill(0,['12BLatitudeNumber','34BLatitudeNumber','13BLongitudeNumber','45BLongitudeNumber'])
except Exception as e:
    excep = 'Adding comment columns for null values in 4 columns and replacing it with 0 failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Handling space and Null values in PROV_CAS_SUFFIX and PROV_CENTER_SUFFIX in inbound file
try:
    df_pcp_addr_final = pcp_addr_trans_df.withColumn(
        "SuffixCode",
        when(
            (col("SuffixCode").isNull()) | (trim(col("SuffixCode")) == ""),
            lpad(col("SuffixCode"), 2, " "),
        ).otherwise(col("SuffixCode"))
    ).withColumn(
        "ProvCenterSuffix",
        when(
            (col("ProvCenterSuffix").isNull())
            | (trim(col("ProvCenterSuffix")) == ""),
            lit("  "),
        ).otherwise(col("ProvCenterSuffix"))
    )
except Exception as e:
    excep = "Handling space and Null values in PROV_CAS_SUFFIX and PROV_CENTER_SUFFIX failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Convert lower case values to uppercase in PCP address input file
# Convert lower case values to uppercase in PCP address file
try:  
    conv_pcp_addr_final_df = df_pcp_addr_final.withColumn(
        "ProvCenterSuffix", upper(col("ProvCenterSuffix"))
    ).withColumn("SuffixCode", upper(col("SuffixCode")))
except Exception as e:
    excep = 'Handling lower case values in PCP address file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select only required columns 
try:
    # Select only required columns from the tables:
    ProviderVendor_df_sel = ProviderVendor_df.select(
        "ProviderKey", lpad(col("VendorNumber"), 9, "0").alias("VendorNumber")
    )
    #Prioritization on Prvider table on Type2Code and selecting required columns:
    prv_df = prioritize_prv_type2Code(Provider_df).selectExpr("ProviderKey","ProviderId as ProvId", "SuffixCode as SuffCode")
except Exception as e:
    excep = "Select required columns failed: " + str(e)
    output = {
        "NOTEBOOK_RUN_STATUS": excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Empty Check on PCP address file
try:
    #Check if PROV_VENDOR_NBR is spaces or not and create respective files:
    #File1: Pcp_Addr is filtered on PROV_VENDOR_NBR is space:
    pcp_addr_withSpaces = conv_pcp_addr_final_df.filter(trim(col('ProvVendorNbr'))=="")

    #File2: Pcp_Addr is filtered on PROV_VENDOR_NBR is not space:
    pcp_addr_withoutSpaces = conv_pcp_addr_final_df.filter(trim(col('ProvVendorNbr'))!="")

except Exception as e:
    excep = 'Empty Check on PCP address file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Provider ,ProviderVendor and pcp_addr_withoutSpaces
try:
    # Join ProviderVendor and Provider
    df_join = (
        ProviderVendor_df_sel.alias("LH")
        .join(
            prv_df.alias("RH"),
            col("LH.ProviderKey") == col("RH.ProviderKey"),
            "left",
        )
        .drop(col("LH.ProviderKey"), (col("RH.ProviderKey")))
    )
    
    # Join df_join with file2 of previous step:
    nonEmpty_vnd_df = pcp_addr_withoutSpaces.alias("LH").join(
        df_join.alias("RH"),
        col("LH.ProvVendorNbr") == col("RH.VendorNumber"),
        "left",
    )

except Exception as e:
    excep = "Join with Provider, ProviderVendor failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filtering out orphan vendor records
try:
    vnd_orphans = nonEmpty_vnd_df.filter(col('VendorNumber').isNull()).selectExpr("*",
        "'Vendor not found in ProviderVendor' AS RejectReason",
        "current_timestamp() as CreatedDateTime",
        f"'{PIPELINE_NAME}' as CreatedBy",
        "'INSERT' as DerivedIndicator")\
        .drop('ProviderId','SuffixCode','SeqNo', 'VendorNumber')\
        .withColumnRenamed('ProvId','ProviderId')\
        .withColumnRenamed('SuffCode','SuffixCode')

    nonEmpty_vnd_df_valid = nonEmpty_vnd_df.filter(col('VendorNumber').isNotNull())
except Exception as e:
    excep = "Filtering out orphan vendor records failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 1: Updating PROV_CAS_ID and PROV_CAS_SUFFIX
# Updating PROV_CAS_ID and PROV_CAS_SUFFIX with ProviderId and SuffixCode from Provider table
# need to add exception if SuffixCode, PROV_CAS_SUFFIX is null or small 
try:
    nonEmpty_vnd_df_final = (
        nonEmpty_vnd_df_valid.withColumn("ProviderId", col("ProvId"))\
        .withColumn("SuffixCode", col("SuffCode"))
        .drop(col("ProvId"), col("VendorNumber"), col("SuffCode"))
    )
except Exception as e:
    excep = "Update PROV_CAS_ID, PROV_CAS_SUFFIX failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter records if "PROV_CENTER_NBR" is spaces.
try:
    # filter datasets when "PROV_CENTER_NBR" is equal to spaces and not spaces
    empty_vend_addr_df = pcp_addr_withSpaces.filter(trim(col("ProvCenterNbr")) == "")
    non_empty_vend_addr_df = pcp_addr_withSpaces.filter(trim(col("ProvCenterNbr")) != "")

except Exception as e:
    excep = "Update PROV_CAS_ID, PROV_CAS_SUFFIX failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Update PROV_CAS_ID, PROV_CAS_SUFFIX
try:
    # Update PROV_CAS_ID, PROV_CAS_SUFFIX
    updated_non_empty_vend_addr_df = non_empty_vend_addr_df.withColumn(
    "ProviderId", trim(col("ProvCenterNbr"))
    ).withColumn("SuffixCode", col("ProvCenterSuffix"))

except Exception as e:
    excep = 'Update PROV_CAS_ID, PROV_CAS_SUFFIX failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Union all existing and updated datasets
try:
    # Union all existing and updated datasets
    final_union_df = (
        updated_non_empty_vend_addr_df.union(non_empty_vend_addr_df)
        .union(empty_vend_addr_df)
        .union(pcp_addr_withoutSpaces)
        .union(nonEmpty_vnd_df_final)
    )
except Exception as e:
    excep = "Union datasets failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select Distinct records on the basis of PROV_CAS_ID,PROV_CAS_SUFFIX
# Select Distinct records on the basis of PROV_CAS_ID,PROV_CAS_SUFFIX
try:
    w = Window.partitionBy("ProviderId", "SuffixCode").orderBy(
        col("ProviderId"), col("ProviderId"),col('SeqNo')
    )
    final_dist_df = (
        final_union_df.withColumn("rn", row_number().over(w))
        .filter(col("rn") == 1)
        .drop("rn","SeqNo")
    )
except Exception as e:
    excep = "Selecting Distinct records failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join final dataframe with Provider table to fetch ProviderKey Column
# Join final dataframe with Provider table to fetch ProviderKey Column
try:
    joined_df = (
        final_dist_df.alias("LH")
        .join(
            prv_df.alias("RH"),
            ((col("LH.ProviderId") == col("RH.ProvId")))
            & (col("LH.SuffixCode") == col("RH.SuffCode")),
            "left",
        )
        .select("LH.*", "RH.ProviderKey")\
        .withColumn('RejectReason',when(col('ProviderKey').isNull(),lit('ProviderKey is Null')))
    )
except Exception as e:
    excep = "Join with Provider table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column calculation.
try:
    # adding audit columns.
    curr_prov_ser_addr_df = joined_df.selectExpr(
        "*",
        "md5(concat(ProviderId, SuffixCode)) as HashKey",
        "current_timestamp() as CreatedDateTime",
        f"'{PIPELINE_NAME}' as CreatedBy",
        "cast(null as timestamp)as ModifiedDateTime",
        "cast(null as string) as ModifiedBy",
        "null as DerivedIndicator",
    )

except Exception as e:
    excep = "Column calculation failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Function to getting column select list.
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Identify Delta records(INSERT, UPDATE, DELETE, and IGNORE).
try:
        # Read data from Stage Provider service address table and calculate HashKey
        # ProvVendorNbr,ProvCenterNbr,ProvCenterSuffix,ProvPrimaryInd,DerivedIndicator to match current dataframe schema.
        prov_srv_addr_df= read_table_to_df(stg_tbl_name)
        joined_prov_srv_addr_df=prov_srv_addr_df.alias("LH")\
                .join(Provider_df.alias("RH"),(col("LH.ProviderKey")==col("RH.ProviderKey")),"left")\
                .select("LH.*","RH.ProviderId","RH.SuffixCode").selectExpr("*","md5(concat(ProviderId, SuffixCode)) as HashKey","null as ProvVendorNbr", "null as ProvCenterNbr", "null as ProvCenterSuffix","null as ProvPrimaryInd","null as DerivedIndicator","null as RejectReason","null as Comment12B","null as Comment34B","null as Comment13B","null as Comment45B").drop("ProviderServiceAddressKey")

        # Create Column list. Which is used for processing.
        new_col_slt_lst = joined_prov_srv_addr_df.columns
        col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)


        # Add suffix 'Old' to column name for existing data to avoid column ambiguous.
        old_renamed_df = joined_prov_srv_addr_df.selectExpr(*col_select_lst)

        # Join previous day with current day data to identify delta data.
        old_joined_df = curr_prov_ser_addr_df.alias('LH')\
                .join(old_renamed_df.alias('RH'),(col("LH.HashKey") == col("RH.OldHashKey")), "full")

        # Get only the records which are needs to insert and create DerivedIndicator column.
        ins_df = old_joined_df\
                .filter((col('OldHashKey').isNull()))\
                .withColumn('DerivedIndicator', lit('INSERT'))\
                .drop(*col_drop_lst)

        # Get only the records which are needs to delete and create DerivedIndicator column.
        dels_df = old_joined_df\
                .filter((col('HashKey').isNull()))\
                .withColumn('OldDerivedIndicator', lit('DELETE'))\
                .selectExpr(*del_col_sel_lst)

        # Get only the records which are needs to updates and create DerivedIndicator column.
        upds_df = old_joined_df\
        .filter((col('HashKey').isNotNull()) & (col('OldHashKey').isNotNull()))\
        .withColumn('DerivedIndicator', when((col("AddressLine1Text").eqNullSafe(col("OldAddressLine1Text"))) &
                (col("AddressLine2Text").eqNullSafe(col("OldAddressLine2Text"))) &
                (col("CityName").eqNullSafe(col("OldCityName"))) &
                (col("StateCode").eqNullSafe(col("OldStateCode"))) &
                (col("ZipCode").eqNullSafe(col("OldZipCode"))) &
                (col("ZipPlusCode").eqNullSafe(col("OldZipPlusCode"))) &
                (col("CountyFIPSCode").eqNullSafe(col("OldCountyFIPSCode"))) &
                (col("12BLatitudeNumber").eqNullSafe(col("Old12BLatitudeNumber"))) &
                (col("34BLatitudeNumber").eqNullSafe(col("Old34BLatitudeNumber"))) &
                (col("13BLongitudeNumber").eqNullSafe(col("Old13BLongitudeNumber"))) &
                (col("45BLongitudeNumber").eqNullSafe(col("Old45BLongitudeNumber"))) &
                (col("LatitudeDirectionIndicator").eqNullSafe(col("OldLatitudeDirectionIndicator"))) &
                (col("LongitudeDirectionIndicator").eqNullSafe(col("OldLongitudeDirectionIndicator")))
                ,lit('IGNORE')).otherwise(lit('UPDATE')))

        #Calculate ModifiedBy and ModifiedDateTime.
                # If it is update set the modifiedDateTime as current timestamp and modifiedBy as task name.
        col_maps = {
                        'ModifiedDateTime' : (when(col('DerivedIndicator') == 'UPDATE', lit(current_timestamp()))
                                                        .otherwise(col('OldModifiedDateTime'))),
                        'ModifiedBy' : (when(col('DerivedIndicator') == 'UPDATE', lit(PIPELINE_NAME))\
                                                .otherwise(col('OldModifiedBy'))),
                        'CreatedBy' : col('OldCreatedBy'),
                        'CreatedDateTime' : col('OldCreatedDateTime')
                }
        calc_audit_col_upds_df = upds_df.withColumns(col_maps)\
                        .select(*new_col_slt_lst)

        # Union Insert, Delete and Update dataframe.
        calc_df = ins_df.unionByName(dels_df)\
                .unionByName(calc_audit_col_upds_df)\
                .unionByName(vnd_orphans,allowMissingColumns=True).drop('HashKey')

        # Replace previous run data with current run data in curated table.
        write_df_as_delta_table(calc_df, cur_tbl_name)

except Exception as e:
    excep = "Identify Delta record failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to Azure SQL stage table.
try:
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    re0797_df = spark.read.table(cur_tbl_name)\
                .filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE', 'DELETE']))\
                .selectExpr(
                    '*', 
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as ProviderServiceAddressKey', 
                    'cast(null as string) as ProcessName')\
                .drop('ProvVendorNbr','ProvCenterNbr','ProvCenterSuffix','ProvPrimaryInd','HashKey','RejectReason','Comment12B','Comment34B','Comment13B','Comment45B')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    upd_col_nullable_df = set_df_columns_not_nullable(spark, re0797_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(upd_col_nullable_df, 'Provider.StageProviderServiceAddress')
    
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
output = {
      'NOTEBOOK_RUN_STATUS' : 'Success'
}
dbutils.notebook.exit(json.dumps(output))
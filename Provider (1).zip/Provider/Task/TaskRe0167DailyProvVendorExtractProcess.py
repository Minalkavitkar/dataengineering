# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job RE0167-ProvVendorExtract to create an interface to extract provider and vendor information using Provider Vendor table from Operational database.
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - Provider.StageProvider
# MAGIC - Provider.StageProviderVendor
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Provider.Re0167DailyProvVendorExtractProcess
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC
# MAGIC - ProdrenRe0167DailyProvVendorExtract.csv (CSV File) 
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Notebook which is used to establish connection to the storage account
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
    col("JobName") == JOB_NAME
)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    re0167_config = config_dict[JOB_NAME]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    config = default_out_config["Config"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re0167_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re0167_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re0167_config["Outbound"]["TableName"]
    outbnd_file_name = re0167_config["Outbound"]["FileName"]
    #input table name
    stg_prv_tbl = re0167_config["Inbound"]["StageProvider"]
    stg_prv_vnd_tbl = re0167_config["Inbound"]["StageProviderVendor"]
    sync_process_names = re0167_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]

except Exception as e:
    excep = "Variable assignment from FileConfig: ", str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read the data from Stage ADLS
try:
    # Read the ProviderVendor table from Stage ADLS
    prov_vendor_df = read_table_to_df(stg_prv_vnd_tbl).select("ProviderKey", "VendorNumber")
    
    # Read the Provider table from Stage ADLS
    provider_df = read_table_to_df(stg_prv_tbl).select("ProviderId","ProviderKey","SuffixCode")

except Exception as e:
    excep = "Read SQL tables failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Perform join operation on ProviderVendor and Provider table to get ProviderID, SuffixCode
try:
    # Perform join operation on ProviderVendor and Provider table to get ProviderID, SuffixCode
    joined_df = (
        provider_df.alias("LH")
        .join(prov_vendor_df.alias("RH"), (col("LH.ProviderKey") == col("RH.ProviderKey")), "inner")
        .select("LH.ProviderId", "LH.SuffixCode", "RH.VendorNumber")
        )
except Exception as e:
    excep = "join operation on ProviderVendor and Provider table failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(joined_df, tbl_name)

    # Read data from stage layer.
    re0167_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0167_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the csv file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the Notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
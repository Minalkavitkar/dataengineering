# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job RE0072-This process creates an interface to generate a Provider and Provider LOB Extract outbound files for MC and EDW application
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - ProviderContract.Re0064DailyContract
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC
# MAGIC - ProdrenRe0072Provider.txt
# MAGIC - ProdrenRe0072ProvLOB.txt
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Notebook which is used to establish connection to the storage account
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path)
    prov_fxd_conf_df = fixed_config_df.filter(col("JobName") == "Re0072Provider")
    prov_lob_fxd_conf_df = fixed_config_df.filter(col("JobName") == "Re0072ProvLOB")
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict["DEFAULT"]
  default_out_config = default_config["Outbound"]
  re0072_config = config_dict[job_name]

  container_name = default_config["ContainerName"]
  file_path_prefix = default_out_config["FilePathPrefix"]
  config = default_out_config["Config"]
  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  
  prov_temp_path_suffix = re0072_config["Outbound"]["Re0072ProvTempFilePathSuffix"]
  prov_tbl_name = re0072_config["Outbound"]["Re0072ProvTableName"]
  prov_outbnd_file_name = re0072_config["Outbound"]["Re0072ProvFileName"]
  prov_lob_tbl_name = re0072_config["Outbound"]["Re0072ProvLOBTableName"]
  prov_lob_temp_path_suffix = re0072_config["Outbound"]["Re0072ProvLOBTempFilePathSuffix"]
  prov_lob_outbnd_file_name = re0072_config["Outbound"]["Re0072ProvLOBFileName"]
  #input table name
  re0064_tbl_name = re0072_config["Inbound"]["Re0064TableName"]
  audit_table_name = default_config["AuditTableName"]

except Exception as e:
  excep = "Variable assignment from FileConfig: ", str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    prov_temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, prov_temp_path_suffix
    )

    prov_lob_temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, prov_lob_temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read the data from Stage ADLS
try:
  # Read the re0064DailyContract ADLS UC table and select required columns
  df_re0064 = read_table_to_df(re0064_tbl_name)\
              .select(substring(col('PcaCtrctKey'),1,11).alias('ProvIdGfld'),
                          "VendorNumber",
                          "ProviderName",
                          "PcaStatCd",
                          "PcaBegCymdDate",
                          "PcaEndCymdDate",
                          "MemberLimitCode",
                          "MemberTypeCode",
                          "ProductLineOfBusinessCode",
                          "LocationId",
                          "ProviderMemberCount",
                          lit(0).alias('CurrMemberCount')
                          )

except Exception as e:
  excep = "Read re0064DailyContract table failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP1:Filter Re0064 output acording to below conditions
try:
  # Filter Re0064 output acording to below conditions:
  df_fltrd = df_re0064.filter(
              (col('PcaStatCd') != 'I') &
              ((col('PcaBegCymdDate')) != (col('PcaEndCymdDate'))) &
              (col('MemberLimitCode')!='D') &
              (col('MemberTypeCode')!='D') &
              (trim(col('ProductLineOfBusinessCode'))!='') &
              (trim(col('LocationId'))!='')
  )
except Exception as e:
    excep = "Filter Re0064 output failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP2:Calculate Cut-off Date
try:
    # Calculate cut off date to fetch only 3 months data
    current_date_ccyy=current_date()
    cutoff_date=add_months(current_date_ccyy, -3)
except Exception as e:
    excep = 'calculation of cut off date failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP3:Filter only last 3 months data.
# Filter only last 3 months data.
try:
    # select the records if ContractEndDate is greater than cutoff date
    prov_calc_df = df_fltrd.filter(year(col("PcaEndCymdDate")) >= year(cutoff_date))
    prov_cutoff_df = prov_calc_df.filter(col("PcaEndCymdDate")>cutoff_date)
except Exception as e:
    excep = 'Filter 3 months records failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Sort the output of STEP3 on required fields
try:
    # Sort the output of STEP3 on required fields
    prov_lob_final_df = prov_cutoff_df.orderBy(
                                    "VendorNumber",
                                    "ProductLineOfBusinessCode",
                                    "LocationId",
                                    "PcaBegCymdDate",
                                    "PcaEndCymdDate",
                                    "MemberLimitCode",
                                    "MemberTypeCode",
                                    "ProviderMemberCount",
                                    "CurrMemberCount")
except Exception as e:
    excep = 'Sort the output on required fields failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(prov_lob_final_df, prov_lob_tbl_name)

    #Read data from stage layer.
    re0072_prov_lob_df = read_table_to_df(prov_lob_tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(prov_lob_fxd_conf_df, re0072_prov_lob_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, prov_lob_temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move Prov outbound file to outbound folder and rename it.
try:
    copy_file_to_outbnd_with_new_name(prov_lob_temp_csv_path, outbnd_csv_path, prov_lob_outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Take distinct of STEP3 output on ProviderId & SuffixCode
try:
    #Take distinct on ProviderId+SuffixCode (ProvIdGfld) from filtered dataframe and order by VendorNumber,ProviderId:
    ws = Window.partitionBy('ProvIdGfld').orderBy('VendorNumber',substring(col('ProvIdGfld'),1,9))                
    prov_final_df = (prov_cutoff_df.withColumn("rn", row_number().over(ws))
            .filter(col("rn")==1)
            .select("ProvIdGfld","VendorNumber","ProviderName")
        )
except Exception as e:
    excep = "Taking distinct on ProviderId,SuffixCode and sorting failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(prov_final_df, prov_tbl_name)

    # Read data from stage layer.
    re0072_prov_df = read_table_to_df(prov_tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(prov_fxd_conf_df, re0072_prov_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, prov_temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(prov_temp_csv_path, outbnd_csv_path, prov_outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : prov_outbnd_file_name+','+prov_lob_outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the Notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
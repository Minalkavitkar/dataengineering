# Databricks notebook source
# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

trexafl_dbp_tbl_name="provider_staging_dev_000.mainframe_servicefund_sit.Product_StageTREXAFLDBP"

# COMMAND ----------

trexafl= spark.read.options(header=True,inferSchema =True, delimiter ='|')\
.csv("dbfs:/FileStore/tables/FileStore/PRODUCT_TREXAFL.TXT")

# COMMAND ----------

trexafl_schema={
    'AFFIL_TY_CD_OWN':'STRING'
    ,'AFFIL_GEN_KEY_OWN':'INT'
    ,'AFFIL_TY_CD_MBR':'STRING'
    ,'AFFIL_GEN_KEY_MBR':'INT'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'TIMESTAMP'
}

trexafl_df=dtype_conversion(trexafl,trexafl_schema)

# COMMAND ----------

write_df_as_delta_table(trexafl_df,trexafl_dbp_tbl_name)

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

tregpaf= spark.read.options(header=True,inferSchema =True, delimiter ='|')\
.csv("dbfs:/FileStore/tables/FileStore/BBS_REPORTING_TREGPAF.TXT")

# COMMAND ----------

tregpaf_dbp_tbl_name="provider_staging_dev_000.mainframe_servicefund_sit.bbsreporting_StageTREGPAFDBP"

# COMMAND ----------

tregpaf_schema ={
'GRP_AFFIL_TY_CD':'STRING',
'GRP_AFFIL_GEN_KEY':'INTEGER',
'GRP_DEST_CNTR_ID':'STRING',
'GRP_DST_GRPR_TY_CD':'STRING',
'GRP_GK_SEL_SRC_CD ':'STRING',
'GRP_RPT_PKG_TBL_ID':'STRING',
'REC_UPDT_DATE':'DATE',
'REC_UPDT_ID':'STRING',
'REC_UPDT_FAC_ID  ':'STRING',
'GRP_GEO_MARKET_IND':'STRING',
'IND1':'STRING',
'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

tregpaf_df=dtype_conversion(tregpaf,tregpaf_schema)

# COMMAND ----------

# write TREGPAF to ADLS stage table
write_df_as_delta_table(tregpaf_df,tregpaf_dbp_tbl_name)
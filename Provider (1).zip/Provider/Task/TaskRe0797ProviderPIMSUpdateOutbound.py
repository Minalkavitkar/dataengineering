# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Job RE0797 - This process will update the Provider Service address information from PIMS feed to Service Fund Provider address table and generate the Provider address file to CAS.
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - Provider.ProviderVendor
# MAGIC - IN_PIMS_PCP_ADDR.TXT
# MAGIC
# MAGIC ###### Intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - Provider.Re0797ProviderPIMSUpdate
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenCasPcpAddressFile.txt 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import *
from datetime import date
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run Transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Job name Assignment
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
try:  
    job_name = JOB_NAME.replace("Outbound", "")
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    default_in_config = default_config["Inbound"]
    Re0797_config = config_dict[job_name]

    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config['FilePathPrefix']
    file_path_prefix_in = default_in_config["FilePathSuffix"]
    config = default_out_config["Config"]

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = Re0797_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = Re0797_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = Re0797_config["Outbound"]["TableName"]
    outbnd_file_name = Re0797_config["Outbound"]["FileName"]
    cur_tbl_name = Re0797_config['Outbound']['TableName']
    stg_prv_vnd_tbl_name = Re0797_config["Inbound"]["StageProviderVendor"]
    stg_prv_tbl_name = Re0797_config["Inbound"]["StageProvider"]
    sync_process_names = Re0797_config["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
    pcp_addr = Re0797_config["Inbound"]["PcpAddrFilePath"]
    stg_tbl_name = Re0797_config['Inbound']['StageTableName']
    sync_table_names = Re0797_config['Outbound']['SyncTableNames']
    
except Exception as e:
    excep = "Variable assignment from FileConfig: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,ProviderServiceAddress table sync process.
try:
   dbutils.notebook.run('../Orchestrate/StageTableSyncExecute',0, {'TABLE_NAMES' : sync_table_names})
except Exception as e:
    excep = 'Sync Process Failed: '+ str(e)
    dbutils.notebook.exit(excep)


# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Curated and temp.
try:  
    temp_csv_path = abfss_path_builder(container_name, storage_account, prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read provider service address data from stage and curated
try:
    # Read from stage table and drop the unwanted columns.
    prov_srv_addr_stg_df = read_table_to_df(stg_tbl_name)\
                .drop("ProviderServiceAddressKey"
                      ,"CreatedDateTime"
                      ,"CreatedBy"
                      ,"ModifiedDateTime"
                      ,"ModifiedBy")

    # Read only the records with Indicator as Insert, Update and Ignore.            
    prov_srv_addr_cur_df = read_table_to_df(cur_tbl_name)\
                .filter(col("DerivedIndicator").isin(["INSERT", "UPDATE", "IGNORE"]))\
                .select('ProviderKey'
                        ,'ProviderId'
                        ,'SuffixCode'
                        ,'ProvVendorNbr'
                        ,'ProvCenterNbr'
                        ,'ProvCenterSuffix'
                        ,'ProvPrimaryInd'
                        ,'Comment12B'
                        ,'Comment34B'
                        ,'Comment13B'
                        ,'Comment45B')
except Exception as e:
    excep = 'Read provider service address data from stage and curated failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Join with curated table to get the missing columns. 
    joined_df = prov_srv_addr_stg_df.join(prov_srv_addr_cur_df
                                      ,['ProviderKey']
                                      ,'inner').drop('ProviderKey')
    
    # Created AddressLineText and filler column.
    calc_df = joined_df.selectExpr("*","' ' as Filler")

except Exception as e:
    excep = 'adding columns to final dataframe: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Passing spaces to 4 integer columns as per the requirement
try:
    col_maps = {
        "12BLatitudeNumber": (when(col("Comment12B").isNotNull(), lit('  ')).otherwise(col("12BLatitudeNumber"))),
        "34BLatitudeNumber": (when(col("Comment34B").isNotNull(), lit('  ')).otherwise(col("34BLatitudeNumber"))),
        "13BLongitudeNumber": (when(col("Comment13B").isNotNull(), lit('   ')).otherwise(col("13BLongitudeNumber"))),
        "45BLongitudeNumber": (when(col("Comment45B").isNotNull(), lit('  ')).otherwise(col("45BLongitudeNumber")))
    }
    calc_df_final = calc_df.withColumns(col_maps).drop('Comment12B','Comment34B','Comment13B','Comment45B')
except Exception as e:
    excep = 'Passing spaces to 4 integer columns failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Convert dataframe as Fixedwidth and write to ADLS
try:
    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, calc_df_final)
    
    # write dataframe as single csv file.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
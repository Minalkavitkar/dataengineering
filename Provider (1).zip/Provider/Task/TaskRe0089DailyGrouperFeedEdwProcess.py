# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0089 - Extract the grouper details from provider grouper table and get superior grouper details and send the details to EDW  
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - Provider.ProviderGrouper
# MAGIC - Provider.ProviderGrouperSuperior
# MAGIC - Provider.GrouperCorrespondenceAddress
# MAGIC - Provider.ProviderGrouperVariable
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - Provider.ProdrenGrouperDailyFeedEdw
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenGrouperDailyFeedEdw.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import required libraries
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
import json

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0089_config = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = re0089_config["Outbound"]["TempFilePathSuffix"]   
    curated_path_suffix = re0089_config['Outbound']['CuratedFilePathSuffix']
    tbl_name = re0089_config['Outbound']['TableName']
    outbnd_file_name = re0089_config["Outbound"]["FileName"]

    stg_prv_grp_tbl_name = re0089_config["Inbound"]["StageProviderGrouper"]
    stg_prv_grp_sup_tbl_name = re0089_config["Inbound"]["StageProviderGrouperSuperior"]
    stg_grp_corr_add_tbl_name = re0089_config["Inbound"]["StageGrouperCorrespondenceAddress"]
    stg_prv_grp_var_tbl_name = re0089_config["Inbound"]["StageProviderGrouperVariable"]
    sync_process_names = re0089_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account,
        file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Reading Required SQL Tables
try: 
    # Read the data from ProviderGrouper Stage table(Adls).
    df_prvdr_grpr= read_table_to_df(stg_prv_grp_tbl_name)
    # Read the data from ProviderGrouperSuperior Stage table(Adls).
    df_prvdr_grpr_supr = read_table_to_df(stg_prv_grp_sup_tbl_name)
    # Read the data from GrouperCorrespondenceAddress Stage table(Adls).
    df_grpr_corr_add = read_table_to_df(stg_grp_corr_add_tbl_name)
    # Read the data from ProviderGrouperVariable Stage table(Adls).
    df_grpr_corr = read_table_to_df(stg_prv_grp_var_tbl_name).filter(col("VariableId").isin(["T", "C", "S", "P", "R"]))
except Exception as e:
    excep = "Read Sql Tables: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting Required Columns from Provider Grouper
# Select only required columns from ProviderGrouper
try:
    df_prvdr_grpr1 = df_prvdr_grpr.select(
        "ProviderGrouperKey",
        "ProviderGrouperId",
        "TypeCode",
        "LastName",
        "FirstName",
        "MiddleInitial",
        "CompanyName",
        "AddressLine1Text",
        "AddressLine2Text",
        "CityName",
        "StateCode",
        "ZipCode",
        "ZipPlusCode",
        "ReelCode",
        "LedgerNumber"
    )
except Exception as e:
    excep = "column selection: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Joining all the required tables:
# 1.Joining ProviderGrouper to ProviderGrouperSuperior
# 2.Joinig output of step1 with GrouperCorrespondenceAddresstable and then joining with GrouperVariable
try:
    cond1 = col("T1.ProviderGrouperId") == col("T2.ProviderGrouperId")
    cond2 = col("T1.ProviderGrouperKey") == col("T3.ProviderGrouperKey")
    cond3 = (((col("T1.ProviderGrouperId")) == (col("T4.ProviderGrouperId")))
                & (trim(col("T1.TypeCode")) == trim(col("T4.TypeCode"))))
    
    df_grpr_grprsupr = df_prvdr_grpr1.alias("T1").join(df_prvdr_grpr_supr.alias("T2"), cond1, "left")
                
    df_grpr_grprsupr_add = df_grpr_grprsupr.join(df_grpr_corr_add.alias("T3"), cond2, "left")
                
    df_join = df_grpr_grprsupr_add.join(df_grpr_corr.alias("T4"), cond3, "left")\
                                  .drop(col("T1.ProviderGrouperKey"))\
                                  .orderBy(col("T1.ProviderGrouperId").asc())
except Exception as e:
    excep = ("Join ProviderGrouper, ProviderGrouperSuperior and GrouperCorrespondenceAddresstable: "+ str(e))
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting all the output Columns 
#Select all the required output columns from the joined tables (ProviderGruper,ProviderGrouperSuperior,GrouperCorrespondenceAddress,ProviderGrouperVariable)
try:
    df_select = df_join.select(
        'T1.*',
        'T2.SuperiorId',
        'T3.CorrespondenceName',
        'T3.CorrespondenceAddressLine1Text',
        'T3.CorrespondenceAddressLine2Text',
        'T3.CorrespondenceCityName',
        'T3.CorrespondenceStateCode',
        'T3.CorrespondenceZipCode',
        'T3.CorrespondenceZipPlusCode',
        'T3.ContractLegalId',
        'T3.ContractLegalName',
        'T4.VariableId',
        'T4.VariableCode'
    )
except Exception as e:
    excep = "column selection: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving VariableCode to specified columns based on VariableId
#Move VariableCodes to respective calculated columns on the basis of VariableId in ('T','C','S','P','R')
try:
    df_calc = df_select.selectExpr("*","CASE WHEN trim(VariableId) ='T' THEN VariableCode END AS PathToRiskTrigger",
                          "CASE WHEN trim(VariableId) ='C' THEN VariableCode END AS ContractIdentifier",
                          "CASE WHEN trim(VariableId) ='S' THEN VariableCode END AS GrouperStuctureCd",
                          "CASE WHEN trim(VariableId) ='P' THEN VariableCode END AS ProvidreOrgCd",
                          "CASE WHEN trim(VariableId) ='R' THEN VariableCode END AS HumProvRelCd")\
                        .drop('VariableId','VariableCode').distinct()
except Exception as e:
    excep = "Creating calculated columns " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))                  

# COMMAND ----------

# DBTITLE 1,Grouping on non calculated columns to update multiple values in same row 
#Grouping on non calculated columns and taking max of calculated columns to get update multiple values in single row 
try:
    calc_cols = ('PathToRiskTrigger','ContractIdentifier','GrouperStuctureCd', 'ProvidreOrgCd', 'HumProvRelCd')
    grpd_Cols_lst = [colm for colm in df_calc.columns if colm not in calc_cols]
    agg_col_lst = [max(colm).alias(colm) for colm in calc_cols]
    df_final = df_calc.groupBy(*grpd_Cols_lst).agg(*agg_col_lst)
except Exception as e:
    excep = "Grouping on non calculated columns " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output)) 

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, tbl_name)
    # Read data from stage area.
    re0089_df = spark.read.table(tbl_name)
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0089_df)
    # write dataframe as .txt file as position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving and renaming the .csv file to outbound folder.
try:
    #Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
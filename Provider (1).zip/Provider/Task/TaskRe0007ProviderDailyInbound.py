# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - The main purpose of this job is to build the inbound interface to read Provider information from CAS application, build the process to format and upload to Provider Operational Database.
# MAGIC ###### Source Details (inbound files):
# MAGIC
# MAGIC
# MAGIC - PRODMCV_PROVIDER_DOCTOR.TXT
# MAGIC - PRODMCV_PROVIDER_HOSPITAL.TXT
# MAGIC
# MAGIC ###### Curated Details (Unmanaged Delta Tables):
# MAGIC - Provider.Re0007ProviderDaily
# MAGIC
# MAGIC ###### Target Details (Azure SQL):
# MAGIC - Provider.StageProvider

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import require libraries.
import json
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Parameter Assignment.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0007ProviderDailyInbound')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME.replace("Inbound", "")
    config_dict = get_file_config(file_conf_path)
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    default_in_config = default_config["Inbound"]
    re0007_config = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    file_path_suffix = default_in_config['FilePathSuffix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"] 
    curated_path_suffix = re0007_config['Outbound']['CuratedFilePathSuffix']
    cur_tbl_name = re0007_config['Outbound']['CuratedTableName']
    stg_tbl_name = re0007_config['Inbound']['StageTableName']
    prv_stg_sql_tbl = re0007_config["Outbound"]["StageProviderSqlTblName"]

    inbound_file_path_dr=  re0007_config['Inbound']['DrFileName'] 
    inbound_file_path_hp=  re0007_config['Inbound']['HpFileName']  
    curated_path_suffix = re0007_config['Outbound']['CuratedFilePathSuffix']
    sync_process_names = re0007_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]

except Exception as e:
    raise Exception("Variable assignment from FileConfig", str(e))
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation.
try:
    dr_path = abfss_path_builder(container_name,storage_account,file_path_suffix,inbound_file_path_dr)
    hp_path = abfss_path_builder(container_name,storage_account,file_path_suffix,inbound_file_path_hp)
    
except Exception as e:
    excep = "Path creation: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Required Column Details
dr_cols = [
    "DRF_CLIENT",
    "DRF_PVD_IND",
    "DRF_PROV",
    "DRF_MULT_ADDRESS_KEY",
    "DRF_PROV_NAME",
    "DRF_ADDR_1",
    "DRF_ADDR_2",
    "DRF_ADDR_3",
    "DRF_ADDR_4",
    "DRF_CITY",
    "DRF_ST",
    "DRF_ZIP",
    "DRF_IRS_NO",
    "DRF_PVD_ST",
    "DRF_PROV_GROUP_NO",
    "DRF_PROV_TYPE",
    "DRF_GROUP_FLAG",
    "DRF_LIC_NO",
    "DRF_CROSS_REF",
    "DRF_SPEC_CD",
    "DRF_COUNTY_CD",
    "DRF_MULT_ADDRESS_IND",
    "DRF_PHONE",
    "DRF_VCH",
    "DRF_PRIOR_INFO",
    "DRF_PROV_PROF_AREA",
]


hp_cols = [
    "HF_CLIENT",
    "HF_PVD_IND",
    "HF_PROV",
    "HF_MULT_ADDRESS_KEY",
    "HF_NM",
    "HF_ADDR1",
    "HF_ADDR2",
    "HF_ADDR3",
    "HF_ADDR4",
    "HF_CITY",
    "HF_ST",
    "HF_ZIP",
    "HF_IRS_NO",
    "HF_PVD_ST",
    "HF_TYPE",
    "HF_GROUP_FLAG",
    "HF_MHEBT_GROUP_NO",
    "HF_LIC",
    "HF_CROSS_REF",
    "HF_SPEC_CD",
    "HF_COUNTY_CD",
    "HF_MULT_ADDRESS_IND",
    "HF_PHONE",
    "HF_VCH",
    "HF_ROOM_RATES",
    "HF_PAY_NOPAY_IND",
]

# COMMAND ----------

# DBTITLE 1,Read doctor, hospital inbound files from adls.
try:
    # Read doctor file from adls and select only the required column.
    doctor_df= read_inbound_csv_file(dr_path)\
            .select(*dr_cols)
    # Read hospital file from adls and select only the required column.
    hospital_df= read_inbound_csv_file(hp_path)\
            .select(*hp_cols)
except Exception as e:
    excep = 'Read doctor, hospital inbound files from adls: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Datatype mapping.
dr_schema = {
    "DRF_CLIENT": "INTEGER",
    "DRF_PVD_IND": "STRING",
    "DRF_PROV": "INTEGER",
    "DRF_MULT_ADDRESS_KEY": "STRING",
    "DRF_PROV_NAME": "STRING",
    "DRF_ADDR_1": "STRING",
    "DRF_ADDR_2": "STRING",
    "DRF_ADDR_3": "STRING",
    "DRF_ADDR_4": "STRING",
    "DRF_CITY": "STRING",
    "DRF_ST": "STRING",
    "DRF_ZIP": "STRING",
    "DRF_IRS_NO": "INTEGER",
    "DRF_PVD_ST": "INTEGER",
    "DRF_PROV_GROUP_NO": "STRING",
    "DRF_PROV_TYPE": "STRING",
    "DRF_GROUP_FLAG": "STRING",
    "DRF_LIC_NO": "INTEGER",
    "DRF_CROSS_REF": "INTEGER",
    "DRF_SPEC_CD": "STRING",
    "DRF_COUNTY_CD": "INTEGER",
    "DRF_MULT_ADDRESS_IND": "STRING",
    "DRF_PHONE": "STRING",
    "DRF_VCH": "STRING",
    "DRF_PRIOR_INFO": "STRING",
    "DRF_PROV_PROF_AREA": "STRING",
}

hp_schema = {
    "HF_CLIENT": "INTEGER",
    "HF_PVD_IND": "STRING",
    "HF_PROV": "INTEGER",
    "HF_MULT_ADDRESS_KEY": "STRING",
    "HF_NM": "STRING",
    "HF_ADDR1": "STRING",
    "HF_ADDR2": "STRING",
    "HF_ADDR3": "STRING",
    "HF_ADDR4": "STRING",
    "HF_CITY": "STRING",
    "HF_ST": "STRING",
    "HF_ZIP": "STRING",
    "HF_IRS_NO": "INTEGER",
    "HF_PVD_ST": "STRING",
    "HF_TYPE": "STRING",
    "HF_GROUP_FLAG": "STRING",
    "HF_MHEBT_GROUP_NO": "STRING",
    "HF_LIC": "INTEGER",
    "HF_CROSS_REF": "INTEGER",
    "HF_SPEC_CD": "STRING",
    "HF_COUNTY_CD": "INTEGER",
    "HF_MULT_ADDRESS_IND": "STRING",
    "HF_PHONE": "STRING",
    "HF_VCH": "STRING",
    "HF_ROOM_RATES": "STRING",
    "HF_PAY_NOPAY_IND": "STRING",
}

# COMMAND ----------

# DBTITLE 1,Remove leading, trailing spaces and data type conversion
try:
  # Remove leading anf trailing spaces for hosptial and doctor df.
  trmd_doctor_df = trim_leading_trailing_space(doctor_df)
  trmd_hospital_df= trim_leading_trailing_space(hospital_df)

  # Datatype conversion for both Doctor and Hospital df.
  dtype_trans_doc_df = dtype_conversion(trmd_doctor_df, dr_schema)
  dtype_trans_hp_df = dtype_conversion(trmd_hospital_df, hp_schema)
except Exception as e:
    excep = 'Remove leading, trailing spaces and data type conversion failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))        

# COMMAND ----------

# DBTITLE 1,Filtering inbound files.
try:
    # Select only the records when client = 58 and PvdInd = D
    doc_filtered_df = dtype_trans_doc_df.filter(
        (col("DrfClient") == 58) & (col("DrfPvdInd") == "D"))

    # Select only the records when client = 58 and PvdInd = H
    hp_filtered_df = dtype_trans_hp_df.filter(
        (col("HfClient") == 58) & (col("HfPvdInd") == "H"))
except Exception as e:

    excep = 'Filtering inbound files failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column name mapping.
doc_col_mapping = {
    "DrfProv": "ProviderId",
    "DrfPvdInd": "Type2Code",
    "DrfMultAddressKey": "SuffixCode",
    "DrfProvName": "ProviderName",
    "DrfAddr1": "AddressLine1Text",
    "DrfAddr2": "AddressLine2Text",
    "DrfAddr3": "AddressLine3Text",
    "DrfAddr4": "AddressLine4Text",
    "DrfCity": "CityName",
    "DrfSt": "StateCode",
    "DrfZip": "ZipCode",
    "DrfPvdSt": "StatusCode",
    "DrfProvGroupNo": "GroupName",
    "DrfProvType": "TypeCode",
    "DrfGroupFlag": "GroupIndicator",
    "DrfLicNo": "LicenseNumber",
    "DrfIrsNo": "IRSNumber",
    "DrfCrossRef": "CrossReferenceNumber",
    "DrfMultAddressInd": "MultiAddressIndicator",
    "DrfPhone": "TelephoneNumber",
    "DrfProvProfArea": "ProviderProfAreaCode",
    "DrfPriorInfo": "PayInfoCode",
    "DrfSpecCd": "SpecialtyCode",
    "DrfCountyCd": "CountyCode",
    "DrfVch": "Vch",
}

HP_col_mapping = {
    "HfProv": "ProviderId",
    "HfPvdInd": "Type2Code",
    "HFMultAddressKey": "SuffixCode",
    "HfNm": "ProviderName",
    "HfAddr1": "AddressLine1Text",
    "HfAddr2": "AddressLine2Text",
    "HfAddr3": "AddressLine3Text",
    "HfAddr4": "AddressLine4Text",
    "HfCity": "CityName",
    "HfSt": "StateCode",
    "HfZip": "ZipCode",
    "HfPvdSt": "StatusCode",
    "HfMhebtGroupNo": "GroupName",
    "HfType": "TypeCode",
    "HfGroupFlag": "GroupIndicator",
    "HfLic": "LicenseNumber",
    "HfIrsNo": "IRSNumber",
    "HfCrossRef": "CrossReferenceNumber",
    "HfMultAddressInd": "MultiAddressIndicator",
    "HfPhone": "TelephoneNumber",
    "HfRoomRates": "ProviderProfAreaCode",
    "HfPayNopayInd": "PayInfoCode",
    "HfSpecCd": "SpecialtyCode",
    "HfCountyCd": "CountyCode",
    "HfVch": "Vch",
}

# COMMAND ----------

# DBTITLE 1,Map doctor & hospital columns as per SQL
try:
    final_doctor_df = col_name_mapping(doc_filtered_df, doc_col_mapping)
    final_hospital_df = col_name_mapping(hp_filtered_df, HP_col_mapping)
        
except Exception as e:
    excep = 'Map doctor & hospital columns as per SQL failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Split doctor dataframe based on status code.
try:
    # filter records in doctor file where StatusCode is equal to 2
    doc_st_cd2_df = final_doctor_df.filter(col("StatusCode")=='2')

    # filter records in doctor file where StatusCode is not equal to 2
    doc_not_st_cd2_df = final_doctor_df.filter(col("StatusCode")!='2')

    not_cd2_union_df = doc_not_st_cd2_df.unionByName(final_hospital_df)
    
except Exception as e:
    excep = 'Split doctor dataframe based on status code failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,.
try:
  condition = ((col('LH.ProviderId') == col('RH.ProviderId')) 
             & ((col('LH.SuffixCode') == col('RH.SuffixCode'))))

  removed_doct_rec_df = doc_st_cd2_df.alias('LH')\
            .join(not_cd2_union_df.filter(col('Type2Code') == 'H').alias('RH'), condition, "leftAnti")
except Exception as e:
    excep = 'Seperate dataframe based on PVD-ST column failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate ProviderId and SuffixCode column.
try:
    col_maps = {
        "ProviderId" : lpad('ProviderId', 9, '0'),
        "SuffixCode" : (when(trim(col('SuffixCode')) == "", lit("  "))
                        .otherwise(col("SuffixCode")))
    }
    final_union_df = removed_doct_rec_df.unionByName(not_cd2_union_df)\
                .withColumns(col_maps)\
                .drop('StatusCode')
except Exception as e:
    excep = 'Calculate ProviderId and SuffixCode column failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column calculation.
try:
    # adding ProviderStartDate, ProviderEndDate and SourceSystemCode with default values.
    curr_prov_df =final_union_df.selectExpr(
                                "*", 
                                "TO_DATE('1990-01-01', 'yyyy-MM-dd') as ProviderStartDate", 
                                "TO_DATE('9999-12-31', 'yyyy-MM-dd') as ProviderEndDate", 
                                "'CAS' as SourceSystemCode",
                                "md5(concat(ProviderId, SuffixCode, Type2Code)) as HashKey",
                                "current_timestamp() as CreatedDateTime",
                                f"'{PIPELINE_NAME}' as CreatedBy",
                                "cast(null as timestamp)as ModifiedDateTime",
                                "cast(null as string) as ModifiedBy"
                                )
    
except Exception as e:
    excep = 'Column calculation failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Function to getting column select list.
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Identify Delta records(INSERT, UPDATE, DELETE, and IGNORE).
try:
        # Read data from Stage Provider table and calculate HashKey
        # Add Vch and DerivedIndicator to match current dataframe schema.
        old_prov_stg_df = read_table_to_df(stg_tbl_name)\
                .selectExpr("*",
                            "md5(concat(ProviderId, SuffixCode, Type2Code)) as HashKey",
                            "null as Vch",
                            "null as DerivedIndicator")\
                .drop('ProviderKey')

        # Create Column list. Which is used for processing.
        new_col_slt_lst = old_prov_stg_df.columns
        col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)


        # Add suffix 'Old' to column name for existing data to avoid column ambiguous.
        old_renamed_df = old_prov_stg_df.selectExpr(*col_select_lst)

        # Join previous day with current day data to identify delta data.
        old_joined_df = curr_prov_df.alias('LH')\
                .join(old_renamed_df.alias('RH'),(col("LH.HashKey") == col("RH.OldHashKey")), "full")

        # Get only the records which are needs to insert and create DerivedIndicator column.
        ins_df = old_joined_df\
                .filter((col('OldHashKey').isNull()))\
                .withColumn('DerivedIndicator', lit('INSERT'))\
                .drop(*col_drop_lst)

        # Get only the records which are needs to delete and create DerivedIndicator column.
        dels_df = old_joined_df\
                .filter((col('HashKey').isNull()))\
                .withColumn('OldDerivedIndicator', lit('DELETE'))\
                .selectExpr(*del_col_sel_lst)

        # Get only the records which are needs to updates and create DerivedIndicator column.
        upds_df = old_joined_df\
                .filter((col('HashKey').isNotNull()) & (col('OldHashKey').isNotNull()))\
                .withColumn('DerivedIndicator', when((col("TypeCode").eqNullSafe(col("OldTypeCode"))) &
                (col("ProviderName").eqNullSafe(col("OldProviderName"))) &
                (col("LicenseNumber").eqNullSafe(col("LicenseNumber"))) &
                (col("IRSNumber").eqNullSafe(col("OldIRSNumber"))) &
                (col("GroupName").eqNullSafe(col("OldGroupName"))) &
                (col("GroupIndicator").eqNullSafe(col("OldGroupIndicator"))) &
                (col("SpecialtyCode").eqNullSafe(col("OldSpecialtyCode"))) &
                (col("MultiAddressIndicator").eqNullSafe(col("OldMultiAddressIndicator"))) &
                (col("AddressLine1Text").eqNullSafe(col("OldAddressLine1Text"))) &
                (col("AddressLine2Text").eqNullSafe(col("OldAddressLine2Text"))) &
                (col("AddressLine3Text").eqNullSafe(col("OldAddressLine3Text"))) &
                (col("AddressLine4Text").eqNullSafe(col("OldAddressLine4Text"))) &
                (col("CityName").eqNullSafe(col("OldCityName"))) &
                (col("StateCode").eqNullSafe(col("OldStateCode"))) &
                (col("ZipCode").eqNullSafe(col("OldZipCode"))) &
                (col("TelephoneNumber").eqNullSafe(col("OldTelephoneNumber"))) &
                (col("ProviderStartDate").eqNullSafe(col("OldProviderStartDate"))) &
                (col("ProviderEndDate").eqNullSafe(col("OldProviderEndDate"))) &
                (col("CrossReferenceNumber").eqNullSafe(col("OldCrossReferenceNumber"))) &
                (col("CountyCode").eqNullSafe(col("OldCountyCode"))) &
                (col("SourceSystemCode").eqNullSafe(col("OldSourceSystemCode")))
                ,lit('IGNORE')).otherwise(lit('UPDATE')))

        #Calculate ModifiedBy and ModifiedDateTime.
                # If it is update set the modifiedDateTime as current timestamp and modifiedBy as task name.
        col_maps = {
                        'ModifiedDateTime' : (when(col('DerivedIndicator') == 'UPDATE', lit(current_timestamp()))
                                                        .otherwise(col('OldModifiedDateTime'))),
                        'ModifiedBy' : (when(col('DerivedIndicator') == 'UPDATE', lit(PIPELINE_NAME))\
                                                .otherwise(col('OldModifiedBy'))),
                        'CreatedBy' : col('OldCreatedBy'),
                        'CreatedDateTime' : col('OldCreatedDateTime')
                }
        calc_audit_col_upds_df = upds_df.withColumns(col_maps)\
                        .select(*new_col_slt_lst)

        # Union Insert, Delete and Update dataframe.
        calc_df = ins_df.unionByName(dels_df)\
                .unionByName(calc_audit_col_upds_df)

        # Replace previous run data with current run data in curated table.
        write_df_as_delta_table(calc_df, cur_tbl_name)

except Exception as e:
    excep = "Identify Delta record failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to Azure SQL stage table.
try:
    # Delete is not handle. Once we get the confirmation. We need to add 'DELETE to isin function'
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    re0007_df = spark.read.table(cur_tbl_name)\
                .filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE', 'DELETE']))\
                .selectExpr(
                    '*', 
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as ProviderKey', 
                    'cast(null as string) as ProcessName')\
                .drop('Vch', 'HashKey')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    upd_col_nullable_df = set_df_columns_not_nullable(spark, re0007_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(upd_col_nullable_df, 'Provider.StageProvider')
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Exit from the Notebook
output = {
      'NOTEBOOK_RUN_STATUS' : 'Success'
}
dbutils.notebook.exit(json.dumps(output))
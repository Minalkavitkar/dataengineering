# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job RE0863-Create an interface to extract data from BBS Reporting and Product Geo Market affiliation SF tables and create a Grouper Delegate stage area table on cloud.
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - Product.StageTREXAFL
# MAGIC - BBSReporting.StageTREGPAF
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Provider.Re0863DailySuperGrouper
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC
# MAGIC - ProdrevGrprClmDelegate.csv (CSV File) 
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Import necessary library.
import json

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
     default_config = config_dict["DEFAULT"]
     default_out_config = default_config["Outbound"]
     re0863_config = config_dict[JOB_NAME]
     container_name = default_config["ContainerName"]
     file_path_prefix = default_out_config["FilePathPrefix"]
     config = default_out_config["Config"]
     prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
     curated_path_suffix = re0863_config["Outbound"]["CuratedFilePathSuffix"]
     temp_path_suffix = re0863_config["Outbound"]["TempFilePathSuffix"]
     tbl_name = re0863_config["Outbound"]["TableName"]
     outbnd_file_name = re0863_config["Outbound"]["FileName"]
     trexafl_tbl_name = re0863_config["Inbound"]["StageTREXAFLTableName"]
     tregpaf_tbl_name = re0863_config["Inbound"]["StageTREGPAFTableName"]
     trexafl_adls_path_suffix = re0863_config["Inbound"]["StageTREXAFLTablePath"]
     tregpaf_adls_path_suffix = re0863_config["Inbound"]["StageTREGPAFTablePath"]
     
     trexafl_dbp_tbl_name = re0863_config["Inbound"]["DBPStageTREXAFL"]
     tregpaf_dbp_tbl_name = re0863_config["Inbound"]["DBPStageTREGPAF"]
    
except Exception as e:
    excep = "Variable assignment from FileConfig: ", str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account, prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
    trexafl_adls_path = abfss_path_builder(container_name, storage_account, trexafl_adls_path_suffix)
    tregpaf_adls_path = abfss_path_builder(container_name, storage_account, tregpaf_adls_path_suffix)
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from StageTREGPAF table.
tregpaf_req_cols = [
    "GrpDestCntrId",
    "GrpDstGrprTyCd",
    "GrpAffilGenKey",
    "GrpAffilTyCd"   
]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from StageTREXAFL table.
trexafl_req_cols = [
    "AffilGenKeyOwn",
    "AffilGenKeyMbr",
    "AffilTyCdOwn",
    "AffilTyCdMbr" 
]

# COMMAND ----------

# DBTITLE 1,Read data from ADLS.
try:
    # Read TREXAFL from ADLS stage table
    tregpaf_df = read_table_to_df( tregpaf_dbp_tbl_name).select(*tregpaf_req_cols)
    
    # Read TREGPAF from ADLS stage table
    trexafl_df = read_table_to_df(trexafl_dbp_tbl_name).select(*trexafl_req_cols)
    
except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write the data into ADLS
#the data has been already loaded into batchprocessing folder and below code will overwrite the data everytime. To avoid overwriting have commented below code.

# write TREGPAF to ADLS stage table
#write_df_as_delta_table(tregpaf_df,tregpaf_dbp_tbl_name,tregpaf_adls_path)

# write TREXAFL to ADLS stage table
#write_df_as_delta_table(trexafl_df,trexafl_dbp_tbl_name,trexafl_adls_path)

# COMMAND ----------

# DBTITLE 1,Join TREGPAF and TREXAFL to fetch the data
# extract the Grouper data from the REGPAF and REXAFL table and create the Delegate Grouper file
try:
    #Step 1: join tregpaf and trexafl on AffilGenKeyOwn matches GrpAffilGenKey

    #Step 2: join the result with tregpaf again on AffilGenKeyMbr matches GrpAffilGenKey

    #step 3: filter "DST" records, typecode 'S' records

    #step 4: select required columns as per resuperg file output layout
    
    resuperg_df = (
        tregpaf_df.alias("A")
        .join(
            trexafl_df.alias("B"), (col("A.GrpAffilGenKey") == col("B.AffilGenKeyOwn"))
        )
        .join(tregpaf_df.alias("C"), col("B.AffilGenKeyMbr") == col("C.GrpAffilGenKey"))
        .filter(
            (col("A.GrpAffilTyCd") == "DST")
            & (col("A.GrpDstGrprTyCd") == "S")
            & (col("B.AffilTyCdOwn") == "DST")
            & (col("B.AffilTyCdMbr") == "DST")
        )
        .select(
            col("A.GrpDestCntrId").alias("GrpDestCntrId"),
            col("C.GrpDestCntrId").alias("GrpDestCntrId1"),
            col("A.GrpDstGrprTyCd"),
            col("B.AffilGenKeyOwn"),
            col("C.GrpDstGrprTyCd").alias("GrpDstGrprTyCd1"),
            col("B.AffilGenKeyMbr").alias("AffilGenKeyMbr"),
        )
    )
except Exception as e:
    excep = "Join tregpaf with trexafl_df failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(resuperg_df, tbl_name)

    # Read data from stage layer.
    re0863_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0863_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the csv file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
    
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
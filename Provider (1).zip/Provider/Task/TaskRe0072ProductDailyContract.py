# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job Re0072Product-This process creates an interface to generate a Product Extract outbound files for MC and EDW application 
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Product.Product
# MAGIC - Product.ProductAffiliation
# MAGIC - Product.ProductSetAffiliation
# MAGIC - Product.ProductSetAssociation
# MAGIC - Provider.ProdrenRe0072ProvLOB
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC
# MAGIC - ProdrenRe0072Product.txt
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Notebook which is used to establish connection to the storage account
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

import json

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict["DEFAULT"]
  default_out_config = default_config["Outbound"]
  re0072Prdt_config = config_dict[job_name]

  container_name = default_config["ContainerName"]
  file_path_prefix = default_out_config["FilePathPrefix"]
  config = default_out_config["Config"]
  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  
  temp_path_suffix = re0072Prdt_config["Outbound"]["TempFilePathSuffix"]
  tbl_name = re0072Prdt_config["Outbound"]["TableName"]
  outbnd_file_name = re0072Prdt_config["Outbound"]["FileName"]
  
  #input table name
  prd_tbl_name = re0072Prdt_config["Inbound"]["StageProduct"]
  prd_set_assc_tbl_name = re0072Prdt_config["Inbound"]["StageProductSetAssociation"]
  prd_set_aff_tbl_name = re0072Prdt_config["Inbound"]["StageProductSetAffiliation"]
  prd_aff_tbl_name = re0072Prdt_config["Inbound"]["StageProductAffiliation"]
  prv_lob_tbl_name = re0072Prdt_config["Inbound"]["Re0072ProvLOBTableName"]
  sync_process_names = re0072Prdt_config["Inbound"]["StageSyncDependencyProcess"]
  audit_table_name = default_config["AuditTableName"]

except Exception as e:
  excep = "Variable assignment from FileConfig: ", str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
#Add required columns to the list from Product table.
prd_req_cols = [
    "ProductKey"
    ,'MarketNumber'
    ,'PlanNumber'
    ,'OptNumber'
]

# Add required columns to the list from ProductSetAssociation table.
prd_set_assc_req_cols = [
    'ProductKey'
    ,'ProductSetKey'
]

# Add required columns to the list from ProductSetAffiliation table.
prd_set_aff_req_cols = [
    'ProductSetKey'
    ,'ProductAffiliationKey'
]

# Add required columns to the list from ProductAffiliation table.
prd_aff_req_cols = [
    'ProductAffiliationKey'
    ,'LineOfBusinessCode'
    ,'LocationId'
]

# Add required columns to the list from Prodrenre0072ProvLOB table.
prv_lob_req_cols = [
    'ProductLineOfBusinessCode'
    ,'LocationId'
]

# COMMAND ----------

# DBTITLE 1,Read the data from Stage ADLS
try:
  # Read Product ADLS UC table and select required columns
  prd_df = read_table_to_df(prd_tbl_name).select(*prd_req_cols)

  # Read ProductSetAssociation ADLS UC table and select required columns
  prd_set_assc_df = read_table_to_df(prd_set_assc_tbl_name).select(*prd_set_assc_req_cols)

  # Read ProductSetAffiliation ADLS UC table and select required columns
  prd_set_aff_df = read_table_to_df(prd_set_aff_tbl_name).select(*prd_set_aff_req_cols)

  # Read ProductAffiliation ADLS UC table and select required columns
  prd_aff_df = read_table_to_df(prd_aff_tbl_name).select(*prd_aff_req_cols)

  # Read Prodrenre0072ProvLOB ADLS UC table and select required columns
  prv_lob_df = read_table_to_df(prv_lob_tbl_name).select(*prv_lob_req_cols).distinct()
            
except Exception as e:
  excep = "Read Sql Tables failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProductAffiliation, ProductSetAffiliation, ProductSetAssociation and Product
try:
  #Step1: Join ProductAffiliation & ProductSetAffiliation on ProductAffiliationKey 
  #Step2: Join step 1 output with ProductSetAssociation on ProductSetKey to get ProductKey
  #Step3: Join step 2 output with Product on ProductKey
  cond1 = col('paf.ProductAffiliationKey')==col('psaf.ProductAffiliationKey')
  cond2 = col('psaf.ProductSetKey')==col('psa.ProductSetKey')
  cond3 = col('psa.ProductKey')==col('p.ProductKey')
  df_joined = prd_aff_df.alias('paf').join(prd_set_aff_df.alias('psaf'),cond1,'inner')\
                                    .join(prd_set_assc_df.alias('psa'),cond2,'inner')\
                                    .join(prd_df.alias('p'),cond3,'inner')\
                                    .drop(col('p.LineOfBusinessCode'),col('psaf.ProductAffiliationKey'))
  
except Exception as e:
    excep = "Join ProductAffiliation, ProductSetAffiliation, ProductSetAssociation and Product failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join with Re0072ProvLOB extract
try:
  #Join with Re0072ProvLOB extract on LineOfBusinessCode & LocationId
  cond4 = (col('LH.LineOfBusinessCode')==col('RH.ProductLineOfBusinessCode')) & (col('LH.LocationId')==col('RH.LocationId'))
 
  df_prd_lob_joined = df_joined.alias('LH').join(prv_lob_df.distinct().alias('RH'),cond4,'inner')\
                               .select('LineOfBusinessCode','LH.LocationId','MarketNumber','PlanNumber','OptNumber') 
  
except Exception as e:
    excep = "Join with Re0072ProvLOB extract failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

df_prd_lob_joined.count() #463682

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_prd_lob_joined, tbl_name)

    #Read data from stage layer.
    re0072_prd_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0072_prd_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move outbound file to outbound folder and rename it.
try:
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path,outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the Notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
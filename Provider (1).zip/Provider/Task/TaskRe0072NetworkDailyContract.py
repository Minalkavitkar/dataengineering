# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job RE0072-This process creates an interface to generate a Provider Network Extract outbound files for MC and EDW application 
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Provider.Provider
# MAGIC - provider.ProviderNetwork
# MAGIC - Provider.ProviderVendor
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC
# MAGIC - ProdrenRe0072Network.txt
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Notebook which is used to establish connection to the storage account
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict["DEFAULT"]
  default_out_config = default_config["Outbound"]
  re0072Ntwrk_config = config_dict[job_name]

  container_name = default_config["ContainerName"]
  file_path_prefix = default_out_config["FilePathPrefix"]
  config = default_out_config["Config"]
  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  
  temp_path_suffix = re0072Ntwrk_config["Outbound"]["TempFilePathSuffix"]
  tbl_name = re0072Ntwrk_config["Outbound"]["TableName"]
  outbnd_file_name = re0072Ntwrk_config["Outbound"]["FileName"]
  
  #input table name
  prv_tbl_name = re0072Ntwrk_config["Inbound"]["StageProvider"]
  prv_vnd_tbl_name = re0072Ntwrk_config["Inbound"]["StageProviderVendor"]
  prv_ntwrk_tbl_name = re0072Ntwrk_config["Inbound"]["StageProviderNetwork"]
  prv_lob_tbl_name = re0072Ntwrk_config["Inbound"]["Re0072ProvLOBTableName"]
  sync_process_names = re0072Ntwrk_config["Inbound"]["StageSyncDependencyProcess"]
  audit_table_name = default_config["AuditTableName"]

except Exception as e:
  excep = "Variable assignment from FileConfig: ", str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
#Add required columns to the list from ProviderContractFund table.
prv_req_cols = [
    "ProviderKey"
    ,"ProviderId"
    ,"SuffixCode"
    ,"ProviderName"
]

# Add required columns to the list from ProviderContractFundedPayment table.
prv_vnd_req_cols = [
    'ProviderKey'
    ,"VendorNumber"
    ,"NetworkTypeCode"
]

# Add required columns to the list from ProviderContractProductAffiliation table.
prv_ntwrk_req_cols = [
    'ProviderKey'
    ,'NetworkId'
    ,'ProviderId'
    ,'ProviderNetworkStartDate'
    ,'ProviderNetworkEndDate'
    ,'PCPIndicator' 
    ,'HumanaClaimPaymentIndicator' 
    ,'ProviderHomeBaseIndicator'
]

# COMMAND ----------

# DBTITLE 1,Read the data from Stage ADLS
try:
  # Read Provider ADLS UC table and select required columns
  prv_df = read_table_to_df(prv_tbl_name).select(*prv_req_cols)
  # Read ProviderVendor ADLS UC table and select required columns
  prv_vnd_df = read_table_to_df(prv_vnd_tbl_name).select(*prv_vnd_req_cols)
  # Read ProviderNetwork ADLS UC table and select required columns
  prv_ntwrk_df = read_table_to_df(prv_ntwrk_tbl_name).select(*prv_ntwrk_req_cols)
  # Read Prodrenre0072ProvLOB ADLS UC table and select required columns
  prv_lob_df = read_table_to_df(prv_lob_tbl_name).select('ProvIdGfld')
            
except Exception as e:
  excep = "Read Sql Tables failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP1:Filter Re0064 output acording to below conditions
try:
  # Join ProviderNetwork & ProviderVendor on ProviderKey and NetworkTypeCode='PCP' and NetowrkStartDate != NetworkEnddate to get VendorNumber:
  cond1 = ((col('LH.ProviderKey')==col('RH.ProviderKey')) & (col('RH.NetworkTypeCode')=='PCP') 
            & (col('ProviderNetworkStartDate')!=col('ProviderNetworkEndDate')))
  df_ntwrk_vnd = prv_ntwrk_df.alias('LH').join(prv_vnd_df.alias('RH'),cond1,'inner').drop(col("RH.ProviderKey"),'NetworkTypeCode')
  
except Exception as e:
    excep = "Join ProviderNetwork and ProviderVendor failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
  # Join with Provider table on ImplKey(ProviderId)= Provider.ProviderId+SuffxCode
  #Join with ProviderVendor to get VendorNumber (ProvvendorNumber)
  cond2 = (col('LH.ProviderId')==concat(trim(col('RH.ProviderId')),trim(col('RH.SuffixCode'))))
  cond3 = (col('RH.ProviderKey')==col('RH1.ProviderKey'))
 
  df_prv_joined = df_ntwrk_vnd.alias('LH').join(prv_df.alias('RH'),cond2,'inner')\
                                        .join(prv_vnd_df.alias('RH1'),cond3,'inner')\
                                        .select('NetworkId','LH.ProviderId','ProviderNetworkStartDate','ProviderNetworkEndDate',col('LH.VendorNumber').alias('NetworkVendorNumber'),col('RH1.VendorNumber').alias('ProvVendorNumber'),'ProviderName')
  
except Exception as e:
    excep = "Join with Provider table failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP2:Calculate Cut-off Date
try:
    # Calculate cut off date to fetch only 3 months data
    current_date_ccyy=current_date()
    cutoff_date=add_months(current_date_ccyy, -3)
except Exception as e:
    excep = 'calculation of cut off date failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP3:Filter only last 3 months data.
# Filter only last 3 months data.
try:
    # select the records if ContractEndDate is greater than cutoff date
    prv_ntwrk_calc_df = df_prv_joined.filter(year(col("ProviderNetworkEndDate")) >= year(cutoff_date))
    prv_ntwrk_cutoff_df = prv_ntwrk_calc_df.filter(col("ProviderNetworkEndDate")>cutoff_date)
except Exception as e:
    excep = 'Filter 3 months records failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join with Re0072ProvLob output
try:
  # Join with Re0072ProvLob output:
  cond4 = trim(col('LH.NetworkId'))==trim(col('RH.ProvIdGfld'))
           
  df_ntwrk_vnd_lob = prv_ntwrk_cutoff_df.alias('LH').join(prv_lob_df.distinct().alias('RH'),cond4,'inner')
  
except Exception as e:
    excep = "Join with Re0072ProvLob output failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_ntwrk_vnd_lob, tbl_name)

    #Read data from stage layer.
    re0072_ntwrk_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0072_ntwrk_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move outbound file to outbound folder and rename it.
try:
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path,outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the Notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
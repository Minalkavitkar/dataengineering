# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - The main purpose of this job is to build the outbound interface for process to create file to be used by external application.
# MAGIC ###### Source Details (Azure SQL):
# MAGIC
# MAGIC
# MAGIC - Provider.Provider
# MAGIC
# MAGIC ###### Curated Details (Unmanaged Delta Tables):
# MAGIC - Provider.Re0007ProviderDaily
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - CSV File 

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import require libraries.
from pyspark.sql.functions import col, regexp_replace

# COMMAND ----------

# DBTITLE 1,Parameter Assignment.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME.replace("Outbound", "")
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0007_config = config_dict[job_name]

    container_name = default_config['ContainerName']
    out_file_path_suffix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"] 
    curated_path_suffix = re0007_config['Outbound']['CuratedFilePathSuffix']
    cur_tbl_name = re0007_config['Outbound']['CuratedTableName']
    stg_tbl_name = re0007_config['Inbound']['StageTableName']
    out_file_name = re0007_config["Outbound"]["FileName"]
    sync_process_names = re0007_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]

    temp_path_suffix = re0007_config["Outbound"]["TempFilePathSuffix"]
    curated_path_suffix = re0007_config['Outbound']['CuratedFilePathSuffix']
    sync_table_names = re0007_config['Outbound']["SyncTableNames"]

except Exception as e:
    excep = "Variable assignment from FileConfig failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Provider table sync process.
try:
   dbutils.notebook.run('../Orchestrate/StageTableSyncExecute',0, {'TABLE_NAMES' : sync_table_names})
except Exception as e:
    excep = 'Sync Process Failed: '+ str(e)
    dbutils.notebook.exit(excep)


# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation.
try:
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, out_file_path_suffix)
    temp_csv_path = abfss_path_builder(container_name,storage_account,prc_file_path_prefix,temp_path_suffix)
    
except Exception as e:
    excep = "Path creation failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read provider data from stage and curated
try:
    # Read from stage table and drop the unwanted columns.
    prov_stg_df = read_table_to_df(stg_tbl_name)\
                .drop("ProviderKey"
                      ,"CreatedDateTime"
                      ,"CreatedBy"
                      ,"ModifiedDateTime"
                      ,"ModifiedBy"
                      ,"SourceSystemCode"
                      ,"ProviderStartDate"
                      ,"ProviderEndDate")

    # Read only the records with Indicator as Insert, Update and Ignore.            
    prov_cur_df = read_table_to_df(cur_tbl_name)\
                .filter(col("DerivedIndicator").isin(["INSERT", "UPDATE", "IGNORE"]))\
                .select('ProviderId'
                        ,'SuffixCode'
                        ,'Type2Code'
                        ,'Vch')
except Exception as e:
    excep = 'Read provider data from stage and curated failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join with curated table to get the VCH column.
try:
    # Join with curated table to get the VCH column. 
    get_vch_col_df = prov_stg_df.join(prov_cur_df
                                      ,['ProviderId', 'SuffixCode', 'Type2Code']
                                      ,'inner')
    col_maps = {
        "ProviderProfAreaCode" : regexp_replace("ProviderProfAreaCode", "[^a-zA-Z0-9]" ," "),
        "PayInfoCode" : regexp_replace("PayInfoCode", "[^a-zA-Z0-9]" ," ")
    }
    calc_colm_df = get_vch_col_df.withColumns(col_maps)
    # Created AddressLineText and filler column.
    calc_df = calc_colm_df.selectExpr("*", "concat(rpad(AddressLine1Text, 30, ' '),rpad(AddressLine2Text, 30, ' '),rpad(AddressLine3Text, 30, ' '),rpad(AddressLine4Text, 30, ' '))  as AddressLineText", "' ' as Filler")

except Exception as e:
    excep = 'adding columns to final dataframe: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Convert dataframe as Fixedwidth and write to ADLS
try:
    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, calc_df)
    
    # write dataframe as single csv file.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename outbound file name.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, out_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : out_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
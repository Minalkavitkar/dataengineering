# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Provider unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Provider{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GrouperCorrespondenceAddress

# COMMAND ----------

grouper_correspondence_address = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageGrouperCorrespondenceAddress(
GrouperCorrespondAddressKey BIGINT NOT NULL
,ProviderGrouperKey BIGINT NOT NULL
,ContractLegalId	VARCHAR(50)
,ContractLegalName	VARCHAR(55)
,ContractLegalDescription	VARCHAR(128)
,CorrespondenceAddressIndicator	CHAR(1)
,CorrespondenceAddressLine1Text	VARCHAR(30)
,CorrespondenceAddressLine2Text	VARCHAR(30)
,CorrespondenceCityName	VARCHAR(55)
,CorrespondenceName	VARCHAR(55)
,CorrespondenceStateCode	VARCHAR(20)
,CorrespondenceZipCode	VARCHAR(5)
,CorrespondenceZipPlusCode	VARCHAR(5)
,DelegatedServiceIndicator	CHAR(1)
,ProviderGrouperTypeCode	VARCHAR(20)
,CreatedBy	VARCHAR(150)
,CreatedDateTime	TIMESTAMP
,ModifiedBy	VARCHAR(150)
,ModifiedDateTime	TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/GrouperCorrespondenceAddress'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouper

# COMMAND ----------

provider_grouper = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderGrouper(
ProviderGrouperKey BIGINT NOT NULL,
AddressLine1Text VARCHAR(30),
AddressLine2Text VARCHAR(30),
AlternatePCPGrouperIndicator CHAR(1),
BBSConnectionMethodCode VARCHAR(20),
BBSDirectoryName VARCHAR(30),
Bypass3gPendIndicator CHAR(1),
BypassAuthenEditIndicator CHAR(1),
BypassReferrallEditIndicator CHAR(1),
BypassReworkLimitAmount DECIMAL(20,6),
BypassSuspendPendIndicator CHAR(1),
CityName VARCHAR(55),
ClaimGrouperIndicator CHAR(1),
CompanyName VARCHAR(50),
DataFormatCode VARCHAR(20),
DataMediaTypeCode VARCHAR(20),
DefaultPayClaimCount INTEGER,
DelgatedSWCode VARCHAR(20),
DeliveryMethodDescription VARCHAR(128),
ELECContestCode VARCHAR(20),
ELECGrouperBalanceCode VARCHAR(20),
ELECGrouperHistIndicator VARCHAR(55),
ELECGrouperRequestIndicator CHAR(1),
ELECManualAdjustmentCode VARCHAR(20),
ELECQuarterlyIndicator CHAR(1),
ELECRE608Indicator CHAR(1),
ELECRE610Indicator CHAR(1),
ELECRE627Indicator CHAR(1),
ELECRE645Indicator CHAR(1),
ElecMbrCapCode VARCHAR(20),
ElecSpcCapCode VARCHAR(20),
FirstName VARCHAR(30),
IdCardAddressIndicator CHAR(1),
LastName VARCHAR(30),
LedgerNumber INTEGER,
MiddleInitial VARCHAR(30),
PaperGrouperIndicator CHAR(1),
PrimaryDataRateCode VARCHAR(20),
ProviderGrouperId VARCHAR(50),
ReelBlkFact INTEGER,
ReelCode VARCHAR(20), 
ReelFillIndicator CHAR(1),
SecondaryDataRateCode VARCHAR(20),
StateCode VARCHAR(20),
SuspendRejectClaimIndicator CHAR(1),
TelephoneExchangeNumber VARCHAR(20),
TelephoneNumber VARCHAR(20),
TypeCode VARCHAR(20),
UserHDWTypeCode VARCHAR(20),
ZipPlusCode VARCHAR(5),
ZipCode VARCHAR(5),
GrouperReportSequenceIndicator CHAR(1),
ReportControlId VARCHAR(55),
SELHistoryIndicator CHAR(1),
SuspendedCutOffDay SMALLINT,
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/ProviderGrouper'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouperSuperior

# COMMAND ----------

provider_grouper_superior = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderGrouperSuperior(
  ProviderGrouperSuperiorKey BIGINT NOT NULL,
  ProviderGrouperId VARCHAR(50),
  SuperiorId VARCHAR(50),
  CreatedBy VARCHAR(150),
  CreatedDateTime TIMESTAMP,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/ProviderGrouperSuperior'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderGrouperVariable

# COMMAND ----------

provider_grouper_variable = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderGrouperVariable(
  ProviderGrouperVariableKey BIGINT NOT NULL,
  ProviderGrouperId VARCHAR(50),
  TypeCode VARCHAR(50),
  VariableId VARCHAR(50),
  VariableCode VARCHAR(50),
  CreatedBy VARCHAR(150),
  CreatedDateTime TIMESTAMP,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/ProviderGrouperVariable'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - Provider

# COMMAND ----------

provider = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProvider(
ProviderKey BIGINT NOT NULL,
ProviderId VARCHAR(50),
SuffixCode Varchar(20),
TypeCode Varchar(20),
Type2Code Varchar(20),
ProviderName Varchar(55),
LicenseNumber INTEGER,
IRSNumber INTEGER,
GroupName Varchar(55),
GroupIndicator Char(1),
SpecialtyCode Varchar(20),
MultiAddressIndicator char(1),
ProviderProfAreaCode VARCHAR(128),
AddressLine1Text VARCHAR (40) ,
AddressLine2Text VARCHAR (40) ,
AddressLine3Text VARCHAR (40) ,
AddressLine4Text VARCHAR (40) ,
CityName Varchar(55),
StateCode Varchar(20),
ZipCode VARCHAR(10),
TelephoneNumber Varchar(20),
PayInfoCode Varchar(20),
ProviderStartDate Date,
ProviderEndDate Date,
CrossReferenceNumber INTEGER,
CountyCode INTEGER,
SourceSystemCode Varchar(10),
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/Provider'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GeoMarket

# COMMAND ----------

geo_market = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageGeoMarket(
  GeoMarketKey BIGINT NOT NULL
  ,GeoMarketId Varchar(50)
  ,GeoMarketName Varchar(55)
  ,SourceSystemCode Varchar(10)
  ,StatusCode Varchar(20)
  ,GeoMarketStartDate DATE
  ,GeoMarketEndDate DATE
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/GeoMarket'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - GeoMarketCycle

# COMMAND ----------

geo_market_cycle = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageGeoMarketCycle(
  GeoMarketCycleKey BIGINT NOT NULL
  ,GeoMarketKey BIGINT NOT NULL
  ,CycleNumber INTEGER
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
 )"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/GeoMarketCycle'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderVendor

# COMMAND ----------

provider_vendor = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderVendor
(
  ProviderVendorKey BIGINT NOT NULL,
  ProviderKey BIGINT NOT NULL,
  NetworkTypeCode	VARCHAR(20),
  VendorNumber VARCHAR(50),
  VendorStartDate	DATE,
  VendorEndDate DATE,
  VendorTypeCode Varchar(20),
  CreatedBy STRING,
  CreatedDateTime TIMESTAMP,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/ProviderVendor'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - ProviderServiceAddress

# COMMAND ----------

provider_service_address = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderServiceAddress 
    (
     ProviderServiceAddressKey BIGINT NOT NULL, 
     ProviderKey BIGINT NOT NULL , 
     AddressLine1Text STRING , 
     AddressLine2Text STRING , 
     CityName STRING , 
     StateCode STRING , 
     --StateCodeLabel STRING , 
     ZipCode STRING , 
     ZipPlusCode STRING , 
     CountyFIPSCode STRING , 
     12BLatitudeNumber INTEGER , 
     34BLatitudeNumber INTEGER , 
     13BLongitudeNumber INTEGER , 
     45BLongitudeNumber INTEGER , 
     LatitudeDirectionIndicator STRING , 
     LongitudeDirectionIndicator STRING , 
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING, 
     ModifiedDateTime TIMESTAMP 
    )"""
  
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/ProviderServiceAddress'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table - VariableDetail

# COMMAND ----------

variable_detail = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageVariableDetail 
(
  VariableDetailKey BIGINT NOT NULL
  ,VariableID VARCHAR(50)
  ,VariableCode VARCHAR(20)
  ,VariableDescription VARCHAR(128)
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/provider/stage/VariableDetail'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###ProviderGrouperAssociation

# COMMAND ----------

provider_grouper_association = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderGrouperAssociation
(
	ProviderGrouperAssociationKey bigint NOT NULL,
	ProviderGrouperId varchar(50),
	ProviderGrouperAssociateId int,
	AssociationTypeCode varchar(20),
	AssociationStartDate date,
	AssociationEndDate date,
	CreatedBy varchar(150) NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy varchar(150),
	ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###ProviderNetwork

# COMMAND ----------

provider_network = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Provider_StageProviderNetwork
(
	ProviderNetworkKey bigint NOT NULL
     ,ProviderKey BIGINT NOT NULL
     ,NetworkId VARCHAR(50)
     ,ProviderId VARCHAR(50)
     ,ProviderNetworkStartDate DATE
     ,ProviderNetworkEndDate DATE
     ,PCPIndicator CHAR(1)
     ,ProviderHomeBaseIndicator CHAR(1)
     ,HumanaClaimPaymentIndicator CHAR(1)
     ,ProviderSpecialtyCode VARCHAR(20)
     ,ProviderSuffix2Code VARCHAR(20)
     ,ProviderIdImplIndicator BOOLEAN
     ,CreatedBy STRING NOT NULL
     ,CreatedDateTime TIMESTAMP NOT NULL
     ,ModifiedBy STRING
     ,ModifiedDateTime TIMESTAMP NOT NULL
)"""

# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
"Provider_StageProvider" : provider,
"Provider_StageGeoMarket" : geo_market,
"Provider_StageGeoMarketCycle" : geo_market_cycle,
"Provider_StageProviderVendor" : provider_vendor,
"Provider_StageProviderGrouper" : provider_grouper,
"Provider_StageProviderGrouperSuperior" : provider_grouper_superior,
"Provider_StageProviderGrouperVariable" : provider_grouper_variable,
"Provider_StageGrouperCorrespondenceAddress" : grouper_correspondence_address,
"Provider_StageVariableDetail" : variable_detail,
"Provider_StageProviderServiceAddress" : provider_service_address,
"Provider_StageProviderGrouperAssociation" : provider_grouper_association,
"Provider_StageProviderNetwork" : provider_network
}

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    # Logic to create table based on the input parameter.
    # If 'All' is provided as parameter then it will create all table in the notebook.
    # If specific table names are provided in parameter then only those will run.
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
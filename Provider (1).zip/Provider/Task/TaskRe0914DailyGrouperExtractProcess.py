# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily Job RE0914- The main purpose of this job is interface to extract data from Provider Grouper and Superior Grouper SF tables and create a Delegated IPA stage area table on cloud and an outbound Delegated IPA MF file for CAS .
# MAGIC ###### Source Details (Azure SQL Tables):
# MAGIC
# MAGIC - Provider.ProviderGrouper
# MAGIC - Provider.ProviderGrouperVariable
# MAGIC - Provider.ProviderGrouperSuperior
# MAGIC - Provider.VariableDetail
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Provider.Re0914DailyGrouperExtractProcess
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenRE914DelegetIPA.csv (CSV File )
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import required libraries
from pyspark.sql.functions import coalesce
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import AdlsHelper notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Job name Assignment
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    re0914_config = config_dict[job_name]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    config = default_out_config["Config"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re0914_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re0914_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re0914_config["Outbound"]["TableName"]
    outbnd_file_name = re0914_config["Outbound"]["FileName"]
    stg_prv_grp_tbl_name = re0914_config["Inbound"]["StageProviderGrouper"]
    stg_prv_grp_sup_tbl_name = re0914_config["Inbound"]["StageProviderGrouperSuperior"]
    stg_var_dtl_tbl_name = re0914_config["Inbound"]["StageVariableDetail"]
    stg_prv_grp_var_tbl_name = re0914_config["Inbound"]["StageProviderGrouperVariable"]
    sync_process_names = re0914_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = "Variable assignment from FileConfig failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(
            f"Stage tables: {sync_process_names} are not in sync with Azure SQL table"
        )
except Exception as e:
    excep = "ControlTable check failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account, prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select required columns from ProviderGrouper
provider_grouper_cols = [
    "ProviderGrouperId",
    "TypeCode",
    "LastName",
    "FirstName",
    "MiddleInitial",
    "CompanyName",
    "AddressLine1Text",
    "AddressLine2Text",
    "CityName",
    "StateCode",
    "ZipCode",
    "ZipPlusCode",
    "ReelCode",
]

# COMMAND ----------

# DBTITLE 1,Read the data from Stage ADLS
try:
    # Read the tables from ProviderGrouper table
    provider_grouper_df = read_table_to_df(stg_prv_grp_tbl_name).select(
        *provider_grouper_cols
    )
    # Read the tables from ProviderGrouperVariable table
    provider_grouper_variable_df = read_table_to_df(stg_prv_grp_var_tbl_name)

    # Read the tables from ProviderGrouperSuperior table
    provider_grouper_superior_df = read_table_to_df(stg_prv_grp_sup_tbl_name)

    # Read the tables from VariableDetail table
    variable_detail_df = read_table_to_df(stg_var_dtl_tbl_name)
except Exception as e:
    excep = "Read Sql Tables failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join function definition
# for all below join operations in the notebook, we will be passing table names and condition to this function.
def perform_join(left_df, right_df, cond, join_type):
    try:
        joined_df = left_df.alias("LH").join(right_df.alias("RH") ,cond ,join_type)
        return joined_df
    except Exception as e:
        excep = "perform_join: "+ str(e)
        output = {
            'NOTEBOOK_RUN_STATUS' : excep
        }
        dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Perform join operation on ProviderGrouper, ProviderGrouperVariable
try:
    # join the tables and get the VariableCode, VariableId from ProviderGrouperVariable table
    condition = (col("LH.ProviderGrouperId") == col("RH.ProviderGrouperId")) & \
                (col("LH.TypeCode") == col("RH.TypeCode"))
    
    # filter the records if VariableId is equal to C and join the tables
    filtered_var_dtl_df = provider_grouper_variable_df.filter(col("VariableId") == "C")
    joined_df = (perform_join(provider_grouper_df, filtered_var_dtl_df, condition, "left")
                .drop("ReelCode") \
                .selectExpr("LH.*", "RH.VariableCode as ReelCode"))
    
except Exception as e:
    excep = "Join operation on ProviderGrouper, ProviderGrouperVariable failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1, Filter R and S dataset
try:
    # Write all records in dataset R if TypeCode is equal to  'R' and ReelCode in ('P','Z','R')
    joined_with_r_df = joined_df.filter((col("TypeCode") == "R")
                                    & ((col("ReelCode") == "P")
                                    | (col("ReelCode") == "Z")
                                    | (col("ReelCode") == "R")))
    
    # Write all records in dataset S if TypeCode is equal to  'S'
    joined_with_s_df = joined_df.filter(col("TypeCode") == "S")
except Exception as e:
    excep = "Filter R and S dataset failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Replace blank spaces with null in ProviderGrouperSuperior
try:
    # Replace blank spaces with null in ProviderGrouperSuperior
    provider_grouper_superior_df = provider_grouper_superior_df.withColumn(
        "SuperiorId",
        when(trim(col("SuperiorId")) != "", col("SuperiorId")).otherwise(None),
    )
except Exception as e:
    excep = "Replace blank values with null failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join R dataset with ProviderGrouperSuperior to get SuperiorId
try:
    # Join R dataset with ProviderGrouperSuperior to get SuperiorId
    cond = col("LH.ProviderGrouperId") == col("RH.ProviderGrouperId")

    superior_r_joined_df = perform_join(
        joined_with_r_df, provider_grouper_superior_df, cond, "left") \
        .select("LH.*", "RH.SuperiorId")

except Exception as e:
    excep = "Join R dataset with ProviderGrouperSuperior failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join the Result with S dataset to fetch SuperiorId details
try:
    # Join the Result with S dataset to fetch SuperiorId details
    condition = col("LH.SuperiorId") == col("RH.ProviderGrouperId")
    
    sup_s_joined_df = perform_join(
        superior_r_joined_df, joined_with_s_df, condition, "left") \
        .selectExpr(
        "LH.*",
        "RH.ProviderGrouperId as ProviderGrouperId_1",
        "RH.TypeCode as TypeCode_1",
        "RH.LastName as LastName_1",
        "RH.FirstName as FirstName_1",
        "RH.MiddleInitial as MiddleInitial_1",
        "RH.CompanyName as CompanyName_1",
        "RH.AddressLine1Text as AddressLine1Text_1",
        "RH.AddressLine2Text as AddressLine2Text_1",
        "RH.CityName as CityName_1",
        "RH.StateCode as StateCode_1",
        "RH.ZipCode as ZipCode_1",
        "RH.ZipPlusCode as ZipPlusCode_1",
        "RH.ReelCode as ReelCode_1",
        )
except Exception as e:
    excep = "Join the Result with S dataset to fetch SuperiorId failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join the Result with ProviderGrouperSuperior to get SuperiorId to fetch 3rd dataset occurrence
try:
    # Join the Result with ProviderGrouperSuperior to get SuperiorId to fetch 3rd dataset occurrence
    condition = col("LH.ProviderGrouperId_1") == (col("RH.ProviderGrouperId"))

    calc_second_occr_cols_df = perform_join(
        sup_s_joined_df, provider_grouper_superior_df, condition, "left") \
        .select("LH.*", col("RH.SuperiorId") \
        .alias("SuperiorId_1"))

except Exception as e:
    excep = "Join with ProviderGrouperSuperior to fetch 3rd dataset failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join result again with S dataset to fetch 3rd dataset
try:
    # Join result again with S dataset to fetch 3rd dataset
    cond = col("LH.SuperiorId_1") == col("RH.ProviderGrouperId")

    #resulting_df_with_three_datasets
    calc_third_occr_cols_df = perform_join(calc_second_occr_cols_df, joined_with_s_df, cond, "left") \
        .selectExpr(
        "LH.*",
        "RH.ProviderGrouperId as ProviderGrouperId_2",
        "RH.TypeCode as TypeCode_2",
        "RH.LastName as LastName_2",
        "RH.FirstName as FirstName_2",
        "RH.MiddleInitial as MiddleInitial_2",
        "RH.CompanyName as CompanyName_2",
        "RH.AddressLine1Text as AddressLine1Text_2",
        "RH.AddressLine2Text as AddressLine2Text_2",
        "RH.CityName as CityName_2",
        "RH.StateCode as StateCode_2",
        "RH.ZipCode as ZipCode_2",
        "RH.ZipPlusCode as ZipPlusCode_2",
        "RH.ReelCode as ReelCode_2",
        )
except Exception as e:
    excep = "Join with S dataset to fetch 3rd dataset failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join the Result with ProviderGrouperSuperior to get SuperiorId to fetch 4th dataset occurrence
try:
    # Join the Result with ProviderGrouperSuperior to get SuperiorId to fetch 4th dataset occurrence.
    cond = col("LH.ProviderGrouperId_2") == (col("RH.ProviderGrouperId"))

    joined_with_superior_df = perform_join(
        calc_third_occr_cols_df, provider_grouper_superior_df, cond, "left"
        ).select("LH.*", col("RH.SuperiorId").alias("SuperiorId_2"))

except Exception as e:
    excep = "Join with ProviderGrouperSuperior to fetch 4th dataset failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join result again with S dataset to fetch 4th dataset
try:
    # Join result again with S dataset to fetch 4th dataset
    cond = col("LH.SuperiorId_2") == col("RH.ProviderGrouperId")
    
    calc_fourth_occr_cols_df = perform_join(joined_with_superior_df, joined_with_s_df, cond, "left")\
        .selectExpr(
        "LH.*",
        "RH.ProviderGrouperId as ProviderGrouperId_3",
        "RH.TypeCode as TypeCode_3",
        "RH.LastName as LastName_3",
        "RH.FirstName as FirstName_3",
        "RH.MiddleInitial as MiddleInitial_3",
        "RH.CompanyName as CompanyName_3",
        "RH.AddressLine1Text as AddressLine1Text_3",
        "RH.AddressLine2Text as AddressLine2Text_3",
        "RH.CityName as CityName_3",
        "RH.StateCode as StateCode_3",
        "RH.ZipCode as ZipCode_3",
        "RH.ZipPlusCode as ZipPlusCode_3",
        "RH.ReelCode as ReelCode_3",
        )
except Exception as e:
    excep = "Join with S dataset to fetch 4th dataset: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter data with VariableId equals to D and VariableCode like MOOP% in VariableDetail table
try:
    # Filter data with VariableId equals to D and VariableCode like MOOP%
    filtered_variable_detail_df = variable_detail_df \
                                .filter((col("VariableId") == "D") & (col("VariableCode") \
                                .like("MOOP%")))
    
except Exception as e:
    excep = "filter VariableId failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter data with VariableId equals to D and VariableCode like MOOP% in ProviderGrouperVariabletable
try:
    # Filter data with VariableId equals to D and VariableCode like MOOP%
    filtered_grouper_variable_df = provider_grouper_variable_df \
                                .filter((col("VariableId") == "D") & (col("VariableCode") \
                                .like("MOOP%")))
    
except Exception as e:
    excep = "filter VariableId failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter data in ProviderGrouperVariable with VariableId equals to D and VariableCode like MOOP%
try:
    cond = (
        ((col("LH.ProviderGrouperId") == col("RH.ProviderGrouperId")) 
            & (col("LH.TypeCode") == col("RH.TypeCode")))
        | ((col("LH.SuperiorId") == col("RH.ProviderGrouperId"))
            & (col("LH.TypeCode_1") == col("RH.TypeCode")))
        | ((col("LH.SuperiorId_1") == col("RH.ProviderGrouperId"))
            & (col("LH.TypeCode_2") == col("RH.TypeCode")))
        | ((col("LH.SuperiorId_2") == col("RH.ProviderGrouperId"))
            & (col("LH.TypeCode_3") == col("RH.TypeCode")))
        )
    joined_df = perform_join(calc_fourth_occr_cols_df, filtered_grouper_variable_df, cond, "left") \
        .selectExpr("LH.*", "RH.VariableId", "RH.VariableCode")

    # remove duplicate records
    joined_df = joined_df.distinct()
except Exception as e:
    excep = "Filter data in ProviderGrouperVariable with VariableId equals to D and VariableCode like MOOP% failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Update VariableDescription
try:
    # When the condition matches update the corresponding VariableDescription into a new column 'MoopGrouperName'
    cond = ((col("LH.VariableId") == col("RH.VariableId")) & \
            (col("LH.VariableCode") == col("RH.VariableCode")))
    
    regrpsup_df = perform_join(joined_df,filtered_variable_detail_df,  cond, "left") \
            .select("LH.*", col("RH.VariableDescription").alias("MoopGrouperName")) \
            .drop("VariableId","VariableCode")

except Exception as e:
    excep = "Updation of VariableDescription failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Drop unwanted columns from final result
try:
    # Drop the columns which we dont need in the final output.
    regrpsup_df = regrpsup_df.drop(
        "SuperiorId",
        "SuperiorId_1",
        "SuperiorId_2",       
    )
except Exception as e:
    excep = "drop columns failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(regrpsup_df, tbl_name)

    # Read data from stage layer.
    re0914_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0914_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the csv file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
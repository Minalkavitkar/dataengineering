# Databricks notebook source
# MAGIC %md
# MAGIC ### Overview
# MAGIC - This notebook facilitates the execution of task notebooks within the Provider subject area. It accepts the job name as a parameter, runs the relevant task notebook based on it, and subsequently records an entry in the control table.

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import libraries.
from pyspark.sql.functions import *
import json
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('PIPELINE_RUN_ID','')
dbutils.widgets.text('JOB_NAME','')
dbutils.widgets.text('JOB_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','')

PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')
JOB_NAME = dbutils.widgets.get('JOB_NAME')
JOB_TYPE= dbutils.widgets.get('JOB_TYPE')
PIPELINE_NAME= dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Definition of task notebook path.
notebook_details = {
    "Re0167DailyProvVendorExtractProcess" : "../Task/TaskRe0167DailyProvVendorExtractProcess",
    "ProdrenGrouperDailyFeedEdw" : "../Task/TaskRe0089DailyGrouperFeedEdwProcess",
    "Re0914DailyGrouperExtractProcess" : "../Task/TaskRe0914DailyGrouperExtractProcess",
    "Re0007ProviderDailyInbound" : "../Task/TaskRe0007ProviderDailyInbound",
    "Re0007ProviderDailyOutbound" : "../Task/TaskRe0007ProviderDailyOutbound",
    "Re0863DailySuperGrouper":"../Task/TaskRe0863DailySuperGrouper",
    "Re0797ProviderPIMSUpdateInbound": "../Task/TaskRe0797ProviderPIMSUpdateInbound",
    "Re0797ProviderPIMSUpdateOutbound": "../Task/TaskRe0797ProviderPIMSUpdateOutbound",
    "Re0486Daily": "../Task/TaskRe0486Daily",
    "TaskRe0688WeeklyProviderFile" :"../Task/TaskRe0688WeeklyProviderFile",
    "Re0072ProvDailyContract": "../Task/TaskRe0072ProvDailyContract",
    "Re0072NetworkDailyContract": "../Task/TaskRe0072NetworkDailyContract",
    "Re0072ProductDailyContract": "../Task/TaskRe0072ProductDailyContract"
}

# COMMAND ----------

# DBTITLE 1,Reading file config and get control table name.
try:
    # Define FileConfig path.
    file_conf_path = env_file_config_path
    # Read FileConfig repo file.
    config_dict = get_file_config(file_conf_path)
    # Define control table name.
    audit_table_name = config_dict["DEFAULT"]["AuditTableName"]
except Exception as e:
    excep = str(e)
    raise Exception("An Exception occured, while reading file config and getting control table name.: " + str(e))

# COMMAND ----------

# DBTITLE 1,Add entry to control table and execute task notebook.
try:
    process_name = f"DBP#{JOB_TYPE}#{JOB_NAME}"
    start_date_time = datetime.now()
    #Create run id.
    task_id = spark.range(1).withColumn('task_id', expr("uuid()")).collect()[0]["task_id"]
    # Write entry to audit table.
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, JOB_TYPE, start_date_time, 'In Progress' ,audit_table_name, None,end_date_time= ' ' ,task_id = task_id)
    #Run task notebbok
    run_status_str = dbutils.notebook.run(notebook_details[JOB_NAME],0, {'JOB_NAME':JOB_NAME})

    run_status = json.loads(run_status_str)
    if run_status["NOTEBOOK_RUN_STATUS"] == "Success":
        update_audit_table(audit_table_name, task_id, 'Success', process_name)
        if "OUTBOUND_FILE_NAMES" in run_status:
            output = {"OUTBOUND_FILE_NAMES" : run_status["OUTBOUND_FILE_NAMES"]}
            dbutils.notebook.exit(json.dumps(output))
    else:
        raise Exception(f"{JOB_NAME} job failed")  
    
except Exception as e:
    excep = str(e)
    # Update control table status as failed for the run.
    update_audit_table(audit_table_name,task_id, 'Failed', process_name, excep)
    raise Exception("An Exception occured: " + str(e))
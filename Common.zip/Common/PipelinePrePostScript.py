# Databricks notebook source
# DBTITLE 1,Running Validate Functions
# MAGIC %run ../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Import ADLS Helper
# MAGIC %run ../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Setting Up Parameters
dbutils.widgets.text('RUN_PLACE','start')
dbutils.widgets.text('SEQ_NUM','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_START_INFO','')

run_place = dbutils.widgets.get('RUN_PLACE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')
load_type = dbutils.widgets.get('LOAD_TYPE')
pipeline_start_info = dbutils.widgets.get('PIPELINE_START_INFO')

# COMMAND ----------

# DBTITLE 1,Importing necessary libraries
from datetime import datetime
import uuid
from pyspark.sql.functions import lit

# COMMAND ----------

# DBTITLE 1,Pipeline Logging & Controlling
if run_place == "start" and load_type == "DeltaLoad":
    previous_run_status = spark.sql(f'''select * from {audit_table_name}
               where SequenceNumber = int({seq_num})-1
               and PipelineGroupName = "master_pipeline"
               order by StartDatetime desc
               limit 1''')\
                .select('Status')\
                .rdd.map(lambda x : x.Status).collect()[0]                

    if previous_run_status != "Success":
        raise Exception ("previous run not successful")
    else:
        pipeline_start_time = datetime.now()
        task_id = str(uuid.uuid4())
        PipelineGroupName = "master_pipeline"
        ProcessName = "DM#"+load_type
        pipeline_start_info = str(pipeline_start_time)+","+task_id+","+PipelineGroupName+","+ProcessName
        dbutils.notebook.exit(pipeline_start_info)

elif run_place == "start" and load_type == "FullLoad":
        
        pipeline_start_time = datetime.now()
        task_id = str(uuid.uuid4())
        PipelineGroupName = "master_pipeline"
        ProcessName = "DM#"+load_type
        pipeline_start_info = str(pipeline_start_time)+","+task_id+","+PipelineGroupName+","+ProcessName
        dbutils.notebook.exit(pipeline_start_info)

elif run_place == "end":

    pipeline_end_time = datetime.now()
    pipeline_start_info_lst = pipeline_start_info.split(",")

    col_map = {
        "TaskId":lit(pipeline_start_info_lst[1]),
        "RunId" : lit(run_id),
        "PipelineGroupName":lit(pipeline_start_info_lst[2]),
        "ProcessName" : lit(pipeline_start_info_lst[3]),
        "RunDate":lit(pipeline_start_info_lst[0]).cast('Date'),
        "SequenceNumber":lit(seq_num).cast('int'),
        "Status":lit("Success"),
        "StartDateTime":lit(pipeline_start_info_lst[0]).cast('TimeStamp'),
        "EndDateTime":lit(pipeline_end_time),
        "Message":lit(None),
        "ErrorCode" : lit(None)
        }

    ctrl_df = spark.range(1).withColumns(col_map).drop('id')
    ctrl_df.write.format("delta").mode("append").saveAsTable(f'{audit_table_name}')

    dbutils.notebook.exit("RUN SUCCESS")
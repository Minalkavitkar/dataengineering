# Databricks notebook source
# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Database creation
# database_name = f"Audit{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name}""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name
write_role = write_owner_role
read_role  = read_owner_role 


# COMMAND ----------

# DBTITLE 1,Create table script.
query = f"""CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.audit_AuditTable(
    TaskId STRING,
    RunId STRING,
    ProcessName STRING,
    PipelineGroupName STRING,
    SequenceNumber INT,
    RunDate DATE,
    Status STRING,
    StartDatetime TIMESTAMP,
    EndDatetime TIMESTAMP,
    Message STRING,
    ErrorCode STRING
)partitioned by (ProcessName)"""
# USING DELTA LOCATION 'abfss://log@{env_storage_account_name}.dfs.core.windows.net/audit/AuditTable'
# partitioned by (ProcessName);"""

# COMMAND ----------

# DBTITLE 1,Execute script
spark.sql(query)
# audit_table= query
# spark.sql(f"AlTER table {audit_table} owner to {write_role}")
# spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {audit_table} TO {write_role}")
# spark.sql(f"GRANT SELECT ON TABLE {audit_table} TO {read_role}")

# COMMAND ----------

# DBTITLE 1,Module's Database Creation
# product_database_name = f"Product{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{product_database_name};""")

# provider_database_name = f"Provider{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{provider_database_name };""")

# providercontract_database_name = f"ProviderContract{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{providercontract_database_name};""")

# member_database_name = f"Member{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{member_database_name};""")

# accounting_database_name = f"Accounting{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{accounting_database_name};""")

# other_database_name = f"Other{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{other_database_name};""")

# rif_database_name = f"Rif{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{rif_database_name};""")

# capitation_database_name = f"Capitation{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{capitation_database_name};""")

# claim_database_name = f"Claim{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{claim_database_name};""")

# bbs_database_name = f"BBSReporting{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{bbs_database_name};""")
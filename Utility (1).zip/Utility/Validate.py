# Databricks notebook source
# DBTITLE 1,Read the environmental variables
# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ./Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Importing Libraries
from datetime import datetime, timedelta
import uuid
from pyspark.sql.functions import col, current_timestamp, lit, concat

# COMMAND ----------

# DBTITLE 1,Defining Audit Table Name
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name
audit_table_name = f"{catalog_name}.{schema_name}.audit_audittable"
table_run_list = env_table_details_config_abs_path

# COMMAND ----------

def validate_notebook():
    with open(table_run_list) as f:
        jsondata = ''.join(line for line in f if "//" not in line)
        data = json.loads(jsondata)
    return data

# COMMAND ----------

# DBTITLE 1,Validate if the notebook is part of the present execution
def notebook_run_check(Module, table_code, seq_num, audit_table_name, Process = "DM", path = env_table_list_config_path):
    
    # identify the load_type
    if seq_num is not None:
        try:
            LoadType = "FullLoad" if int(seq_num) == 0 else "DeltaLoad"
        except ValueError:
            raise Exception ("Incorrect sequence number: ")
    elif seq_num is None:
        LoadType = "ReverseSync"
    
    
    if LoadType == "DeltaLoad":
        previous_run_details_lst = spark.sql(f'''select Status from {audit_table_name}
                                where SequenceNumber = int({seq_num})-1
                                and (ProcessName = "{Process}#FullLoad#{table_code}"
                                or ProcessName = "{Process}#DeltaLoad#{table_code}")
                                and Status = "Success"
                                order by StartDatetime desc
                                limit 1''')\
                                .rdd.map(lambda x : x.Status).collect()

        previous_run_status = "Success" if "Success" in previous_run_details_lst else "NotSuccess"
        
    elif LoadType == 'ReverseSync':
        previous_run_details_lst = spark.sql(f'''select Status, EndDatetime from {audit_table_name}
                                where ProcessName = "{Process}#ReverseSync#{table_code}"
                                and Status = "Success"
                                order by StartDatetime desc
                                limit 1''')\
                                .collect()
        
        previous_run_status = "NotSuccess" if not previous_run_details_lst else "Success"
        previous_enddate = previous_run_details_lst[0]['EndDatetime'] if previous_run_details_lst else datetime.now() - timedelta(days=1)
    
    #Extract configured tables list
    tbl_name_lst = validate_notebook()[Module]
    
    
    if table_code not in tbl_name_lst:
        table_config = "No"
    else: table_config = "Yes"  
    
    
    #table run check
    if LoadType == "FullLoad" and table_config == "No":
        dbutils.notebook.exit(f"{table_code}#{LoadType}#skipped")
    elif LoadType == "DeltaLoad" and table_config == "No":
        dbutils.notebook.exit(f"{table_code}#{LoadType}#skipped")
    elif LoadType == "DeltaLoad" and table_config == "Yes" and previous_run_status != "Success":
        raise Exception ("Previous Run Not Completed")

# COMMAND ----------

# DBTITLE 1,function for appending a row into a df
def append_rows_into_df(input_df, base_df):
    output_df = base_df.union(input_df)
    return output_df

# COMMAND ----------

# DBTITLE 1,Insert Audit Column Entry
def exit_notebook(run_id, module, load_type, table_code, seq_num, start_time, cur_loaded_time, audit_table_name, Message=None, Status=None, process ="DM"):

    task_id = str(uuid.uuid4())
    if seq_num is None:
        seq_num = 0

    if load_type == "ReverseSync":
        finished_timestamp = cur_loaded_time
    else:
        finished_timestamp = current_timestamp()

    col_map_common = {
        "TaskId":lit(task_id),
        "RunId" : lit(run_id),
        "PipelineGroupName":lit(module),
        "ProcessName" : concat(lit(process),lit("#"),lit(load_type),lit("#"),lit(table_code)),
        "RunDate":lit(start_time).cast('Date'),
        "SequenceNumber":lit(seq_num).cast('int'),
        "Message":lit(Message).cast('string'),
        "ErrorCode" : lit(None).cast('string')
        }
    
    if Status is None:
        Status = 'Success'
        
    col_map_final = {
        "Status" : lit(Status),
        "StartDateTime":lit(start_time).cast('timestamp'),
        "EndDateTime" : lit(finished_timestamp).cast('timestamp')
        }
    
    ctrl_final_df = spark.range(1).withColumns(col_map_common).drop('id')\
                        .withColumns(col_map_final)

    if load_type != "ReverseSync" and cur_loaded_time != None:

        # adding log for stage to curated
        col_map_stage_stage_Curated = {
            "Status" : lit("Audit-StageToMain"),
            "StartDateTime":lit(start_time).cast('timestamp'),
            "EndDateTime" : lit(cur_loaded_time).cast('timestamp')
            }
        
        ctrl_stage_Curated_df = spark.range(1).withColumns(col_map_common).drop('id')\
                        .withColumns(col_map_stage_stage_Curated)

        ctrl_final_df = append_rows_into_df(ctrl_stage_Curated_df, ctrl_final_df)


        # adding log for curated to sql load
        col_map_sql_load = {
            "Status" : lit("Audit-MainToDomain"),
            "StartDateTime":lit(cur_loaded_time).cast('timestamp'),
            "EndDateTime" : lit(current_timestamp()).cast('timestamp')
            }

        ctrl_sql_load_df = spark.range(1).withColumns(col_map_common).drop('id')\
                            .withColumns(col_map_sql_load)

        ctrl_final_df = append_rows_into_df(ctrl_sql_load_df, ctrl_final_df)
    
   
    ctrl_final_df.write.format("delta").mode("append").saveAsTable(f'{audit_table_name}')

    if load_type == "FullLoad" and Status == "Success":
        dbutils.notebook.exit(f"{table_code}#FullLoad#Success")
    elif load_type == "DeltaLoad" and Status == "Success":
        dbutils.notebook.exit(f"{table_code}#DeltaLoad#Success")
    elif load_type == "FullLoad" and Status == "Failed":
        dbutils.notebook.exit(f"{table_code}#FullLoad#Failed")
    elif load_type == "DeltaLoad" and Status == "Failed":
        dbutils.notebook.exit(f"{table_code}#DeltaLoad#Failed")
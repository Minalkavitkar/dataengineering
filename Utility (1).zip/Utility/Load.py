# Databricks notebook source
# DBTITLE 1,Read the environmental variables
# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Collect all information to connect to Azure SQL
#config for servicefund sql database
sf_user = dbutils.secrets.get(scope = env_scope , key = env_app_id_key)
sf_password = dbutils.secrets.get(scope = env_scope , key = env_secret_key)
sf_db_host = env_sf_server_address
sf_db_name = env_sf_db_name
server_address = env_sf_server_address
server_name = "jdbc:sqlserver://" + server_address
sf_url = server_name + ";" + "databaseName=" + sf_db_name + ";"


# COMMAND ----------

write_role = write_owner_role
read_role  = read_owner_role 

# COMMAND ----------

# DBTITLE 1,Function to load dataframe to Azure SQL using JDBC
def load_df_to_sf_sql_db_jdbc(df, tbl_name, writeMode = 'append', auth = "ActiveDirectoryServicePrincipal", batch_size = "10000"):
    try:
        """
        Description:
        This function writes dataframe into Azure SQL using JDBC Connector.  
        JDBC connector doesn't capable of KEEP IDENTITY ON while loading. 
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string].
        :param write_mode: [Type: string].
        :param auth: [Type: string].
        :param batch_size: [Type: string] Number of rows in each batch. At the end of each batch, the rows in the batch are sent to the server.
        """
        (df.write
            .format("sqlserver")
            .mode(writeMode)
            .option("host", sf_db_host)
            .option("authentication", auth)
            .option("user", sf_user)
            .option("batchsize", batch_size)
            .option("password", sf_password)
            .option("database", sf_db_name)
            .option("dbtable", tbl_name) # (if schemaName not provided, default to "dbo")
            .save())
    except Exception as e:
        raise Exception ('loadSQL failed',str(e))

# COMMAND ----------

# DBTITLE 1,Function to load dataframe to Azure SQL using SPARK
def load_df_to_sf_sql_db_spark(df, tbl_name, write_mode = 'append', auth = "ActiveDirectoryServicePrincipal", keep_iden = True, tab_lock = True, relbty_level = 'BEST_EFFORT'):
    try:
        """
        Description:
        This function writes dataframe into Azure SQL using SPARK Connector.  
        Spark connector capable of keep identity on while loading.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string].
        :param write_mode (optional): [Type: string].
        :param auth (optional): [Type: string].
        :param keep_iden (optional): [Type: string] This one used to turn on the identity_insert of the respective table.
        :param tab_lock (optional): [Type: string] Implements an insert with TABLOCK option to improve write performance.
        :param relbty_level (optional): [Type: string] implements an reliable insert in executor restart scenarios.
        """
        df.write\
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .mode(write_mode) \
            .option("url", sf_url) \
            .option("authentication", auth)\
            .option("user", sf_user) \
            .option("password", sf_password) \
            .option("dbtable", tbl_name)\
            .option("KeepIdentity", keep_iden) \
            .option("TableLock", tab_lock) \
            .option("reliabilityLevel", relbty_level)\
            .save()
    except Exception as e:
        raise Exception ('loadSQL failed ',str(e))

# COMMAND ----------

# DBTITLE 1,Function to read Azure SQL table or query to dataframe using SPARK
# port is optional, can use default port 1433 if omittedpor
def read_sf_sql_tbl_to_df_spark(tbl_name=None, query=None, auth="ActiveDirectoryServicePrincipal"):
    try:
        if tbl_name:
            remote_table = (
                spark.read.format("com.microsoft.sqlserver.jdbc.spark")
                .option("url", sf_url)
                .option("authentication", auth)
                .option("user", sf_user)
                .option("password", sf_password)
                .option("dbtable", tbl_name)
                .load()
            )
            return remote_table
        elif query:
            remote_table = (
                spark.read.format("com.microsoft.sqlserver.jdbc.spark")
                .option("url", sf_url)
                .option("authentication", auth)
                .option("user", sf_user)
                .option("password", sf_password)
                .option("query", query)
                .load()
            )
            return remote_table
        else:
            raise Exception("Invalid SQL table details")
    except Exception as e:
        raise Exception("read_table_spark: ", str(e))

# COMMAND ----------

# DBTITLE 1,Retrieve fixed width information for a file
def get_fixed_width_file_config(path):
    try:
        with open(path) as json_file:
            fixed_config_dict = json.load(json_file)
        # parsing table table details json to pandas data frame.
        fxd_dtl_df = pd.json_normalize(fixed_config_dict, record_path = ['FileDetails'], meta = ['JobName'])
        # Converting pandas dataframe to spark dataframe.
        fixed_config_df = spark.createDataFrame(fxd_dtl_df)
        return fixed_config_df
    except Exception as e:
        raise Exception("get_fixed_width_file_config", str(e))

# COMMAND ----------

# DBTITLE 1,Covert each column to specific length  per fixed width decided for them
# def convert_col_to_fixed_width(config_df, df):
#     try:
#         counter = 1
#         slt_lst = []
#         if config_df.count() == 0:
#             raise Exception("Config Dataframe is empty")
#         config_df = config_df.orderBy(col('SequenceNo').cast('int'))
#         rdd = config_df.rdd.map(lambda x : [x[0], x[1], x[2], x[3]]).collect()
#         for col_name, seq_no, col_len, d_type in rdd:
#             if col_name.strip() not in df.columns:
#                 raise Exception(f"{col_name} not found in given dataframe")
#             elif counter != int(seq_no):
#                 raise Exception("Column Sequence is missing. Please check")
#             if d_type.lower() == 'string':
#                 slt_lst.append(f"rpad({col_name}, {col_len}, ' ') as {col_name}")
#             elif d_type.lower() == 'integer':
#                 slt_lst.append(f"lpad({col_name}, {col_len}, '0') as {col_name}")
#             elif d_type.lower() == 'date':
#                 slt_lst.append(f"replace({col_name}, '-', '') as {col_name}")
#             elif d_type.lower() == 'timestamp':
#                 slt_lst.append(f"replace({col_name}, 'T', '-') as {col_name}")
#             counter += 1
#         return df.selectExpr(*slt_lst)
#     except Exception as e:
#         raise Exception("convert_col_to_fixed_width", str(e))

# COMMAND ----------

# DBTITLE 1,Write the outbound files to ADLS 
# def write_outbnd_file_to_adls(df, path, config, write_mode='overwrite'):
#     """
#         Description:
#         This function is used to write dataframe as single csv file to ADLS.
#         :param df: [Type: pyspark.sql.dataframe.Dataframe].
#         :param path: [Type: string].
#         :param config: [Type: string].
#         :param write_mode: [Type: string].
#     """
#     try:
#         df.coalesce(1).write.mode(write_mode).format("csv")\
#             .options(**config).save(path)
#     except Exception as e:
#         raise Exception("write_outbnd_file_to_adls", str(e))


# COMMAND ----------

# DBTITLE 1,Write data to curated layer
def write_to_curated(df,tablename, format="delta", write_mode="overwrite", partition=None):
    try:
        if partition is None:
            df.write.format(format).mode(write_mode).saveAsTable(tablename)
              
        else:
            df.write.format(format).mode(write_mode).partitionBy(partition).saveAsTable(tablename)
        spark.sql(f"AlTER table {tablename} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tablename} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tablename} TO {read_role}")
            
    except Exception as e:
        raise Exception("write_to_curated ",str(e))

# COMMAND ----------

# DBTITLE 1,Write data to stage layer
def write_to_stage(df,tablename, format="delta", write_mode="overwrite"):
    try:
        df.write.format(format).mode(write_mode).saveAsTable(tablename)
        spark.sql(f"AlTER table {tablename} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tablename} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tablename} TO {read_role}") 
    except Exception as e:
        raise Exception("write_to_stage ",str(e))

# COMMAND ----------

# DBTITLE 1,Write data to curated layer using path
def write_to_curated_path(df,tablename,path, format="delta", write_mode="overwrite"):
    try:
        df.write.format(format).mode(write_mode).option('path',path).saveAsTable(tablename)
        spark.sql(f"AlTER table {tablename} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tablename} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tablename} TO {read_role}") 
    except Exception as e:
        raise Exception("write_to_curated_path ",str(e))
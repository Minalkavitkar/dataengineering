# Databricks notebook source
# DBTITLE 1,Import required python libraries
from delta.tables import *
from pyspark.sql.window import Window
import json as js
import pandas as pd
from re import finditer, escape, sub
from pyspark.sql.functions import lit, row_number, trim, col, last_day, to_date, concat, when, max, round, regexp_replace, lower
# spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled","true")

# COMMAND ----------

# DBTITLE 1,Rename stage columns to SQL domain names
def col_name_mapping(df, col_mapping_dict):
    try:
        '''
        Description:
        This function is used to perform columns between source and target.
        :param df: [Type: string] source dataframe.
        :param col_mapping_dict: [Type: string] column mapping dictionary.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        '''
        lst = []
        for src_col_name, trg_col_name in col_mapping_dict.items():
            lst.append(f"{src_col_name} AS {trg_col_name}")
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("col_name_mapping: ",str(e))

# COMMAND ----------

# DBTITLE 1,Add created and Modified columns
def add_tgt_audit_column(df, pipeline_name,load_type="FullLoad",fileDate =None):
    '''
    Description:
    This function is used to audit columns.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param pipeline_name: [Type: string].
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    if load_type == 'FullLoad': 
        if fileDate is None:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", "current_timestamp() CreatedDateTime"
                            , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        else:
            df = df.selectExpr('*', f"'{pipeline_name}' as CreatedBy", f"cast('{fileDate}' as TIMESTAMP) as CreatedDateTime"
                            , "cast(null as STRING) as ModifiedBy", "cast(null as TIMESTAMP) ModifiedDateTime") 
        return df
    elif load_type == 'DeltaLoad':
        audit_cols = {
        "CreatedBy": lit(f'{pipeline_name}'),

        "CreatedDateTime":current_timestamp(),

        "ModifiedBy": when(col('DerivedIndicator')=='UPDATE',f'{pipeline_name}')\
        .when(col('DerivedIndicator')=='INSERT',None)\
        .when(col('DerivedIndicator')=='DELETE',None),

        "ModifiedDateTime": when(col('DerivedIndicator')=='UPDATE',current_timestamp())\
        .when(col('DerivedIndicator')=='INSERT',None)\
        .when(col('DerivedIndicator')=='DELETE',None)
        }
        df = df.withColumns(audit_cols)
        return df

# COMMAND ----------

# DBTITLE 1,DataType conversion as per Domain tables
def dtype_tgt_conversion(df, schema):
    '''
    Description:
    This function is used to convert the data type of each column.
    :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
    :param schema: [Type: dictionary] contains column name as key and column value as data type.
    :param df: [Type: pyspark.sql.dataframe.Dataframe]converted data type dataframe
    '''

    lst = []
    keys = schema.keys()
    for col_name in df.columns:
        if col_name in keys:
            lst.append(f"CAST({col_name} as {schema[col_name]}) as {col_name}")
        else:
            lst.append(col_name)
    return df.selectExpr(*lst)

# COMMAND ----------

# DBTITLE 1,Function to get the provider necessary Type Code
def prioritize_prv_type2Code(df):
    prv_trans_df = df.withColumn('Type2Code', when(trim(col('Type2Code')).isNull(), lit('ZZZ'))\
                                    .otherwise(trim(col('Type2Code'))))

    window_spec = Window.partitionBy('ProviderId', 'SuffixCode').orderBy('Type2Code')
    prv_trans_df = prv_trans_df.withColumn('RN', row_number().over(window_spec))\
                        .filter(col('RN') == 1).drop('RN')
    return prv_trans_df

# COMMAND ----------

# DBTITLE 1,Function used to convert yyMMdd to spark date format.
def date_format_conversion(df, lst, inp_dt_format):
    for col_name in lst:
        if inp_dt_format == 'yyMMdd':  
            cmonth = substring(col(col_name), 3, 2)
            cday = substring(col(col_name), -2, 2)
            cyear = substring(col(col_name), 1, 2)
        elif inp_dt_format == 'MMddyy':
            cmonth = substring(col(col_name), 1, 2)
            cday = substring(col(col_name), 3, 2)
            cyear = substring(col(col_name), -2, 2)

        df = df.withColumn(col_name, to_date(\
            when(col(col_name) == '999999', lit('9999-12-31'))\
            .when(col(col_name)=='000000', lit('1900-01-01'))\
            .when((cyear.cast('int') >= 80) & (cyear.cast('int') <= 99), \
                concat(lit('19'),cyear, lit('-'),cmonth, lit('-'), cday))\
            .otherwise(concat(lit('20'),cyear, lit('-'),cmonth, lit('-'), cday)), 'yyyy-MM-dd'))
    return df

# COMMAND ----------

# DBTITLE 1,Function used to convert INT date column to month end/start date
def dt_format_cym(df, convert_date_col,day = 'start'):
    try:
        if day == 'start':
            for col_name in convert_date_col:
                df = df.withColumn(col_name, when((col(col_name) == 0),to_date(lit('1900-01-01'),'yyyy-MM-dd'))
                                   .when((col(col_name) == 999999),to_date(lit('9999-12-31'),'yyyy-MM-dd'))
                                   .when((col(col_name)%100 == 0), to_date(concat((col(col_name)/100).cast('int'), lit("1231")), 'yyyyMMdd'))
                                   .otherwise(to_date(concat(col_name, lit("01")), 'yyyyMMdd')))
        elif day == 'end':
            for col_name in convert_date_col:
                df = df.withColumn(col_name, when((col(col_name) == 999999),to_date(lit('9999-12-31'),'yyyy-MM-dd'))
                        .otherwise(last_day(to_date(concat(col_name, lit("01")), 'yyyyMMdd'))))
        return df
    except Exception as e:
        raise Exception ("date format converstion failed", str(e))

# COMMAND ----------

# DBTITLE 1,Read delta table to dataframe
def read_table_to_df(tablename):
    try:
        df = spark.read.table(tablename)
        return df
    except Exception as e:
        raise Exception("not able to read the table",str(e))

# COMMAND ----------

# DBTITLE 1,Function to execute the DDL statements
def cur_table_creation(mapping, tbl_lst):
    try:
        for tbl_name in tbl_lst:
            tbl_name = tbl_name.strip()
            spark.sql(mapping[tbl_name])
            print(tbl_name + ": Created")
    except Exception as e:
        raise Exception(f"table_creation: {e}")

# COMMAND ----------

# DBTITLE 1,Function to random partition dataframes
def partition_col_add(df, key_col, no_of_partitions = 50):
  maximum_key_list = df.select(max(key_col)).rdd.flatMap(lambda x: x).collect()
  max_key = maximum_key_list[0]

  partition_size = max_key/(no_of_partitions-1)
  df = df.withColumn('part_col', round(col(key_col)/partition_size,0).cast('int'))

  part_col_list = list(range(no_of_partitions))
  return df, part_col_list


# COMMAND ----------

# DBTITLE 1,Concatenate method for ProvidercontractID
# Function to create ProviderContractId
# ProviderContractId is made up of 4 fields
# 1. ProviderNumber - add leading zeroes until length is 9
# 2. ProviderSuffixCode - add trailing spaces until length is 2
# 3. ProviderType2Code - no additional processing required, length should always be 3
# 4. SequenceNumber - add leading zeroes until length is 3
def create_provider_contract_id(df, col_lst, col_name = "ProviderContractId"):
    try:
        calc_df = df.withColumn(col_name, concat(\
            lpad(col(col_lst[0]), 9, '0'), rpad(col(col_lst[1]), 2, ' '),\
                col(col_lst[2]), lpad(col(col_lst[3]), 3, '0')))
        return calc_df
    except Exception as e:
        raise Exception('create_provider_contract_id: ', str(e))

# COMMAND ----------

# DBTITLE 1,Function to remove null records of required columns from dataframe
def remove_invalid_records(input_df, stage_tbl_name, not_null_col_lst, join_key = 'StgUnqId'): 
    try:
        #Initializing the dataframes
        analyzed_df = input_df

        #Analyzing the records whether and rejecting if it is invalid
        for key in not_null_col_lst:
            analyzed_df  = analyzed_df\
                .withColumn("Status",
                    when((col(key).isNull()), lit("R"))
                    .when(col("Status") == "R", lit("R"))
                    .when(col(key).isNotNull() & (col("Status") == "S"), lit("S")))\
                .withColumn("RejectReason",
                    when((col(key).isNotNull()) & (col("RejectReason").isNull()) , lit(None))
                    .when((col(key).isNotNull()) & (col("RejectReason").isNotNull()) , col("RejectReason"))
                    .when((col(key).isNull()) & (col("RejectReason").isNull()) , lit(f"{key} is null"))
                    .when((col(key).isNull()) & (col("RejectReason").isNotNull()) , concat(col("RejectReason"),lit(" # "),lit(f"{key} is null"))))

        #Filtering out the rejected records
        rejected_records_df = analyzed_df.filter("Status == 'R'")
        
        #merging condition prepare
        merging_condition = "LH."+join_key+ " = "+ "RH."+join_key

        #merging the rejected records with stage table
        dt = DeltaTable.forName(spark,stage_tbl_name)
        dt.alias('LH')\
            .merge(rejected_records_df.alias('RH'), merging_condition )\
            .whenMatchedUpdate(set = {
                "LH.Status": "RH.Status",
                "LH.RejectReason": "RH.RejectReason"
                })\
                .execute()

        Validated_records_df = analyzed_df.filter("Status != 'R'")
        return Validated_records_df
    
    except Exception as e:
        raise Exception('rejecting null records failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Function to remove duplicate records of the unique columns
def remove_dup_records(input_df, uniq_keys, stage_tbl_name, join_key = 'StgUnqId'):
    try:
        #marked duplicate records using row number
        window_spec = Window.partitionBy(uniq_keys).orderBy(join_key)
        rn_calc_df = input_df.withColumn('RN', row_number().over(window_spec))


        #rejection marking in the records
        rejection_marked_df  = rn_calc_df\
            .withColumn("Status",
                when(col('RN') > 1 , lit("R"))
                .when(col("Status") == "R", lit("R"))
                .when((col('RN') == 1) & ((col("Status") == "S")),lit("S")))\
            .withColumn("RejectReason",
                when((col('RN') == 1) & (col("RejectReason").isNull()) , lit(None))
                .when((col('RN')== 1) & (col("RejectReason").isNotNull()) , col("RejectReason"))
                .when((col('RN') > 1) & (col("RejectReason").isNull()) , lit("unique key duplicated"))
                .when((col('RN') > 1) & (col("RejectReason").isNotNull()) , concat(col("RejectReason"),lit(" # "),lit("unique key duplicated"))))

        
        #Filtering out the rejected records      
        rejected_records_df = rejection_marked_df.filter((col('Status')=="R")&(col('RN')>1)).drop('RN')
            
        #merging condition prepare
        merging_condition = "LH."+join_key+ " = "+ "RH."+join_key

        #merging the rejected records with stage table
        dt = DeltaTable.forName(spark,stage_tbl_name)
        dt.alias('LH')\
            .merge(rejected_records_df.alias('RH'), merging_condition)\
            .whenMatchedUpdate(set = {
                "LH.Status": "RH.Status",
                "LH.RejectReason": "RH.RejectReason"
                })\
                .execute()

        validated_records_df = rejection_marked_df.filter("Status != 'R'").drop('RN')
        return validated_records_df
        
    except Exception as e:
        raise Exception('rejecting duplicate records failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Function to remove dup records without rejecting/auditing and with Order By
def remove_dup_records_simple(input_df, uniq_keys, order_by, ordering = 'desc'):
    try:
        if ordering == 'desc':
            window_spec = Window.partitionBy(uniq_keys)\
                            .orderBy(desc(order_by))
        else:
            window_spec = Window.partitionBy(uniq_keys).orderBy(order_by)
        rn_clac_df = input_df.withColumn('RN', row_number().over(window_spec))
        final_df = rn_clac_df.filter(col('RN') == 1).drop('RN')
        return final_df
    except Exception as e:
        raise Exception('removing duplicate records failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Function to get the path of delta table
def delta_table_path(tableName):
    deltaTablePath = spark.sql(f"desc formatted {tableName}").filter("col_name == 'Location' ").select('data_type').rdd.map(lambda x : x.data_type).collect()[0]
    if deltaTablePath is None:
        deltaTablePath = "NoTable"
        return "NoTable"
    else:
        return deltaTablePath

# COMMAND ----------

# DBTITLE 1,Delta Merge Operation
def delta_operation(cur_tbl_name,df,conditions,not_update_lst = ['CreatedBy','CreatedDateTime']):
    # condition is a list of columns for join operation eg: conditions = ['col1','col2','col3','col4']
    #  OR can be as its presently used as there may be situation where the conditions are not add
    #  list can only be sent if the conditions are used as AND
    
    # df is the dataframe with delta records
    # cur_tbl_name is the table which needs to be merged

    cond_list = []

    if isinstance(conditions, list):
        for element in conditions:
            cond_list.append('curated.'+element+'='+'stage.'+element)
        cond = ' and '.join(cond_list)
    else:
        raise Exception('Please pass conditions as list')
    
    col_list = df.columns
    
    updt_list = [x  for x in col_list if x not in not_update_lst]

    updt_dict = {}
    for element in updt_list:
        updt_dict[element] = 'Stage.'+element


    insrt_dict = {}
    for element in col_list:
        insrt_dict[element] = 'Stage.'+element

    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)
    dfUpdates =df.filter(df.DerivedIndicator.isin(["UPDATE","INSERT","DELETE"]))
    
    deltaTableCurated.alias('Curated')\
        .merge(
            dfUpdates.alias('Stage'),cond)\
        .whenMatchedDelete(condition= "Stage.DerivedIndicator='DELETE'")\
        .whenMatchedUpdate(condition ="Stage.DerivedIndicator='UPDATE'",
                           set = updt_dict)\
        .whenNotMatchedInsert(condition = "Stage.DerivedIndicator='INSERT'",
                              values = insrt_dict)\
                                  .execute()

# COMMAND ----------

# DBTITLE 1,join with curated table and get primarykey
def get_primary_key(input_df, cur_df, conditions, primary_key):
    # This function used to get the primary key from curated layer/main catalog, using unqiues keys in the dataframe
    joined_df = input_df.alias("LH").join(cur_df.alias("RH"), conditions).select("LH.*",primary_key)
    return joined_df

# COMMAND ----------

# DBTITLE 1,Replace table_code with table_name in the query
def replace_table_code (string):
    # This functioned replaces the table code into table name, whichever mentioned inside curly braces
    # This is useful when the number of table code to be converted into table name is not defined in the input string
    # The output also string format
    pattern = r'\{([^}]+)\}'
    replaced_string = string
    matches = finditer(pattern,string)
    
    for match in matches:
        variable = match.group(1)
        table_name = table_name_selector(tbl_conf_df, variable)
        escape_variable = escape(match.group(0))
        replaced_string = sub(escape_variable, str(table_name),replaced_string)
    
    return replaced_string

# COMMAND ----------

def delta_delete_operation(source_df,table_code, tbl_conf_df, cond, child_tbl_config_path):
    # This function is used to do the delta of only delete records in the curated layer/main catalog


    # reading config json file
    with open(child_tbl_config_path) as f:
        jsondata = ''.join(line for line in f if "//" not in line)
        data = json.loads(jsondata)
    child_tbl_config = data[table_code]


    # iterating the list of child tables of current running notebook(table)
    for tbl in child_tbl_config.keys():

        # deleting the child records, where parent keys are present in child
        if child_tbl_config[tbl] == None:
            tbl_name = table_name_selector(tbl_conf_df, tbl)
            target_tbl = DeltaTable.forName(spark,tbl_name)
            target_tbl.alias('Curated')\
                        .merge(source_df.alias('Stage'),cond)\
                        .whenMatchedDelete(condition= "Stage.DerivedIndicator='DELETE'")\
                        .execute()

        # deleting the child records, where parent keys are not present in child
        # so reading a query from config json and deleting the records.
        else :
            # with the query from the config table, list of delete records prepared.
            view_name = table_code+"_view"
            source_df.createOrReplaceTempView(view_name)
            table_name_replaced_string = replace_table_code(child_tbl_config[tbl])
            df = spark.sql(table_name_replaced_string)

            # with the query from the config table, list of keys received, with that condition formed.
            conditions_col = []
            for col in df.columns:
                conditions_col.append('curated.'+col+'='+'stage.'+col)   
            del_cond = ' and '.join(conditions_col)

            # finally deleting the records at child table 
            tbl_name = table_name_selector(tbl_conf_df, tbl)
            target_tbl = DeltaTable.forName(spark,tbl_name)
            target_tbl.alias('Curated')\
                        .merge(df.alias('Stage'), del_cond )\
                        .whenMatchedDelete()\
                        .execute()

# COMMAND ----------

def delta_operate(cur_tbl_name,df,conditions, table_code, tbl_conf_df, child_tbl_config_path, primary_key, not_update_lst = ['CreatedBy','CreatedDateTime']):
    # condition is a list of columns for join operation eg: conditions = ['col1','col2','col3','col4']
    #  OR can be as its presently used as there may be situation where the conditions are not add
    #  list can only be sent if the conditions are used as AND
    
    # df is the dataframe with delta records
    # cur_tbl_name is the table which needs to be merged

    cond_list = []

    if isinstance(conditions, list):
        for element in conditions:
            cond_list.append('curated.'+element+'='+'stage.'+element)
        cond = ' and '.join(cond_list)
    else:
        raise Exception('Please pass conditions as list')
    
    col_list = df.columns
    
    updt_list = [x  for x in col_list if x not in not_update_lst]

    updt_dict = {}
    for element in updt_list:
        updt_dict[element] = 'Stage.'+element


    insrt_dict = {}
    for element in col_list:
        insrt_dict[element] = 'Stage.'+element


    #delta for INSERT and UPDATE   
    insert_update_df =df.filter(df.DerivedIndicator.isin(["UPDATE","INSERT"]))

    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)
    deltaTableCurated.alias('Curated')\
        .merge(insert_update_df.alias('Stage'),cond)\
                    .whenMatchedUpdate(condition ="Stage.DerivedIndicator='UPDATE'", set = updt_dict)\
                    .whenNotMatchedInsert(condition = "Stage.DerivedIndicator='INSERT'", values = insrt_dict)\
                    .execute()


    #delta for DELETE
    delete_df =df.filter(col("DerivedIndicator").isin("DELETE"))
    cur_df = deltaTableCurated.toDF()
    with_primary_key_df = get_primary_key(delete_df, cur_df, conditions, primary_key)
    # delta_delete_operation(with_primary_key_df,table_code, tbl_conf_df, cond, child_tbl_config_path)
    with_primary_key_df.cache()
    delta_delete_operation(with_primary_key_df,table_code, tbl_conf_df, cond, child_tbl_config_path)
    with_primary_key_df.unpersist()


# COMMAND ----------

# DBTITLE 1,Set DF to Not Null Column
def set_df_columns_not_nullable(spark, df, column_list, nullable=False):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

# DBTITLE 1,Set DF to Null Column
def set_df_columns_nullable(spark, df, column_list, nullable=True):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

# DBTITLE 1,Replacing foreign character
def replace_foreign_char(df, col_lst, char_to_replace, replacement_char):
    lst = []
    for colm in df.columns:
        if colm in col_lst:
            lst.append(f"regexp_replace({colm}, '{char_to_replace}', '{replacement_char}') as {colm}")
        else:
            lst.append(f"{colm}")
    return df.selectExpr(*lst)

# COMMAND ----------

# DBTITLE 1,Update Rejected Records
def update_rej_records(rej_df, RejectReason, tbl_name, join_key = 'StgUnqId'):
    try:
        #rejection marking in the records
        rejection_marked_df  = rej_df\
            .withColumn("Status", lit("R"))\
            .withColumn("RejectReason",
                when((col("RejectReason").isNull()) , lit(RejectReason))
                .when((col("RejectReason").isNotNull()) , concat(col("RejectReason"),lit(" # "),lit(RejectReason))))

        #merging condition prepare
        merging_condition = "LH."+join_key+ " = "+ "RH."+join_key

        #merging the rejected records with stage table
        dt = DeltaTable.forName(spark, tbl_name)
        dt.alias('LH')\
            .merge(rejection_marked_df.alias('RH'), merging_condition)\
            .whenMatchedUpdate(set = {
                "LH.Status": "RH.Status",
                "LH.RejectReason": "RH.RejectReason"
                })\
                .execute()
                
    except Exception as e:
        raise Exception('rejecting duplicate records failed: ',str(e))


# COMMAND ----------

# DBTITLE 1,Convert column values to fixed width.
def convert_col_to_fixed_width(config_df, df):
    """
        Description:
        This function is used to convert column values to fixed width value using Fixed Width configuration file.
        :param config_df: [Type: pyspark.sql.dataframe.Dataframe] Fixed Width configuration file dataframe.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] df to convert Fixed width value.
        :returns df: [Type: string] Converted dataframe.
    """
    try:
        counter = 1
        slt_lst = []
        if config_df.count() == 0:
            raise Exception("Config Dataframe is empty")
        config_df = config_df.orderBy(col('SequenceNo').cast('int'))
        rdd = config_df.rdd.map(lambda x : [x[0], x[1], x[2], x[3]]).collect()
        for col_name, seq_no, col_len, d_type in rdd:
            if col_name.strip() not in df.columns:
                raise Exception(f"{col_name} not found in given dataframe")
            elif counter != int(seq_no):
                raise Exception("Column Sequence is missing. Please check")
            if d_type.lower() == 'string':
                slt_lst.append(f"substring(rpad(coalesce({col_name}, ''), {col_len}, ' '),1,{col_len}) as {col_name}")
            elif d_type.lower() == 'numeric':
                slt_lst.append(f"substring(CASE WHEN {col_name} < 0 then concat('-', lpad(abs(coalesce({col_name}, 0)),{col_len} - 1, '0')) else lpad(coalesce({col_name}, 0), {col_len}, '0') end, 1, {col_len}) as {col_name}")
            elif d_type.lower() == 'date':
                slt_lst.append(f"substring(case when {col_name} is null then lpad('', {col_len}, ' ') else replace({col_name}, '-', '') end,1,{col_len}) as {col_name}")
            elif d_type.lower() == 'timestamp':
                slt_lst.append(f"substring(case when {col_name} is null then lpad('', {col_len}, ' ') else replace({col_name}, 'T', '-') end, 1, {col_len}) as {col_name}")
            else:
                raise Exception(f"Incorrect datatype - {d_type}")
            counter += 1
        return df.selectExpr(*slt_lst)
    except Exception as e:
        raise Exception("convert_col_to_fixed_width", str(e))

# COMMAND ----------

# DBTITLE 1,Write outbound file to ADLS.
def write_outbnd_file_to_adls(df, path, config, write_mode='overwrite'):
    """
        Description:
        This function is used to write dataframe as single text file to ADLS for the given input path.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param path: [Type: string].
        :param config: [Type: string].
        :param write_mode: [Type: string].
    """
    try:
        if df.rdd.isEmpty():
            dbutils.fs.put(f"{path}/EmptyFile.txt","")
        else:
            concated_df = df.withColumn("data", concat_ws("", *[col(c) for c in df.columns])).select('data')
            dbutils.fs.rm(path, True)
            concated_df.coalesce(1).write.mode(write_mode).format("text")\
                .options(**config).save(path)
    except Exception as e:
        raise Exception("write_outbnd_file_to_adls", str(e))

# COMMAND ----------

# DBTITLE 1,Collect the foreign keys, table names and its respective columns in one list
def get_sql_table_name(key_name = '', tbl = ''):
    # this functions give the Azure sqL table names, i.e, module.table_name
    if key_name != '':
        qry = f"select TABLE_SCHEMA, TABLE_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE where CONSTRAINT_NAME like 'PK%' and COLUMN_NAME = '{key_name}'"
        sch_name = read_sf_sql_tbl_to_df_spark(query=qry).collect()[0].TABLE_SCHEMA
        tbl_name = read_sf_sql_tbl_to_df_spark(query=qry).collect()[0].TABLE_NAME

    elif tbl != '':
        qry = f"select distinct TABLE_SCHEMA, TABLE_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE where TABLE_NAME = '{tbl}' "
        sch_name = read_sf_sql_tbl_to_df_spark(query=qry).collect()[0].TABLE_SCHEMA
        tbl_name = read_sf_sql_tbl_to_df_spark(query=qry).collect()[0].TABLE_NAME
    
    return sch_name+'.'+tbl_name


def get_foreign_key_table_detail_lst(dict_of_cols):
    fk_detail_list =[]
    # collect all foreign keys and table_names from azure SQL
    if 'foreignkey_list' in dict_of_cols:
        fk_key_lst = dict_of_cols['foreignkey_list']
        counter = 0
        for i in fk_key_lst:
            sql_table_name = get_sql_table_name(key_name = i)
            fk_detail_list.append([sql_table_name,i, dict_of_cols[i[:-3]+'_list']])
    elif 'joining_cols' in dict_of_cols:
        for tbl, joinCols in dict_of_cols['joining_cols'].items():
            sql_table_name = get_sql_table_name(tbl = tbl)
            fk_detail_list.append([sql_table_name,joinCols, dict_of_cols[tbl+'_list']])
    else:
        fk_detail_list=''
    
    return fk_detail_list

# COMMAND ----------

# DBTITLE 1,Create query for reverse sync select
def func_to_create_query(table_name, dict_of_cols, startdate, endDate,fk_detail_list=''):
    
    stmt, stmt_fk, all_col_names = '','',''
    tbl_alias_counter = 1
    tname = table_name.split('.')[-1]

    src_cols = dict_of_cols['src_table_col_list']
    dict_of_cols.pop('src_table_col_list')

    src_cols_str = ','.join(src_cols)
    all_col_names = ','.join(['t1.' + fk for fk in src_cols])
    if len(dict_of_cols)>0:
        if 'foreignkey_list' in dict_of_cols:
            foreign_key_cols = dict_of_cols['foreignkey_list']
            src_cols_str = ','.join(foreign_key_cols) + ',' + src_cols_str
            all_col_names = ','.join(['t1.' + sub for sub in foreign_key_cols]) + ',' + all_col_names
        
            for i in fk_detail_list:
                tbl_alias_counter = tbl_alias_counter + 1
                stmt_fk = f"""inner join {i[0]} t{tbl_alias_counter} on t1.{i[1]} = t{tbl_alias_counter}.{i[1]}\n"""
                all_col_names = all_col_names + ',' + ','.join([f't{tbl_alias_counter}.' + sub for sub in i[2]])
                stmt = stmt + stmt_fk
            

        elif 'joining_cols' in dict_of_cols:
            for i in fk_detail_list:
                tbl_alias_counter = tbl_alias_counter + 1
                lst = i[1]
                stmt_join = ''
                for tpl_occ in lst:
                    if lst[len(lst)-1] == tpl_occ:
                        stmt_join_occ = f"""t1.{tpl_occ[0]} = t{tbl_alias_counter}.{tpl_occ[1]}\n"""
                    else:
                        stmt_join_occ = f"""t1.{tpl_occ[0]} = t{tbl_alias_counter}.{tpl_occ[1]} and\n"""
                    stmt_join = stmt_join + stmt_join_occ
                
                stmt_fk = f"""inner join {i[0]} t{tbl_alias_counter} on {stmt_join}\n"""
                all_col_names = all_col_names + ',' + ','.join([f't{tbl_alias_counter}.' + sub for sub in i[2]])
                stmt = stmt + stmt_fk
            

    # src_table_qry = f"""select {all_col_names}, t1.Indicator \nfrom (select {src_cols_str}, 'INSERT' as Indicator \nfrom {table_name} \n where CreatedDateTime between '{startdate}' and '{endDate}' \nunion \nselect {src_cols_str}, 'UPDATE' as Indicator \nfrom {table_name} \n where ModifiedDateTime between '{startdate}' and '{endDate}') t1\n"""+ stmt


    src_table_qry = f"""select {all_col_names}, t1.Indicator \nfrom (select {src_cols_str}, 'INSERT' as Indicator \nfrom {table_name} \nwhere <=25) t1\n"""+ stmt

    return src_table_qry

# COMMAND ----------

# DBTITLE 1,Parse fixed width file config as dataframe.
def get_fixed_width_file_config(path):
    """
        Description:
        This function is used to read FixedWidthFileConfig json from repo and convert it to a spark dataframe.
        :param path: [Type: string].
        :returns fixed_config_df: [Type: string] Converted df.
    """
    try:
        with open(path) as json_file:
            fixed_config_dict = js.load(json_file)
        # parsing table table details json to pandas data frame.
        fxd_dtl_df = pd.json_normalize(fixed_config_dict, record_path = ['FileDetails'], meta = ['JobName'])
        # Converting pandas dataframe to spark dataframe.
        fixed_config_df = spark.createDataFrame(fxd_dtl_df)
        return fixed_config_df
    except Exception as e:
        raise Exception("get_fixed_width_file_config", str(e))

# COMMAND ----------

# DBTITLE 1,Get config file as dictionary.
def get_file_config(path):
    """
        Description:
        This function is used to read FileConfig json from repo and convert it to a Dictonary.
        :param path: [Type: string].
        :returns config_dict: [Type: dictonary].
    """
    try:
        with open(file_conf_path) as json_file:
            config_dict = js.load(json_file)
        return config_dict
    except Exception as e:
        raise Exception("get_file_config failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Azure blob file system path builder.
def abfss_path_builder(container, storage_account, path_suffix="", regex="", path_prefix = ""):
    '''
    Description:
    This function is used to build the path.
    :param path_suffix: [Type: string].
    :param regex: [Type: string].
    :returns path: [Type: path] complete path.
    '''
    root_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/"
    path = f"{root_path}{path_prefix}{path_suffix}{regex}"
    return path

# COMMAND ----------

# DBTITLE 1,Move file to target location and rename it.
def copy_file_to_outbnd_with_new_name(temp_path, outbnd_path, outbnd_file_name,Rundate=None):
    """
        Description:
        This function is used to move file from one path to another, and during the move, it will also rename the file according to provided input.
        :param temp_path: [Type: string] Source path.
        :param outbnd_path: [Type: string] Target path.
        :param outbnd_file_name: [Type: string].
    """
    try:
        if Rundate is None:
            counter = 0
            for file_info in dbutils.fs.ls(temp_path):
                if file_info.name.endswith('.txt'):
                    counter += 1
                    temp_file_name = file_info.name
            if counter == 0:
                raise Exception(f"{temp_path} directory doesn't have txt file.")
            elif counter == 1:
                dbutils.fs.cp(temp_path + temp_file_name, outbnd_path + outbnd_file_name)
                dbutils.fs.rm(temp_path, True)
            else:
                raise Exception(f"{temp_path} directory contain more than one txt file.")
        else:
            counter = 0
            dt = Rundate.strftime('%d%m%Y')
            for file_info in dbutils.fs.ls(temp_path):
                if file_info.name.endswith('.txt'):
                    counter += 1
                    temp_file_name = file_info.name
            if counter == 0:
                raise Exception(f"{temp_path} directory doesn't have csv file.")
            elif counter == 1:
                outbnd_file_name = outbnd_file_name.replace(".txt",f"_{dt}.txt")
                dbutils.fs.cp(temp_path + temp_file_name, outbnd_path + outbnd_file_name)
                dbutils.fs.rm(temp_path, True)
            else:
                raise Exception(f"{temp_path} directory contain more than one csv file.")
    except Exception as e:
        raise Exception("copy_file_to_outbnd_with_new_name", str(e))

# COMMAND ----------

# DBTITLE 1,Extract Delta Load
#This function extract detla load from mentioned table, based on the previous run of target table with audit table
def extract_delta(proc_name, audit_table_name, delta_table_ins_upd , buz_keys, delta_table_del):
    table_latest_run_time = spark.sql(f'''select StartDateTime from {audit_table_name} 
                         where ProcessName = "{proc_name}" and Status = "Success"
                         order by StartDatetime desc limit 1''')\
                    .collect()[0]['StartDateTime']

    delta_table_ins_upd_df = read_table_to_df (delta_table_ins_upd)

    insert_df = delta_table_ins_upd_df.filter(col("CreatedDateTime") > table_latest_run_time)\
                            .withColumn("DerivedIndicator",lit("INSERT"))
    
    update_df = delta_table_ins_upd_df.filter(col("ModifiedDateTime") > table_latest_run_time)\
                            .filter(col("CreatedDateTime") < table_latest_run_time)\
                            .withColumn("DerivedIndicator",lit("UPDATE"))


    insert_update_df = insert_df.union(update_df)

    # delta_table_del_df = read_table_to_df(delta_table_del)

    # delete_df = delta_table_del_df.join(delta_table_ins_upd_df, buz_keys, "left_anti")\
    #                         .withColumn("DerivedIndicator",lit("DELETE"))

    # delta_df = insert_update_df.unionByName(delete_df,allowMissingColumns=True)

    return insert_update_df

# COMMAND ----------

def delta_update_full_table(input_df, buz_keys, stage_full_table):
    #For merge, preparing the merge condition with buz keys
    lst = []
    for key in buz_keys:
        join_cond = "LH."+key+" = "+"RH."+key
        lst.append(join_cond)
    merging_condition = " AND ".join(lst)


    final_insert_df = input_df.filter(col('DerivedIndicator')=="INSERT")
    final_del_df = input_df.filter(col('DerivedIndicator')=="DELETE")

    StageFullTable = DeltaTable.forName(spark, stage_full_table)

    cond_list = []
    for key in buz_keys:
        cond_list.append('Tgt.'+key+'='+'Src.'+key)
    conditions = ' and '.join(cond_list)

    StageFullTable.alias('Tgt')\
        .merge(final_del_df.alias('Src'), conditions)\
        .whenMatchedDelete(condition = "Src.DerivedIndicator='DELETE'")\
        .execute()

    StageFullTable.alias('Tgt')\
        .merge(final_insert_df.alias('Src'), conditions)\
        .whenNotMatchedInsertAll(condition = "Src.DerivedIndicator='INSERT'")\
        .execute()

# COMMAND ----------

def get_table_information(subjectarea, db2table):
    try:
     # Read the JSON data from the file
        with open(local_parameter_file_path) as file:
            data = js.load(file)
        # Search for the matching table information based on subjectarea and db2table values
        for item in data:
            if item['table_code'].upper() == f"{subjectarea.upper()}_{db2table.upper()}":
                return (
                    item['table_code'],
                    item['src_table_name'],
                    item['JOB_NAME'],
                    item['Areasequence'],
                    item['Tablesequence']
                )
    except Exception as e:
        raise Exception("get_table_information ",str(e))

# COMMAND ----------

# DBTITLE 1,Member Tables GH to CI Conversion
def gh_ci_conversion(source_df, cust_df, mem_df, conv_type = 'GH_to_CI'):
    try:
        if conv_type == 'GH_to_CI':
            cust_norm_df = cust_df.select("GHGroupIdentifier","EmployerGroupNumber","CIGroupIdentifier","BenefitSequence","CIClassNumber").distinct()

            customer_join_condition = ((col('SRC.GHGroupIdentifier') == col('CUST_TGT.GHGroupIdentifier')) 
                                     & (col('SRC.EmployerGroupNumber') == col('CUST_TGT.EmployerGroupNumber')))
            
            select_lst = [
                        "SRC.*",
                          "CUST_TGT.CIGroupIdentifier", 
                          "CUST_TGT.BenefitSequence", 
                          "CUST_TGT.CIClassNumber"
                          ]
            
            final_df= source_df.alias('SRC')\
                        .join(cust_norm_df.alias('CUST_TGT'), customer_join_condition, 'left')\
                        .selectExpr(*select_lst)

        return final_df

    except Exception as e:
        raise Exception("gh_ci_conversion failed: ", str(e))



# COMMAND ----------

def write_df_as_delta_table(df, tbl_name, part_col=None, format_type='delta', mode = 'overwrite'):
    """
        Description:
        This function is used to write dataframe as delta table.
        :param df: [Type: pyspark.sql.dataframe.Dataframe].
        :param tbl_name: [Type: string] table name.
        :param path: [Type: string].
        :param part_col: [Type: string] partition column.
        :default param format_type: [Type: string].
        :default param mode: [Type: string].
    """
    try:
        if part_col is not None:
            part_col = [item.replace(" ", "") for item in part_col.split(',')]
            df.write.format(format_type).mode(mode).partitionBy(*part_col)\
                .option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        elif part_col is None:
            df.write.format(format_type).mode(mode).option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        else:
            df.write.format(format_type).mode(mode)\
                .option('mergeSchema', 'true').saveAsTable(f'{tbl_name}')
        spark.sql(f"AlTER table {tbl_name} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tbl_name} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tbl_name} TO {read_role}")
    except Exception as e:
        raise Exception("JobFailed write_df_as_delta_table: ", str(e))
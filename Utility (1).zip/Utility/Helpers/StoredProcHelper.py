# Databricks notebook source
# MAGIC %run ./EnvironmentVariableHelper

# COMMAND ----------

application_id = env_application_id
directory_id = env_directory_id
storage_account_name = env_storage_account_name 
service_credential = dbutils.secrets.get(scope=env_scope,key=env_secret_key)

#config for servicefund sql database
sf_user = dbutils.secrets.get(scope = env_scope , key = env_app_id_key)
sf_password = dbutils.secrets.get(scope = env_scope , key = env_secret_key)
sf_db_host = env_sf_server_address
sf_db_name = env_sf_db_name
server_address = env_sf_server_address
server_name = "jdbc:sqlserver://" + server_address
sf_url = server_name + ";" + "databaseName=" + sf_db_name + ";"


# COMMAND ----------

rdbms_server = sf_db_host
rdbms_port = 1433
rdbms_database = sf_db_name
rdbms_sql_query_timeout = 30
rdbms_sql_login_timeout = 30
rdbms_authority_url = ''
tenant_id = ''
application_id = ''
service_credential = service_credential
rdbms_token_scope = ''

# COMMAND ----------

# Drop staging table indexes before data load
import msal
try:
#   logger.debug("{process_name} - {notebook} :start Drop staging table indexes before data load".format(process_name = process_name,notebook = curated_to_rdbms_load_notebook_name))
  
  jdbc_url = f"jdbc:sqlserver://{rdbms_server}:{rdbms_port};database={rdbms_database};queryTimeout={rdbms_sql_query_timeout};loginTimeout={rdbms_sql_login_timeout}"
#   statement = f"""EXEC [dbo].[CreateDropTableIndex] @SchemaName = '{rdbms_tbl_schema}',@StagingTableName = '{rdbms_stg_tbl_name}',@BusinessTableName = '{rdbms_business_tbl_name}',@BatchjobId = {batchjob_id},@BatchjobLogId = {batchjob_log_id},@IndexOperation = 'D'"""
  statement = f""

  # Generate an OAuth2 access token for service principal
  authority = rdbms_authority_url + tenant_id
  app = msal.ConfidentialClientApplication(application_id, service_credential, authority)
  token = app.acquire_token_for_client(scopes = rdbms_token_scope)["access_token"]

  # Create a spark properties object and pass the access token
  properties = spark._sc._gateway.jvm.java.util.Properties()
  properties.setProperty("accessToken", token)

  # Fetch the driver manager from your spark context
  driver_manager = spark._sc._gateway.jvm.java.sql.DriverManager

  # Create a connection object and pass the properties object
  con = driver_manager.getConnection(jdbc_url, properties)

  # Create callable statement and execute it
  exec_statement = con.prepareCall(statement)
  exec_statement.execute()

  # Close connections
  exec_statement.close()
  con.close()
except Exception as e:
    raise Exception("Error: ", str(e))
#   logger.debug("{process_name} - {notebook} :completed Drop staging table indexes before data load".format(process_name = process_name,notebook = curated_to_rdbms_load_notebook_name))
# except Exception as inst:
#   errorMessage = "[Error]: Instance Type - {insttype} | {process_name} - {notebook} : Drop staging table indexes before data load | Details: {inst}".format(insttype = type(inst), process_name = process_name, notebook = curated_to_rdbms_load_notebook_name, inst = inst)
#   nbStatus = {}
#   nbStatus["status"] = errorMessage
# #   DB batch job error log entry update
#   UpdateBatchjobLogError(batchjob_id, batchjob_log_id,sql_est_current_timestamp,errorMessage)
#   UpdateBatchjobStatus(batchjob_id, batchjob_log_id, process_step_id, failed_process_status_id, sql_est_current_timestamp, errorMessage)
# #   Log Error in file  
#   logger.error(errorMessage)
# #   send email
#   emailSubject = "FAILED batch Job:{process_name} - {notebook} Drop staging table indexes before data load".format(process_name = process_name, notebook = curated_to_rdbms_load_notebook_name)
#   emailBody = "FAILED batch Job:{process_name} - {notebook} Drop staging table indexes before data load: {errorMessage}".format(process_name = process_name, notebook = curated_to_rdbms_load_notebook_name, errorMessage = errorMessage)
#   SendEmailNotification(emailSubject, emailBody)
#   SendBusinessEmailNotification(emailSubject,emailBody,batchjob_id,process_step_id)
# #   SNOW API integration
#   SnowApiIntegration(errorMessage)
# #   Exit from notebook
#   dbutils.notebook.exit(nbStatus)
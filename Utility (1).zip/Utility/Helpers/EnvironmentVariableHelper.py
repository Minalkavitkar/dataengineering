# Databricks notebook source
import json
from os import getenv

# COMMAND ----------

try:
    env_var_clstr = getenv('env_var_clstr')
    environment_variable_title = env_var_clstr.title().split("-")[0]
    environment_variable_lwr = env_var_clstr.lower().split("-")[0]
except Exception as e:
    raise Exception('not able to get environment variable, check the cluster name', str(e))

# COMMAND ----------

def envFileCall():
    try:
        with open(f'/Workspace/Repos/APP0002055-ServiceFundCloud-dm-{environment_variable_lwr}/ServicefundCloud_DataTransferProcess_Processing/Config/{environment_variable_title}Env.json') as f:
            env_var_file = json.load(f)
            return env_var_file
    except: 
        raise Exception("Environmental variable not found")

# COMMAND ----------

try:
    if environment_variable_title == "Sit":
        databricks_schema_suf = ("mainframe_servicefund"+"_"+environment_variable_title)
    else:
        databricks_schema_suf = "mainframe_servicefund"
except: 
        raise Exception("Schema name not found")

# COMMAND ----------

try:
    if environment_variable_title =="Dev":
        databricks_catalog_name = "provider_main_dev_000"
        databricks_stage_catalog_name = "provider_staging_dev_000"
        databricks_raw_catalog_name = "provider_raw_dev_000"
        write_owner_role = "role_object_write__mainframe_servicefund_dev"
        read_owner_role = "role_object_read__mainframe_servicefund_dev"
    elif environment_variable_title =="Sit":
        databricks_catalog_name = "provider_main_dev_000"
        databricks_stage_catalog_name = "provider_staging_dev_000"
        databricks_raw_catalog_name = "provider_raw_dev_000"
        write_owner_role = "role_object_write__mainframe_servicefund_sit_dev"
        read_owner_role = "role_object_read__mainframe_servicefund_sit_dev"
    elif environment_variable_title == "Preprod":
        databricks_catalog_name = "provider_main_preprod_000"
        databricks_stage_catalog_name = "provider_staging_preprod_000"
        databricks_raw_catalog_name = "provider_raw_preprod_000"
        write_owner_role = "role_object_write__mainframe_servicefund_preprod"
        read_owner_role = "role_object_read__mainframe_servicefund_preprod"
    elif environment_variable_title == "Prod":
        databricks_catalog_name = "provider_main_prod_000"
        databricks_stage_catalog_name = "provider_staging_prod_000"
        databricks_raw_catalog_name = "provider_raw_prod_000"
        write_owner_role = "role_object_write__mainframe_servicefund_prod"
        read_owner_role = "role_object_read__mainframe_servicefund_prod"
    elif environment_variable_title =="Uat":
        databricks_catalog_name = "provider_main_qa_000"
        databricks_stage_catalog_name = "provider_staging_qa_000"
        databricks_raw_catalog_name = "provider_raw_qa_000"
        write_owner_role = "role_object_write__mainframe_servicefund_qa"
        read_owner_role = "role_object_read__mainframe_servicefund_qa"
except:
    raise Exception("Catalog/schema  not found")     

# COMMAND ----------

try:
    env_var_file = envFileCall()
    env_storage_account_name = env_var_file["StorageAccountName"]
    env_application_id = env_var_file["ApplicationId"]
    env_directory_id = env_var_file["DirectoryId"]
    env_sf_db_name = env_var_file["SfDbName"]
    env_sf_server_address = env_var_file["SfServerAddress"]
    env_table_details_config_path = env_var_file["TableDetailsConfigPath"]
    env_table_details_config_abs_path=env_var_file["TableListConfigAbsPath"]
    env_fxd_wdt_file_config_path = env_var_file["FixedWidthFileConfigPath"]
    env_file_config_path = env_var_file["FileConfigPath"]
    env_scope = env_var_file["Scope"]
    env_secret_key  = env_var_file["SecretKey"]
    env_app_id_key = env_var_file["AppIdKey"]
    env_table_list_config_path = env_var_file["TableListConfigPath"]
    env_local_parameter_config_path = env_var_file["GetLocalParameterPath"]
except Exception as e:
    raise Exception ("enviroment variables not found at config file",str(e))
# Databricks notebook source
# DBTITLE 1,Import python libraries
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DecimalType
from pyspark.sql.functions import col, lit, to_timestamp, split, input_file_name, current_date, current_timestamp,size,desc,expr,substring, regexp_extract, concat_ws,  when, trim, year, to_date, lpad, rpad, concat,expr,upper, length, row_number, date_format, count 
from datetime import datetime, date, timedelta
from delta.tables import *
import pandas as pd
from pyspark.sql.window import Window
import json

# COMMAND ----------

# DBTITLE 1,Read the environmental variables
# MAGIC %run ./Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Get the role for table 
write_role = write_owner_role
read_role  = read_owner_role 
catalog_name = databricks_catalog_name

# COMMAND ----------

# DBTITLE 1,Create Path for the raw files
def path_builder(container, storage_account, path_suffix="", regex="", path_prefix = ""):
    '''
    Description:
    This function is used to build the path.
    :param path_suffix: [Type: string].
    :param regex: [Type: string].
    :param path: [Type: path] complete path.
    '''
    root_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/" 
    path = f"{root_path}{path_prefix}{path_suffix}{regex}"
    return path

# COMMAND ----------

# DBTITLE 1,Read the raw files into dataframe
def read_csv(path, config, format_type = 'csv'):
    try:
        df = spark.read.format(format_type)\
            .options(**config).load(path)
        return df
    except Exception as e:
        raise Exception("read_csv: ",str(e))

# COMMAND ----------

# DBTITLE 1,Check the files is FullLoad or not
def validate_fullload(df,load_type):
    try:
        if load_type == 'FullLoad':
            lst = df.select('IND1').distinct().rdd.map(lambda x : x.IND1).collect()
            lst.remove('ADD')
            if len(lst) > 0:
                raise Exception('File rejected, because it is not FullLoad')
            else:
                return(df)
        elif load_type == 'DeltaLoad':
            return(df)
        else:
            return(df)
    except Exception as e:
        raise Exception("validate_fullload",str(e))

# COMMAND ----------

# DBTITLE 1,Read the table name from the Json files
def table_name_selector(df, table_code):
    table_name = df.filter(col('table_code') == table_code)\
        .select('table_name').rdd.flatMap(lambda x : x).collect()
    if len(table_name) == 0:
        raise Exception("Table_name_selector : Table not found")
    elif len(table_name) > 1:
        raise Exception("Table_name_selector : More than one table found for the Table Code")
    return table_name[0]


# COMMAND ----------

# DBTITLE 1,Convert the raw file timestamp format
def ts_format_conversion(df, column_list):
    '''
    Description:
    This function is used to convert the Mainframe timestamp to standart timestamp.
    :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
    :param column_list: [Type: list] contains column name to convert as standard timestamp.
    :param df: [Type: pyspark.sql.dataframe.Dataframe]converted dataframe
    '''
    try:
        for col_name in column_list:
            df = df.withColumn(col_name, to_timestamp(col(col_name), 'yyyy-MM-dd-HH.mm.ss.SSSSSS'))
        return df
    except Exception as e:
        raise Exception("ts_format_conversion: ", str(e))

# COMMAND ----------

# DBTITLE 1,List the non string and Timestamp columns and trim them
def non_string_col_builder(schema):
    ts_list, non_string_list = [], []
    for col, dtype in schema.items():
        if dtype != 'STRING':
            non_string_list.append(col)
            if dtype == 'TIMESTAMP':
                ts_list.append(col)
    return ts_list, non_string_list

def trim_leading_trailing_space(df):
    try:
        lst = [f"CASE WHEN trim({col}) = '' THEN {col} ELSE trim({col}) END AS {col}" for col in df.columns]
        # df.   select([trim(col(c)).alias(c) if c in lst else col(c) for c in df.columns])
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("trim_leading_trailing_space: ", str(e))

# COMMAND ----------

# DBTITLE 1,Addition of audit columns
def add_audit_columns(df):
    '''
    Description:
    This function is used to audit columns.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        split_col = split(input_file_name(),'/')
        cols_map = {
                'LoadDate' : lit(current_date()).cast('date'),
                'LoadTimestamp' : lit(current_timestamp()).cast('timestamp'),
                'FileName' : split_col[(size(split_col) - 1)].cast('string'),
                'RunId' : lit(None).cast('String')
        }
        return df.withColumns(cols_map)
    except Exception as e:
        raise Exception("add_audit_columns: ", str(e))

# COMMAND ----------

# DBTITLE 1,Mark the records IGNORE, UPDATE, DELETE, INSERT based on based on business keys of each file
def add_calc_column(df, keys, load_type):
    agg_df = df.groupBy(*keys).count()
    joined_df = df.join(agg_df, keys)
    if load_type == 'DeltaLoad':
        cols_map = {
                'DerivedIndicator' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('INSERT'))\
                        .when((col('count') == 1) & (col('Ind1') == 'DEL'), lit('DELETE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'ADD'), lit('UPDATE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'DEL'), lit('IGNORE'))\
                        .when((col('count') >= 3) , lit('IGNORE')),
                'Status' : when(col('count') >= 3, lit('R')).otherwise(lit('S')),
                'RejectReason' : when(col('count') >= 3, lit('Incorrect record')).otherwise(lit(None))
        }
    elif load_type == 'FullLoad':   
        cols_map = {
                'DerivedIndicator' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('INSERT'))\
                                    .otherwise(lit('IGNORE')),
                'Status' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('S'))\
                    .otherwise(lit('R')),
                'RejectReason' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit(None))\
                    .otherwise(lit('Incorrect Record'))
        }
    else:
        raise Exception("Please check the load_type. Its not valid")
    df = joined_df.withColumns(cols_map).drop('count')
    return df

# COMMAND ----------

def add_calc_column_keep_one(df, keys, load_type):

    if load_type == 'DeltaLoad':
        window_spec = Window.partitionBy(*keys,'Ind1').orderBy(*keys)
        rn_clac_df = df.withColumn('RN', row_number().over(window_spec))

        cols_map = {
            "DerivedIndicator": when(col('RN') == 1,lit(None)).otherwise(lit('IGNORE')),
            "Status":when(col('RN') == 1,lit('S')).otherwise(lit('R')),
            "RejectReason":when(col('RN') == 1,lit(None)).otherwise(lit('Duplicate Record'))}

        df_all = rn_clac_df.withColumns(cols_map).drop("RN")
        df_duplicate = df_all.filter(col('Status') == 'R')
            
        df = df_all.filter(col('Status') == 'S')
        agg_df = df.groupBy(*keys).count()
        joined_df = df.join(agg_df, keys)

        cols_map = {
                'DerivedIndicator' : when((col('count') == 1) & (col('Ind1') == 'ADD'), lit('INSERT'))\
                        .when((col('count') == 1) & (col('Ind1') == 'DEL'), lit('DELETE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'ADD'), lit('UPDATE'))\
                        .when((col('count') == 2) & (col('Ind1') == 'DEL'), lit('IGNORE'))\
                        .when((col('count') >= 3) , lit('IGNORE')),
                'Status' : when(col('count') >= 3, lit('R')).otherwise(lit('S')),
                'RejectReason' : when(col('count') >= 3, lit('Incorrect record')).otherwise(lit(None))}
        
        df = joined_df.withColumns(cols_map).drop('count')

        df = df.unionAll(df_duplicate)
        return df

    elif load_type == 'FullLoad':   
        window_spec = Window.partitionBy(*keys).orderBy(*keys)
        rn_clac_df = df.withColumn('RN', row_number().over(window_spec))

        cols_map = {
            "DerivedIndicator":when(col('RN') == 1,lit('INSERT')).otherwise(lit('IGNORE')),
            "Status":when(col('RN') == 1,lit('S')).otherwise(lit('R')),
            "RejectReason":when(col('RN') == 1,lit(None)).otherwise(lit('Incorrect Record'))}

        df = rn_clac_df.withColumns(cols_map).drop("RN")
        return df

    else:
        raise Exception("Please check the load_type. Its not valid")


# COMMAND ----------

# DBTITLE 1,DataType conversion as raw files has everything as STRING
def dtype_conversion(df, schema):
    try:   
        '''
        Description:
        This function is used to convert the data type of each column.
        :param df: [Type: pyspark.sql.dataframe.Dataframe] contains data to convert the data type.
        :param schema: [Type: dictionary] contains column name as key and column value as data type.
        :param df: [Type: pyspark.sql.dataframe.Dataframe]converted data type dataframe
        '''
        lst = []
        for col_name, dtype in schema.items():
            alias_name = col_name.replace("_", " ").title().replace(" ", "")
            lst.append(f"CAST({col_name} AS {dtype}) AS {alias_name}")
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("JobFailed dtype_conversion: ", str(e))

# COMMAND ----------

# DBTITLE 1,Create the partition column before loading data into stage tables
def defPartDate(final_df,partCol,DtFormat):
    try:
        final_df = final_df.withColumn('YYYY', date_format(partCol,DtFormat))
        return final_df
    except Exception as e:
        raise Exception("defPartDate: ", str(e))

# COMMAND ----------

# DBTITLE 1,Create the stage table unique identifier 
def add_StgUnqId(input_df):
    windowSpec = Window().orderBy(lit('A'))
    return input_df.withColumn('StgUnqId', row_number().over(windowSpec))

# COMMAND ----------

# DBTITLE 1,Stage full name derive from stage table
def stg_full_name_from_stage(stg_tbl_name):
    schema_name = stg_tbl_name.split(".")[1]
    module = stg_tbl_name.split(".")[2].split("_")[0]
    tbl_name = stg_tbl_name.split(".")[2].split("_")[1].replace("Stage","")
    return catalog_name+"."+schema_name+"."+module+"_"+tbl_name

# COMMAND ----------

# DBTITLE 1,Write the final datafrane to stage tables
#removed path
def write_as_table(df, tbl_name, partCol=None, format_type='delta', mode = 'overwrite'):
    try:
        if partCol is not None:
            df.write.format(format_type).mode(mode).partitionBy(f'{partCol}').saveAsTable(f'{tbl_name}')
        elif partCol is None:
            df.write.format(format_type).mode(mode).saveAsTable(f'{tbl_name}')   
        else:
            df.write.format(format_type)\
                .mode(mode).saveAsTable(f'{tbl_name}')
        spark.sql(f"AlTER table {tbl_name} owner to {write_role}")
        spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {tbl_name} TO {write_role}")
        spark.sql(f"GRANT SELECT ON TABLE {tbl_name} TO {read_role}")    
    except Exception as e:
        raise Exception("JobFailed write_as_table: ", str(e))

# COMMAND ----------

# DBTITLE 1,Main function to sequentially call the functions & load the raw file into stage
def main_function(file_config, load_type, table_name, schema, buz_keys, reject_dup="Yes",stage_full="NoStageFull"):
    try:
        container_name = file_config['ContainerName'] if 'ContainerName' in file_config.keys() else ""
        storage_account = file_config['StorageAccountName'] if 'StorageAccountName' in file_config.keys() else ""
        src_path_suffix = file_config['FilePathSuffix'] if 'FilePathSuffix' in file_config.keys() else ""
        stg_path_suffix = file_config['StagePathSuffix'] if 'StagePathSuffix' in file_config.keys() else ""        
        src_regex = file_config['FileRegex'] if 'FileRegex' in file_config.keys() else ""
        config = file_config['Config'] if 'Config' in file_config.keys() else ""
        source_file_format = file_config['SourceFileFormat'] if 'SourceFileFormat' in file_config.keys() else ""
        partCol = file_config['partCol'] if 'partCol' in file_config.keys() else None
        DtFormat = file_config['DtFormat'] if 'DtFormat' in file_config.keys() else None


        source_path = path_builder(container_name, storage_account, src_path_suffix, src_regex)
        stage_path = path_builder(container_name, storage_account, stg_path_suffix)
        df = read_csv(path= source_path, format_type = source_file_format, config = config)

        validated_df = validate_fullload(df,load_type)
        ts_lst, non_str_lst = non_string_col_builder(schema)
        ts_trans_df = ts_format_conversion(trim_leading_trailing_space(validated_df) ,ts_lst)
        dtype_transd_df= dtype_conversion(ts_trans_df, schema)
        col_added_df = add_audit_columns(dtype_transd_df)

        if stage_full == "StageFull":
            load_stage_full_df = col_added_df.drop("LoadDate","FileName","RunId")
            stage_full_table_name = stg_full_name_from_stage(table_name)
            write_stage_full(load_stage_full_df, stage_full_table_name, load_type, buz_keys)

        stg_unique_id_added_df = add_StgUnqId(col_added_df)

        # duplicate check & deriving indicator
        if reject_dup == "Yes":
            final_df = add_calc_column(stg_unique_id_added_df, buz_keys, load_type)
        elif reject_dup == "KeepOne":
            final_df = add_calc_column_keep_one(stg_unique_id_added_df, buz_keys, load_type)

        # writing into stagetable
        if DtFormat is None or partCol is None:
            write_as_table(df=final_df, tbl_name = table_name)
        else:
            final_df = defPartDate(final_df, partCol, DtFormat)
            write_as_table(df=final_df, tbl_name = table_name, partCol=DtFormat)
        
    except Exception as e:
        raise Exception("JobFailed stage main function: ", str(e))

# COMMAND ----------

# DBTITLE 1,Read the JSON file and get information of each table
def get_table_config(path):
    try:
        with open(path) as f:
            src_file = json.load(f)
        tbl_dtl_df = pd.json_normalize(src_file, record_path = ['table_details'], meta = ['subject_area'])
        spark_df = spark.createDataFrame(tbl_dtl_df).cache()
        return spark_df
    except: 
        raise Exception("Table details config file not found. Please check...")

# COMMAND ----------

# DBTITLE 1,Read the JSON file into dataframe
def get_file_config(path):
    try:
        with open(file_conf_path) as json_file:
            config_dict = json.load(json_file)
        return config_dict
    except Exception as e:
        raise Exception("get_file_config failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Write the dataframe into Stage Full Table
def write_stage_full(final_df, stage_full_table_name, load_type, buz_keys, format_type = "delta"):
    try:
        if load_type == "FullLoad":
            # deciding version number
            if spark.catalog.tableExists(stage_full_table_name):
                version_num = spark.sql(f"DESCRIBE HISTORY {stage_full_table_name} LIMIT 1").select('version').collect()[0][0] + 1
            else:
                version_num = 0
 
            # adding version number in the dataframe
            version_num_added_df = final_df.withColumn("version",lit(version_num))
 
            # writing into stage
            version_num_added_df.write.format(format_type).mode("overwrite").saveAsTable(f'{stage_full_table_name}')
            spark.sql(f"AlTER table {stage_full_table_name} owner to {write_role}")
            spark.sql(f"GRANT ALL PRIVILEGES ON TABLE {stage_full_table_name} TO {write_role}")
            spark.sql(f"GRANT SELECT ON TABLE {stage_full_table_name} TO {read_role}") 

 
        elif load_type == "DeltaLoad":
            final_add_df = final_df.filter(col('IND1')=="ADD")
            final_del_df = final_df.filter(col('IND1')=="DEL")
 
            StageFullTable= DeltaTable.forName(spark, stage_full_table_name)
            cond_list = []
            for key in buz_keys:
                cond_list.append('Tgt.'+key+'='+'Src.'+key)
            conditions = ' and '.join(cond_list)
 
            StageFullTable.alias('Tgt')\
                .merge(final_del_df.alias('Src'), conditions)\
                .whenMatchedDelete(condition = "Src.IND1='DEL'")\
                .execute()
 
            # deciding version number & adding it
            version_num = spark.sql(f"DESCRIBE HISTORY {stage_full_table_name} LIMIT 1").select('version').collect()[0][0] + 1
            version_num_added_df = final_add_df.withColumn("version", lit(version_num))
 
            StageFullTable.alias('Tgt')\
                .merge(version_num_added_df.alias('Src'), conditions)\
                .whenNotMatchedInsertAll(condition = "Src.IND1='ADD'")\
                .execute()
    except Exception as e:
        raise Exception("stage full table update failed: ", str(e))
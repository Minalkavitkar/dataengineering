# Databricks notebook source
# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../Utility/Helpers/AdlsHelper
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Database creation.
# database_name = f"Audit{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name}""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# DBTITLE 1,Create table script.
query = f"""CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.audit_AuditTable(
    TaskId STRING,
    RunId STRING,
    ProcessName STRING,
    PipelineGroupName STRING,
    SequenceNumber INT,
    RunDate DATE,
    Status STRING,
    StartDatetime TIMESTAMP,
    EndDatetime TIMESTAMP,
    Message STRING,
    ErrorCode STRING
)partitioned by (ProcessName)"""
# USING DELTA LOCATION 'abfss://log@{env_storage_account_name}.dfs.core.windows.net/audit/AuditTable'
# partitioned by (ProcessName);"""

# COMMAND ----------

# DBTITLE 1,Execute script
spark.sql(query)
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREXPSP
# MAGIC ##### Curated Tables
# MAGIC - Product.ProductSetAssociation
# MAGIC ##### Target Table
# MAGIC - Product.ProductSetAssociation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'PRODUCT_TREXPSP'
buz_keys = ['PrdSetGenKey','ProdNbr']
not_null_col_lst = ['ProductKey','ProductSetKey']
table_code = "Product_ProductSetAssociation" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProductSetAssociation') 
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
pipeline_name = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Product', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Product', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProductStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    child_tbl_config_path = conf["ChildTblConfigPath"]
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prd_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_Product')
    prdset_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_ProductSet')
    stage_trepdst_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREPDST_FULL")
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trexpsp_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading the stage table, parent curated table & Filter the valid records
try:
    trexpsp_stage_df = read_table_to_df(stage_tbl_name)
    validated_df = trexpsp_stage_df.filter(trexpsp_stage_df["Status"] == 'S')
    product_df = read_table_to_df(prd_cur_tbl_name)
    productset_df = read_table_to_df(prdset_cur_tbl_name)
    trepdst_stage_full_df = read_table_to_df(stage_trepdst_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

# DBTITLE 1,Join with ProductSet Stage Full to get PrdSetGenKey
#join with product set table
try:
    trepdst_keys_added_df = validated_df.alias('LH')\
        .join(trepdst_stage_full_df.alias('RH'),\
            (col('LH.PrdSetGenKey')== col('RH.PrdSetGenKey')),\
                'left')\
        .select('LH.*','RH.PrdSetId','RH.ReLob')
except Exception as e:
    raise Exception('joining with Product Set failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping
column_mapping ={
'PrdSetId': 'ProductSetId',
'ReLob': 'LineOfBusinessCode',
'ProdNbr':'ProdNbr',
'StgUnqId':'StgUnqId',
"RunId":"RunId",
"DerivedIndicator":"DerivedIndicator",
"Status":"Status",
"RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Adding audit columns, Renaming columns
try:
    col_mapped_df = col_name_mapping(trepdst_keys_added_df,column_mapping)
    audit_col_added_df = add_tgt_audit_column(col_mapped_df,pipeline_name,LOAD_TYPE)
except Exception as e:
    raise Exception('column mapping or audit columns addition failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with Product to get ProductKey
try:
    product_joined_df = audit_col_added_df.alias('LH')\
    .join(product_df.alias('RH'),\
        (col('LH.ProdNbr')== col('RH.ExtProdSeqNo')),\
                'left')\
    .select('LH.*','RH.ProductKey')
except Exception as e:
    raise Exception('joining with product failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProductSet to get ProductSetKey
#join with product set table
try:
    joined_df = product_joined_df.alias('LH')\
        .join(productset_df.alias('RH'),\
            (col('LH.ProductSetId')== col('RH.ProductSetId')) & \
                (col('LH.LineOfBusinessCode')== col('RH.LineOfBusinessCode')),\
                'left')\
        .select('LH.*','RH.ProductSetKey')
except Exception as e:
    raise Exception('joining with product set failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Removing orphan records and unwanted columns
try:
    invalid_records_removed_df = remove_invalid_records(joined_df, stage_tbl_name, not_null_col_lst)

    uniq_keys = ["ProductKey","ProductSetKey"]
    delta_final_df = remove_dup_records(invalid_records_removed_df, uniq_keys, stage_tbl_name)\
        .drop('RunId','Status','RejectReason','StgUnqId')
                
    final_df = delta_final_df.drop('LineOfBusinessCode','ProductSetId','ProdNbr')
except Exception as e:
    raise Exception('filtering the valid records failed: ',str(e)) 

# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProductDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        prd_set_assoc_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(prd_set_assoc_df, 'Product.ProductSetAssociation')
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['ProductKey','ProductSetKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProductSetAssociationKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProductSetAssociationKey':lit(None).cast("BIGINT"),
        'ProductKey': lit(None).cast("BIGINT"),
        'ProductSetKey':  lit(None).cast("BIGINT")
        }
        mapped_df= delta_final_df.withColumns(mapping)
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Product.StageProductSetAssociation')
        
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)


except Exception as e:
    raise Exception ('load failed: ',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREXAFL
# MAGIC ##### Curated Tables
# MAGIC - Product.ProductSetAssociation
# MAGIC ##### Target Table
# MAGIC - Product.ProductSetAssociation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "PRODUCT_TREXAFL"
buz_keys = ['AffilGenKeyMbr','AffilGenKeyOwn']
not_null_col_lst = ['ProductAffiliationKey','GeoMarketAffiliationKey']
table_code = "Product_ProductGeoMarketAffiliation" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProductGeoMarketAffiliation') 
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Product', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Product', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProductStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    child_tbl_config_path = conf["ChildTblConfigPath"]
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    geo_mkt_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_GeoMarketAffiliation')
    prd_aff_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_ProductAffiliation')
    stage_trepdaf_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREPDAF_FULL")
    stage_tregoaf_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREGOAF_FULL")
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trexafl_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading the stage table, parent curated table & Filter the valid records
try:
    trexafl_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    pro_aff_df = read_table_to_df(prd_aff_cur_tbl_name)
    geo_mkt_aff_df = read_table_to_df(geo_mkt_cur_tbl_name)
    trepdaf_stage_full_df = read_table_to_df(stage_trepdaf_full_tbl_name)
    tregoaf_stage_full_df = read_table_to_df(stage_tregoaf_full_tbl_name)
except Exception as e:
    raise Exception("Reading stage table or parent table failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Filtering out non-relevant records and dividing the dataframe
#splitting into dataframes based on type code GEO or PRD and union it.
try:
    filtered_trexafl_stage_df1 = trexafl_stage_df.filter((col('AffilTyCdOwn') == 'GEO' ) & (col('AffilTyCdMbr') == 'PRD' ))\
        .select(col('AffilGenKeyMbr').alias('ProductTablesKeyOld'),col('AffilGenKeyOwn').alias('GeoMarketsKeyOld'),'StgUnqId','Status','RejectReason','DerivedIndicator')

    filtered_trexafl_stage_df2 = trexafl_stage_df.filter((col('AffilTyCdOwn') == 'PRD' ) & (col('AffilTyCdMbr') == 'GEO' ))\
        .select(col('AffilGenKeyMbr').alias('GeoMarketsKeyOld'),col('AffilGenKeyOwn').alias('ProductTablesKeyOld'),'StgUnqId','Status','RejectReason','DerivedIndicator')

    union_trexafl_stage_df = filtered_trexafl_stage_df1.unionByName(filtered_trexafl_stage_df2)\
        .selectExpr("CAST(trim(ProductTablesKeyOld) AS Integer) as PrdAffilGenKeyDrv", "CAST(trim(GeoMarketsKeyOld) AS Integer) as GeoAffilGenKeyDrv",'StgUnqId','Status','RejectReason','DerivedIndicator')\
        .distinct()
        
except Exception as e:
    raise Exception("GEO or PRD processing failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with Trepdaf Stage Full to get PrdTableId and ReLob
#join with product Affiliation table
try:
    trepdaf_keys_added_df = union_trexafl_stage_df.alias('LH')\
        .join(trepdaf_stage_full_df.alias('RH'),\
            (col('LH.PrdAffilGenKeyDrv')== col('RH.PrdAffilGenKey')),\
                'left')\
        .select('LH.*','RH.PrdTableId','RH.ReLob')
except Exception as e:
    raise Exception('joining with Product Affiliation failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with Tregoaf Stage Full to get GeoMktId
#join with Geo Market Affiliation table
try:
    tregoaf_keys_added_df = trepdaf_keys_added_df.alias('LH')\
        .join(tregoaf_stage_full_df.alias('RH'),\
            (col('LH.GeoAffilGenKeyDrv')== col('RH.GeoAffilGenKey')),\
                'left')\
        .select('LH.*','RH.GeoMktId')
except Exception as e:
    raise Exception('joining with Geo Market Affiliation failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProductAffiliation to get ProductAffiliationKey
try:
    pro_aff_joined_df = tregoaf_keys_added_df.alias('LH')\
                        .join(pro_aff_df.alias('RH'), (col('LH.PrdTableId')== col('RH.LocationId')) & \
                (col('LH.ReLob')== col('RH.LineOfBusinessCode')), 'left').select('LH.*','RH.ProductAffiliationKey')
except Exception as e:
    raise Exception("join with product affilation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with GeoMarketAffiliation to get GeoMarketAffiliationKey
try:
    joined_df = pro_aff_joined_df.alias('LH')\
                            .join(geo_mkt_aff_df.alias('RH'), col('LH.GeoMktId') == col('RH.GeographicMarketId'), 'left').select('LH.*','RH.GeoMarketAffiliationKey')
except Exception as e:
    raise Exception("join with geo market affilation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping
column_mapping = {
'GeoMarketAffiliationKey': 'GeoMarketAffiliationKey',
'ProductAffiliationKey': 'ProductAffiliationKey',
'GeoMktId':'GeographicMarketId',
'ReLob':'LineOfBusinessCode',
'PrdTableId':'LocationId',
'StgUnqId':'StgUnqId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Columns renaming
try:
    col_mapped_df = col_name_mapping(joined_df,column_mapping)
except Exception as e:
    raise Exception('column mapping or audit columns addition failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    valid_df = remove_invalid_records(col_mapped_df, stage_tbl_name, not_null_col_lst)\
                .drop('Status','RejectReason','StgUnqId')

    remove_duplicate_df = valid_df.distinct()

    final_df = add_tgt_audit_column(remove_duplicate_df,PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('Removing invalide records failed: ',str(e)) 

# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProductDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df, cur_tbl_name)
        cur_loaded_time = datetime.now()
                
        pro_geo_mkt_aff_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','GeographicMarketId','LocationId','LineOfBusinessCode')
        load_df_to_sf_sql_db_spark(pro_geo_mkt_aff_df, 'Product.ProductGeoMarketAffiliation')
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['ProductAffiliationKey','GeoMarketAffiliationKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProductGeoMarketAffiliationKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'GeoMarketAffiliationKey':lit(None).cast("BIGINT"),
        'ProductAffiliationKey': lit(None).cast("BIGINT"),
        'ProductGeoMarketAffiliationKey':  lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Product.StageProductGeoMarketAffiliation')
        
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception ('load failed: ',str(e))
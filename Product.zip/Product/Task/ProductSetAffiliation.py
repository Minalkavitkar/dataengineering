# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREXAFP
# MAGIC ##### Curated Tables
# MAGIC - Product.ProductSetAffiliation
# MAGIC ##### Target Table
# MAGIC - Product.ProductSetAffiliation

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "PRODUCT_TREXAFP"
buz_keys = ['PrdSetGenKey','PrdAffilGenKey']
not_null_col_lst = ['ProductAffiliationKey','ProductSetKey']
table_code = "Product_ProductSetAffiliation" 

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_ProductSetAffiliation')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')  

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Product', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Product', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./ProductStageSchema

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    child_tbl_config_path = conf["ChildTblConfigPath"]
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    prd_set_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_ProductSet')
    prd_aff_cur_tbl_name = table_name_selector(tbl_conf_df, 'Product_ProductAffiliation')
    stage_trepdst_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREPDST_FULL")
    stage_trepdaf_full_tbl_name = table_name_selector(tbl_conf_df, "PRODUCT_TREPDAF_FULL")
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading Stage Table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, trexafp_schema, buz_keys)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading the stage table, parent curated table & Filter the valid records
try:
    trexafp_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')\
                        .select('PrdSetGenKey','PrdAffilGenKey','StgUnqId','RunId','DerivedIndicator','Status','RejectReason')
    prd_pdst_header_df = read_table_to_df(prd_set_cur_tbl_name)
    prd_pdaf_header_df = read_table_to_df(prd_aff_cur_tbl_name)
    trepdst_stage_full_df = read_table_to_df(stage_trepdst_full_tbl_name)
    trepdaf_stage_full_df = read_table_to_df(stage_trepdaf_full_tbl_name)
except Exception as e:
    raise Exception("reading table or filtering valid records failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with Trepdst Stage Full to get PrdSetId and ReLob
#join with product set table
try:
    trepdst_keys_added_df = trexafp_stage_df.alias('LH')\
        .join(trepdst_stage_full_df.alias('RH'),\
            (col('LH.PrdSetGenKey')== col('RH.PrdSetGenKey')),\
                'left')\
        .select('LH.*','RH.PrdSetId',col("RH.ReLob").alias("PrdSetReLob"))
except Exception as e:
    raise Exception('joining with Product Set failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with Trepdaf Stage Full to get PrdTableId and ReLob
#join with product Affiliation table
try:
    trepdaf_keys_added_df = trepdst_keys_added_df.alias('LH')\
        .join(trepdaf_stage_full_df.alias('RH'),\
            (col('LH.PrdAffilGenKey')== col('RH.PrdAffilGenKey')),\
                'left')\
        .select('LH.*','RH.PrdTableId',col("RH.ReLob").alias("PrdAffReLob"))
except Exception as e:
    raise Exception('joining with Product Affiliation failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProductSet to get ProductSetKey
try:
    pdst_trexafp_joined_df = trepdaf_keys_added_df.alias('LH')\
    .join(prd_pdst_header_df.alias('RH'), (col('LH.PrdSetId')== col('RH.ProductSetId')) & \
                (col('LH.PrdSetReLob')== col('RH.LineOfBusinessCode')), 'left').select('LH.*','RH.ProductSetKey')
except Exception as e:
    raise Exception("join with product set failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Join with ProductAffiliation to get ProductAffiliationKey
try:
    pdaf_pdst_trexafp_joined_df = pdst_trexafp_joined_df.alias('LH')\
    .join(prd_pdaf_header_df.alias('RH'), (col('LH.PrdTableId')== col('RH.LocationId')) & \
                (col('LH.PrdAffReLob')== col('RH.LineOfBusinessCode')), 'left').select('LH.*','RH.ProductAffiliationKey')
except Exception as e:
    raise Exception("join with product affiliation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Column mapping
column_mapping = {
'ProductSetKey':'ProductSetKey',
'ProductAffiliationKey':'ProductAffiliationKey',
'PrdSetId':'ProductSetId',
'PrdSetReLob':'PSLineOfBusinessCode',
'PrdAffReLob':'PALineOfBusinessCode',
'PrdTableId':'LocationId',
'StgUnqId':'StgUnqId',
'RunId':'RunId',
'DerivedIndicator':'DerivedIndicator',
'Status':'Status',
'RejectReason':'RejectReason'
}

# COMMAND ----------

# DBTITLE 1,Adding audit columns, Renaming columns
try:
    col_mapped_df = col_name_mapping(pdaf_pdst_trexafp_joined_df,column_mapping)
    audit_col_added_df = add_tgt_audit_column(col_mapped_df,PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception('column mapping or audit columns addition failed: ',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    final_df = remove_invalid_records(audit_col_added_df, stage_tbl_name, not_null_col_lst)\
                .drop('RunId','Status','RejectReason','StgUnqId')

except Exception as e:
    raise Exception('Removing invalide records failed: ',str(e)) 

# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./ProductDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(final_df, cur_tbl_name )
        cur_loaded_time = datetime.now()
        
        prd_set_aff_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator','ProductSetId','PSLineOfBusinessCode','PALineOfBusinessCode','LocationId')
        load_df_to_sf_sql_db_spark(prd_set_aff_df, 'Product.ProductSetAffiliation')
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['ProductAffiliationKey','ProductSetKey']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path,"ProductSetAffiliationKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'ProductSetAffiliationKey':lit(None).cast("BIGINT"),
        'ProductAffiliationKey': lit(None).cast("BIGINT"),
        'ProductSetKey':  lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)
        delta_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
       
        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Product.StageProductSetAffiliation')
        
        exit_notebook(run_id, "Product", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception('load failed: ',str(e)) 
# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "product/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|"
        },
        "SourceFileFormat" : "csv"
    },
    "PRODUCT_TREPRDT":{
        "FileRegex" : "PRODUCT_TREPRDT.TXT",
        "StagePathSuffix" : "product/stage/StageTREPRDT"
    },
    "PRODUCT_TREGOAF":{
        "FileRegex" : "PRODUCT_TREGOAF.TXT",
        "StagePathSuffix" : "product/stage/StageTREGOAF"
    },

    "PRODUCT_TREPDAF":{
        "FileRegex" : "PRODUCT_TREPDAF.TXT",
        "StagePathSuffix" : "product/stage/StageTREPDAF"
    },
    "PRODUCT_TREXAFP":{
        "FileRegex" : "PRODUCT_TREXAFP.TXT",
        "StagePathSuffix" : "product/stage/StageTREXAFP"
    },

    "PRODUCT_TREXAFL":{
        "FileRegex" : "PRODUCT_TREXAFL.TXT",
        "StagePathSuffix" : "product/stage/StageTREXAFL" 
    },
    "PRODUCT_TREPDST":{
        "FileRegex" : "PRODUCT_TREPDST.TXT",
        "StagePathSuffix" : "product/stage/StageTREPDST"
    },
    "PRODUCT_TREXPSP":{
        "FileRegex" : "PRODUCT_TREXPSP.TXT",
        "StagePathSuffix" : "product/stage/StageTREXPSP"
    }
}

# COMMAND ----------

treprdt_schema = {
    "SEQ_NBR":"INT"
    ,"PROD_PLAN_DATE":"INT"
    ,"PROD_LOB_CD":"STRING"
    ,"PROD_PLAN_NM":"STRING"
    ,"PROD_OPT_CD":"STRING"
    ,"PROD_MKT_NAME":"STRING"
    ,"CTRCT_BEG_DT":"STRING"
    ,"CTRCT_END_DT":"STRING"
    ,"PROD_CMT_1_TEXT":"STRING"
    ,"PROD_CMT_2_TEXT":"STRING"
    ,"NADJ_YR_NBR":"SMALLINT"
    ,"NADJ_SEQ_NBR":"SMALLINT"
    ,"EXP_ACCT_PFX_NBR":"INT"
    ,"PLTFM_CD":"STRING"
    ,"IND1":"STRING"
    ,"TIMESTAMP":"TIMESTAMP"
}

# COMMAND ----------

tregoaf_schema = {
    'GEO_AFFIL_TY_CD':'STRING'
    ,'GEO_AFFIL_GEN_KEY':'INT'
    ,'GEO_MKT_ID':'STRING'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'TIMESTAMP'       
}

# COMMAND ----------

trepdaf_schema = {
    'PRD_AFFIL_TY_CD':'STRING'
    ,'PRD_AFFIL_GEN_KEY':'INT'
    ,'PRD_TABLE_ID':'STRING'
    ,'RE_LOB':'STRING'
    ,'HMP_CD':'STRING'
    ,'REC_UPDT_DATE':'DATE'
    ,'REC_UPDT_ID':'STRING'
    ,'REC_UPDT_FAC_ID':'STRING'
    ,'PRD_TABLE_DESC':'STRING'
    ,'IND1':'STRING'
    ,'Timestamp':'TIMESTAMP'
}

# COMMAND ----------

trexafp_schema = {
    'PRD_SET_GEN_KEY':'INT'
    ,'PRD_AFFIL_GEN_KEY':'INT'
    ,'ACTION_CD':'STRING'
    ,'IND1':'STRING'
    ,'Timestamp':'TIMESTAMP'
}


# COMMAND ----------

trexafl_schema={
    'AFFIL_TY_CD_OWN':'STRING'
    ,'AFFIL_GEN_KEY_OWN':'INT'
    ,'AFFIL_TY_CD_MBR':'STRING'
    ,'AFFIL_GEN_KEY_MBR':'STRING'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

trepdst_schema ={
    'IND1': 'STRING',
 'Timestamp': 'TIMESTAMP',
 'PRD_SET_GEN_KEY': 'INT',
 'PRD_SET_ID': 'STRING',
 'RE_LOB': 'STRING',
 'HMP_CD': 'STRING',
 'REC_UPDT_DATE': 'DATE',
 'REC_UPDT_ID': 'STRING',
 'REC_UPDT_FAC_ID': 'STRING',
 'PRD_SET_DESC': 'STRING'
}

# COMMAND ----------

trexpsp_schema ={
'IND1': 'STRING',
'Timestamp': 'TIMESTAMP',
'PRD_SET_GEN_KEY':'INT',
'PROD_NBR':'INT',
'ACTION_CD':'STRING'
}

# COMMAND ----------

trerfcd_schema={
    'IND1':'STRING',
    'IND2':'STRING',
    'TIMESTAMP':'TIMESTAMP',
    'VARIABLE_ID':'STRING',
    'VARIABLE_CD':'STRING',
    'VARIABLE_DESC':'STRING',
    'REC_UPDT_ID':'STRING',
    'REC_UPDT_DT':'DATE'
}
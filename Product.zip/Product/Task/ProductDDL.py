# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates Product Curater Layer Tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Product{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product

# COMMAND ----------

product = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_Product(
  ProductKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) 
  ,ProductId VARCHAR(50)
  ,ExtProdSeqNo INT
  ,ExpenseAccountPrefixNumber INT
  ,LineOfBusinessCode VARCHAR(20)
  ,MarketNumber VARCHAR(50)
  ,OptNumber VARCHAR(10)
  ,PlanNumber VARCHAR(10)
  ,ProductComment1Text VARCHAR(128)
  ,ProductComment2Text VARCHAR(128)
  ,ProductPlanDate DATE
  ,ProductEndDate DATE
  ,ProductStartDate DATE
  ,SourceSystemCode VARCHAR(10)
  ,AdjustmentYearNumber SMALLINT
  ,AdjustmentSequenceNumber SMALLINT
  ,DerivedIndicator STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP

)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/Product'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductSet

# COMMAND ----------

product_set = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_ProductSet(
        ProductSetKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
        ProductSetId VARCHAR(50),
        LineOfBusinessCode VARCHAR(20),
        HMPCode VARCHAR(20),
        ProductSetDescription VARCHAR(128),
        DerivedIndicator STRING,
        CreatedBy STRING NOT NULL,
        CreatedDateTime TIMESTAMP NOT NULL,
        ModifiedBy STRING,
        ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/ProductSet'"""


# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductAffiliation

# COMMAND ----------

product_affiliation = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_ProductAffiliation(
        ProductAffiliationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
        AffiliationCode VARCHAR(20),
        HMPCode VARCHAR(20),
        LineOfBusinessCode VARCHAR(20),
        LocationDescription VARCHAR(128),
        LocationId VARCHAR(50),
        DerivedIndicator STRING,
        CreatedBy STRING NOT NULL,
        CreatedDateTime TIMESTAMP NOT NULL,
        ModifiedBy STRING,
        ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/ProductAffiliation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### GeoMarketAffiliation

# COMMAND ----------

geo_market_affiliation = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_GeoMarketAffiliation(
        GeoMarketAffiliationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
        ,GeographicMarketId VARCHAR(50)
        ,AffiliationCode VARCHAR(20)
        ,DerivedIndicator STRING
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/GeoMarketAffiliation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductSetAssociation

# COMMAND ----------

product_set_association = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_ProductSetAssociation
        (
        ProductSetAssociationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
        ProductSetKey BIGINT NOT NULL,
        ProductKey BIGINT NOT NULL,
        DerivedIndicator STRING,
        CreatedBy STRING NOT NULL,
        CreatedDateTime TIMESTAMP NOT NULL,
        ModifiedBy STRING,
        ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/ProductSetAssociation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductSetAffiliation

# COMMAND ----------

product_set_affiliation = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_ProductSetAffiliation(
        ProductSetAffiliationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
        ,ProductSetKey BIGINT NOT NULL
        ,ProductAffiliationKey BIGINT NOT NULL
        ,ProductSetId STRING
        ,PSLineOfBusinessCode STRING
        ,PALineOfBusinessCode STRING
        ,LocationId STRING
        ,DerivedIndicator STRING
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/ProductSetAffiliation'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProductGeoMarketAffiliation

# COMMAND ----------

product_geo_market_affiliation = f"""CREATE or REPLACE TABLE {catalog_name}.{schema_name}.product_ProductGeoMarketAffiliation(
        ProductGeoMarketAffiliationKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1)
        ,GeoMarketAffiliationKey BIGINT NOT NULL
        ,ProductAffiliationKey BIGINT NOT NULL
        ,GeographicMarketId STRING
        ,LineOfBusinessCode STRING
        ,LocationId STRING
        ,DerivedIndicator STRING
        ,CreatedBy STRING NOT NULL
        ,CreatedDateTime TIMESTAMP NOT NULL
        ,ModifiedBy STRING
        ,ModifiedDateTime TIMESTAMP
        )"""
        # USING DELTA
        # LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/product/curated/ProductGeoMarketAffiliation'"""

# COMMAND ----------

# DBTITLE 1,Table mapping
tbl_mapping = {
    "product_Product" : product
    ,"product_ProductSet" : product_set
    ,"product_ProductAffiliation" : product_affiliation
    ,"product_GeoMarketAffiliation" : geo_market_affiliation
    ,"product_ProductSetAssociation" : product_set_association
    ,"product_ProductSetAffiliation" : product_set_affiliation
    ,"product_ProductGeoMarketAffiliation" : product_geo_market_affiliation
}

# COMMAND ----------

# DBTITLE 1,DDL Execution
TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
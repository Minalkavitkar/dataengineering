# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Monthly Job 3831 creates ledger extract file with ledger and open/close fund period data
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC - Accounting.StageStopLossRule
# MAGIC - Accounting.StageStopLossDetail
# MAGIC - Accounting.StageFinanceLedgerHeader
# MAGIC - Accounting.StageFinanceLedgerFundPeriod
# MAGIC ###### Target Details (File)
# MAGIC - LedgerExtract.txt
# MAGIC - Accounting_re3831LedgerExtract
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
  file_conf_path = env_file_config_path
  fxd_wdth_path = env_fxd_wdt_file_config_path
  storage_account = env_storage_account_name
except Exception as e:
  excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
  job_name = JOB_NAME
  config_dict =  get_file_config(file_conf_path)
  fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)

except Exception as e:
  excep = 'Read File Config and Fixed Width File Config: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict['DEFAULT']
  default_out_config = default_config['Outbound']
  Re3831Monthly_config = config_dict[job_name]

  container_name = default_config['ContainerName']
  file_path_prefix = default_out_config['FilePathPrefix']
  config = default_out_config['Config']

  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  temp_path_suffix = Re3831Monthly_config["Outbound"]["TempFilePathSuffix"]   
  curated_path_suffix = Re3831Monthly_config["Outbound"]["CuratedFilePathSuffix"]
  outbnd_file_name = Re3831Monthly_config["Outbound"]["Filename"]
  Re3831Monthly= Re3831Monthly_config["Outbound"]["Tablename"]

  stg_stop_loss_rule = Re3831Monthly_config["Inbound"]["StageStopLossRule"]
  stg_stop_loss_detail = Re3831Monthly_config["Inbound"]["StageStopLossDetail"]
  stg_fin_ledger_hdr = Re3831Monthly_config["Inbound"]["StageFinanceLedgerHeader"]
  stg_fin_ledger_fnd_prd = Re3831Monthly_config["Inbound"]["StageFinaceLedgerFundPeriod"]
  sync_process_names = Re3831Monthly_config["Inbound"]["StageSyncProcessNames"]
  ctrl_table_name = default_config["AuditTableName"]
    
except Exception as e:
  excep = 'Variable assignment from FileConfig: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
  prc_status = start_process_check(ctrl_table_name, sync_process_names)
  if prc_status != True:
      dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
  excep = "ControlTable check failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    cur_delta_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        curated_path_suffix
    )
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix     
    )  
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account, 
        path_prefix=file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Define columns
finledgerhdr_cols=[
    'FinanceLedgerHeaderKey',
    'LedgerNumber',
    'FinanceLedgerGeographicCode',
    'HMPVsNonHMPIndicator',
    'LineOfBusinessCode',
    'FinanceNetVsGrossCode'
]

finledgerfundprd_cols=[
    'FinanceLedgerHeaderKey',
    'FundPeriodBeginDate',
    'FundPeriodEndDate',
    'FundPeriodStatusCode'
]



# COMMAND ----------

# DBTITLE 1,Read table as dataframe
try: 
    
  # Read the data from MeberCoverage Stage table(Adls).
  df_stoplossrule = read_table_to_df(stg_stop_loss_rule)
  
  # Read the data from Product Stage table(Adls).
  df_stoplossdetail = read_table_to_df(stg_stop_loss_detail).filter((col('StoplossRuleTypeCode') ==lit('PROD')) & (col('StoplossRuleCategoryCode') == lit('PRCCTL')))
  
  # Read the data from FinanceLedgerHeader Stage table(Adls).    
  df_finledgerhdr = read_table_to_df(stg_fin_ledger_hdr).select(*finledgerhdr_cols)

  # Read the data from Geomarketaffiliation Stage table(Adls).    
  df_finledgerfundprd = read_table_to_df(stg_fin_ledger_fnd_prd).select(*finledgerfundprd_cols)
       
except Exception as e:
  excep = "Read Sql Tables: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Joining the required tables 
try:
  df_fin_ledger = df_finledgerhdr.alias('fh').join(df_finledgerfundprd.alias('fp'),"FinanceLedgerHeaderKey")\
    .withColumn('FundPeriodBeginDate',date_format('FundPeriodBeginDate','yyyyMM'))\
    .withColumn('FundPeriodEndDate',date_format('FundPeriodEndDate','yyyyMM'))\
    .drop('FinanceLedgerHeaderKey')

  df_max_StopLossId = df_stoplossrule.join(df_stoplossdetail,'StoplossRuleKey')\
    .select(max('StopLossId').alias('StopLossId'))
  
  StopLossId=df_max_StopLossId.withColumn('StopLossId',col('StopLossId').substr(1,6)).first()[0]

except Exception as e:
  excep = ("Joining tables failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Find open fund date and closed fund date for each ledger
try:

    filter_df=df_fin_ledger.filter(col('FundPeriodBeginDate') <= StopLossId)
    
    Winow_spec= Window.partitionBy('LedgerNumber').orderBy(col('FundPeriodBeginDate').desc())
    Latest_ledgers=filter_df.withColumn('rn',row_number().over(Winow_spec)).filter(col('rn')<=10).drop('rn')

    find_open_and_close_dt= Latest_ledgers.withColumn('RefundpdOpenBegDate',when(col('FundPeriodStatusCode').isin('O','P'),col('FundPeriodBeginDate')))\
    .withColumn('RefundpdOpenEndDate',when(col('FundPeriodStatusCode').isin('O','P'),col('FundPeriodBeginDate')))\
    .withColumn('Refundpd1StClosedBegDate',when(~col('FundPeriodStatusCode').isin('O','P'),col('FundPeriodBeginDate')))\
    .withColumn('Refundpd1StClosedEndDate',when(~col('FundPeriodStatusCode').isin('O','P'),col('FundPeriodBeginDate')))

    grouped_df= find_open_and_close_dt.groupBy('LedgerNumber','FinanceLedgerGeographicCode','HMPVsNonHMPIndicator','LineOfBusinessCode','FinanceNetVsGrossCode')\
        .agg(count(col('LedgerNumber')).alias('RefundpdTotalFundpdCnt')\
        ,first('RefundpdOpenBegDate',ignorenulls=True).alias('RefundpdOpenBegDate')\
        ,first('RefundpdOpenEndDate',ignorenulls=True).alias('RefundpdOpenEndDate')\
        ,first('Refundpd1StClosedBegDate',ignorenulls=True).alias('Refundpd1StClosedBegDate')\
        ,first('Refundpd1StClosedEndDate',ignorenulls=True).alias('Refundpd1StClosedEndDate')\
        ,count(when(col('fp.FundPeriodStatusCode').isin('O','P'),True)).alias('RefundpdOpenFundpdCnt')\
        ,collect_list(struct('FundPeriodStatusCode','FundPeriodBeginDate','FundPeriodEndDate')).alias('struct_list'))

    grouped_df_fillna=grouped_df.fillna('000000',['RefundpdOpenBegDate','RefundpdOpenEndDate','Refundpd1StClosedBegDate','Refundpd1StClosedEndDate'])

except Exception as e:
    excep = ("Find open fund date and closed fund date for each ledger failed "+ str(e))
    output = {
    'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

col_list=[
    col('struct_list1.FundPeriodStatusCode').alias('FundPeriodStatusCode1'),
    col('struct_list1.FundPeriodBeginDate').alias('FundPeriodBeginDate1'),
    col('struct_list1.FundPeriodEndDate').alias('FundPeriodEndDate1'),
    col('struct_list2.FundPeriodStatusCode').alias('FundPeriodStatusCode2'),
    col('struct_list2.FundPeriodBeginDate').alias('FundPeriodBeginDate2'),
    col('struct_list2.FundPeriodEndDate').alias('FundPeriodEndDate2'),
    col('struct_list3.FundPeriodStatusCode').alias('FundPeriodStatusCode3'),
    col('struct_list3.FundPeriodBeginDate').alias('FundPeriodBeginDate3'),
    col('struct_list3.FundPeriodEndDate').alias('FundPeriodEndDate3'),
    col('struct_list4.FundPeriodStatusCode').alias('FundPeriodStatusCode4'),
    col('struct_list4.FundPeriodBeginDate').alias('FundPeriodBeginDate4'),
    col('struct_list4.FundPeriodEndDate').alias('FundPeriodEndDate4'),
    col('struct_list5.FundPeriodStatusCode').alias('FundPeriodStatusCode5'),
    col('struct_list5.FundPeriodBeginDate').alias('FundPeriodBeginDate5'),
    col('struct_list5.FundPeriodEndDate').alias('FundPeriodEndDate5'),
    col('struct_list6.FundPeriodStatusCode').alias('FundPeriodStatusCode6'),
    col('struct_list6.FundPeriodBeginDate').alias('FundPeriodBeginDate6'),
    col('struct_list6.FundPeriodEndDate').alias('FundPeriodEndDate6'),
    col('struct_list7.FundPeriodStatusCode').alias('FundPeriodStatusCode7'),
    col('struct_list7.FundPeriodBeginDate').alias('FundPeriodBeginDate7'),
    col('struct_list7.FundPeriodEndDate').alias('FundPeriodEndDate7'),
    col('struct_list8.FundPeriodStatusCode').alias('FundPeriodStatusCode8'),
    col('struct_list8.FundPeriodBeginDate').alias('FundPeriodBeginDate8'),
    col('struct_list8.FundPeriodEndDate').alias('FundPeriodEndDate8'),
    col('struct_list9.FundPeriodStatusCode').alias('FundPeriodStatusCode9'),
    col('struct_list9.FundPeriodBeginDate').alias('FundPeriodBeginDate9'),
    col('struct_list9.FundPeriodEndDate').alias('FundPeriodEndDate9'),
    col('struct_list10.FundPeriodStatusCode').alias('FundPeriodStatusCode10'),
    col('struct_list10.FundPeriodBeginDate').alias('FundPeriodBeginDate10'),
    col('struct_list10.FundPeriodEndDate').alias('FundPeriodEndDate10') 
]

# COMMAND ----------

# DBTITLE 1,Expand dataframe as per output layout
try:
    max_element= grouped_df_fillna.select('RefundpdTotalFundpdCnt').collect()[0][0]

    select_exprs= [col('struct_list').getItem(i).alias(f'struct_list{i+1}') for i in range(max_element)]
    
    list_to_col_df=grouped_df_fillna.select('*',*select_exprs).drop('struct_list')

    final_df=list_to_col_df.select('*',*col_list)\
        .withColumn('Filler',lpad(lit(' '),28,' '))\
        .drop('struct_list1','struct_list2','struct_list3','struct_list4','struct_list5','struct_list6','struct_list7','struct_list8','struct_list9','struct_list10')

except Exception as e:
    excep = ("Expand dataframe as per output layout failed "+ str(e))
    output = {
    'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

col_schema={
    'LedgerNumber':'string'
    ,'FinanceLedgerGeographicCode':'string'
    ,'HMPVsNonHMPIndicator':'string'
    ,'LineOfBusinessCode':'string'
    ,'FinanceNetVsGrossCode':'string'
    ,'Refundpd1StClosedBegDate':'string'
    ,'Refundpd1StClosedEndDate':'string'
    ,'RefundpdOpenBegDate':'string'
    ,'RefundpdOpenEndDate':'string'
    ,'RefundpdOpenFundpdCnt':'integer'
    ,'RefundpdTotalFundpdCnt':'integer'
    ,'FundPeriodStatusCode1':'string'
    ,'FundPeriodBeginDate1':'string'
    ,'FundPeriodEndDate1':'string'
    ,'FundPeriodStatusCode2':'string'
    ,'FundPeriodBeginDate2':'string'
    ,'FundPeriodEndDate2':'string'
    ,'FundPeriodStatusCode3':'string'
    ,'FundPeriodBeginDate3':'string'
    ,'FundPeriodEndDate3':'string'
    ,'FundPeriodStatusCode4':'string'
    ,'FundPeriodBeginDate4':'string'
    ,'FundPeriodEndDate4':'string'
    ,'FundPeriodStatusCode5':'string'
    ,'FundPeriodBeginDate5':'string'
    ,'FundPeriodEndDate5':'string'
    ,'FundPeriodStatusCode6':'string'
    ,'FundPeriodBeginDate6':'string'
    ,'FundPeriodEndDate6':'string'
    ,'FundPeriodStatusCode7':'string'
    ,'FundPeriodBeginDate7':'string'
    ,'FundPeriodEndDate7':'string'
    ,'FundPeriodStatusCode8':'string'
    ,'FundPeriodBeginDate8':'string'
    ,'FundPeriodEndDate8':'string'
    ,'FundPeriodStatusCode9':'string'
    ,'FundPeriodBeginDate9':'string'
    ,'FundPeriodEndDate9':'string'
    ,'FundPeriodStatusCode10':'string'
    ,'FundPeriodBeginDate10':'string'
    ,'FundPeriodEndDate10':'string'
    ,'Filler':'string'
}

col_mapping ={
    'LedgerNumber':'RefundpdPcaFinRptLedgrNbr'
    ,'FinanceLedgerGeographicCode':'RefundpdFinLedgrGeoCd'
    ,'HMPVsNonHMPIndicator':'RefundpdHmpVsNonHmpInd'
    ,'LineOfBusinessCode':'RefundpdFinLedgrLobCd'
    ,'FinanceNetVsGrossCode':'RefundpdFinNetVsGrossInd'
    ,'Refundpd1StClosedBegDate':'Refundpd1StClosedBegDate'
    ,'Refundpd1StClosedEndDate':'Refundpd1StClosedEndDate'
    ,'RefundpdOpenBegDate':'RefundpdOpenBegDate'
    ,'RefundpdOpenEndDate':'RefundpdOpenEndDate'
    ,'RefundpdOpenFundpdCnt':'RefundpdOpenFundpdCnt'
    ,'RefundpdTotalFundpdCnt':'RefundpdTotalFundpdCnt'
    ,'FundPeriodStatusCode1':'RefundpdFundPerStatInd1'
    ,'FundPeriodBeginDate1':'RefundpdPerBegCymDate1'
    ,'FundPeriodEndDate1':'RefundpdPerEndCymDate1'
    ,'FundPeriodStatusCode2':'RefundpdFundPerStatInd2'
    ,'FundPeriodBeginDate2':'RefundpdPerBegCymDate2'
    ,'FundPeriodEndDate2':'RefundpdPerEndCymDate2'
    ,'FundPeriodStatusCode3':'RefundpdFundPerStatInd3'
    ,'FundPeriodBeginDate3':'RefundpdPerBegCymDate3'
    ,'FundPeriodEndDate3':'RefundpdPerEndCymDate3'
    ,'FundPeriodStatusCode4':'RefundpdFundPerStatInd4'
    ,'FundPeriodBeginDate4':'RefundpdPerBegCymDate4'
    ,'FundPeriodEndDate4':'RefundpdPerEndCymDate4'
    ,'FundPeriodStatusCode5':'RefundpdFundPerStatInd5'
    ,'FundPeriodBeginDate5':'RefundpdPerBegCymDate5'
    ,'FundPeriodEndDate5':'RefundpdPerEndCymDate5'
    ,'FundPeriodStatusCode6':'RefundpdFundPerStatInd6'
    ,'FundPeriodBeginDate6':'RefundpdPerBegCymDate6'
    ,'FundPeriodEndDate6':'RefundpdPerEndCymDate6'
    ,'FundPeriodStatusCode7':'RefundpdFundPerStatInd7'
    ,'FundPeriodBeginDate7':'RefundpdPerBegCymDate7'
    ,'FundPeriodEndDate7':'RefundpdPerEndCymDate7'
    ,'FundPeriodStatusCode8':'RefundpdFundPerStatInd8'
    ,'FundPeriodBeginDate8':'RefundpdPerBegCymDate8'
    ,'FundPeriodEndDate8':'RefundpdPerEndCymDate8'
    ,'FundPeriodStatusCode9':'RefundpdFundPerStatInd9'
    ,'FundPeriodBeginDate9':'RefundpdPerBegCymDate9'
    ,'FundPeriodEndDate9':'RefundpdPerEndCymDate9'
    ,'FundPeriodStatusCode10':'RefundpdFundPerStatInd10'
    ,'FundPeriodBeginDate10':'RefundpdPerBegCymDate10'
    ,'FundPeriodEndDate10':'RefundpdPerEndCymDate10'
    ,'Filler':'Filler'
}

# COMMAND ----------

try:
  df_ledger_ext_trim = trim_leading_trailing_space(final_df)
  df_ledger_ext_trans = dtype_conversion(df_ledger_ext_trim, col_schema)
  df_ledger_ext_map = col_name_mapping(df_ledger_ext_trans, col_mapping)  

except Exception as e:
  excep = 'Datatype and column mapping failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to table and ADLS Gen2.
try:
  #write to table 
  write_df_as_delta_table(df_ledger_ext_map,Re3831Monthly)

  # Convert dataframe to fixed width length column.
  df_write_active_cov = convert_col_to_fixed_width(fixed_config_df, df_ledger_ext_map)
  
  # write dataframe as .txt file as position delimited.
  write_outbnd_file_to_adls(df_write_active_cov, temp_csv_path, config)

except Exception as e:
  excep = 'Write to ADLS: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving and renaming the .csv file to outbound folder.
try:
    #Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)

except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
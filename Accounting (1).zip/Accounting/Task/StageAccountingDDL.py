# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Product unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Accounting{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### SettlementProviderContract

# COMMAND ----------

# DBTITLE 0,Product table script.
settlement_provider_contract = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Accounting_StageSettlementProviderContract(
  SettlementProviderContractKey BIGINT NOT NULL,
  SettlementControlDetailKey BIGINT NOT NULL,
  PaymentContractKey BIGINT NOT NULL, 
  FinanceLedgerGeoMarketCode STRING,
  FinanceLedgerNumber INT,
  PaymentContractId STRING,
  PaymentContractName STRING,
  ProductLineOfBusinessCode STRING,
  ProviderContractDescription STRING,
  ProviderContractId STRING,
  ProviderContractKey BIGINT NOT NULL,
  ProviderGrouperId STRING,
  ProviderGrouperName STRING,
  SettlementContractId STRING,
  SettlementContractKey BIGINT NOT NULL,
  SettlementControlId STRING,
  CreatedBy STRING NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy STRING,
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://dataprocessing@{env_storage_account_name}.dfs.core.windows.net/processingdatabase/accounting/stage/SettlementProviderContract'"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###FinanceLedgerFundPeriod

# COMMAND ----------

finance_ledger_fund_period = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Accounting_StageFinanceLedgerFundPeriod(
	FinanceLedgerFundPeriodKey BIGINT NOT NULL,
	FinanceLedgerHeaderKey BIGINT NOT NULL,
	FundPeriodBeginDate date,
	FundPeriodEndDate date,
	FundPeriodStatusCode varchar(20),
	FundStatusChangeDate date,
	ApproverFullName varchar(55),
	FundExpenseCode varchar(20),
	FundPeriodAccountCode varchar(20),
	CreatedBy varchar(150) NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy varchar(150),
	ModifiedDateTime TIMESTAMP
	)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###FinanceLedgerHeader

# COMMAND ----------

finance_ledger_header = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Accounting_StageFinanceLedgerHeader(
	FinanceLedgerHeaderKey bigint NOT NULL,
	LedgerNumber int ,
	HMPVsNonHMPIndicator char(1) ,
	LedgerDescription varchar(128) ,
	LedgerStatusCode varchar(30) ,
	LedgerApproverName varchar(55) ,
	FinancialLedgerCode varchar(20) ,
	FinanceLedgerName varchar(55) ,
	LineOfBusinessCode varchar(20) ,
	FinanceLedgerGeographicCode varchar(20) ,
	CASNetworkNumber int ,
	CASLineOfBusinessCode varchar(20) ,
	CASProviderNetworkNumber int ,
	CASMarketNumber varchar(50) ,
	WithholdPerGrouperIndicator char(1) ,
	LedgerStatusDate date ,
	FinanceNetVsGrossCode varchar(20) ,
	GateKeeperLedgerIndicator char(1) ,
	CreatedBy varchar(150) NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy varchar(150), 
 	ModifiedDateTime TIMESTAMP 
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###StopLossRule

# COMMAND ----------

stop_loss_rule = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.Accounting_StageStoplossRule
(
	StoplossRuleKey BIGINT NOT NULL,
	StoplossRuleTypeCode STRING,
	StoplossRuleCategoryCode STRING,
    DerivedIndicator STRING,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP,
	flag STRING
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###StopLossDetail

# COMMAND ----------

stop_loss_detail = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.Accounting_StageStoplossDetail
(
    StoplossDetailKey BIGINT NOT NULL,
    StoplossRuleKey BIGINT NOT NULL,
    DerivedIndicator STRING,
    CreatedBy STRING NOT NULL,
    CreatedDateTime	TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP,
    StoplossDescription STRING,
    StoplossId STRING,
    StoplossRuleTypeCode STRING,
    StoplossRuleCategoryCode STRING
)"""

# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
    "Accounting_StageSettlementProviderContract" : settlement_provider_contract
    ,"Accounting_StageFinanceLedgerFundPeriod" : finance_ledger_fund_period
    ,"Accounting_StageFinanceLedgerHeader" : finance_ledger_header
    ,"Accounting_StageStopLossRule" : stop_loss_rule
    ,"Accounting_StageStopLossDetail" : stop_loss_detail

}

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    # Logic to create table based on the input parameter.
    # If 'All' is provided as parameter then it will create all table in the notebook.
    # If specific table names are provided in parameter then only those will run.
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
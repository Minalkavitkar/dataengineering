# Databricks notebook source
# MAGIC %md
# MAGIC ### Overview
# MAGIC - This notebook helps us keep the stage tables up to date with Azure SQL tables and adds an entry to the control table for the run. This process ensures that our data remains synchronized and that we maintain a record of each run in the control table, allowing for easy tracking and auditing of data updates

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Parameter Cell.
dbutils.widgets.text('PIPELINE_RUN_ID','')
dbutils.widgets.text('TABLE_NAMES','All')
dbutils.widgets.text('JOB_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')
JOB_TYPE= dbutils.widgets.get('JOB_TYPE')
PIPELINE_NAME= dbutils.widgets.get('PIPELINE_NAME')
subject_area = 'ProviderContract'

# COMMAND ----------

# DBTITLE 1,Read and parse SyncProcessConfig file.
try:
    sync_prc_conf_path = env_sync_prc_config_path
    conf_df = get_sync_process_config(sync_prc_conf_path)
    conf_filtered_df = select_required_tables_from_sync_config(conf_df, subject_area, TABLE_NAMES)
    conf_lst = convert_sync_config_df_to_lst(conf_filtered_df)
except Exception as e:
    excep = "Read and Parse SyncProcessConfig file" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Run StageDDL and PreTask.
try:
    # No of iteration is depends on the tables provided in SyncProcessConfig file.
    for sql_tbl_name, stg_tbl_name, merge_key, proc_name, ctrl_tbl_name, read_num_partition in conf_lst:
        tbl_name = stg_tbl_name.split('.')[2]
        tbl_run_status = 'Success'
        process_name = f"DBP#{JOB_TYPE}#{proc_name}"
        start_date_time = datetime.now()
        # If stage table not exists then execute the stage table DDL notebook.
        if not spark.catalog.tableExists(stg_tbl_name):
            tbl_run_status = dbutils.notebook.run('../Task/StageProviderContractDDL', 0, {'TABLE_NAMES' : tbl_name})
        # If the stage table DDL notebook run status is success then execute the StageTableSyncHelper notebook else raise exception.
        if tbl_run_status == 'Success':
            task_id = spark.range(1).withColumn('task_id', expr("uuid()")).collect()[0]["task_id"]
            # Write entry to audit table.
            insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, proc_name, JOB_TYPE, start_date_time, 'In Progress' ,ctrl_tbl_name, None,end_date_time= ' ' ,task_id = task_id)
            run_status = dbutils.notebook.run('../../Utility/Helpers/StageTableSyncHelper', 0, {'SQL_TABLE_NAME' : sql_tbl_name, 'STAGE_TABLE_NAME' : stg_tbl_name ,'MERGE_KEY' : merge_key,'PROCESS_NAME' : process_name, 'CONTROL_TABLE_NAME' : ctrl_tbl_name, 'READ_NUM_PARTITION' : read_num_partition,'PIPELINE_RUN_ID' : PIPELINE_RUN_ID})
            # update control table.
            if run_status == 'Success':
                update_audit_table(ctrl_tbl_name, task_id, 'Success', process_name)
            else:
                update_audit_table(ctrl_tbl_name,task_id, 'Failed', process_name, run_status)
        else:
            raise Exception(tbl_run_status)
except Exception as e:
    raise Exception("Run StageDDL and PreTask:", str(e))
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Provider Contract unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Adls connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContract

# COMMAND ----------

Provider_Contract = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContract(
  ProviderContractKey BIGINT NOT NULL
  ,ProviderKey BIGINT NOT NULL 
  ,ProviderId VARCHAR(50)
  ,ProviderSuffixCode VARCHAR(20)
  ,ProviderServiceTypeCode VARCHAR(20)
  ,ProviderSequenceNumber VARCHAR(50)
  ,AdditionalMaximumCount INTEGER
  ,FundPeriodBeginCode VARCHAR(20)
  ,CapitationBeginCode VARCHAR(20)
  ,CapitationEndCode VARCHAR(20)
  ,CategoryCode VARCHAR(20)
  ,ContractCountyCode VARCHAR(55)
  ,ContractStartDate DATE
  ,ContractEndDate DATE
  ,ContractEndReasonCode VARCHAR(20)
  ,ContractLagAnnualCount INT
  ,ContractLagPeriodCount INT
  ,ContractProgramTypeCode VARCHAR(20)
  ,DefaultStatusIndicator CHAR(1)
  ,DistanceCalculatedIndicator CHAR(1)
  ,DistanceLengthNumber VARCHAR(50)
  ,EverPaymentCode VARCHAR(20)
  ,FundClassCode VARCHAR(20)
  ,IndividualSettlementRuleCode VARCHAR(20)
  ,LateClaimCode VARCHAR(20)
  ,MemberLimitCode VARCHAR(20)
  ,MemberTypeCode VARCHAR(20)
  ,PaymentAccountNumber VARCHAR(50)
  ,PaymentDateNumber INTEGER
  ,PaymentOptionCode VARCHAR(20)
  ,ProductLineOfBusinessCode VARCHAR(20)
  ,ProviderContractDescription VARCHAR(128)
  ,ProviderContractId VARCHAR(50)
  ,ProviderGrouperId VARCHAR(50)
  ,ProviderMemberCount INTEGER
  ,RecoveryFundTypeCode VARCHAR(20)
  ,RecoveryMonthCount INTEGER
  ,RecoveryPaymentAmount DECIMAL(20,6)
  ,RecoveryPercent DECIMAL(20,6)
  ,RenewalDate DATE
  ,ReprocessIndicator CHAR(1)
  ,ReprocessDate DATE
  ,Settlement1Description VARCHAR(128)
  ,Settlement2Description VARCHAR(128)
  ,SettlementAnnualPaymentCode VARCHAR(20)
  ,SettlementByFundIndicator CHAR(1)
  ,SettlementFrequencyCode VARCHAR(20)
  ,SettlementPeriodPaymentCode VARCHAR(20)
  ,StatusCode VARCHAR(20)
  ,StatusDate DATE
  ,TerminationMaximumCount INTEGER
  ,ReportPackageControlId VARCHAR(50)
  ,ExpenseId VARCHAR(20)
  ,ReportControlId VARCHAR(50)
  ,ReportDetailIndicator CHAR(1)
  ,ReportIndicator BOOLEAN
  ,PCPSequenceNumber DECIMAL(10,5)
  ,PCPPlanYearCode VARCHAR(5)
  ,IPAIndicator CHAR(1)
  ,ReportOptionCode CHAR(1)
  ,MassMoveInd CHAR(1)
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractFund

# COMMAND ----------

Provider_Contract_Fund = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractFund(
ProviderContractFundKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
FundAccountKey BIGINT NOT NULL,
ProviderId VARCHAR(50),
ProviderSuffixCode VARCHAR(20),
ProviderServiceTypeCode VARCHAR(20),
ProviderSequenceNumber VARCHAR(50),
CompletionFactorId varchar(50),
ExpensedFundTypeCode varchar(20),
FundClaimCalculatedMethodCode varchar(20),
FundClaimRecoverIndicator CHAR(1),
FundExpenseMethodCode varchar(20),
FundIBNRMethodCode varchar(20),
FundIBNRPercent Decimal(10,5),
FundMethodCode varchar(20),
FundPeriodMonthCount INTEGER,
FundPlanClaimPaymentIndicator CHAR(1),
FundSequenceNumber INTEGER,
FundTypeCode varchar(20),
IBNRPeriodMonthCount INTEGER,
PartAEligibileIndicator CHAR(1),
PaymentLastDate DATE,
PeriodSettlementPayIndicator CHAR(1),
PeriodPaymentBasisCode varchar(20),
PeriodPaymentDirectPayPercent Decimal(10,5),
PeriodPaymentFrequencyCount INTEGER,
PrePaymentServiceIndicator CHAR(1),
ProviderDiscountKey BIGINT,
CapitationPaymentDate INT,
CapitationPaymentCode varchar(20),
CatastrophHoldBackIndicator CHAR(1),
ContnAdmnDayCount INTEGER,
FinalSettlementId varchar(50),
PaymentContractId varchar(50),
FundedAcountId varchar(50),
PeriodSettlementId varchar(50),
SharedFundGroupId VARCHAR(20),
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractGeoMktAffiliation

# COMMAND ----------

Provider_Contract_GeoMktAffiliation = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractGeoMktAffiliation(
ProviderContractGeoMktAffilKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
GeoMarketAffiliationKey BIGINT NOT NULL,
GeoMarketId VARCHAR(50),
ProviderContractId VARCHAR(50),
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP,
StartDate Date,
EndDate Date
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractProductAffiliation

# COMMAND ----------

Provider_Contract_ProductAffiliation = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractProductAffiliation(
ProviderContractProductAffiliationKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
ProductAffiliationKey BIGINT NOT NULL,
ProviderContractId VARCHAR(50),
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractPaymentHeader

# COMMAND ----------

Provider_Contract_PaymentHeader = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractPaymentHeader(
ProviderContractPymtHdrKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
PaymentTypeCode VARCHAR(20) NOT NULL,
PaymentDate DATE NOT NULL,
PaymentStatusCode VARCHAR(30),
PaymentStatusDate DATE,
PrimaryBroughtFrwrdPymtAmt DECIMAL(20,6),
CapitationPaymentAmount DECIMAL(20,6),
IMMCKPaymentAmount DECIMAL(20,6),
SettlementPaymentAmount DECIMAL(20,6),
ManualAdjustmentPaymentAmount DECIMAL(20,6),
NetPaymentAmount DECIMAL(20,6),
ProviderBroughtFrwrdPymtAmt DECIMAL(20,6),
PaymentApproverName VARCHAR(55),
PaymentUpdaterName VARCHAR(55),
PaymentContractId VARCHAR(50),
PaymentDDDate INTEGER,
FrozenPaymentAmount DECIMAL (20,6),
FrozenIndividualAmount DECIMAL (20,6),
ContractPaymentIndicator CHAR (1),
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractFundPayment

# COMMAND ----------

Provider_Contract_FundPayment = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractFundPayment(
ProviderContractFundPaymentKey BIGINT NOT NULL,
ProviderContractFundKey BIGINT NOT NULL,
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
FundSequenceNumber INTEGER,
CapitationFundAmount DECIMAL(20,6),
CatastrophWiithholdAdjstmntAmt DECIMAL(20,6),
CatastrophicWiithholdAmount DECIMAL(20,6),
DeficitAbsorbAmount DECIMAL(20,6),
ExpensedMemberMonthCount INTEGER,
FundAmount DECIMAL(20,6),
FundBroughtForwardAmount DECIMAL(20,6),
FundCapitationExpenseAmount DECIMAL(20,6),
FundClaimBenefitAmount DECIMAL(20,6),
FundClaimDiscountAmount DECIMAL(20,6),
FundClaimExpenseAmount DECIMAL(20,6),
FundClosedDate DATE,
FundDirectPaymentAmount DECIMAL(20,6),
FundFinalPaymentAmount DECIMAL(20,6),
FundIBNRAmount DECIMAL(20,6),
FundIBNRSettledIndicator CHAR (1),
FundLateClaimAmount DECIMAL(20,6),
FundManualAdjustmentAmount DECIMAL(20,6),
FundMemberMonthCount INTEGER,
FundNetACTAmount DECIMAL(20,6),
FundOtherAmount DECIMAL(20,6),
FundProviderRiskAmount DECIMAL(20,6),
FundReconciliationAmount DECIMAL(20,6),
FundReturnLimitAmount DECIMAL(20,6),
FundSettlementAmount DECIMAL(20,6),
FundStatusCode VARCHAR(30),
FundStatusDate DATE,
FundTransferInAmount DECIMAL(20,6),
FundTransferOutAmount DECIMAL(20,6),
FundTypeCode VARCHAR(20),
FundWithholdClaimAmount DECIMAL(20,6),
PeriodBeginDate DATE NOT NULL,
PeriodEndDate DATE,
PrimaryPeriodBroughtFrwrdAmt DECIMAL(20,6),
ReturnLimitMonthCount INTEGER,
StoplossExcessAmount DECIMAL(20,6),
OpenFundIndicator CHAR(1),
FundComment VARCHAR(128),
CreatedBy VARCHAR(150),
CreatedDateTime TIMESTAMP,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractControl
# MAGIC

# COMMAND ----------

Provider_Contract_Control = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractControl(
ProviderContractControlKey BIGINT NOT NULL,
ProviderContractKey	BIGINT NOT NULL,
ProviderContractId VARCHAR(50),
ControlTypeCode	VARCHAR(20),
ControlTypeId VARCHAR(50),
CreatedBy	VARCHAR(100),
CreatedDateTime	TIMESTAMP,
ModifiedBy	VARCHAR(100),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractType
# MAGIC

# COMMAND ----------

Provider_Contract_Type = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractType(
ProviderContractTypeKey BIGINT NOT NULL,
ProviderContractKey	BIGINT NOT NULL,
ProviderContractId VARCHAR(50),
ContractTypeCode VARCHAR(20),
ContractlTypeId VARCHAR(50),
CreatedBy	VARCHAR(100),
CreatedDateTime	TIMESTAMP,
ModifiedBy	VARCHAR(100),
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ### ProviderContractProductAffiliation

# COMMAND ----------

Provider_Contract_ProductAffiliation = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractProductAffiliation(
ProviderContractProductAffiliationKey BIGINT NOT NULL,
ProviderContractKey BIGINT NOT NULL,
ProductAffiliationKey BIGINT NOT NULL,
ProviderId STRING,
ProviderSuffixCode STRING,
ProviderServiceTypeCode STRING,
ProviderSequenceNumber STRING,
ProviderContractId VARCHAR(50),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ###Table - ProviderContractPaymentTerm

# COMMAND ----------

provider_contract_payment_term = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractPaymentTerm
(
	ProviderContractPaymentTermKey bigint NOT NULL,
	ProviderContractKey bigint NOT NULL,
	FundNumber varchar(10),
	StartDate date NOT NULL,
	EndDate date,
	HumanaClaimPaymentCode varchar(20),
	FundPrepayIndicator char(1),
	FundMethodCode varchar(20),
	ClaimPaymentDefaultIndicator char(1),
	ClaimDeductibleIndicator char(1),
	PDAInitName varchar(55),
	PaymentStatusCode varchar(20),
	CreatedBy varchar(150) NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy varchar(150),
	ModifiedDateTime TIMESTAMP NOT NULL
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ##ProviderContractTransfer

# COMMAND ----------

Provider_Contract_Transfer = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractTransfer(
ProviderContractTransferKey BIGINT NOT NULL,
ContractTransferEndDate	DATE,
ContractTransferStartDate DATE,
TransferStatusCode VARCHAR(30),
ContractTransferCode VARCHAR(20),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
FromProviderId VARCHAR(50),
FromProviderSequenceNumber VARCHAR(50),
FromProviderServiceTypeCode VARCHAR(20),
FromProviderSuffixCode VARCHAR(20),
IdCardRequestIndicator CHAR(1),
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP NOT NULL,
FromProviderContractKey BIGINT NOT NULL,
ToProviderContractKey BIGINT NOT NULL,
ToProviderId VARCHAR(50),
ToProviderSequenceNumber VARCHAR(50),
ToProviderServiceTypeCode VARCHAR(20),
ToProviderSuffixCode VARCHAR(20),
FromProviderContractId VARCHAR(50),
ToProviderContractId VARCHAR(50),
OperatorName VARCHAR(30),
DerivedIndicator STRING,
ProviderChangeProcessDate DATE
)"""

# COMMAND ----------

# MAGIC %md
# MAGIC ##ProviderContractTransferZipCode

# COMMAND ----------

Provider_Contract_Transfer_Zip_Code = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.ProviderContract_StageProviderContractTransferZipCode(
ProviderContractTransferZipCodeKey BIGINT NOT NULL,
FromProviderContractKey BIGINT NOT NULL,
FromProviderId VARCHAR(50),
FromProviderSequenceNumber VARCHAR(50),
FromProviderServiceTypeCode VARCHAR(20),
FromProviderSuffixCode VARCHAR(20),
ProviderChangeProcessDate DATE,
ZipCode VARCHAR(5),
CreatedBy STRING NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy STRING,
ModifiedDateTime TIMESTAMP NOT NULL,
DerivedIndicator STRING
)"""

# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
    "ProviderContract_StageProviderContract": Provider_Contract,
    "ProviderContract_StageProviderContractGeoMktAffiliation": Provider_Contract_GeoMktAffiliation,
    "ProviderContract_StageProviderContractProductAffiliation": Provider_Contract_ProductAffiliation,
    "ProviderContract_StageProviderContractFund": Provider_Contract_Fund,
    "ProviderContract_StageProviderContractFundPayment": Provider_Contract_FundPayment,
    "ProviderContract_StageProviderContractControl" : Provider_Contract_Control,
    "ProviderContract_StageProviderContractType" : Provider_Contract_Type,
    "ProviderContract_StageProviderContractPaymentHeader" : Provider_Contract_PaymentHeader,
    "ProviderContract_StageProviderContractProductAffiliation" : Provider_Contract_ProductAffiliation,
    "ProviderContract_StageProviderContractPaymentTerm" : provider_contract_payment_term,
    "ProviderContract_StageProviderContractTransfer" : Provider_Contract_Transfer,
    "ProviderContract_StageProviderContractTransferZipCode" : Provider_Contract_Transfer_Zip_Code
}

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0061 - Its a process to extract the Enrolled and Active member details for the provider vendors and creates the Contract daily FLPNV file
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - Member.StageMemberCoverage
# MAGIC - ProviderContract.StageProviderContractControl
# MAGIC - ProviderContract.StageProviderContractType
# MAGIC - ProviderContract.StageProviderContractPaymentHeader
# MAGIC - Provider.Re0167DailyProvVendorExtractProcess
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - ProviderContract.Re0061ProviderVendorExtract
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenCtrctDailyFlpnvFile.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Importing sql functions
from pyspark.sql.functions import *
import json

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0061_config = config_dict[JOB_NAME]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re0061_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re0061_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re0061_config["Outbound"]["TableName"]
    outbnd_file_name = re0061_config["Outbound"]["FileName"]
    re0167_tbl_name = re0061_config["Inbound"]["Re0167TableName"]
    re0167_curated_path_suffix = re0061_config["Inbound"]["Re0167CuratedFilePathSuffix"]
    
    #input table name
    stg_pc_tbl = re0061_config["Inbound"]["StageProviderContract"]
    stage_pc_ctrl_tbl = re0061_config["Inbound"]["StageProviderContractControl"]
    stg_pc_typ_tbl = re0061_config["Inbound"]["StageProviderContractType"]
    stg_pc_pytmhdr_tbl = re0061_config["Inbound"]["StageProviderContractPaymentHeader"]
    stg_prv_tbl = re0061_config["Inbound"]["StageProvider"]
    stg_mem_cov_tbl = re0061_config["Inbound"]["StageMemberCoverage"]

    sync_process_names = re0061_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Reading Required Tables from ADLS and AzureSQL
try:  
    df_prvdr_ctrct= read_table_to_df(stg_pc_tbl)
    df_mbr_cvrg= read_table_to_df(stg_mem_cov_tbl).select('CoverageEndDate','GateKeeperProviderId','GateKeeperProviderSuffixCode')
    df_prvdr_cntrl= read_table_to_df(stage_pc_ctrl_tbl).select('ProviderContractKey','ControlTypeCode','ControlTypeId')
    df_prvdr_type= read_table_to_df(stg_pc_typ_tbl).select('ProviderContractKey','ContractTypeCode','ContractlTypeId')
    df_prvdr_pymnt_hdr= read_table_to_df(stg_pc_pytmhdr_tbl).select('ProviderContractKey','PaymentUpdaterName','PaymentDate')\
                            .filter(trim(col('PaymentUpdaterName')) != '')
    df_prov_vndr_extrct = read_table_to_df(re0167_tbl_name)

except Exception as e:
    excep = 'Read Sql Tables failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter the Records of ProviderContract
#Filtering ProviderContract on ProviderServiceTypeCode in ('FFS','PCP') and active records
try:
    df_prvdr_ctrct_filtered = df_prvdr_ctrct\
            .filter((col('ProviderServiceTypeCode').isin('FFS','PCP')) \
                    & (col('ContractEndDate')>current_date()))
except Exception as e:
    excep = 'Filter the Records of ProviderContract failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select Required Columns from ProviderContractControl and ProviderContractType
try:    
    df_prvdr_cntrl_fltr= df_prvdr_cntrl\
            .filter(col('ControlTypeCode').isin(['Capitation/Rate','Stoploss','LedgerNumber']))
    df_prvdr_type_fltr= df_prvdr_type\
            .filter(col('ContractTypeCode').isin(['FundedContract','Re-AssignContract','MailContract/Rate','PaymentContract']))
except Exception as e:
    excep = 'Select Required Columns from ProviderContractControl and ProviderContractType failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Pivot ProviderContractControl and ProviderContractType Table
try:
    df_prvdr_cntrl_pvt = pvt_cols(df_prvdr_cntrl_fltr,['ProviderContractKey'],'ControlTypeCode','ControlTypeId')
    df_prvdr_type_pvt = pvt_cols(df_prvdr_type_fltr,['ProviderContractKey'],'ContractTypeCode','ContractlTypeId')
except Exception as e:
    excep = 'Pivot ProviderContractControl and ProviderContractType Table failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting latest PaymentUpdaterName by taking max of PaymentDate
#Selecting latest PaymentUpdaterName by max of PaymentDate:
try:
    windowSpec = Window.partitionBy('ProviderContractKey').orderBy(col('PaymentDate').desc())
    df_prvdr_pymnt_hdr_fltrd = df_prvdr_pymnt_hdr.withColumn('max',row_number().over(windowSpec))\
        .filter(col('max')==1).drop('max','PaymentDate')
except Exception as e:
    excep = 'Selecting latest PaymentUpdaterName failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProviderContract with ProviderContractControl,ProviderContractType and ProviderContractPaymentHeader
#Joining ProviderContract with ProviderContractControl_pivot, ProviderContractType_pivot and ProviderContractPaymentHeader to get the missing columns
try:
    df_prvdr_ctrct_joined = df_prvdr_ctrct_filtered.alias('LH').join(df_prvdr_cntrl_pvt.alias('RH'),
                                                col('LH.ProviderContractKey')==col('RH.ProviderContractKey'),'left')\
                                                .join(df_prvdr_type_pvt.alias('RH1'),col('LH.ProviderContractKey')==col('RH1.ProviderContractKey'),'left')\
                                                .join(df_prvdr_pymnt_hdr_fltrd.alias('RH2'),col('LH.ProviderContractKey')==col('RH2.ProviderContractKey'),'left')
                                                
except Exception as e:
    excep = 'Join ProviderContract with ProviderContractControl,ProviderContractType and ProviderContractPaymentHeader failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting required columns from ProviderContract 
try:
    df_prvdr_ctrct_final = df_prvdr_ctrct_joined.select(
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber",
        "LedgerNumber",
        "ProviderGrouperId",
        "ReportPackageControlId",
        "ProviderContractDescription",
        "ContractStartDate",
        "ContractEndDate",
        "StatusCode",
        "StatusDate",
        "RenewalDate",
        "ProductLineOfBusinessCode",
        concat(col('EverPaymentCode'),lit(' ')).alias("SpecialtyCode"),
        col("MailContract/Rate").alias("MailContract"),
        "FundedContract",
        "PaymentContract",
        col("Re-AssignContract").alias("ReAssignContract"),
        col("Capitation/Rate").alias("CapitationRate"),
        "ExpenseId",
        "ReportControlId",
        "Stoploss",
        "PaymentAccountNumber",
        "CapitationBeginCode",
        "CapitationEndCode",
        "TerminationMaximumCount",
        "AdditionalMaximumCount",
        "DefaultStatusIndicator",
        "PaymentOptionCode",
        "FundClassCode",
        "LateClaimCode",
        "PaymentDateNumber",
        "ContractProgramTypeCode",
        "ProviderMemberCount",
        round(col("RecoveryPaymentAmount"), 2).alias("RecoveryPaymentAmount"),
        "RecoveryMonthCount",
        round(col("RecoveryPercent"), 2).alias("RecoveryPercent"),
        "RecoveryFundTypeCode",
        "ReportDetailIndicator",
        "PaymentUpdaterName",
        "MemberLimitCode",
        "MemberTypeCode",
        "ReprocessDate",
        "CategoryCode"
    )
except Exception as e:
    excep = "Selecting required columns from ProviderContract failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProviderContract and ProviderVendorExtract(Re0167)
# Replaced fullOuter with left join and removed filter
# Joining filtered ProviderContract to ProviderVendorExtract
try:
    cond = (col("LH.ProviderId") == col("RH.ProviderId")) & (col("LH.ProviderSuffixCode") == col("RH.SuffixCode"))

    df_prv_vndr = (df_prvdr_ctrct_final.alias("LH")
                    .join(df_prov_vndr_extrct.alias("RH"), cond, "left")
                    .select("LH.*", "RH.VendorNumber"))
except Exception as e:
    excep = "Join ProviderContract and ProviderVendorExtract(Re0167) failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Splitting MemberCoverage as MemberEnrolled
# Splitting MemberCoverage as MemberEnrolled if CoverageEndDate >current_date and adding count in FlpnvEnrolledLoad column
try:
    df_mbr_enrl = (df_mbr_cvrg.filter(col("CoverageEndDate") > current_date())
                   .groupBy("GateKeeperProviderId", "GateKeeperProviderSuffixCode").count()
                   .withColumnRenamed("count", "FlpnvEnrolledLoad"))
except Exception as e:
    excep = "Splitting MemberCoverage as MemberEnrolled failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Splitting MemberCoverage as MemberActive
# Splitting MemberCoverage as MemberActive if provider is active from last year and adding count in FlpnvActiveLoad column
try:
    df_mbr_active = (
        df_mbr_cvrg.filter(col("CoverageEndDate") > (current_date() - 365))
        .groupBy("GateKeeperProviderId", "GateKeeperProviderSuffixCode").count()
        .withColumnRenamed("count", "FlpnvActiveLoad")
    )
except Exception as e:
    excep = "Splitting MemberCoverage as MemberActive failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Joining ProviderVendor, MemberEnrolled and MemberActive 
#Step1: Join ProviderVendor file with MemberEnrolled on ProviderId and ProviderSuffixCode
#Step2: Joining the step1 outpt with MemberActive on ProviderId and ProviderSuffixCode
try:
    cond1 = (col('LH.ProviderId')==col('RH.GateKeeperProviderId')) & (col('LH.ProviderSuffixCode')==col('RH.GateKeeperProviderSuffixCode'))
    cond2 = (col('LH.ProviderId')==col('RH1.GateKeeperProviderId')) & (col('LH.ProviderSuffixCode')==col('RH1.GateKeeperProviderSuffixCode'))
    
    df_prv_enrl_actv = df_prv_vndr.alias('LH')\
                            .join(df_mbr_enrl.alias('RH'),cond1,'left')\
                            .join(df_mbr_active.alias('RH1'),cond2,'left')
except Exception as e:
    excep = 'Joining ProviderVendor, MemberEnrolled and MemberActive failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check for enrollment and active patient count and populate into output file
#Check Provider ID number from member provider enrollment,member provider active,contractor are matched then move contractor detail,enrolled load,active load  
#Check if provider number is matching from enrollment and contractor move contractor details, enrolled load and active load as zero  
#Check if provider number is matching from active provider and contractor move contractor details, active load, and enrolled load as zero.
try:
    df_prv_enrl_actv_filter = df_prv_enrl_actv.withColumn('FlpnvEnrolledLoad',
                                            when(col('RH.GateKeeperProviderId').isNotNull(),col('FlpnvEnrolledLoad')).otherwise(lit(0)))\
                                            .drop(col('RH.GateKeeperProviderId'),col('RH.GateKeeperProviderSuffixCode'))\
                                            .withColumn('FlpnvActiveLoad',
                                            when((col('RH1.GateKeeperProviderId').isNotNull()),col('FlpnvActiveLoad')).otherwise(lit(0)))\
                                            .drop(col('RH1.GateKeeperProviderId'),col('RH1.GateKeeperProviderSuffixCode'))
except Exception as e:
    excep = 'Check for enrollment and active patient count and populate into output file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_prv_enrl_actv_filter, tbl_name)
    # Read data from stage area.
    re0061_df = read_table_to_df(tbl_name)
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0061_df)
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }   

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
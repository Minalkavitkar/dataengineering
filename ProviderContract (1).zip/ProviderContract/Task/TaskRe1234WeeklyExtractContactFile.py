# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Weekly job RE1234 - Its a process to to create outbound file for count of members with active coverage members and creates weekly job file
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC -- StageProviderContract,
# MAGIC -- StageMemberCoverage,
# MAGIC -- StageProviderVendor,
# MAGIC  --StageProviderContractControl,
# MAGIC -- StageProduct
# MAGIC
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - ProviderContract.TaskRe1234WeeklyExtractContactFile
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - WeeklyExtractContactFile1234.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Venkata Ramaraju
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Importing sql functions
from pyspark.sql.functions import *
import json

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re1234_config = config_dict[JOB_NAME]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re1234_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re1234_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re1234_config["Outbound"]["TableName"]
    outbnd_file_name = re1234_config["Outbound"]["FileName"]
    
    #input table name
    stg_pc_tbl = re1234_config["Inbound"]["StageProviderContract"] 
    stg_mem_cov_tbl = re1234_config["Inbound"]["StageMemberCoverage"] 
    stg_prov_vend_tbl = re1234_config["Inbound"]["StageProviderVendor"]
    stg_prov_control_tbl = re1234_config["Inbound"]["StageProviderContractControl"]
    stg_prodct_tbl = re1234_config["Inbound"]["StageProduct"]
    sync_process_names = re1234_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]

except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Reading Required Tables from ADLS and AzureSQL
try:
  df_prvdr_ctrct= read_table_to_df(stg_pc_tbl).select('ProviderId','ProviderSuffixCode','ProviderContractKey')
  df_mbr_cvrg= read_table_to_df(stg_mem_cov_tbl).select('MemberKey','ProviderContractKey','ProductKey','CoverageEndDate')
  df_prov_vend = read_table_to_df(stg_prov_vend_tbl).select('ProviderVendorKey','ProviderKey','VendorTypeCode','VendorNumber')
  df_prov_control = read_table_to_df(stg_prov_control_tbl).select('ProviderContractKey','ControlTypeId','ControlTypeCode')
  df_prodct = read_table_to_df(stg_prodct_tbl).select("LineOfBusinessCode","ProductKey")
except Exception as e:
  excep = 'Read Sql Tables failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,fetching Ledger 
# Fetcht ControlTypeId when ControlTypeCode = LedgerNumber from ProviderContractControlTable
try:
    control_type_df = df_prov_control\
                    .filter((col("ControlTypeCode") == "LedgerNumber"))\
                    .select("ControlTypeId","ControlTypeCode","ProviderContractKey")
except Exception as e:
  excep = 'Filter the Records of ProviderContract failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filtering records 
#Fetch LineOfBusinessCode  ="MER" using product key from Product Table
try:

  Mer_prodct = df_prodct\
                .filter(col("LineOfBusinessCode") == "MER")\
                .select("ProductKey","LineOfBusinessCode")
except Exception as e:
  excep = 'Filter the Records of ProviderContract failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    

# COMMAND ----------

# DBTITLE 1,Fetch Provider contract Key and Member Key for active member coverage
#Fetch Provider contract Key and Member Key for active member coverage
try:

    cond =(col("mcv.CoverageEndDate") >= datetime.now())
    cond1 =(col("mcv.ProductKey") == col("prov.ProductKey"))
    Active_mbr_covrg = df_mbr_cvrg.alias("mcv")\
                        .filter(cond)\
                        .join(Mer_prodct.alias("prov"),cond1,"inner")\
                        .select("MemberKey","mcv.ProductKey","ProviderContractKey","CoverageEndDate")\
                        .withColumnRenamed("mcv.ProductKey","ProductKey")
except Exception as e:
    excep = 'Filter the Records of ProviderContract failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Fetching required fields
#Fetch ProviderId,ProviderSuffixCode from ProviderContract table
try:

    ProviderInfo = df_prvdr_ctrct.select("ProviderId","ProviderSuffixCode","ProviderContractKey")
except Exception as e:
    excep = 'Filter the Records of ProviderContract failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate member count based on Provider ID
# Calculate Member count on Provider ID
try:
    
    cond = (col("mc.ProviderContractKey") == col("pc.ProviderContractKey"))
    Prov_mbr_count = Active_mbr_covrg.alias("mc")\
                      .join(ProviderInfo.alias("pc"), cond, "left_outer")\
                      .groupBy("pc.ProviderId","pc.ProviderSuffixCode")\
                      .agg(count("MemberKey").alias("MemberCount"))

except Exception as e:
    excep = ' Member count on Provider ID failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Combined results
#combine the results
try:  
  Final_output_df = control_type_df\
          .filter(col("ControlTypeCode") == 'LedgerNumber')\
          .join(Prov_mbr_count, col("ProviderContractKey") == col("ProviderContractKey"),"left")\
          .join(df_prov_vend, col("ProviderContractKey") == col("ProviderContractKey"),"left")\
          # .select("ControlTypeId","ProviderId","ProviderSuffixCode","MemberCount","VendorNumber")

except Exception as e:
    excep = 'Combined results failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Changing column datatypes
#doing typecasting to get desired columns datatypes
try:
    df_final2 = Final_output_df.selectExpr(
          "cast(ProviderId as string) as Provider",
          "cast(ProviderSuffixCode as string) as ProviderSuffix",
          "cast(VendorNumber as string) as ProviderVendor" ,
          "cast(MemberCount as string) as MemberCount",
          "cast(ControlTypeId as string) as ProviderLedger"
      )
except Exception as e:
  excep = 'Write to ADLS: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))   

          

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
  final_df = convert_col_to_fixed_width(fixed_config_df,df_final2)
  # write dataframe as single text file with position delimited.
  write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
  excep = 'Write to ADLS: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }   

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
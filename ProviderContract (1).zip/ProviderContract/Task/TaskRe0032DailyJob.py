# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC #### Create an interface to generate a SPC Charge back report with appropriate error message
# MAGIC
# MAGIC ##### To acheive the requirement below steps has been followed.
# MAGIC
# MAGIC * Step 1: Extract All PCP & SPC contracts details using respective tables.
# MAGIC * Step 2: Extract open fund period begin and end date where Fund Period Status Code is in 'O' or 'P' using respective tables.
# MAGIC * Step 3: Create a SPCChargeBackReport in Delta Lake Unity Catalog Table.
# MAGIC * Step 4: Generate and Upload the SPC_Charge_Back_Report.txt file to ADLS container / Outbound folder

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Source table 
# MAGIC - ProviderContract.ProviderContract (MF table : TRE2341)
# MAGIC - Provider.Provider  (MF table : TREFPRV)
# MAGIC - Provider.GeoMarket  (MF table : TRE2340)
# MAGIC - ProviderContract.ProviderContractFund  (MF table : TRE2345)
# MAGIC - ProviderContract.ProviderContractControl (MF table : TRE2341, TRE2481, TREPRVJ)
# MAGIC - ProviderContract.ProviderContractGeoMktAffiliation (MF table : TRECTRT,TREXACT)
# MAGIC - Provider.GeoMarketCycle (MF table : TRE2340)
# MAGIC - Accounting.FinanceLedgerHeader (MF table : TRE2355)
# MAGIC - Accounting.FinanceLedgerFundPeriod (MF table : TRE2356)
# MAGIC
# MAGIC ##### Outbound File
# MAGIC - Re0032DailyProcess.txt

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0032SyncUp')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import ingest notebook
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    Re0032Daily = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = Re0032Daily["Outbound"]["TempFilePathSuffix"]   
    curated_path_suffix = Re0032Daily['Outbound']['CuratedFilePathSuffix']
    tbl_name = Re0032Daily['Outbound']['TableName']
    outbnd_file_name = Re0032Daily["Outbound"]["FileName"]

    stg_geo_mkt_tbl_name = Re0032Daily["Inbound"]["StageGeoMarket"]
    stg_prov_tbl_name = Re0032Daily["Inbound"]["StageProvider"]
    stg_geo_mkt_cycl_tbl_name = Re0032Daily["Inbound"]["StageGeoMarketCycle"]
    stg_prov_con_tbl_name = Re0032Daily["Inbound"]["StageProviderContract"]
    stg_prov_con_ctrl_tbl_name = Re0032Daily["Inbound"]["StageProviderContractControl"]
    stg_prov_con_fnd_tbl_name = Re0032Daily["Inbound"]["StageProviderContractFund"]
    stg_prov_con_geo_mkt_aff_tbl_name = Re0032Daily["Inbound"]["StageProviderContractGeoMktAffiliation"]
    stg_fin_ldgr_hdr_tbl_name = Re0032Daily["Inbound"]["StageFinanceLedgerHeader"]
    stg_fin_ldgr_fnd_prd_tbl_name = Re0032Daily["Inbound"]["StageFinanceLedgerFundPeriod"]
    
    
    sync_process_names = Re0032Daily["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account,
        file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read table data into the dataframe from the respective table.
try: 
    # Read the data from Geo Market Stage table(Adls).
    df_geo_mkt_cycl = read_table_to_df(stg_geo_mkt_cycl_tbl_name)
    # Read the data from Provider Stage table(Adls).
    df_prov = read_table_to_df(stg_prov_tbl_name)    
    # Read the data from Geo Market Cycle Stage table(Adls).
    df_geo_mkt = read_table_to_df(stg_geo_mkt_tbl_name)
    # Read the data from ProviderContract Stage table(Adls).
    df_prov_con = read_table_to_df(stg_prov_con_tbl_name)
    # Read the data from ProviderContractFund Stage table(Adls).
    df_prov_con_fnd = read_table_to_df(stg_prov_con_fnd_tbl_name)
    # Read the data from ProviderContractControl Stage table(Adls).
    df_prov_con_ctrl = read_table_to_df(stg_prov_con_ctrl_tbl_name)
    # Read the data from ProviderContractGeoMarketAffiliation Stage table(Adls).
    df__prov_con_geo_mkt_aff = read_table_to_df(stg_prov_con_geo_mkt_aff_tbl_name)
     # Read the data from ProviderContractControl Stage table(Adls).
    df_fin_ldgr_hdr = read_table_to_df(stg_fin_ldgr_hdr_tbl_name)
    # Read the data from ProviderContractGeoMarketAffiliation Stage table(Adls).
    df_fin_ldgr_fnd_perd = read_table_to_df(stg_fin_ldgr_fnd_prd_tbl_name)

    
except Exception as e:
    excep = "Read Sql Tables: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Derive required columns for the report from respective tables.
# Derive column "GeoMarketId" from table GeoMarket & Column "CycleNumber" from GeoMarketCycle using key column "GeoMarketKey".
df_geo_mkt_fltr = df_geo_mkt_cycl.join(df_geo_mkt, ["GeoMarketKey"]).select(
    "GeoMarketKey", "GeoMarketId", "CycleNumber"
)

# Derived columns from ProviderContract & ProviderContractControl table using key column "ProviderContractKey".
df_pro_con_fltr = (
    df_prov_con_ctrl.join(df_prov_con, ["ProviderContractKey"])
    .filter(col("ControlTypeCode") == "LedgerNumber")
    .select(
        "ProviderContractKey",
        "ControlTypeId",
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber",
        "ProviderContractDescription",
        "ProductLineOfBusinessCode",
        "ContractStartDate",
        "ContractEndDate",
    )
)


# Derive column "GeoMarketId" from table ProviderContractGeoMktAffiliation using key column "ProviderContractKey".
df_pro_con_fltr_final = (
    df_pro_con_fltr.alias("LH")
    .join(df__prov_con_geo_mkt_aff.alias("RH"), ["ProviderContractKey"])
    .select("LH.*", "RH.GeoMarketId")
)


# Derived required columns from ProviderContractFund table .
df_prov_con_fnd_fltr = df_prov_con_fnd.select(
    "ProviderContractKey",
    "FundTypeCode",
    "FundSequenceNumber",
    "FundExpenseMethodCode",
    "ExpensedFundTypeCode",
)


# Derived columns from FinanceLedgerHeader & FinanceLedgerFundPeriod & Provider respectively.

df_fin_ldgr_hdr_fltr = df_fin_ldgr_hdr.select(
    "FinanceLedgerHeaderKey",
    "LedgerNumber",
    "HMPVsNonHMPIndicator",
    "LedgerDescription",
    "LedgerStatusCode",
    "LedgerStatusDate",
    "LedgerApproverName",
    "FinancialLedgerCode",
    "FinanceLedgerName",
    "LineOfBusinessCode",
    "FinanceLedgerGeographicCode",
    "CASNetworkNumber",
    "CASLineOfBusinessCode",
    "CASProviderNetworkNumber",
    "CASMarketNumber",
    "GateKeeperLedgerIndicator",
    "WithholdPerGrouperIndicator",
)

df_fin_ldgr_fnd_perd_fltr = df_fin_ldgr_fnd_perd.select(
    "FinanceLedgerHeaderKey",
    "FundPeriodBeginDate",
    "FundPeriodEndDate",
    "FundPeriodStatusCode",
    "FundStatusChangeDate",
    "ApproverFullName",
    "FundPeriodAccountCode",
    "FundExpenseCode",
)

df_prov_fltr = df_prov.select("ProviderId", "SuffixCode", "ProviderName")

# COMMAND ----------

# DBTITLE 1,Prepare SPC Contract extract file along with appropriate error message
df_spc_ext = df_pro_con_fltr_final.join(df_geo_mkt_fltr, "GeoMarketId") \
    .join(df_prov_con_fnd_fltr, ["ProviderContractKey"]) \
    .filter(~col("ProviderServiceTypeCode").isin("PCP", "FFS")) \
    .withColumn("ProviderId", col("ProviderId").cast("Integer")) \
    .withColumn("ProviderSequenceNumber", col("ProviderSequenceNumber").cast("Integer")) \
    .withColumn("Error_DESC", 
                when(col("FundExpenseMethodCode") == "H", "CHARGE BACK FUND EXIST WITH MTHD CD H") \
                .when(col("FundExpenseMethodCode") == "P", "NO CHARGE BACK FUND EXIST WITH MTHD CD P") \
                .otherwise("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")) \
    .select(
        col("CycleNumber"),
        col("GeoMarketId"),
        col("ControlTypeId"),
        col("ProviderId"),
        col("ProviderSuffixCode"),
        col("ProviderServiceTypeCode"),
        col("ProviderSequenceNumber"),
        col("ProviderContractDescription"),
        col("ProductLineOfBusinessCode"),
        col("ContractStartDate"),
        col("ContractEndDate"),
        col("FundTypeCode"),
        col("FundExpenseMethodCode"),
        col("ExpensedFundTypeCode"),
        col("Error_DESC")
    ) \
    .orderBy(
        col("GeoMarketId").asc(),
        col("ProviderId").asc(),
        col("ProviderSuffixCode").asc(),
        col("ProviderServiceTypeCode").asc(),
        col("ProviderSequenceNumber").asc(),
        col("FundSequenceNumber").asc()
    )

# COMMAND ----------

# DBTITLE 1,Prepare PCP Contract extract file along with appropriate error message
df_pcp_ext = df_pro_con_fltr_final.join(df_geo_mkt_fltr, "GeoMarketId") \
    .join(df_prov_con_fnd_fltr, [ "ProviderContractKey"]) \
    .filter((col("ProviderServiceTypeCode").isin("PCP", "FFS")) & ((col("FundExpenseMethodCode") == "P") | (col("ExpensedFundTypeCode") != "    "))) \
    .withColumn("ProviderId", col("ProviderId").cast("Integer")) \
    .withColumn("ProviderSequenceNumber", col("ProviderSequenceNumber").cast("Integer")) \
    .withColumn("Error_DESC", 
                when(col("FundExpenseMethodCode") == "P", "CAP SPEC EXP MTHD - P FOR PCP CONTRACT") \
                .when(col("ExpensedFundTypeCode") != "    ", "CHARGE BACK FUND ON PCP CONTRACT") \
                .otherwise("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")) \
    .select(
        col("CycleNumber"),
        col("GeoMarketId"),
        col("ControlTypeId"),
        col("ProviderId"),
        col("ProviderSuffixCode"),
        col("ProviderServiceTypeCode"),
        col("ProviderSequenceNumber"),
        col("ProviderContractDescription"),
        col("ProductLineOfBusinessCode"),
        col("ContractStartDate"),
        col("ContractEndDate"),
        col("FundTypeCode"),
        col("FundExpenseMethodCode"),
        col("ExpensedFundTypeCode"),
        col("Error_DESC")
    ) \
    .orderBy(
        col("GeoMarketId").asc(),
        col("ProviderId").asc(),
        col("ProviderSuffixCode").asc(),
        col("ProviderServiceTypeCode").asc(),
        col("ProviderSequenceNumber").asc(),
        col("FundSequenceNumber").asc()
    )

# COMMAND ----------

# DBTITLE 1,Combine SPC & PCP contract file to get the complete Contract extract file 
df_cntrct_ext = df_spc_ext.unionAll(df_pcp_ext).orderBy(asc(col("ControlTypeId")))

# COMMAND ----------

# DBTITLE 1,Fetch Fund details from the table for the Financial report ledger
# Join table FinanceLedgerHeader & FinanceLedgerFundPeriod to derive column LedgerNumber. And Fetch Fund details from the table for the Financial report ledger
df_fech_fnd_dtl = df_fin_ldgr_hdr_fltr.alias("LH1").join(
    df_fin_ldgr_fnd_perd_fltr.alias("RH1"), ["FinanceLedgerHeaderKey"]
)
df_fech_fnd_dtl_final = df_fech_fnd_dtl.select(
    "LedgerNumber",
    "FundPeriodBeginDate",
    "FundPeriodEndDate",
    "FundPeriodStatusCode",
    "FundStatusChangeDate",
    "ApproverFullName",
    "FundPeriodAccountCode",
    "FundExpenseCode",
).filter((col("FundPeriodStatusCode") == "O") | (col("FundPeriodStatusCode") == "P"))

# COMMAND ----------

# Fetch records when the Fund Status Indicator field if its ‘O’ or ‘P’ an the Contract End is Greater than equal to Fund Begin date and Contract end date is Lesser than or equal to Fund end date or Contract end date Greater than equal to Fund end date.

df_fin_ledgr_dtl = (
    df_cntrct_ext.alias("LH2")
    .join(
        df_fech_fnd_dtl_final.alias("RH2"),
        col("LH2.ControlTypeId") == col("RH2.LedgerNumber"),
    )
    .select("LH2.*")
    .filter(
        (
            (col("ContractEndDate") >= col("FundPeriodBeginDate"))
            & (col("ContractEndDate") <= col("FundPeriodEndDate"))
        )
        | (col("ContractEndDate") >= col("FundPeriodEndDate"))
    )
)

# COMMAND ----------

# DBTITLE 1,Derive Provider name from the Provider table
df_final = (
    df_fin_ledgr_dtl.alias("LH3")
    .join(
        df_prov_fltr.alias("RH3"),
        (col("LH3.ProviderId") == col("RH3.ProviderId"))
        & (col("LH3.ProviderSuffixCode") == col("RH3.SuffixCode")),
        "left"
    )
    .select("LH3.*", "RH3.ProviderName")
)

# COMMAND ----------

# DBTITLE 1,Adding all the hardcoded columns to the dataframe
df_final = (
    df_final.withColumn("filler1", lit(" ").cast("String"))
    .withColumn("filler2", lit(" ").cast("String"))
    .withColumn("filler3", lit(" ").cast("String"))
    .withColumn("filler4", lit(" ").cast("String"))
    .withColumn("filler5", lit(" ").cast("String"))
    .withColumn("filler6", lit(" ").cast("String"))
    .withColumn("filler7", lit(" ").cast("String"))
    .withColumn("filler8", lit(" ").cast("String"))
    .withColumn("filler9", lit(" ").cast("String"))
    .withColumn("filler10", lit(" ").cast("String"))
    .withColumn("filler11", lit(" ").cast("String"))
    .withColumn("filler12", lit(" ").cast("String"))
)

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, tbl_name)
    # Read data from stage area.
    re0032_df = spark.read.table(tbl_name)
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0032_df)
    # write dataframe as .txt file as position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }
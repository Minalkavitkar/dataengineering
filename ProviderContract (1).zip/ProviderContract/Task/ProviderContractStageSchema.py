# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "dataprocessing",
        "FilePathSuffix" : "inbound/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "Config":{
            "header":"true",
            "delimiter":"|",
            "multiline":"true"
        },
        "SourceFileFormat" : "csv"
    },
    "IN_PE_PEPRVATR_CCYYMMDD":{
        "FileRegex" : "IN_PE_PEPRVATR_CCYYMMDD.TXT",
        "StagePathSuffix" : "processingdatabase/providercontract/stage/StageCASProviderCategory"
   }
}

# COMMAND ----------

CASProviderCategory_schema = {
    'PEPRVATR_SOURCE_CD':'STRING',
    'PEPRVATR_SOURCE_ID':'STRING',
    'PROV_ATTR_TYPE_CD':'STRING',
    'PROV_ATTR_SEQ':'STRING',
    'PROV_ATTR_CD':'STRING'    
}
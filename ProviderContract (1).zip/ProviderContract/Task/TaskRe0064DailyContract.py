# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0064 - It's a process to extract all contract details and generate Contract Extract Delta Lake Unity Catalog Table
# MAGIC - Daily job RE0064Dual - This job creates an interface to generate a Dual Contract Extract details outbound file for MC and EDW application 
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - ProviderContract.StageProviderContractProductAffiliation
# MAGIC - ProviderContract.StageProviderContractControl
# MAGIC - ProviderContract.StageProviderContractType
# MAGIC - Product.StageProductAffiliation
# MAGIC - Provider.Provider
# MAGIC - Provider.GeoMarket
# MAGIC - Provider.GeoMarketCycle
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - ProviderContract.Re0064DailyContract
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC - ProdrenRe0064DailyCtrctextDual.txt
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Importing sql functions
from pyspark.sql.functions import *
import json

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0064_config = config_dict[JOB_NAME]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = re0064_config["Outbound"]["TempFilePathSuffix"]
    re0064_tbl_name = re0064_config["Outbound"]["Re0064TableName"]
    re0064_dual_tbl_name = re0064_config["Outbound"]["Re0064DualTableName"]
    outbnd_file_name = re0064_config["Outbound"]["FileName"]
    
    #input table name
    stg_pc_tbl = re0064_config["Inbound"]["StageProviderContract"]
    stg_pc_prd_aff_tbl = re0064_config["Inbound"]["StageProviderContractProductAffiliation"]
    stg_prd_aff_tbl = re0064_config["Inbound"]["StageProductAffiliation"] 
    stage_pc_ctrl_tbl = re0064_config["Inbound"]["StageProviderContractControl"]
    stg_pc_typ_tbl = re0064_config["Inbound"]["StageProviderContractType"]
    stg_prv_tbl = re0064_config["Inbound"]["StageProvider"]
    stg_prv_vnd_tbl = re0064_config["Inbound"]["StageProviderVendor"]
    stg_prv_geomkt_tbl = re0064_config["Inbound"]["StageGeoMarket"]
    stg_prv_geomktcyc_tbl = re0064_config["Inbound"]["StageGeoMarketCycle"]

    sync_process_names = re0064_config["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
# Add required columns to the list from Provider table.
prv_req_cols = [
    'ProviderKey',
    'Type2Code',
    'ProviderName',
    'IRSNumber',
    'SpecialtyCode',
    concat('AddressLine1Text','AddressLine2Text','AddressLine3Text','AddressLine4Text').alias('ProviderAddress')
]

# Add required columns to the list from ProviderVendor table.
prv_vndr_req_cols = [
    'ProviderKey',
    'VendorNumber'
]

# Add required columns to the list from ProviderContractProductAffiliation table.
prv_ctrt_prdt_aff_req_cols = [
    "ProviderContractKey"
    ,"ProductAffiliationKey"
]

# Add required columns to the list from ProviderContractControl table.
prv_ctrt_ctrl_req_cols = [
    "ProviderContractKey",
    "ControlTypeCode",
    "ControlTypeId"
]

# Add required columns to the list from ProviderContractType table.
prv_ctrt_type_req_cols = [
    "ProviderContractKey",
    "ContractTypeCode",
    "ContractlTypeId"
]
# Add required columns to the list from ProductAffiliation table.
prd_aff_req_cols = [
    "ProductAffiliationKey",
    "LocationId"
]
# Add required columns to the list from GeoMarket table.
geomkt_req_cols =[
    'GeoMarketKey',
    'GeoMarketId',
    'StatusCode'
]
# Add required columns to the list from GeoMarketCycle table.
geomkt_cyc_req_cols =[
    'GeoMarketKey'
    ,'CycleNumber'
]

# COMMAND ----------

# DBTITLE 1,Reading Required Tables from ADLS and AzureSQL
try:  
    df_prvdr_ctrct= read_table_to_df(stg_pc_tbl)
    df_pc_prd_aff= read_table_to_df(stg_pc_prd_aff_tbl).select(*prv_ctrt_prdt_aff_req_cols)
    df_prd_aff= read_table_to_df(stg_prd_aff_tbl).select(*prd_aff_req_cols)
    df_prvdr_cntrl= read_table_to_df(stage_pc_ctrl_tbl).select(*prv_ctrt_ctrl_req_cols)
    df_prvdr_type= read_table_to_df(stg_pc_typ_tbl).select(*prv_ctrt_type_req_cols)
    df_prvdr = read_table_to_df(stg_prv_tbl).select(*prv_req_cols)
    df_prv_vndr = read_table_to_df(stg_prv_vnd_tbl).select(*prv_vndr_req_cols) 
    df_geomkt = read_table_to_df(stg_prv_geomkt_tbl).select(*geomkt_req_cols)
    df_geomkt_cyc = read_table_to_df(stg_prv_geomktcyc_tbl).select(*geomkt_cyc_req_cols)

except Exception as e:
    excep = 'Read Sql Tables failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select Required Columns from ProviderContractControl and ProviderContractType
try:    
    df_prvdr_cntrl_fltr= df_prvdr_cntrl\
            .filter(col('ControlTypeCode').isin(['Capitation/Rate','MandateSpecialist','Stoploss','LedgerNumber',
                                        'OutOfAreaNetwork','CostAllocation','GeoMkt','ClaimRule']))
    df_prvdr_type_fltr= df_prvdr_type\
            .filter(col('ContractTypeCode').isin(['FundedContract','Re-AssignContract','MailContract/Rate',
                                        'PaymentContract','SettlementContract']))
except Exception as e:
    excep = 'Select Required Columns from ProviderContractControl and ProviderContractType failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Pivot ProviderContractControl and ProviderContractType Table
try:
    df_prvdr_cntrl_pvt = pvt_cols(df_prvdr_cntrl_fltr,['ProviderContractKey'],'ControlTypeCode','ControlTypeId')
    df_prvdr_type_pvt = pvt_cols(df_prvdr_type_fltr,['ProviderContractKey'],'ContractTypeCode','ContractlTypeId')
except Exception as e:
    excep = 'Pivot ProviderContractControl and ProviderContractType Table failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step1 : Join ProviderContract with ProviderContractControl and ProviderContractType
#Joining ProviderContract with ProviderContractControl_pivot, ProviderContractType_pivot and ProviderContractPaymentHeader to get the missing columns
try:
    df_prvdr_ctrct_joined = df_prvdr_ctrct.alias('LH').join(df_prvdr_cntrl_pvt.alias('RH'),
                                                col('LH.ProviderContractKey')==col('RH.ProviderContractKey'),'inner')\
                                                .join(df_prvdr_type_pvt.alias('RH1'),col('LH.ProviderContractKey')==col('RH1.ProviderContractKey'),'inner')
                                                
except Exception as e:
    excep = 'Join ProviderContract with ProviderContractControl,ProviderContractType failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step2: Selecting required columns from ProviderContract 
try:
    df_prvdr_ctrct_final = df_prvdr_ctrct_joined.select(
    'LH.ProviderContractKey'
    ,col('ProviderContractId').alias('PcaCtrctKey')
    ,'LedgerNumber'
    ,'ProviderGrouperId'
    ,'ReportPackageControlId'
    ,'ProviderContractDescription'
    ,col('ContractStartDate').alias('PcaBegCymdDate')
    ,col('ContractEndDate').alias('PcaEndCymdDate')
    ,col('StatusCode').alias('PcaStatCd')
    ,'StatusDate'
    ,'RenewalDate'
    ,'ProductLineOfBusinessCode'
    ,'EverPaymentCode'
    ,col("MailContract/Rate").alias("MailContractKey"),
    "FundedContract",
    "PaymentContract",
    col("Re-AssignContract").alias("ReAssignContract"),
    col("Capitation/Rate").alias("CapitationRate")
    ,'ExpenseId'
    ,'ReportControlId'
    ,'Stoploss'
    ,'PaymentAccountNumber'
    ,'CapitationBeginCode'
    ,'CapitationEndCode'
    ,'TerminationMaximumCount'
    ,'AdditionalMaximumCount'
    ,'DefaultStatusIndicator'
    ,'PaymentOptionCode'
    ,'FundClassCode'
    ,'LateClaimCode'
    ,'PaymentDateNumber'
    ,'ContractProgramTypeCode'
    ,'ProviderMemberCount'
    ,round(col('RecoveryPaymentAmount'), 2).alias('RecoveryPaymentAmount')
    ,'RecoveryMonthCount'
    ,round(col('RecoveryPercent'), 2).alias('RecoveryPercent')
    ,'RecoveryFundTypeCode'
    ,'ReportDetailIndicator'
    ,lit('   ').alias('UpdtInitNm')
    ,'MemberTypeCode'
    ,'MemberLimitCode'
    ,'ReprocessDate'
    ,'CategoryCode'
    ,'ClaimRule'
    ,'SettlementContract'
    ,'FundPeriodBeginCode'
    ,'SettlementPeriodPaymentCode'
    ,'SettlementAnnualPaymentCode'
    ,'SettlementByFundIndicator'
    ,'IndividualSettlementRuleCode'
    ,'ContractCountyCode'
    ,'SettlementFrequencyCode'
    ,when(col('ContractLagPeriodCount').isNull(),lit(0)).otherwise(col('ContractLagPeriodCount')).alias('ContractLagPeriodCount')
    ,when(col('ContractLagAnnualCount').isNull(),lit(0)).otherwise(col('ContractLagAnnualCount')).alias('ContractLagAnnualCount')
    ,'Settlement1Description'
    ,col('GeoMkt').alias('GeoMarketId'),
    'ProviderKey'
    )
except Exception as e:
    excep = "Selecting required columns from ProviderContract failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step3 : Join output of step2 with Provider and ProviderVendor table 
# Join output of step1 with Provider and ProviderVendor table 
try:
    prov_joined_df = df_prvdr_ctrct_final.join(df_prvdr,['ProviderKey'],'inner')\
                                      .withColumn('IRSNumber',when(trim(col('Type2Code'))!='D',lit(0)).otherwise(col('IRSNumber')))\
                                      .withColumn('SpecialtyCode',when(trim(col('Type2Code'))!='D',lit('0')).otherwise(col('SpecialtyCode')))\
                                      .drop('Type2Code')
                                        
    prov_vndr_joined_df = prov_joined_df.join(df_prv_vndr,['ProviderKey'],'inner').drop('ProviderKey')
except Exception as e:
    excep = "Join with Provider and ProviderVendor table failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 4: Join output of step3 with GeoMarket
# Join GeoMarket with GeomarketCycle on GeoMarketKey to get CycleNumber.
try:
    geo_mkt_df = df_geomkt\
            .join(df_geomkt_cyc, ['GeoMarketKey'], 'inner')

    # Join providerContract with GeoMarket on GeoMarketId.
    geo_mkt_joined_df = prov_vndr_joined_df\
            .join(geo_mkt_df, ['GeoMarketId'], 'inner').drop('GeoMarketKey')
except Exception as e:
    excep = "Join providerContract with GeoMarket failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 5: Join step 4 output with ProviderContractProductAffiliation and then with ProductAffiliation
# Step1: Join above dataframe with ProviderContractProductAffiliation table on ProviderContractKey
# Step2: The output of step1 is joined with ProductAffiliation table on ProductAffiliationKey and then selecting the required for the output file
try:
    affl_joined_df = (
        geo_mkt_joined_df.alias("LH")
        .join(
            df_pc_prd_aff.alias("PCAFF"),
            ["ProviderContractKey"],
            "left",
        )
        .join(
            df_prd_aff.alias("PAFF"),
            ["ProductAffiliationKey"],
            "left",
        )
        .drop(col("ProductAffiliationKey"))
    )
except Exception as e:
    excep = "Join with ProviderContractProductAff and ProductAffiliation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(affl_joined_df, re0064_tbl_name)
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# MAGIC %md ##Re0064DailyCtrctextDual

# COMMAND ----------

# DBTITLE 1,Read re0064DailyContract stage table and filter it to create required outbound
try:
    # Read data from re0064 stage layer.
    re0064_df = read_table_to_df(re0064_tbl_name).select(
        "PcaStatCd",
        "ContractProgramTypeCode",
        "CycleNumber",
        substring(col("PcaCtrctKey"), 1, 9).alias('ProviderIdNbr'),
        substring(col("PcaCtrctKey"), 10, 2).alias('ProviderSuffixCode'),
        substring(col("PcaCtrctKey"), 12, 3).alias('ProviderServiceTypeCode'),
        "VendorNumber"
    )

    #Filter re0064DailyContract data on below conditions:
    df_re0064_fltr = re0064_df.filter(
        (trim(col("PcaStatCd")) == "A")
        & (col("ContractProgramTypeCode") == "DUAL")
        & (col("CycleNumber").isin(5, 9, 10, 11))
        & (col("ProviderServiceTypeCode").isin("PCP", "FFS"))
        ).select('ProviderIdNbr','ProviderSuffixCode','VendorNumber')
except Exception as e:
    excep = "Write processed data to ADLS failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_re0064_fltr, re0064_dual_tbl_name)

    # Read data from stage layer.
    re0064_dual_df = read_table_to_df(re0064_dual_tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0064_dual_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write processed data to ADLS failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC #### Create an interface to generate an outbound Daily PIMS file for PE and EDW application
# MAGIC
# MAGIC ##### To acheive the requirement below steps has been followed.
# MAGIC
# MAGIC * Step 1: Extract contract details and provider name details from Geo Market and Provider Contract Delta Lake Unity Catalog table. 
# MAGIC * Step 2: Mainframe system shall be able to provide the CAS Provider Attribution and Category Code details files on NAS drive 
# MAGIC * Step 3: Create a CAS Provider Category Code Delta Lake Unity Catalog table
# MAGIC * Step 4: Combine the result of contract and provider name details with CAS provider category table using provider key to get Provider Attribution Code and create Daily PIMS Delta Lake Unity Catalog Table .
# MAGIC * Step 5: Extract the details from Daily PIMS Delta Lake Unity Catalog table and generate a Daily PIMS text file at NAS drive
# MAGIC * Step 6: Generate and Upload the DailyPIMSFile file  to ADLS container / Outbound folder
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Source table 
# MAGIC - ProviderContract.ProviderContract 
# MAGIC - Provider.GeoMarket 
# MAGIC - Provider.GeoMarketCycle
# MAGIC - Provider.Provider
# MAGIC - Provider.GeoMarketCycle
# MAGIC - ProviderContract.ProviderContractControl
# MAGIC - ProviderContract.ProviderContractGeoMktAffiliation
# MAGIC
# MAGIC ##### Inbound File
# MAGIC - CAS Provider Attribution and Category Code details file
# MAGIC
# MAGIC
# MAGIC ##### Outbound File
# MAGIC - DailyPIMSFile.txt

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "IN_PE_PEPRVATR_CCYYMMDD"

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskDaliyPIMSFileSyncUp')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import ingest notebook
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Provider Contract table schema
# MAGIC %run ./ProviderContractStageSchema

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Getting config & stage table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(env_table_details_config_path)
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = "Read File Config and Fixed Width File Config: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Loading inbound file to Table
#loading file to stage table
try:
    main_function_dp_ci(conf, stage_tbl_name, CASProviderCategory_schema)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    DailyPIMS = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = DailyPIMS["Outbound"]["TempFilePathSuffix"]   
    curated_path_suffix = DailyPIMS['Outbound']['CuratedFilePathSuffix']
    tbl_name = DailyPIMS['Outbound']['TableName']
    outbnd_file_name = DailyPIMS["Outbound"]["FileName"]

    stg_prov_con_tbl_name = DailyPIMS["Inbound"]["StageProviderContract"]
    stg_geo_mrk_tbl_name = DailyPIMS["Inbound"]["StageGeoMarket"]
    stg_geo_mkt_cycl_tbl_name = DailyPIMS["Inbound"]["StageGeoMarketCycle"]
    stg_prov_con_ctrl_tbl_name = DailyPIMS["Inbound"]["StageProviderContractControl"]
    stg_prov_con_geo_mkt_aff_tbl_name = DailyPIMS["Inbound"]["StageProviderContractGeoMktAffiliation"]
    stg_prv_tbl = DailyPIMS["Inbound"]["StageProvider"]
    stg_CASProviderCategory_tbl = DailyPIMS["Inbound"]["StageCASProviderCategory"]
      
        
    sync_process_names = DailyPIMS["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account,
        file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read table data into the dataframe from the respective table.
try: 
    # Read the data from Geo Market Stage table(Adls).
    df_geo_mkt = read_table_to_df(stg_geo_mrk_tbl_name)
    # Read the data from ProviderContract Stage table(Adls).
    df_prov_con = read_table_to_df(stg_prov_con_tbl_name)
    # Read the data from Geo Market Cycle Stage table(Adls).
    df_geo_mkt_cycl = read_table_to_df(stg_geo_mkt_cycl_tbl_name)
    # Read the data from ProviderContractControl Stage table(Adls).
    df_prov_con_ctrl = read_table_to_df(stg_prov_con_ctrl_tbl_name)
    # Read the data from ProviderContractGeoMarketAffiliation Stage table(Adls).
    df_prov_con_geo_mkt_aff = read_table_to_df(stg_prov_con_geo_mkt_aff_tbl_name)
    # Read the data from Provider Stage table(Adls).
    df_prvdr = read_table_to_df(stg_prv_tbl)
    # Read the data from CAS Provider Category code Stage table(Adls).
    df_CASProviderCategory = read_table_to_df(stg_CASProviderCategory_tbl)   
  
     
except Exception as e:
    excep = "Read Sql Tables: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Derive required columns for the report from respective tables.
try:
    # Derive column "GeoMarketId" from table GeoMarket & Column "CycleNumber" from GeoMarketCycle using key column "GeoMarketKey".
    df_geo_mkt_fltr = (
        df_geo_mkt_cycl.join(df_geo_mkt, ["GeoMarketKey"])
        .select("GeoMarketId", "CycleNumber")
        .filter(col("CycleNumber").isin([1, 2, 20, 21, 22, 23, 31, 32, 50, 51, 52, 53]))
    )

    # Derive column ControlTypeId from provider contract control table.
    df_prov_con_ctrl_fltr = df_prov_con_ctrl.filter(
        col("ControlTypeCode") == "LedgerNumber"
    ).select("ProviderContractKey", "ControlTypeId")

    # Derived Provider Contract details along with contract start end date, status code, ProviderGrouperId from Provider Contract table.
    df_prov_con_fltr = (
        df_prov_con.filter(col("StatusCode") == "A")
        .filter((col("ProviderId") >= 100000) & (col("ProviderId") <= 999999))
        .select(
            "ProviderContractKey",
            'ProviderKey',
            "ProviderGrouperId",
            "ProviderId",
            "ProviderSuffixCode",
            "ProviderServiceTypeCode",
            "ProviderSequenceNumber",
            "StatusCode",
            "ContractStartDate",
            "ContractEndDate",
        )
    )

    # Derived columns from ProviderContract & ProviderContractControl table using key column "ProviderContractKey".
    df_pro_con_ctrl_join = df_prov_con_ctrl_fltr.join(
        df_prov_con_fltr, ["ProviderContractKey"]
    ).select(
        "ProviderContractKey",
        "ProviderKey",
        "ControlTypeId",
        "ProviderGrouperId",
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber",
        "StatusCode",
        "ContractStartDate",
        "ContractEndDate",
    )

    # Derive column "GeoMarketId" from table ProviderContractGeoMktAffiliation using key column "ProviderContractKey".
    df_pro_con_fltr_final = (
        df_pro_con_ctrl_join.alias("LH")
        .join(df_prov_con_geo_mkt_aff.alias("RH"), ["ProviderContractKey"])
        .select("RH.GeoMarketId", "LH.*")
    )

    df_prov_con_nam_ext = df_geo_mkt_fltr.join(df_pro_con_fltr_final, ["GeoMarketId"]).select(
        "ProviderKey",
        "CycleNumber",
        "ControlTypeId",
        "ProviderGrouperId",
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber",
        "StatusCode",
        "ContractStartDate",
        "ContractEndDate",
    ).orderBy(asc(col("GeoMarketId")), asc(col("ProviderId")), asc(col("ProviderSuffixCode")), asc(col("ProviderServiceTypeCode")) ,asc(col("ProviderSequenceNumber")))
    
    # Derive the provider name from the provider table
    df_prvdr_fltr = (
    df_prvdr.filter(
        (col("ProviderId") >= "000100000") & (col("ProviderId") <= "000999999")
    )
    .select("ProviderKey", "ProviderId", "SuffixCode", "ProviderName")
    .withColumn(
        "Provider_key", concat(col("ProviderId"), lpad(col("SuffixCode"), 2, "  "))
    )
    ) 

    df_prvdr_fltr_rnm = df_prvdr_fltr.withColumnRenamed("SuffixCode", "ProviderSuffixCode")

   
except Exception as e:
    excep = "Read Sql Tables: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Extract contract and provider name details from Geo Market and Provider Contract UC table
try:  
    df_prov_con_nam_ext = df_prov_con_nam_ext.select(
    "ProviderKey", "ProviderId", "ProviderSuffixCode"
    ).distinct()
    
    df_prov_con_nam_ext_fltr = (
        df_prov_con_nam_ext.alias("LH2")
        .join(df_prvdr_fltr_rnm.alias("RH2"), ["ProviderKey"])
        .select("LH2.ProviderId", "LH2.ProviderSuffixCode", "RH2.ProviderName")
        .orderBy(asc(col('ProviderId')), asc(col('ProviderSuffixCode')))
    )
    
except Exception as e:
    excep = 'Read sql tables: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Prepare dataframe to create Daily PIMS Delta Lake Unity Catalog Table
try:
    # Combine the result of contract and provider name details with CAS provider category table using provider key to get Provider Attribution Code
    df_CASProviderCategory_fltr = df_CASProviderCategory.withColumn('ProviderId', substring(col("PeprvatrSourceId"), 1, 9)).withColumn('ProviderSuffixCode', substring(col("PeprvatrSourceId"), 10, 1)).withColumn('Provider_key', concat(substring(col("PeprvatrSourceId"), 1, 9), lit(' '),substring(col("PeprvatrSourceId"), 10, 1)) ).filter(col("ProvAttrTypeCd") == 'PROVCLSS')

    # Prepare the provider key from provider id and provider suffix code
    df_prvdr_key_ext = df_prov_con_nam_ext_fltr.withColumn(
            "Provider_key",
            concat(col("ProviderId"), lpad(col("ProviderSuffixCode"), 2, "  ")),
        )

    df_final = df_prvdr_key_ext.alias("LH3").join(df_CASProviderCategory_fltr.alias("RH3"), ['Provider_key']).select('LH3.ProviderId' , 'LH3.ProviderSuffixCode', 'LH3.ProviderName' , 'RH3.ProvAttrCd').orderBy(asc(col("ProviderId")), asc(col("ProviderSuffixCode")))

except Exception as e:
    excep = "Read sql tables: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Adding all the hardcoded columns to the dataframe
try:  
  df_final = (
    df_final.withColumn("filler1", lit(" ").cast("String"))
    .withColumn("filler2", lit(" ").cast("String"))
    .withColumn("filler3", lit(" ").cast("String"))
    .withColumn("filler4", lit(" ").cast("String")))    
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, tbl_name)
    # Read data from stage area.
    PIMS_df = spark.read.table(tbl_name)
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, PIMS_df)
    # write dataframe as .txt file as position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0642 - It’s a process to create an Interface to extract Provider information from Provider Affiliation, contract, Fund and RIF SF tables 
# MAGIC                      and create a daily contract table at stage Area and an Outbound contract Focus file for EDW and DO System 
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - Provider.StageProvider
# MAGIC - Provider.StageProviderVendor
# MAGIC - Provider.StageGeoMarket
# MAGIC - Product.StageProductAffiliation
# MAGIC - ProviderContract.StageProviderContractProductAffiliation
# MAGIC - ProviderContract.StageProviderContractControl
# MAGIC - ProviderContract.StageProviderContractType
# MAGIC - ProviderContract.Stage ProviderContractPaymentHeader
# MAGIC - ProviderContract.StageProviderContractFund
# MAGIC - RIF.StageRIF
# MAGIC - RIF.StageRIFProviderContract
# MAGIC - Accounting.StageSettlementProviderContract
# MAGIC - Member.StageMemberCoverage
# MAGIC
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - ProviderContract.Re0642DailyContractFileEDW
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenCYC*RectrctFocusEdwDaily.txt
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Import required library. 
import json

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0642_config = config_dict[JOB_NAME]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re0642_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re0642_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re0642_config["Outbound"]["TableName"] 
    outbnd_file_name = re0642_config["Outbound"]["FileName"]
    
    #input table name
    stg_pc_tbl = re0642_config["Inbound"]["StageProviderContract"]
    stage_pc_geomkt_aff_tbl = re0642_config["Inbound"]["StageProviderContractGeoMktAffiliation"]
    stg_pc_prd_aff_tbl = re0642_config["Inbound"]["StageProviderContractProductAffiliation"]
    stg_prv_vnd_tbl = re0642_config["Inbound"]["StageProviderVendor"]
    stg_prv_tbl = re0642_config["Inbound"]["StageProvider"]
    stg_pc_fund_tbl = re0642_config["Inbound"]["StageProviderContractFund"]
    stg_pc_fnd_paymt_tbl = re0642_config["Inbound"]["StageProviderContractFundPayment"]
    stg_prv_geomkt_tbl = re0642_config["Inbound"]["StageGeoMarket"]
    stg_prv_geomktcyc_tbl = re0642_config["Inbound"]["StageGeoMarketCycle"]
    stg_prd_affil_tbl =  re0642_config["Inbound"]["StageProductAffiliation"]
    stg_pc_ctrl_tbl = re0642_config["Inbound"]["StageProviderContractControl"]
    stg_pc_type_tbl = re0642_config["Inbound"]["StageProviderContractType"]
    stg_pc_pytmhdr_tbl = re0642_config["Inbound"]["StageProviderContractPaymentHeader"]
    stg_rif_tbl =  re0642_config["Inbound"]["StageRIF"]
    stg_rif_pc_tbl = re0642_config["Inbound"]["StageRIFProviderContract"]
    stg_stlmnt_pc_tbl = re0642_config["Inbound"]["StageSettlementProviderContract"]
    stg_mbr_cvg_tbl = re0642_config["Inbound"]["StageMemberCoverage"]

    sync_process_names = re0642_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
    part_col = 'CycleNumber'
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account, prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
# Add required columns to the list from ProviderContractFund table.
prv_ctrt_fund_req_cols = [
    "ProviderContractKey"
,'FundSequenceNumber'
,'FundTypeCode'
,'FundMethodCode'
,'FundExpenseMethodCode'
,'ExpensedFundTypeCode'
,'FundPeriodMonthCount'
,'SharedFundGroupId'
,'ProviderDiscountKey'
,'FundedAcountId'
,'PrePaymentServiceIndicator'
,'FundClaimRecoverIndicator'
,'FundPlanClaimPaymentIndicator'
,'FundClaimCalculatedMethodCode'
,'PeriodPaymentBasisCode'
,round(col('PeriodPaymentDirectPayPercent'),2).alias('PeriodPaymentDirectPayPercent')
,'PeriodPaymentFrequencyCount'
,'PaymentLastDate'
,'PeriodSettlementId'
,'PeriodSettlementPayIndicator'
,'FinalSettlementId'
,'FundIBNRMethodCode'
,'ContnAdmnDayCount'
,'CompletionFactorId'
,round(col('FundIBNRPercent'), 2).alias('FundIBNRPercent')
,'IBNRPeriodMonthCount'
,'CatastrophHoldBackIndicator'
,'PartAEligibileIndicator'
]

# Add required columns to the list from Provider table.
prv_req_cols = [
    'ProviderKey',
    'TypeCode',
    'ProviderName',
    'IRSNumber',
    'SpecialtyCode',
    'AddressLine1Text',
    'AddressLine2Text',
    'CityName',
    'StateCode',
    'ZipCode'
]

# Add required columns to the list from ProviderVendor table.
prv_vndr_req_cols = [
    'ProviderKey',
    'VendorNumber'
]

# Add required columns to the list from ProviderContractProductAffiliation table.
prv_ctrt_prdt_aff_req_cols = [
    "ProviderContractKey"
    ,"ProductAffiliationKey"
]

# Add required columns to the list from ProviderContractControl table.
prv_ctrt_ctrl_req_cols = [
    "ProviderContractKey",
    "ControlTypeCode",
    "ControlTypeId"
]

# Add required columns to the list from ProviderContractType table.
prv_ctrt_type_req_cols = [
    "ProviderContractKey",
    "ContractTypeCode",
    "ContractlTypeId"
]
# Add required columns to the list from ProductAffiliation table.
prd_aff_req_cols = [
    "ProductAffiliationKey",
    "LineOfBusinessCode",
    "LocationId"
]

# COMMAND ----------

# DBTITLE 1,Reading Required Tables from ADLS and AzureSQL
try:  
    df_prvdr_ctrct= read_table_to_df(stg_pc_tbl)
    df_prd_aff= read_table_to_df(stg_prd_affil_tbl).select(*prd_aff_req_cols)
    df_pc_prd_aff= read_table_to_df(stg_pc_prd_aff_tbl).select(*prv_ctrt_prdt_aff_req_cols)
    df_prv_vndr = read_table_to_df(stg_prv_vnd_tbl).select(*prv_vndr_req_cols)
    df_geomkt = read_table_to_df(stg_prv_geomkt_tbl).select('GeoMarketKey','GeoMarketId','GeoMarketName','StatusCode','GeoMarketStartDate')
    df_geomkt_cyc = read_table_to_df(stg_prv_geomktcyc_tbl).select('GeoMarketKey','CycleNumber')
    df_prvdr = read_table_to_df(stg_prv_tbl).filter(col('Type2Code').isin('D','H')).select(*prv_req_cols)
    df_prvdr_cntrl = read_table_to_df(stg_pc_ctrl_tbl).select(*prv_ctrt_ctrl_req_cols)
    df_prvdr_type = read_table_to_df(stg_pc_type_tbl).select(*prv_ctrt_type_req_cols)
    df_prvdr_pymnt_hdr= read_table_to_df(stg_pc_pytmhdr_tbl).select('ProviderContractKey','PaymentUpdaterName','PaymentDate')\
                            .filter(trim(col('PaymentUpdaterName')) != '')
    pc_fund_df = read_table_to_df(stg_pc_fund_tbl).select(*prv_ctrt_fund_req_cols)
    df_rif = read_table_to_df(stg_rif_tbl).select('RIFKey','RIFId')
    df_rif_pc =read_table_to_df(stg_rif_pc_tbl).select('ProviderContractKey','RIFKey')
    df_setl_pc =read_table_to_df(stg_stlmnt_pc_tbl).select('ProviderContractKey','SettlementControlId')
    df_mbr_cvg = read_table_to_df(stg_mbr_cvg_tbl).select(col('ProviderContractKey').alias('MbrCvgPCKey')).distinct()

except Exception as e:
    excep = 'Read Sql Tables failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Empty Check of all the tables used
try:
    if (df_prvdr_ctrct.rdd.isEmpty()) or (df_prd_aff.rdd.isEmpty()) or (df_pc_prd_aff.rdd.isEmpty()) or (df_prv_vndr.rdd.isEmpty()) or (df_geomkt.rdd.isEmpty()) or (df_geomkt_cyc.rdd.isEmpty()) or (df_prvdr.rdd.isEmpty()) or (df_prvdr_cntrl.rdd.isEmpty()) or (df_prvdr_type.rdd.isEmpty()) or (df_prvdr_pymnt_hdr.rdd.isEmpty()) or (pc_fund_df.rdd.isEmpty()) or (df_rif.rdd.isEmpty()) or (df_rif_pc.rdd.isEmpty()) or (df_setl_pc.rdd.isEmpty()) or (df_mbr_cvg.rdd.isEmpty()):
        raise Exception("Dataframe is Empty")
except Exception as e:
    excep = 'Empty check failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProviderContract with MemberCoverage on ProviderContractKey
#Join ProviderContract with MemberCoverage on ProviderContractKey
try:
    joined_mbrcvrg_provctrct_df=df_prvdr_ctrct.alias("LH").join(df_mbr_cvg.alias("RH"),((col("LH.ProviderContractKey"))==(col("RH.MbrCvgPCKey"))),"left")
except Exception as e:
    excep = 'join with member coverage failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Update column CtrprodMbrMoCnt to 1 if ProviderContractKey is not null else update to 0
#Update column CtrprodMbrMoCnt to 1 if ProviderContractKey is not null else update to 0
try:
    filtered_prvdr_ctrct_df=joined_mbrcvrg_provctrct_df.withColumn("CtrprodMbrMoCnt",when(col("MbrCvgPCKey").isNotNull(),lit(1)).otherwise(lit(0))).drop('MbrCvgPCKey')
except Exception as e:
    excep = 'Update column CtrprodMbrMoCnt failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select Required Columns from ProviderContractControl and ProviderContractType
try:
    df_prvdr_cntrl_fltr= df_prvdr_cntrl.filter(col('ControlTypeCode').isin(['Capitation/Rate','MandateSpecialist','Stoploss','LedgerNumber',
                                        'OutOfAreaNetwork','CostAllocation','GeoMkt','ClaimRule']))
    df_prvdr_type_fltr= df_prvdr_type.filter(col('ContractTypeCode').isin(['FundedContract','Re-AssignContract','MailContract/Rate',
                                        'PaymentContract','SettlementContract']))
except Exception as e:
    excep = 'Select Required Columns from ProviderContractControl and ProviderContractType failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Pivot ProviderContractControl and ProviderContractType Table
try:
    df_prvdr_cntrl_pvt = pvt_cols(df_prvdr_cntrl_fltr,['ProviderContractKey'],'ControlTypeCode','ControlTypeId')
    df_prvdr_type_pvt = pvt_cols(df_prvdr_type_fltr,['ProviderContractKey'],'ContractTypeCode','ContractlTypeId')
except Exception as e:
    excep = 'Pivot ProviderContractControl and ProviderContractType Table failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting latest PaymentUpdaterName by taking max of PaymentDate
#Selecting latest PaymentUpdaterName by max of PaymentDate:
try:
    windowSpec = Window.partitionBy('ProviderContractKey').orderBy(col('PaymentDate').desc())
    df_prvdr_pymnt_hdr_fltrd = df_prvdr_pymnt_hdr.withColumn('max',row_number().over(windowSpec))\
        .filter(col('max')==1).drop('max','PaymentDate')
except Exception as e:
    excep = 'Selecting latest PaymentUpdaterName failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProviderContract with ProviderContractControl ,ProviderContractType and ProviderContractPaymentHeader
# Joining ProviderContract with ProviderContractControl_pivot, ProviderContractType_pivot and ProviderContractPaymentHeader to get the missing columns
try:
    df_prvdr_ctrct_joined = (
        filtered_prvdr_ctrct_df.alias("pc_fltrd")
        .join(
            df_prvdr_cntrl_pvt.alias("cntrl_pvt"),col("pc_fltrd.ProviderContractKey") == col("cntrl_pvt.ProviderContractKey"),"left")
        .join(
            df_prvdr_type_pvt.alias("type_pvt"),col("pc_fltrd.ProviderContractKey") == col("type_pvt.ProviderContractKey"),"left")
        .join(
            df_prvdr_pymnt_hdr_fltrd.alias("pymnt_hdr_fltrd"),
            col("pc_fltrd.ProviderContractKey")== col("pymnt_hdr_fltrd.ProviderContractKey"),"left")
    )
except Exception as e:
    excep = ("Join ProviderContract with ProviderContractControl and ProviderContractType failed: "+ str(e))
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting required columns from ProviderContract 
try:
    df_prvdr_ctrct_final = df_prvdr_ctrct_joined.select(
    col('ProviderContractId').alias('CtrctPcaKey')
    ,concat(col('ProviderId'),col('ProviderSuffixCode')).alias('SrvcProvId')
    ,'ProviderId'
    ,'CtrprodMbrMoCnt'
    ,'ProviderSuffixCode'
    ,'ProviderServiceTypeCode'
    ,'ProviderSequenceNumber'
    ,col('ContractEndDate').alias('SrvcPcaEndDate')
    ,col('ContractStartDate').alias('PcaBegCymdDate')
    ,col('ContractEndDate').alias('PcaEndCymdDate')
    ,'StatusCode'
    ,'StatusDate'
    ,'RenewalDate'
    ,'ProductLineOfBusinessCode'
    ,'ProviderGrouperId'
    ,'ExpenseId'
    ,'ReportPackageControlId'
    ,'PaymentAccountNumber'
    ,'CapitationBeginCode'
    ,'CapitationEndCode'
    ,'TerminationMaximumCount'
    ,'AdditionalMaximumCount'
    ,'DefaultStatusIndicator'
    ,'PaymentOptionCode'
    ,'FundClassCode'
    ,'ContractProgramTypeCode'
    ,'ProviderMemberCount'
    ,'MemberTypeCode'
    ,'MemberLimitCode'
    ,'ReportControlId'
    ,round(col('RecoveryPaymentAmount'), 2).alias('RecoveryPaymentAmount')
    ,round(col('RecoveryPercent'), 2).alias('RecoveryPercent')
    ,'RecoveryMonthCount'
    ,'RecoveryFundTypeCode'
    ,concat(col('ProviderId'),col('ProviderSuffixCode')).alias('CtrprodProvId')
    ,'IPAIndicator'
    ,substring(col('ContractStartDate'),3,8).alias('CtprodBegDate')
    ,when(col('ContractEndDate')=='9999-12-31','99-99-99').otherwise(substring(col('ContractEndDate'),3,8)).alias('CtprodEndDate')
    ,'PaymentDateNumber'
    ,'ReprocessIndicator'
    ,substring(col('ReprocessDate'),3,8).alias('PcaCtrctRprocDate')
    ,'LateClaimCode'
    ,'EverPaymentCode'
    ,col('ReprocessDate').alias('RprocDateCymd')
    ,'ReportDetailIndicator'
    ,'CategoryCode'
    ,col('ProviderContractId').alias('CtrctDbkey')
    ,'FundPeriodBeginCode'
    ,'SettlementPeriodPaymentCode'
    ,'SettlementAnnualPaymentCode'
    ,'SettlementByFundIndicator'
    ,'ContractCountyCode'
    ,'SettlementFrequencyCode'
    ,'ContractLagAnnualCount'
    ,'Settlement1Description'
    ,'Settlement2Description'
    ,'DistanceCalculatedIndicator'
    ,'DistanceLengthNumber'
    ,col("LedgerNumber").alias('CtrctMarketId'),
    col("LedgerNumber").alias('PcaFinRptLedgrNbr'),
    col("MailContract/Rate").alias("MailContractKey"),
    "FundedContract",
    "PaymentContract",
    col("Re-AssignContract").alias("ReAssignContract"),
    col("Capitation/Rate").alias("CapitationRate"),
    "SettlementContract",
    "MandateSpecialist",
    "Stoploss",
    'OutOfAreaNetwork',
    'CostAllocation',
    'ClaimRule',
    'PaymentUpdaterName',
    col('GeoMkt').alias('GeoMarketId'),
    'ProviderKey',
    'pc_fltrd.ProviderContractKey'
    )
except Exception as e:
    excep = "Selecting required columns from ProviderContract failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 1: Join ProviderContract and GeoMarket
# Join GeoMarket with GeomarketCycle on GeoMarketKey to get CycleNumber.
try:
    geo_mkt_df = df_geomkt\
            .join(df_geomkt_cyc, ['GeoMarketKey'], 'inner')\
            .selectExpr("*","StatusCode AS PcaGrpStatCd","StatusCode AS GrpStat").drop("StatusCode")

    # Join providerContract with GeoMarket on GeoMarketId.
    geo_mkt_joined_df = df_prvdr_ctrct_final\
            .join(geo_mkt_df, ['GeoMarketId'], 'inner').drop('GeoMarketKey')
except Exception as e:
    excep = "Join providerContract with GeoMarket failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 2: Join with Provider and ProviderVendor table
# Join output of step1 with Provider and ProviderVendor table 
try:
    prov_joined_df = geo_mkt_joined_df.join(df_prvdr,['ProviderKey'],'inner').selectExpr("*","ProviderName AS PcaName")
    prov_vndr_joined_df = prov_joined_df.join(df_prv_vndr,['ProviderKey'],'inner').drop('ProviderKey')
except Exception as e:
    excep = "Join with Provider table failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 3: Join step 2 output with ProviderContractProductAffiliation and then with ProductAffiliation
# Step1: Join above dataframe with ProviderContractProductAffiliation table on ProviderContractKey
# Step2: The output of step1 is joined with ProductAffiliation table on ProductAffiliationKey and then selecting the required for the output file
try:
    affl_joined_df = (
        prov_vndr_joined_df.alias("LH")
        .join(
            df_pc_prd_aff.alias("PCAFF"),
            ["ProviderContractKey"],
            "left",
        )
        .join(
            df_prd_aff.alias("PAFF"),
            ["ProductAffiliationKey"],
            "left",
        )
        .drop("ProductAffiliationKey")
    )
except Exception as e:
    excep = "Join with ProviderContractProductAff and ProductAffiliation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 4: Updating column LocationId to 'Not Found' and LineOfBusinessCode to '000' if it is null
try:
    affl_joined_df_sel = affl_joined_df.withColumn("LocationId",when(col('LocationId').isNull(),lit("NOT FOUND")).otherwise(col('LocationId')))\
                                       .withColumn("LineOfBusinessCode",when(col('LineOfBusinessCode').isNull(),lit("000")).otherwise(col('LineOfBusinessCode')))
except Exception as e:
    excep = "Updating column LocationId and LineOfBusinessCode if it is null failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 5: Getting count of fund details for each Provider Contract data
#Getting count of fund details for each Provider Contract data
try:    
    fnd_count_df = pc_fund_df.groupBy("ProviderContractKey").count()
    pc_fnd_cnt_joined_df = (
        pc_fund_df.alias("LH")
        .join(fnd_count_df.alias("RH"), ["ProviderContractKey"], "left")
        .select("*", col("count").alias("CtrprodFndCount"))
        .drop("RH.ProviderContractKey","count")
    )
except Exception as e:
    excep = "Getting count of fund details failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 5: Joining step 4 with step 5 output on ProviderContractKey
#Joining step 4 with step 5 output on ProviderContractKey to get fund columns
try:
    fund_joined_df = affl_joined_df_sel.join(pc_fnd_cnt_joined_df,['ProviderContractKey'],'left')\
                     .selectExpr("*","FundSequenceNumber AS CtrctFundRptSeqNbr","FundSequenceNumber AS FdfFundRptSeqNbr").drop("FundSequenceNumber")
except Exception as e:
    excep = "Join with ProviderContractFund failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Updating column CtrctFundRptSeqNbr & FdfFundRptSeqNbr to 999 if it is null
try:
    fund_joined_df_sel = fund_joined_df.withColumn("CtrctFundRptSeqNbr",when(col('CtrctFundRptSeqNbr').isNull(),lit(999)).otherwise(col('CtrctFundRptSeqNbr')))\
                                        .withColumn("FdfFundRptSeqNbr",when(col('FdfFundRptSeqNbr').isNull(),lit(999)).otherwise(col('FdfFundRptSeqNbr')))\
                                        .withColumn("PaymentLastDate",when(col('PaymentLastDate').isNull(),lit('0000-00-00')).otherwise(col('PaymentLastDate')))
except Exception as e:
    excep = "Updating column CtrctFundRptSeqNbr & FdfFundRptSeqNbr to 999 if it is null failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join above output with RIF and SettlementProviderContract 
#Join above output with RIF and SettlementProviderContract  to get RIFId and SettlementControlId
try:
    rif_rifpc_setl_df = df_rif_pc.join(df_rif,['RIFKey'],'left')
                            
    joined_df = fund_joined_df_sel.join(rif_rifpc_setl_df,['ProviderContractKey'],'left').join(df_setl_pc,['ProviderContractKey'],'left')\
                                .drop('ProviderContractKey','RIFKey')
except Exception as e:
    excep = "Join with RIF and SettlementProviderContract failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1, Adding all the hardcoded columns
# Adding all the hardcoded columns
try:
    df_final = joined_df.selectExpr(
        "*",
        " ' ' AS SrvcName",
        "round(0.00,2) as CtrprodFundHistAmt",
        "round(0.00,2) as CtrprodClmsHistAmt",
        " ' ' as Filler1",
        " ' ' as Filler2",
        " ' ' as Filler3",
        " ' ' as Filler4",
        " ' ' as Filler5",
        " ' ' as Filler6",
        " ' ' as Filler7",
        " '0' as MstrIdNbr",
        " ' ' as MstrSuffCd",
        " ' ' as MstrServTyCd",
        " '0' as MstrSeqNbr",
        " 'N' as MstrCtrctInd",   
        "CASE WHEN PartAEligibileIndicator ='*' THEN 'NA' WHEN PartAEligibileIndicator ='N' THEN 'N' WHEN PartAEligibileIndicator ='Y' THEN 'Y' END AS FdfFullMedicareCap",
    ).drop('PartAEligibileIndicator')
except Exception as e:
    excep = " Adding the hardcoded columns failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS stage area
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, tbl_name,part_col)
except Exception as e:
    excep = 'Write to ADLS stage area failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1, Write the file as text file in ADLS and move to outbound folder and rename it.
try:
    # Read data from stage area.
    file_name_split = outbnd_file_name.split('CYC')
    part_details_df = spark.sql(f"SHOW Partitions {tbl_name}")
    cycle_no = [row.CycleNumber for row in part_details_df.collect()]
    fileNamesList = []
    for cycle in cycle_no:
        # Read data from stage area.
        re0642_df= read_table_to_df(tbl_name).filter(col('CycleNumber')== cycle)
        # Convert dataframe to fixed width length column.
        final_df = convert_col_to_fixed_width(fixed_config_df, re0642_df)
        # write dataframe as text file with position delimited.
        write_outbnd_file_to_adls(final_df, temp_csv_path, config)
        # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
        file_name = file_name_split[0]+'CYC'+str('{:02d}'.format(cycle))+file_name_split[1]
        copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, file_name)
        fileNamesList.append(file_name)
except Exception as e:
    excep = 'Move to outbound folder: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    fileNames = ','.join(fileNamesList)
    output = {
        'OUTBOUND_FILE_NAMES' : fileNames,
		'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
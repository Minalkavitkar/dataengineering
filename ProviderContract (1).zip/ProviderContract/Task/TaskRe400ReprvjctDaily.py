# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE400 - The main purpose of this job is to fetch Provider Contract Information from Azure SQL Database, which is used by SubLedger(GG) system.
# MAGIC
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - ProviderContract.StageProviderContractProductAffiliation
# MAGIC - ProviderContract.StageProviderContractFund
# MAGIC - ProviderContract.StageProviderContractFundPayment
# MAGIC - ProviderContract.StageProviderContractControl
# MAGIC - Provider.StageGeoMarket
# MAGIC - Provider.StageGeoMarketCycle
# MAGIC - Product.StageProductAffiliation
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - ProviderContract.Re400ReprvjctDaily
# MAGIC
# MAGIC ###### Target details (File):
# MAGIC - ProdrevRe400ReprvjctDailyFile.csv (CSV File)
# MAGIC ###### Created By: Dinesh S
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
import json
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path)\
                        .filter(col("JobName") == job_name)
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    re400_config = config_dict[job_name]

    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    cur_path_suffix = re400_config["Outbound"]["CuratedFilePathSuffix"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_file_path_suffix = re400_config["Outbound"]["TempFilePathSuffix"]
    outbnd_file_name = re400_config["Outbound"]["FileName"]
    config = default_out_config["Config"]
    cur_tbl_name = re400_config["Outbound"]["TableName"]
    #input table names:
   
    stg_prv_ctrct_tbl = re400_config["Inbound"]["StageProviderContract"]
    stg_pc_geomktaffil_tbl = re400_config["Inbound"]["StageProviderContractGeoMktAffiliation"]
    stg_pc_prdaffil_tbl = re400_config["Inbound"]["StageProviderContractProductAffiliation"]
    stg_pc_fund_tbl = re400_config["Inbound"]["StageProviderContractFund"]
    stg_pc_fnd_paymt_tbl = re400_config["Inbound"]["StageProviderContractFundPayment"]
    stg_prv_geomkt_tbl = re400_config["Inbound"]["StageGeoMarket"]
    stg_prv_geomktcyc_tbl = re400_config["Inbound"]["StageGeoMarketCycle"]
    stg_prd_affil_tbl =  re400_config["Inbound"]["StageProductAffiliation"]
    stg_pc_ctrl_tbl = re400_config["Inbound"]["StageProviderContractControl"]
    stg_inbnd_dt_tbl = re400_config["Inbound"]["StageInboundDateTable"]
    sync_process_names = re400_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]

except Exception as e:
    excep = 'Variable assignment from FileConfig: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account, prc_file_path_prefix, temp_file_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
# Add required columns to the list from ProviderContractFund table.
prv_ctrt_fund_req_cols = [
    "ProviderContractFundKey"
    ,"ProviderContractKey"
]

# Add required columns to the list from ProviderContractFundedPayment table.
prv_ctrt_fund_pymt_req_cols = [
    "ProviderContractFundKey"
    ,"OpenFundIndicator"
]

# Add required columns to the list from ProviderContractProductAffiliation table.
prv_ctrt_prdt_aff_req_cols = [
    "ProviderContractKey"
    ,"ProductAffiliationKey"
]

# Add required columns to the list from ProviderContractControl table.
prv_ctrt_ctrl_req_cols = [
    "ProviderContractKey",
    "ControlTypeCode",
    "ControlTypeId"
]
# Add required columns to the list from ProviderContractGeoMarket table.
geo_mkt_req_cols = [
    "GeoMarketKey",
    "GeoMarketId",
]
# Add required columns to the list from ProviderContractGeoMarketCycle table.
geo_mkt_cyc_req_cols = [
    "GeoMarketKey",
    "CycleNumber"
]
# Add required columns to the list from ProviderContract table.
prv_ctrt_req_cols = [
    "ProviderServiceTypeCode",
    "ProviderContractId",
    "ProviderSequenceNumber",
    "ProviderId",
    "ProviderSuffixCode",
    "PCPPlanYearCode",
    "IPAIndicator",
    "StatusCode",
    "ContractStartDate",
    "ContractEndDate",
    "ProviderMemberCount",
    "MemberLimitCode",
    "MemberTypeCode",
    "ProviderGrouperId",
    "ProviderContractKey",
    "ReprocessDate"
]
# Add required columns to the list from ProductAffiliation table.
prd_aff_req_cols = [
    "ProductAffiliationKey",
    "LineOfBusinessCode",
    "LocationId"
]

# COMMAND ----------

# DBTITLE 1,Read data from stage tables.

try:
# Read the data from ProviderContract Stage table(Adls) and select columns which are required for the process. 
    prv_ctrt_df = read_table_to_df(stg_prv_ctrct_tbl)\
                    .select(*prv_ctrt_req_cols)

# Read the data from GeoMarket Stage table(Adls) and select columns which are required for the process.
    geo_mkt_df = read_table_to_df(stg_prv_geomkt_tbl)\
                    .select(*geo_mkt_req_cols)

# Read the data from GeoMarketCycle Stage table(Adls) and select columns which are required for the process.
    geo_mkt_cyc_df = read_table_to_df(stg_prv_geomktcyc_tbl)\
                    .select(*geo_mkt_cyc_req_cols)

# Read the data from ProviderContractFundedPayment Stage table(Adls) and select columns which are required for the process. 
# Then filter records when the OpenFundIndicator = Y
    prv_ctrct_fund_pymt_df = read_table_to_df(stg_pc_fnd_paymt_tbl)\
                    .select(*prv_ctrt_fund_pymt_req_cols)\
                    .filter(col('OpenFundIndicator') == 'Y')

# Read the data from ProviderContractFund Stage table(Adls) and select columns which are required for the process.
    prv_ctrct_fund_df = read_table_to_df(stg_pc_fund_tbl)\
                    .select(*prv_ctrt_fund_req_cols)

# Read the data from ProviderContractProductAffiliation Stage table(Adls) and select columns which are required for the process.
    prv_ctrt_prdt_aff_df = read_table_to_df(stg_pc_prdaffil_tbl)\
                    .select(*prv_ctrt_prdt_aff_req_cols)
# Read the data from ProviderContractControl Stage table(Adls) and select columns which are required for the process.
    prv_ctrt_ctrl_df = read_table_to_df(stg_pc_ctrl_tbl)\
                    .select(*prv_ctrt_ctrl_req_cols)

# Read the data from ProductAffiliation Stage table(Adls) and select columns which are required for the process.
    prdt_aff_df = read_table_to_df(stg_prd_affil_tbl)\
                    .select(*prd_aff_req_cols)

# Read the data from ProductAffiliation Stage table(Adls) and select columns which are required for the process.
    in_cutoff_dt_df = read_table_to_df(stg_inbnd_dt_tbl)
except Exception as e:
    excep = 'Read Sql Tables: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Pivot ProviderContractControlTable.
try:
    filtered_ctrt_ctrl_df = prv_ctrt_ctrl_df\
                .filter(col('ControlTypeCode')\
                .isin(['ClaimRule', 'LedgerNumber', 'GeoMkt']))
                
    pvt_ctrt_ctrl_df = pvt_cols(filtered_ctrt_ctrl_df, ['ProviderContractKey'], 'ControlTypeCode', 'ControlTypeId')
except Exception as e:
    excep = "Pivot ProviderContractControlTable failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 1: Get only required provider contract details and join with ProviderContractControl.
# Filter out records only when ProviderServiceTypeCode not equal to ('SPC', 'HMS', 'GRS')
# Get the ClaimRuleId and LedgerNumber from ProviderContractControl table.
try:
    filtered_df = prv_ctrt_df.filter(~col('ProviderServiceTypeCode')\
                    .isin(['SPC', 'HMS', 'GRS']))\
                    .join(pvt_ctrt_ctrl_df,['ProviderContractKey'],'left')\
                    .withColumnRenamed('GeoMkt', 'GeoMarketId')
except Exception as e:
    excep = "Get only required provider contract details and join with provider contract control failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 2: Join output of step1 with GeoMarket
try:
    # Join GeoMarket with GeomarketCycle on GeoMarketKey to get CycleNumber.
    geo_mkt_df = geo_mkt_df\
            .join(geo_mkt_cyc_df, ['GeoMarketKey'], 'left')
            
    # Join output of Step 5 with GeoMarket on GeoMarketId.
    geo_mkt_joined_df = filtered_df\
            .join(geo_mkt_df, ['GeoMarketId'], 'inner').drop('GeoMarketKey')
except Exception as e:
    excep = "Join output of Step 5 with GeoMarket failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate cut off date
#Read the cut-off date from inbound date file
try:
    cal_in_cutoff_dt_df = in_cutoff_dt_df.withColumn("column",from_unixtime(unix_timestamp(col("col1"),"MMddyy"),"yyyy-MM-dd"))

    cut_off_dt=cal_in_cutoff_dt_df.select(col("column")).collect()[0][0]
except Exception as e:
    excep = "Fetch date from stage inbound table failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 3: Calculate ClmRpocInd and PcaFundedContractInd column.
# Compare the cut off date with Provider contract table, if the ReprocessDate from Provider contract is greater than to Prior Month date, then add 'Y' to ClmRprocInd else add 'N' to ClmRprocInd
# Create PcaFundedContractInd column and populate 'N' to it.
try:
    calc_df = geo_mkt_joined_df\
            .withColumn("ClmRprocInd",when(col("ReprocessDate") > cut_off_dt, lit("Y")).otherwise(lit("N")))\
            .withColumn("PcaFundedContractInd", lit("N"))
except Exception as e:
    excep = "Calculate ClmRpocInd and PcaFundedContractInd failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 4: Join ProviderContractFundPayment with ProviderContractFund
# Join ProviderContractFundPayment with ProviderContractFund on ProviderContractFundKey to obtain ProviderContractKey
# select only the ProviderContractKey and OpenFundIndicator
try:
    fund_pymt_filtered_df = (
        prv_ctrct_fund_pymt_df.alias("LH")
        .join(
            prv_ctrct_fund_df.alias("RH"),
            col("LH.ProviderContractFundKey") == col("RH.ProviderContractFundKey"),
            "inner")
        .select("LH.OpenFundIndicator", "RH.ProviderContractKey")
        .distinct()
    )
except Exception as e:
    excep = "Join ProviderContractFundPayment with ProviderContractFund failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 5: Join output of both Step 3 and Step 4.
try:
# Join calc_df with fund_pymt_filtered_df on ProviderContractKey
    join_pc_fund_pymt_df = calc_df.join(fund_pymt_filtered_df, ['ProviderContractKey'], 'left')\
                    .withColumn('OpenFundIndicator', when(col('OpenFundIndicator') == 'Y', lit('Y')).otherwise(lit('N')))
except Exception as e:
    excep = "Join output of both Step 3 and Step 4 failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 6: Join Step 5 output with ProviderContractProductAff, and ProductAffiliation
# Step1: Join above dataframe with ProviderContractGeoMktAff table on ProviderContractKey
# Step2: The output of Step1 is joined with ProviderContractProductAffiliation table on ProviderContractKey
# Step3: The output of step2 is joined with ProductAffiliation table on ProductAffiliationKey and then selecting the required for the output file
try:
    joined_df = (
        join_pc_fund_pymt_df.alias("CTRT")
        .join(
            prv_ctrt_prdt_aff_df.alias("PCAFF"),
            ["ProviderContractKey"],
            "inner",
        )
        .join(
            prdt_aff_df.alias("PAFF"),
            ["ProductAffiliationKey"],
            "inner",
        )
        .drop("ProductAffiliationKey", "ReprocessDate")
    )
except Exception as e:
    excep = "Join Step 5 output with ProviderContractProductAff, and ProductAffiliation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 7: Calculate RectrtGkProvIdGfld and RectrctvPrvjctDbkey column.
try:
    # Concat ProviderId and ProviderSuffixCode to create RectrtGkProvIdGfld column.
    # Concat ProviderId, ProviderSuffixCode, ProviderServiceTypeCode, and ProviderSequenceNumber column.
    add_calc_col_df = joined_df.selectExpr(
        "*",
        "concat(ProviderId, ProviderSuffixCode) as RectrtGkProvIdGfld",
        "ProviderContractId as RectrctvPrvjctDbkey",
    )
except Exception as e:
    excep = "Calculate RectrtGkProvIdGfld and RectrctvPrvjctDbkey failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Step 8: Write transformed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(add_calc_col_df, cur_tbl_name)

    # Read data from stage layer.
    re400_df = read_table_to_df(cur_tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re400_df)
    
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
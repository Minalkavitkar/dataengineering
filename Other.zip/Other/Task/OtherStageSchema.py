# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "other/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|",
            "multiline":"true"
        },
        "SourceFileFormat" : "csv"
    },
    "OTHER_TRE2400":{
        "FileRegex":"OTHER_TRE2400.TXT",
        "StagePathSuffix":"other/stage/StageTRE2400"
    },
    "OTHER_TRE2410":{
        "FileRegex":"OTHER_TRE2410.TXT",
        "StagePathSuffix":"other/stage/StageTRE2410"
    },
    "OTHER_TREICDT":{
        "FileRegex":"OTHER_TREICDT.TXT",
        "StagePathSuffix":"other/stage/StageTREICDT"
    },
    "OTHER_TREICDD":{
        "FileRegex":"OTHER_TREICDD.TXT",
        "StagePathSuffix":"other/stage/StageTREICDD"
    }  

}

# COMMAND ----------

tre2400_schema = {
    'Ind1':'STRING',
    'Ind2':'STRING',
    'Timestamp':'TIMESTAMP',
    'FUND_TY_CD':'STRING',
    'FUND_FULL_DESC':'STRING',
    'LONG_HDR_1_DESC':'STRING',
    'LONG_HDR_2_DESC':'STRING',
    'SHORT_HDR_1_DESC':'STRING',
    'SHORT_HDR_2_DESC':'STRING',
    'ACT_RPT_SEQ_NBR':'INTEGER',
    'PLTFM_CD':'STRING'
}

# COMMAND ----------

treicdt_schema = {
    'ICD10_TABLE_ID':'STRING'
    ,'ICD10_TABLE_CD':'STRING'
    ,'ICD10_DESC':'STRING'
    ,'LAST_UPDT_ID':'STRING'
    ,'LAST_UPDT_DT':'DATE'
    ,'COPY_FROM_TBL_ID':'STRING'
    ,'ICD10_COPY_IND ':'STRING'
    ,'NOTIFY_EMAIL_ID':'STRING'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'TIMESTAMP'
}

# COMMAND ----------

treicdd_schema = {
    'ICD10_CD':'STRING'       
    ,'ICD10_TABLE_ID':'STRING'
    ,'LAST_UPDT_ID':'STRING' 
    ,'LAST_UPDT_DT':'DATE'
    ,'IND1':'STRING'
    ,'TIMESTAMP':'TIMESTAMP'
    }


# COMMAND ----------

tre2410_schema = {
     'Ind1':'STRING'
    ,'Ind2':'STRING'
    ,'Timestamp':'TIMESTAMP'
    ,'PROD_LOB_CD ':'STRING'   
    ,'PCA_FIN_LEDGR_NBR':'STRING'
    ,'FUND_ACT_CD':'STRING'       
    ,'FUND_ACT_DESC':'STRING'  
    ,'GL_PRIM_ACCT_TY_CD':'STRING'
    ,'GL_OFFS_ACCT_TY_CD':'STRING'
    ,'FUND_ACT_SEQ_NBR':'INTEGER'  
    ,'PLTFM_CD':'STRING'           
}
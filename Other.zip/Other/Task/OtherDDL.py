# Databricks notebook source
# DBTITLE 1,Setting up environment variables
# MAGIC %run "../../Utility/Helpers/EnvironmentVariableHelper"

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES') 

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Other{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# DBTITLE 1,Fund
Fund = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.other_Fund(
    CreatedBy STRING NOT NULL,
    CreatedDateTime TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP,
    FundTypeCode STRING,
    FundDescription STRING,
    ShortCode STRING,
    ShortCodeLabel STRING,
    LongCode STRING,
    LongCodeLabel STRING,
    DerivedIndicator STRING,
    FundKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL,
    AccountReportSequenceNumber INTEGER
)"""
# USING DELTA LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/other/curated/Fund' """


# COMMAND ----------

# MAGIC %md
# MAGIC ####ProviderProductFundAccount

# COMMAND ----------

provider_product_fund_account = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.other_ProviderProductFundAccount(
    FundAccountKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL,
    ProductLineOfBusinessCode STRING,
    DerivedIndicator STRING,
    ProviderFinanceLedgerNumber INTEGER,
    FundAccountCode STRING,
    FundAccountDescription STRING,
    GenLdgrPrimaryAcctTypeCode STRING,
    GenLdgrOffsetAcctTypeCode STRING,
    FundAccountSequenceNumber INTEGER,
    CreatedBy STRING not null,
    CreatedDateTime TIMESTAMP not null,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP   
)"""
# USING DELTA LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/other/curated/ProviderProductFundAccount' """


# COMMAND ----------


ICDTableInfo = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.other_ICDTableInfo(
    ICDTableInfoKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL,
    DerivedIndicator STRING,
	ICD10Id STRING,
	ICDTypeCode STRING,
	ICDDescription STRING,
	BeginDate TIMESTAMP ,
	EndDate TIMESTAMP,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP
 )"""
# USING DELTA LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/other/curated/ICDTableInfo' """

# COMMAND ----------

# MAGIC %md
# MAGIC ### ICDDetail

# COMMAND ----------

ICDDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.other_ICDDetail(
	ICDDetailKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL,
	ICDTableInfoKey BIGINT NOT NULL,
	ICD10Code STRING,
	ICD10Id STRING,
	ICDTypeCode STRING,
	ICDDescription STRING,
	CreatedBy STRING NOT NULL,
	CreatedDateTime TIMESTAMP NOT NULL,
	ModifiedBy STRING,
	ModifiedDateTime TIMESTAMP,
 	DerivedIndicator STRING 
 )"""
# USING DELTA LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/other/curated/ICDDetail' """

# COMMAND ----------

tbl_mapping = {
    "other_Fund":Fund,
    "other_ProviderProductFundAccount":provider_product_fund_account,
    "other_ICDTableInfo":ICDTableInfo,
    "other_ICDDetail":ICDDetail
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)




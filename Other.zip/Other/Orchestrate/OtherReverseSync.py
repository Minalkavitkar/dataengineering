# Databricks notebook source
# MAGIC %md
# MAGIC #####This notebook is to collect all the table information of OTHER module into one oubound file.
# MAGIC - OtherTre2400
# MAGIC - OtherTreicdt
# MAGIC - OtherTre2410
# MAGIC - OtherTreicdd
# MAGIC ##### The final outbound file which will be sent to mainframe team is OtherReverseSync.txt

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','ReverseSync')
dbutils.widgets.text('PIPELINE_NAME','Nb_ReverSyncOther')
dbutils.widgets.text('RUN_ID','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run "../../Utility/Validate"

# COMMAND ----------

# DBTITLE 1,Check the table run and get the StartDateTime
try:
    table_code = 'OtherReverseSync'
    start_date_time = notebook_run_check('Other', table_code, None, audit_table_name)
    end_date_time = datetime.now()
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
    local_parameter_file_path = env_local_parameter_config_path
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception('Get required details from environment variable helper notebook failed:',Message)

# COMMAND ----------

# DBTITLE 1,Get the table names and config info
try:
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == table_code)
    OtherReverseSync = config_dict[table_code]
    
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]

    container_name = default_config["ContainerName"]
    config = default_out_config["Config"]
    temp_path_suffix = OtherReverseSync["Outbound"]["TempFilePathSuffix"]
    outbnd_file_name = OtherReverseSync["Outbound"]["FileName"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    file_path_prefix = default_out_config["FilePathPrefix"]
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Table configuration failed: ",Message)

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Outbound
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )

    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )

except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Path Creation failed:",Message)

# COMMAND ----------

# DBTITLE 1,List the mainframe other file names

try:
    #list of file names of the output of each table
    list_file_names = [
        'OtherTre2400.txt',
        'OtherTreicdt.txt',
        'OtherTre2410.txt',
        'OtherTreicdd.txt'
    ]
    
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("list of the names of files",str(e))

# COMMAND ----------

# DBTITLE 1,Collect all files information into one dataframe
try:
    # Create an empty dataframe to work for loops
    df_all = spark.createDataFrame([], StructType([StructField('Column1',StringType(), True)]))

    for file in list_file_names:
        df = read_csv(path=(outbnd_csv_path+file),config={})
        if df.rdd.isEmpty():
            pass
        else:
            if df_all.rdd.isEmpty():
                df_all = df
            else:
                df_all = df_all.union(df)
    if df_all.rdd.isEmpty():
        Message = f"{table_code} empty data exported successfully from {start_date_time} to {end_date_time}"
    else:
        Message = f"{table_code} data exported successfully for {end_date_time.date()} and {end_date_time.time().hour} hour"

except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("list of the names of files",str(e))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2
try:                                                                                                   
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(df_all, temp_csv_path, config)

    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
    
except Exception as e:
    Message = str(e)
    exit_notebook(run_id,'Other', LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name,Message,'Failed')
    raise Exception("Run failed with error:",Message)
else:
    exit_notebook(run_id,'Other',LOAD_TYPE,table_code, None, start_date_time, end_date_time, audit_table_name, Message,'Success')
    dbutils.notebook.exit(Message)
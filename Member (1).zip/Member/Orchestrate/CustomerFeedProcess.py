# Databricks notebook source
# MAGIC %md
# MAGIC ##### This notebook orchestrates the Customer Feed, RE4005 and RE0016 jobs
# MAGIC Customer Feed
# MAGIC - If Full Load
# MAGIC   - It is a starigh load in all tables, i.e, Customer, benefitTypeOccuerence and BenefitCopay
# MAGIC - If Delta Load
# MAGIC   - We need to delete the Copay and Benefit records for the UPDATE and DELETE records from CI CUSTOMER file, reason is the BenTyCd can change, either increase or decrease, hence we need to refresh the all records of Benefit and Copay for whome UPDATE or DELETE is there.
# MAGIC
# MAGIC
# MAGIC RE4005 executed in both full and delta loads
# MAGIC
# MAGIC RE0016 only executed in case of a delta load

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
RUN_ID = dbutils.widgets.get('RUN_ID')
SEQ_NUM = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Get the schema for stage tables
# MAGIC %run ../Task/MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Get the environment variables
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Call the functions to ingest a file into stage tables
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Call the transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# MAGIC %md
# MAGIC #### Customer Feed

# COMMAND ----------

# DBTITLE 1,Get the required tables Names
try:
    conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])

    stage_cicustomer = table_name_selector(tbl_conf_df, 'CI_CUSTOMER_STAGE')
    cust_tbl_name = table_name_selector(tbl_conf_df, 'Member_Customer')
    bentyocr_tbl_name=table_name_selector(tbl_conf_df,'Member_BenefitTypeOccurrence')
    bencopay_tbl_name=table_name_selector(tbl_conf_df,'Member_BenefitCopayOccur')
except Exception as e:
    raise Exception("")

# COMMAND ----------

# DBTITLE 1,Load data into Stage and CICustomer
dbutils.notebook.run('../Task/CICustomer',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':PIPELINE_NAME, 'RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})

# COMMAND ----------

# DBTITLE 1,Delete the Copay and Benefits for UPDATE and DELETE from CI file
try:
    if LOAD_TYPE == 'DeltaLoad':
        deltaStageCI = DeltaTable.forName(spark,stage_cicustomer)
        deltaCust = DeltaTable.forName(spark,cust_tbl_name)
        deltaBenTyOc = DeltaTable.forName(spark,bentyocr_tbl_name)
        deltabenCoPay = DeltaTable.forName(spark,bencopay_tbl_name)


        dfStageCI = read_table_to_df(stage_cicustomer)\
            .filter(col('Status') == 'S')

        dfStageCIValid = dfStageCI.filter(dfStageCI.DerivedIndicator.isin(['UPDATE','DELETE']))\
            .select('CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate')
        
        benTyOccKey = read_table_to_df(bentyocr_tbl_name)

        benTyOccKey = dfStageCIValid.alias('LH')\
            .join(benTyOccKey.alias('RH'), (col('LH.CiGrpId')==col('RH.CIGroupIdentifier')) & 
                  (col('LH.GrpNbrBen')==col('RH.BenefitSequence')) & 
                  (col('LH.CiClsNbr')==col('RH.CIClassNumber')) & 
                  (col('LH.BenDtlEffDate')==col('RH.BenefitEffectiveDate')), "inner")\
                .selectExpr('RH.BenefitTypeOccurenceKey')
        
        
        deltabenCoPay.alias('LH')\
            .merge(benTyOccKey.alias('RH'),'LH.BenefitTypeOccurenceKey = RH.BenefitTypeOccurenceKey' )\
            .whenMatchedUpdate(set = {
                'LH.DerivedIndicator':lit('DELETE')
            }).execute()
        deltaBenTyOc.alias('LH')\
            .merge(benTyOccKey.alias('RH'),'LH.BenefitTypeOccurenceKey = RH.BenefitTypeOccurenceKey' )\
            .whenMatchedUpdate(set = {
                'LH.DerivedIndicator':lit('DELETE')
            }).execute()
        
        
        deltabenCoPay.delete(condition= "DerivedIndicator='DELETE'" )
        deltaBenTyOc.delete(condition= "DerivedIndicator='DELETE'")
            
except Exception as e:
    raise Exception("Unable to read tables:", str(e))

# COMMAND ----------

# DBTITLE 1,Load date into Customer table
dbutils.notebook.run('../Task/Customer',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':PIPELINE_NAME,'RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})

# COMMAND ----------

# DBTITLE 1,Load date into BenefitTypeOccurrence table
dbutils.notebook.run('../Task/BenefitTypeOccurrence',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':PIPELINE_NAME,'RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})

# COMMAND ----------

# DBTITLE 1,Load date into BenefitCopay table
dbutils.notebook.run('../Task/BenefitCopayOccur',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':PIPELINE_NAME,'RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})

# COMMAND ----------

# DBTITLE 1,Delete records in benefit, Copay and Customer if no benefits
try:
    # if more than 50 customers are effected in one run, STOP the delete process and manually verify the deletion is required or not.
    if LOAD_TYPE == 'DeltaLoad':
        dfCust = read_table_to_df(cust_tbl_name)
        dfbenTyOcc = read_table_to_df(bentyocr_tbl_name)
        dfbenTyOccCH = dfbenTyOcc.filter(" DerivedIndicator != 'DELETE' ")

        onCols = ['CIGroupIdentifier','BenefitSequence','CIClassNumber']
        CustkeysCH = dfCust.join(dfbenTyOccCH, onCols, "leftanti")\
            .select('CustomerKey').rdd.map(lambda x : x.CustomerKey).collect()

        if len(CustkeysCH)>=50:
            dbutils.notebook.exit("STOP, more than 50 Customer effected:")
        else:
            #  Delete the records from CoPay
            deltabenCoPay.delete(condition= "DerivedIndicator='DELETE'")

            #  Delete the records from BenefitTypeOccurrence
            deltaBenTyOc.delete(condition= "DerivedIndicator='DELETE'")

            # Delete the records from Customer is no benefits are present
            Custkeys = dfCust.join(dfbenTyOcc, onCols, "leftanti")\
                .select('CustomerKey')\
                .rdd.map(lambda x : x.CustomerKey).collect()

            deltaCust.delete(col('CustomerKey').isin(Custkeys))

except Exception as e:
    raise Exception("Delete to customer didn't work:", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Cstomer Coverage RE4005

# COMMAND ----------

# DBTITLE 1,RE4005 Execution
dbutils.notebook.run('../Task/CustomerFeedCoverageRE4005',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':'pl_CustomerCoverage','RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})

# COMMAND ----------

# MAGIC %md
# MAGIC #### Cstomer Coverage RE0016

# COMMAND ----------

# DBTITLE 1,RE0016 Execution
try:
    if LOAD_TYPE == 'DeltaLoad':
        dbutils.notebook.run('../Task/CustomerFeedCoverageRE0016',0,{'LOAD_TYPE':LOAD_TYPE, 'PIPELINE_NAME':'pl_CustomerCoverage','RUN_ID':RUN_ID, 'SEQ_NUM':SEQ_NUM})
except Exception as e:
    raise Exception("Unable to read tables:", str(e))
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job ReclmmbrDaily - The main purpose of this job to build the Outbound process to create RECLMMBR stage area table on cloud and fetch the Claims Member information and create INCREM stage area table on cloud for increment for 24 Months of data.
# MAGIC
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - Product.StageProduct
# MAGIC - Member.StageMemberCoverage
# MAGIC - Member.StageMember
# MAGIC - ProviderContract.Re400ReprvjctDaily
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.ReclmmbrDailyFull
# MAGIC - Member.ReclmmbrDailyIncrement
# MAGIC
# MAGIC ###### Target details (File):
# MAGIC - ProdrenRe401ClmmbrDailyIncrem.csv (CSV File)
# MAGIC - ProdrenRe401ClmmbrDailySorted.csv (CSV File)
# MAGIC ###### Created By: Dinesh S
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import *
from datetime import date
from dateutil.relativedelta import relativedelta
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path)
    full_fxd_conf_df = fixed_config_df.filter(col("JobName") == "ReclmmbrDailyFull")
    Incr_fxd_conf_df = fixed_config_df.filter(col("JobName") == "ReclmmbrDailyIncr")
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    clmmbr_config = config_dict[job_name]

    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    proc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    config = default_out_config["Config"]

    full_curated_path_suffix = clmmbr_config["Outbound"]["FullCuratedFilePathSuffix"]
    full_temp_path_suffix = clmmbr_config["Outbound"]["FullTempFilePathSuffix"]
    full_tbl_name = clmmbr_config["Outbound"]["FullTableName"]
    incr_curated_path_suffix = clmmbr_config["Outbound"]["IncrCuratedFilePathSuffix"]
    incr_temp_path_suffix = clmmbr_config["Outbound"]["IncrTempFilePathSuffix"]
    incr_tbl_name = clmmbr_config["Outbound"]["IncrTableName"]
    re400_tbl_name = clmmbr_config["Inbound"]["Re400TableName"]
    prd_tbl_name = clmmbr_config["Inbound"]["StageProductTableName"]
    ci_cust_tbl_name = clmmbr_config["Inbound"]["CICustomerTableName"]
    ci_mem_tbl_name = clmmbr_config["Inbound"]["CIMemTableName"]
    mem_cov_tbl_name = clmmbr_config["Inbound"]["StageMemberCoverageTableName"]
    mem_tbl_name = clmmbr_config["Inbound"]["StageMemberTableName"]
    sync_process_names = clmmbr_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
     
    full_file_name = clmmbr_config["Outbound"]["FullFileName"]
    incr_file_name = clmmbr_config["Outbound"]["IncrFileName"]
except Exception as e:
    excep = "Variable assignment from FileConfig failed: ", str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check Product, Member and MemberCoverage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Curated and temp.
try:    
    full_temp_csv_path = abfss_path_builder(
        container_name, storage_account, proc_file_path_prefix, full_temp_path_suffix
    )
    incr_temp_csv_path = abfss_path_builder(
        container_name, storage_account,proc_file_path_prefix, incr_temp_path_suffix
    )
   
    
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = "Path creation for Curated and temp failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# Add required columns to the list from ProviderContract table.
mem_cov_req_col = [
    "MemberCustomerNumber"
    ,"GateKeeperProviderTypeCode"
    ,"MemberKey"
    ,"CoverageStartDate"
    ,"CoverageEndDate"
    ,"ProductKey"
    ,"ProviderContractKey"
    ,"MemberGroupNumber"
    ,"WokerCompensationOccurenceId"
    ,"CoverageEndReasonCode"
    ,"MemberCoverageKey"
    ,'CIClassNumber'
    ,'CoverageTypeCode'
]

# Add required columns to the list from GeoMarket table.
re400_req_cols = [   
    "ProviderGrouperId"
    ,"RectrtGkProvIdGfld"
    ,"ProviderServiceTypeCode"
    ,"ProviderSequenceNumber"
    ,"CycleNumber"
    ,"ProviderId"
    ,"ProviderSuffixCode"
    ,"IPAIndicator"
    ,"GeoMarketId"
    ,"ClmRprocInd"
    ,"ContractStartDate"
    ,"ContractEndDate"
    ,"OpenFundIndicator"
    ,"ProviderContractKey"
    ,"LedgerNumber"
    ,"ClaimRule"
]

mem_req_cols = [
    "MemberKey",
    "MemberId",
    "SubscriberId",
    "HumanaIdentifier",
    "MemberFirstName",
    "MemberLastName",
    "MemberBirthDate",
    "ClaimFundExceptionIndicator"
]

prd_req_cols = [
    "ProductKey",
    "ExtProdSeqNo", 
    "MarketNumber", 
    "LineOfBusinessCode", 
    "PlanNumber", 
    "OptNumber"
]

cust_req_cols = [
    "CIGroupIdentifier",
    "CIClassNumber",
    "BenefitSequence",
    "GHGroupIdentifier",
    "EmployerGroupNumber"
]


# COMMAND ----------

# DBTITLE 1,Read data from Stage(ADLS).
try:
        # Read MemberCoverage data from Stage table(ADLS).
        mem_cov_df = read_table_to_df(mem_cov_tbl_name)\
                .select(*mem_cov_req_col).filter(col('CoverageTypeCode')=='PCP')\
                .drop('CoverageTypeCode')

        # Read RE400 processed data from Stage table(ADLS).
        re400_cur_df = read_table_to_df(re400_tbl_name)\
                .select(*re400_req_cols)

        # Read Product table from Stage table(ADLS).
        prd_df = read_table_to_df(prd_tbl_name)\
                .select(*prd_req_cols)

        # Read Member data from Stage table(ADLS).
        mem_df = read_table_to_df(mem_tbl_name)\
                .select(*mem_req_cols)

        cimem_df = read_table_to_df(ci_mem_tbl_name)\
                .select('CiGrpId','CiBenSeqNbr','CiClsNbr','MbrPid','MbrGhGroup','MbrGhSubGroup', 'MbrSubPid').distinct()

        ci_df = read_table_to_df(ci_cust_tbl_name).\
                select('GhGrpId','GhEmprGrpNbr','EmprFacIdNbr','CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate').distinct()
        window = Window.partitionBy('GhGrpId','GhEmprGrpNbr','EmprFacIdNbr','CiGrpId','GrpNbrBen','CiClsNbr')\
                .orderBy(desc('BenDtlEffDate'))
        cicust_df = ci_df.withColumn('RN', row_number().over(window)).filter('RN == 1 ').drop('RN')
except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Product, MemberCoverage and Re400 processed data.
try:
    # Join MemberCoverage with Product on ProductKey.
    prd_joined_df = mem_cov_df.join(prd_df, ['ProductKey'], 'left')

    # Join ouput of above step with StageMember on MemberKey.
    mem_joined_df = prd_joined_df.join(mem_df, ['MemberKey'], 'left')\
                    .drop('MemberKey')

    # Join ouput of above step with Re400 processed data on ProviderContractKey.
    mem_cov_joined_df = mem_joined_df.join(re400_cur_df, ['ProviderContractKey'], 'left')
except Exception as e:
    excep = "Join Product, MemberCoverage and Re400 processed data failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join MemberCoverage with Customer.
try:
    # Join Member Coverage with Customer to get GHGroupIdentifier and EmployerGroupNumber.
    condition1 = ((col('LH.MemberCustomerNumber') == col('RH.CiGrpId'))
                & (col('LH.MemberGroupNumber') == col('RH.GrpNbrBen'))
                & (col('LH.CIClassNumber') == col('RH.CiClsNbr')))
    condition2 = ((col('LH.MemberCustomerNumber') == col('RH1.CiGrpId')) & (col('LH.MemberGroupNumber') == col('RH1.CiBenSeqNbr'))\
                & (col('LH.CIClassNumber') == col('RH1.CiClsNbr')) & (col('LH.MemberId') == col('RH1.MbrPid')) & (col('LH.SubscriberId') == col('RH1.MbrSubPid')))

    cust_joined_df = mem_cov_joined_df.alias('LH').join(cicust_df.alias('RH'), condition1, 'left')\
                .join(cimem_df.alias('RH1'),condition2, 'left')\
                .selectExpr("LH.*", "RH.GhGrpId",'RH.GhEmprGrpNbr', 'RH1.MbrGhGroup','RH1.MbrGhSubGroup')\
                .drop("CIClassNumber", "MemberCustomerNumber", "MemberGroupNumber")

    casCols = {
            'GHCust': when(col('GhGrpId').isNull(),col('MbrGhGroup')).otherwise(col('GhGrpId')),
            'GhGrpNbr': when(col('GhEmprGrpNbr').isNull(),col('MbrGhSubGroup')).otherwise(col('GhEmprGrpNbr'))
        }
    cust_joined_df_final = cust_joined_df.withColumns(casCols).drop('GhGrpId','GhEmprGrpNbr','MbrGhGroup','MbrGhSubGroup')

except Exception as e:
    excep = "Join Product, MemberCoverage and Re400 processed data failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate ActiveIndicator and CoverageEndYear column.

try:
    # If current date falls between CoverageStartDate and CoverageEndDate and OpenFundIndicator = 'Y' and ContractStartDate <> ContractEndDate then Set ActiveIndicator to "Y", else Set it to 'N'

    # Calculate Year from CoverageEndDate which is used for partitioning.
    col_map = {
                "ActiveInd" : when((current_date() >= col("CoverageStartDate")) 
                                    & (current_date() <= col("CoverageEndDate"))
                                    & (col("ContractStartDate") != col("ContractEndDate")) 
                                    & (col("OpenFundIndicator") == "Y"), lit("Y")).otherwise(lit("N")),
                "CoverageEndYear" : substring(col('CoverageEndDate'), 1, 4),
                "WokerCompensationOccurenceId" : round("WokerCompensationOccurenceId")
            }

    col_added_df = cust_joined_df_final\
                .withColumns(col_map)\
                .drop('ContractStartDate', 
                      'ContractEndDate', 
                      'OpenFundIndicator', 
                      'ProviderContractKey')

except Exception as e:
    excep = "Calculate ActiveIndicator and CoverageEndYear column: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(col_added_df, full_tbl_name, part_col='CoverageEndYear', mode='overwrite')

    # Read data from curated layer.
    reclmmbr_full_df = read_table_to_df(full_tbl_name)\
                .orderBy('GHCust', 
                         'MemberId', 
                         'GateKeeperProviderTypeCode', 
                         'CoverageStartDate')

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(full_fxd_conf_df, reclmmbr_full_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, full_temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move Full file to outbound folder and rename it.
try:
    copy_file_to_outbnd_with_new_name(full_temp_csv_path, outbnd_csv_path, full_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate date to take only last 24 months data.
try:
    # Date Calculation: Subtract 24 months from current date.
    dt = date.today() - relativedelta(months = 24)

    # Reclmmbr curated table is partitioned on CoverageEndYear. Get only the required partition.
    reclmmbr_full_df = read_table_to_df(full_tbl_name)\
                .withColumn("CoverageEndMonth", substring(col('CoverageEndDate'), 6, 2))\
                .filter(col('CoverageEndYear') >= dt.year)\
                .drop('HumanaIdentifier', 
                        'MemberFirstName', 
                        'MemberLastName', 
                        'MemberBirthDate', 
                        'RectrtGkProvIdGfld')
                            
    # From the above step filter for the required dates and add IsUpdated column which is used for incremental process.
    current_df = (reclmmbr_full_df.filter(col('CoverageEndMonth') >= dt.month)
                .withColumn('RecordType', lit('A')))\
                .drop('CoverageEndMonth')
except Exception as e:
    excep = 'Calculate date to take only last 24 months data: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Function used to create select and drop column list.
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Logic to identify the delta records.
try:
        # If the delta log folder exists, Identify the incremental data and write it into curated table.
            # A - ADD, C - Change, D - Delete, I - Ignore

    if spark.catalog.tableExists(incr_tbl_name):
        # Read previous load data from Increment Curated table.
        old_df = read_table_to_df(incr_tbl_name)\
                .filter(col('RecordType')\
                .isin(['A', 'C', 'I']))

        # Create Column list. Which is used for processing.
        new_col_slt_lst = old_df.columns
        col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)


        # Add suffix 'Old' to column name for existing data to avoid column ambiguous.
        old_renamed_df = old_df.selectExpr(*col_select_lst)

        # Join previous day and current day data to identify incremental data.
        old_joined_df = current_df.alias('LH')\
                .join(old_renamed_df.alias('RH'),(col("LH.MemberCoverageKey") == col("RH.OldMemberCoverageKey")), "full")

        # Get only the records which are needs to insert and create RecordType column.
        ins_df = old_joined_df\
                .filter((col('OldMemberCoverageKey').isNull()))\
                .withColumn('RecordType', lit('A')).drop(*col_drop_lst)

        # Get only the records which are needs to delete and create RecordType column.
        dels_df = old_joined_df\
                .filter((col('MemberCoverageKey').isNull()))\
                .withColumn('OldRecordType', lit('D')).selectExpr(*del_col_sel_lst)
        # Get only the records which are needs to updates and create RecordType column.
        upds_df = old_joined_df\
                .filter((col('MemberCoverageKey').isNotNull()) & (col('OldMemberCoverageKey').isNotNull()))\
                .withColumn('RecordType', when(((col("MemberCoverageKey").eqNullSafe(col("OldMemberCoverageKey"))) &
                    (col("ProductKey").eqNullSafe(col("OldProductKey"))) &
                    (col("ExtProdSeqNo").eqNullSafe(col("OldExtProdSeqNo"))) &
                    (col("GHCust").eqNullSafe(col("OldGHCust"))) &
                    (col("GateKeeperProviderTypeCode").eqNullSafe(col("OldGateKeeperProviderTypeCode"))) &
                    (col("CoverageStartDate").eqNullSafe(col("OldCoverageStartDate"))) &
                    (col("CoverageEndDate").eqNullSafe(col("OldCoverageEndDate"))) &
                    (col("GhGrpNbr").eqNullSafe(col("OldGhGrpNbr"))) &
                    (col("WokerCompensationOccurenceId").eqNullSafe(col("OldWokerCompensationOccurenceId"))) &
                    (col("CoverageEndReasonCode").eqNullSafe(col("OldCoverageEndReasonCode"))) &
                    (col("MarketNumber").eqNullSafe(col("OldMarketNumber"))) &
                    (col("ProviderId").eqNullSafe(col("OldProviderId"))) &
                    (col("ClaimFundExceptionIndicator").eqNullSafe(col("OldClaimFundExceptionIndicator"))) &
                    (col("LedgerNumber").eqNullSafe(col("OldLedgerNumber"))) &
                    (col("ClaimRule").eqNullSafe(col("OldClaimRule"))) &
                    (col("ProviderSuffixCode").eqNullSafe(col("OldProviderSuffixCode"))) &
                    (col("LineOfBusinessCode").eqNullSafe(col("OldLineOfBusinessCode"))) &
                    (col("PlanNumber").eqNullSafe(col("OldPlanNumber"))) &
                    (col("OptNumber").eqNullSafe(col("OldOptNumber"))) &
                    (col("ProviderGrouperId").eqNullSafe(col("OldProviderGrouperId"))) &
                    (col("ProviderServiceTypeCode").eqNullSafe(col("OldProviderServiceTypeCode"))) &
                    (col("ProviderSequenceNumber").eqNullSafe(col("OldProviderSequenceNumber"))) &
                    (col("CycleNumber").eqNullSafe(col("OldCycleNumber"))) &
                    (col("IPAIndicator").eqNullSafe(col("OldIPAIndicator"))) &
                    (col("GeoMarketId").eqNullSafe(col("OldGeoMarketId"))) &
                    (col("ClmRprocInd").eqNullSafe(col("OldClmRprocInd"))) &
                    (col("ActiveInd").eqNullSafe(col("OldActiveInd"))))
            ,lit('I')).otherwise(lit('C'))).select(*new_col_slt_lst)

        # Union Insert, Delete and Update dataframe.
        calc_df = ins_df.unionByName(dels_df).unionByName(upds_df)

        ordered_df = calc_df.orderBy('GHCust', 
                                     'MemberId', 
                                     'GateKeeperProviderTypeCode', 
                                     'CoverageStartDate')

        # Replace previous run data with current run data in curated table.
        write_df_as_delta_table(ordered_df, incr_tbl_name, mode = 'overwrite')

    # If the delta log folder not exists, write entire data to curated table.
    else:
        ordered_df = current_df.orderBy('GHCust', 
                                        'MemberId', 
                                        'GateKeeperProviderTypeCode', 
                                        'CoverageStartDate')
        
        write_df_as_delta_table(ordered_df, incr_tbl_name)
except Exception as e:
    excep = "Identify incremental data: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write delta data frame to ADLS.
try:
    # Read data from stage layer.
    incr_reclmmbr_df = read_table_to_df(incr_tbl_name)\
        .filter(col('RecordType')\
        .isin(['A', 'C', 'D']))

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(Incr_fxd_conf_df, incr_reclmmbr_df)
    
    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, incr_temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move Full file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(incr_temp_csv_path, outbnd_csv_path, incr_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : full_file_name+','+incr_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
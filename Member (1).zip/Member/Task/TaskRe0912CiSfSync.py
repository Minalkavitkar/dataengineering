# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Daily Job RE0912 will read CI SSN difference file and delete those member data from SF database
# MAGIC ###### Source details 
# MAGIC - IN_CI_ITCSCINA_CCYYMMDD.TXT
# MAGIC - IN_CI_SYNCREC_CCYYMMDD.TXT
# MAGIC - MemberCoverage.StageMemberCoverage
# MAGIC - Member.StageMember
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0912CiSfSync')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
  file_conf_path = env_file_config_path
  fxd_wdth_path = env_fxd_wdt_file_config_path
  storage_account = env_storage_account_name
except Exception as e:
  excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
  job_name = JOB_NAME
  config_dict =  get_file_config(file_conf_path)
  fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)

except Exception as e:
  excep = 'Read File Config and Fixed Width File Config: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict['DEFAULT']
  default_out_config = default_config['Outbound']
  default_in_config = default_config["Inbound"]
  Re0912Daily_config = config_dict[job_name]

  container_name = default_config['ContainerName']
  file_path_prefix = default_out_config['FilePathPrefix']
  config = default_out_config['Config']

  file_path_suffix = default_in_config['FilePathSuffix']
  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  temp_path_suffix = Re0912Daily_config["Outbound"]["TempFilePathSuffix"]   
  curated_path_suffix = Re0912Daily_config["Outbound"]["CuratedFilePathSuffix"]
  outbnd_modified_file = Re0912Daily_config["Outbound"]["Filename_modified"]
  outbnd_error_file = Re0912Daily_config["Outbound"]["Filename_error"]
  table_nm = Re0912Daily_config["Outbound"]["Table_name"]

  stg_member = Re0912Daily_config["Inbound"]["StageMember"]
  stg_member_cov = Re0912Daily_config["Inbound"]["StageMemberCoverage"]  
  sync_process_names = Re0912Daily_config["Inbound"]["StageSyncProcessNames"]
  inbound_ci_file= Re0912Daily_config['Inbound']['CiFileName'] 
  inbound_ci_prv_file= Re0912Daily_config['Inbound']['CiPrvFileName'] 
  ctrl_table_name = default_config["AuditTableName"]
    
except Exception as e:
  excep = 'Variable assignment from FileConfig: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
  prc_status = start_process_check(ctrl_table_name, sync_process_names)
  if prc_status != True:
      dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
  excep = "ControlTable check failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    cur_delta_path = abfss_path_builder(
        container_name,storage_account,prc_file_path_prefix,curated_path_suffix
    )
    temp_csv_path = abfss_path_builder(
        container_name,storage_account,prc_file_path_prefix,temp_path_suffix     
    )  
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, path_prefix=file_path_prefix
    )
    ci_file_path = path_builder(
        container_name,storage_account,inbound_ci_file,path_prefix=file_path_suffix
    )
    ci_prv_file_path = path_builder(
        container_name,storage_account,inbound_ci_prv_file,path_prefix=file_path_suffix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try: 
    
  # Read the data from MeberCoverage Stage table(Adls).
  df_member_cov = read_table_to_df(stg_member_cov)

  # Read the data from MeberCoverage Stage table(Adls).
  df_member = read_table_to_df(stg_member)

  df_ci_file= read_inbound_csv_file(ci_file_path)

  df_ci_prv_file= read_inbound_csv_file(ci_prv_file_path)
       
except Exception as e:
  excep = "Read Sql Tables: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Do groupBy on MemberKey and CI fields in Member Coverage 
    filtered_mbr_cvrg_df=df_member_cov.select("MemberKey","MemberCustomerNumber","MemberGroupNumber","CIClassNumber").groupBy("MemberKey","MemberCustomerNumber","MemberGroupNumber","CIClassNumber").count()

    #select distinct records
    filtered_mbr_cvrg_df=filtered_mbr_cvrg_df.distinct()

    mbr_with_mbrcvrg_df = (
        df_member_cov.alias("LH")
        .join(df_member.alias("RH"), (col("LH.MemberKey") == col("RH.MemberKey")), "left")
    ).select('LH.*','RH.SourceSystemCode','RH.MemberId','RH.SubscriberId','RH.ClaimFundExceptionIndicator','RH.HumanaIdentifier','RH.MemberFirstName','RH.MemberLastName','RH.MemberMiddleName','RH.MemberSexCode','RH.MemberBirthDate')

except Exception as e:
    excep = "Join member and member coverage: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Compare after PID and before PID with Member data
try:

  ci_merge=df_ci_file.union(df_ci_prv_file)  

  valid_after_pid=ci_merge.alias('LH').join(mbr_with_mbrcvrg_df.alias('RH'),(col('LH.IT_PER_SSN_AFTER') == col('RH.MemberId')) & (col('LH.IT_PER_SUBPID_A') == col('RH.SubscriberId')),'inner')
  
  reprocess_after_pid=ci_merge.alias('LH').join(mbr_with_mbrcvrg_df.alias('RH'),col('LH.IT_PER_SSN_AFTER') == col('RH.MemberId'),'left_anti')

  valid_before_pid=valid_after_pid.alias('LH').join(mbr_with_mbrcvrg_df.alias('RH'),(col('LH.IT_PER_SSN_BEFORE') == col('RH.MemberId')) ,'inner').select('RH.*').drop('MemberCoverageKey','MemberKey') 

except Exception as e:
  excep = ("Compare after PID and before PID with Member data failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Member and MemberCoverage
try:
  mbr_and_mbrcvg_df=df_member.alias("LH").join(df_member_cov.alias("RH"),(col("LH.MemberKey")==col("RH.MemberKey")),"left").select("RH.*"
  ,'LH.SourceSystemCode'
  ,'LH.MemberId'
  ,'LH.SubscriberId'
  ,'LH.ClaimFundExceptionIndicator'
  ,'LH.HumanaIdentifier'
  ,'LH.MemberFirstName'
  ,'LH.MemberLastName'
  ,'LH.MemberMiddleName'
  ,'LH.MemberSexCode'
  ,'LH.MemberBirthDate'
  ,col('LH.CreatedBy').alias('CreatedBy_mbr')
  ,col('LH.CreatedDateTime').alias('CreatedDateTime_mbr')
  ,col('LH.ModifiedBy').alias('ModifiedBy_mbr')
  ,col('LH.ModifiedDateTime').alias('ModifiedDateTime_mbr')
  ,col('RH.CreatedBy').alias('CreatedBy_mbrcvg')
  ,col('RH.CreatedDateTime').alias('CreatedDateTime_mbrcvg')
  ,col('RH.ModifiedBy').alias('ModifiedBy_mbrcvg')
  ,col('RH.ModifiedDateTime').alias('ModifiedDateTime_mbrcvg')
  ).drop('MemberKey','MemberCoverageKey',"ModifiedBy","CreatedDateTime","ModifiedDateTime","CreatedBy")

except Exception as e:
  excep = ("Joining tables failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output)) 

# COMMAND ----------

try:
    #Trim leading and trailing spaces of joined tables dataset.
    dtype_df=trim_leading_trailing_space(mbr_and_mbrcvg_df)
    
    #Trim leading and trailing spaces of inbound files dataset.
    inbnd_dtype_df=trim_leading_trailing_space(valid_before_pid)
      
except Exception as e:
    excep = "Trim leading and trailing spaces of datasets failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

col_dtype_schema={
    'ProviderContractKey':'long'
    ,'ExtProdSeqNo':'integer'
    ,'ProductKey':'long'
    ,'CoverageTypeCode':'string'
    ,'CoverageTypeCodeLabel':'string'
    ,'CoverageStartDate':'date'
    ,'CoverageEndDate':'date'
    ,'CoverageEndReasonCode':'string'
    ,'CoverageEndReasonCodeLabel':'string'
    ,'VendorSequenceNumber':'integer'
    ,'GateKeeperProviderId':'string'
    ,'GateKeeperProviderSuffixCode':'string'
    ,'GateKeeperProviderTypeCode':'string'
    ,'WokerCompensationOccurenceId':'decimal(20,6)'
    ,'CIClassNumber':'string'
    ,'MemberCustomerNumber':'string'
    ,'MemberGroupNumber':'string'
    ,'SourceSystemCode':'string'
    ,'MemberId':'string'
    ,'SubscriberId':'string'
    ,'ClaimFundExceptionIndicator':'string'
    ,'HumanaIdentifier':'string'
    ,'MemberFirstName':'string'
    ,'MemberLastName':'string'
    ,'MemberMiddleName':'string'
    ,'MemberSexCode':'string'
    ,'MemberBirthDate':'date'
    ,'CreatedBy_mbr':'string'
    ,'CreatedDateTime_mbr':'timestamp'
    ,'ModifiedBy_mbr':'string'
    ,'ModifiedDateTime_mbr':'timestamp'
    }

# COMMAND ----------

# DBTITLE 1,Create Hashkey for delta tables
try:
    #Create Hashkey using md5 function
    mbr_hash_df=dtype_df.withColumn("HashKey",md5(concat(col('MemberCustomerNumber'),col('MemberId'),col('SourceSystemCode'),col('ProviderContractKey'),col('CoverageTypeCode'),col('CoverageEndDate'),col('CoverageStartDate'))))\
        .withColumn("DerivedIndicator",lit(''))

    dtype_tbls_df = dtype_conversion(mbr_hash_df, col_dtype_schema)
    
except Exception as e:
    excep = "Creation of  Hashkey failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    #Add columns to balance schema
    inbound_balanced_df =inbnd_dtype_df.selectExpr(
    "*", 
    "md5(concat(MemberCustomerNumber,MemberId,SourceSystemCode,ProviderContractKey,CoverageTypeCode,CoverageEndDate,CoverageStartDate)) as HashKey",
    "current_timestamp() as CreatedDateTime_mbrcvg",
    "current_timestamp() as CreatedDateTime_mbr",
    f"'{PIPELINE_NAME}' as CreatedBy_mbrcvg",
    f"'{PIPELINE_NAME}' as CreatedBy_mbr",
    "cast(null as timestamp)as ModifiedDateTime_mbrcvg",
    "cast(null as timestamp)as ModifiedDateTime_mbr",
    "cast(null as string) as ModifiedBy_mbrcvg",
    "cast(null as string) as ModifiedBy_mbr",
    "cast(null as string) as DerivedIndicator",
    )
    # inbound_curr_df = dtype_conversion(inbound_balanced_df, col_dtype_schema)

except Exception as e:
    excep = "Add columns to balance schema failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create Column list, which is used for processing
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Create Column list
try:
    # Create Column list. Which is used for processing.
    new_col_slt_lst = mbr_hash_df.columns
    col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)

    old_renamed_df = mbr_hash_df.selectExpr(*col_select_lst)

except Exception as e:
    excep = "Create Column list failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Identify Delta record
try:
    old_joined_df_del = (
        old_renamed_df.alias("LH").join(inbound_balanced_df.alias("RH"),(col("LH.OldHashKey") == col("RH.HashKey")),"full")
        .filter((col("HashKey").isNotNull()) & (col("OldHashKey").isNotNull()))
        .withColumn("OldDerivedIndicator",lit("DELETE"))
        .selectExpr(*del_col_sel_lst)
        .filter(col('DerivedIndicator').isNotNull())
        .drop(col("RH1.HashKey")))
    
    del_ignr_df = old_joined_df_del.withColumn(
        "OldDerivedIndicator",
        when((col("OldCoverageStartDate") < col("minEffDt")) | (col("OldCoverageStartDate") > col("maxEffDt")),lit("IGNORE"))\
        .when((col("OldCoverageStartDate").isNotNull()) & (col("CoverageStartDate").isNull()),lit("DELETE")))\
        .selectExpr(*del_col_sel_lst)\
        .filter(col('DerivedIndicator').isNotNull())
    
    dtype_curr_final_df = dtype_tgt_conversion(old_joined_df_del, col_dtype_schema)
    write_df_as_delta_table(dtype_curr_final_df, table_nm, mode = 'overwrite')

except Exception as e:
    excep = "Identify Delta record failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    mbr_cvg_df = read_table_to_df(table_nm).filter(col('DerivedIndicator').isin('DELETE'))\
                .selectExpr(
                    '*', 
                    'CreatedBy_mbrcvg as CreatedBy',
                    'CreatedDateTime_mbrcvg as CreatedDateTime',
                    'ModifiedDateTime_mbrcvg as ModifiedDateTime',
                    'ModifiedBy_mbrcvg as ModifiedBy',
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as MemberCoverageKey', 
                    'cast(null as string) as ProcessName')\
                    .drop('CreatedBy_mbrcvg', 'HashKey','SourceSystemCode','MemberId','SubscriberId','ClaimFundExceptionIndicator','HumanaIdentifier','MemberFirstName','MemberLastName','MemberMiddleName','MemberSexCode','CreatedDateTime_mbrcvg','ModifiedDateTime_mbrcvg','ModifiedBy_mbrcvg','MemberBirthDate')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    mbr_cvg_upd_col_nullable_df = set_df_columns_not_nullable(spark, mbr_cvg_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    mbr_cvg_upd_col_nullable_df1 = set_df_columns_not_nullable(spark, mbr_cvg_upd_col_nullable_df, ['DerivedIndicator'], nullable=True)
    
    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(mbr_upd_col_nullable_df1, 'Member.StageMember')
    
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    mbr_df = read_table_to_df(table_nm).filter(col('DerivedIndicator').isin('DELETE'))\
                .selectExpr(
                    '*', 
                    'CreatedBy_mbr as CreatedBy',
                    'CreatedDateTime_mbr as CreatedDateTime',
                    'ModifiedDateTime_mbr as ModifiedDateTime',
                    'ModifiedBy_mbr as ModifiedBy',
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as MemberKey', 
                    'cast(null as string) as ProcessName')\
                    .drop('CreatedBy_mbrcvg', 'HashKey','ModifiedDateTime_mbrcvg','ModifiedBy_mbrcvg','CreatedDateTime_mbrcvg','ProviderContractKey','ExtProdSeqNo','ProductKey','CoverageTypeCode','CoverageTypeCodeLabel','CoverageStartDate','CoverageEndReasonCode','CoverageEndReasonCodeLabel','CreatedBy_mbr','CreatedDateTime_mbr','ModifiedDateTime_mbr','ModifiedBy_mbr','VendorSequenceNumber','GateKeeperProviderId','GateKeeperProviderSuffixCode','GateKeeperProviderTypeCode','WokerCompensationOccurenceId','CIClassNumber','MemberCustomerNumber','MemberGroupNumber')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    mbr_upd_col_nullable_df = set_df_columns_not_nullable(spark, mbr_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    mbr_upd_col_nullable_df1 = set_df_columns_not_nullable(spark, mbr_upd_col_nullable_df, ['DerivedIndicator'], nullable=True)
    
    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(hdr_upd_col_nullable_df1, 'Member.StageMember')
    
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
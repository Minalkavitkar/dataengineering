# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Below are the major features involved in the membership process:
# MAGIC - Copy data from Azure sql to UC
# MAGIC - Extract massmove contracts
# MAGIC - Extract member coverage records for from contract
# MAGIC - Member coverage split
# MAGIC - Provider validation
# MAGIC - Provider contract assignment
# MAGIC - Load processed to SQL table
# MAGIC - Report creation(Error / Success)
# MAGIC
# MAGIC
# MAGIC ###### Stage and main Tables used by the process:
# MAGIC
# MAGIC - provider_main_dev_000.mainframe_servicefund.Member_stageMember
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMemberCoverage,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMemberContact,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Provider_StageProvider,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContract,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContractTransfer,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContractTransferZipCode,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContractProductAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProduct,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAssociation
# MAGIC
# MAGIC ###### Intermediate table details
# MAGIC - provider_staging_dev_000.mainframe_servicefund_sit.massmove_bfrmemcovsplit
# MAGIC - provider_staging_dev_000.mainframe_servicefund_sit.massmove_providercontracttransfer
# MAGIC
# MAGIC ###### Target details (Azure SQL Stage table):
# MAGIC - Member.StageDBPMemberCoverage
# MAGIC - ProviderContract.StageDBPProviderContractTransfer
# MAGIC
# MAGIC ###### Report details:
# MAGIC - MassMove_Output_MemberCoverage_BeforeAfter_report.TXT
# MAGIC - MassMove_Output_ProvContractTransfer_BeforeAfter_report.TXT
# MAGIC - RE02349Error.TXT
# MAGIC
# MAGIC ###### Outbound Files:
# MAGIC - MassMoveDetailReport.TXT
# MAGIC
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper Notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest Notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# MAGIC %run ../../Utility/MemberCoverage

# COMMAND ----------

# DBTITLE 1,Import Necessary Libraries
from pyspark.sql.functions import input_file_name, current_date, current_timestamp, lit, col, row_number, lpad, sha1, concat_ws,lit,when
from delta.tables import DeltaTable
from pyspark.sql.window import Window
from datetime import datetime, timedelta
import json
from pyspark.sql.types import *


# COMMAND ----------

# DBTITLE 1,Parameter Cell.
dbutils.widgets.text('JOB_NAME','')
dbutils.widgets.text('PIPELINE_NAME','')
dbutils.widgets.text('PIPELINE_RUN_ID','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

audit_start_date_time = datetime.now()
job_type = 'DeltaLoad'
process_name = "DBP#" + job_type + "#" + JOB_NAME


# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path)\
                        .filter(col("JobName") == job_name)
                        
except Exception as e:
    excep = 'Reading file config failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_in_config = default_config["Inbound"]
    default_out_config = default_config["Outbound"]
    mass_move_config = config_dict[JOB_NAME]
    config = default_out_config["Config"]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    in_file_path_suffix = default_in_config["FilePathSuffix"]
    outbnd_temp_err_path_suffix = mass_move_config["Outbound"]["TempFileErrorPathSuffix"]
    outbnd_temp_detail_path_suffix = mass_move_config["Outbound"]["TempFileDetailPathSuffix"]
    outbnd_temp_detail_path_pct_suffix=mass_move_config["Outbound"]["TempFileDetailPathpctSuffix"]
    proc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    stage_prv_tbl = mass_move_config["Inbound"]["stageProvider"]
    stage_pc_tbl = mass_move_config["Inbound"]["stageProviderContract"]
    stage_pc_transfer_tbl = mass_move_config["Inbound"]["StageProviderContractTransferTableName"]
    stage_pc_transferzc_tbl = mass_move_config["Inbound"]["StageProviderContractTransferZipCodeTableName"]
    stg_prd_affil_tbl = mass_move_config["Inbound"]["StageProductAffliationTableName"]
    stg_prd_set_affil_tbl = mass_move_config["Inbound"]["StageProductSetAffliationTableName"]
    stg_prd_set_asso_tbl = mass_move_config["Inbound"]["StageProductSetAssociationTableName"]
    member_coverage_tbl = mass_move_config["Inbound"]["StageMemberCoverage"]
    member_contact_tbl = mass_move_config["Inbound"]["StageMemberContact"]
    member_contact_d_tbl = mass_move_config["Inbound"]["mc_membercontactdummytable"]
    err_file_name = mass_move_config["Outbound"]["ErrorFileName"]
    success_file_name = mass_move_config["Outbound"]["SuccessFileName"]
    outbound_file_name = mass_move_config["Outbound"]["OutboundFileName"]
    PCT_Detail_Report = mass_move_config["Outbound"]["PCTFileName"]
    audit_table_name = default_config["AuditTableName"]
    stg_prd_tbl = mass_move_config["Inbound"]["StageProduct"]
    stg_mbr_tbl = mass_move_config["Inbound"]["StageMember"]
    stg_prd_d_tbl = mass_move_config["Inbound"]["prd_productdummytable"]
    stg_prv_ctrt_prd_affl = mass_move_config["Inbound"]["StageProviderContractProductAffiliation"]
    # created dummy data since there was no records status code 2 and 4
    stg_prv_d_tbl = mass_move_config["Inbound"]["pc_rawdatatable"]
     # created dummy data since there was no records status code 2 and 4
    stg_prv_d_zip_tbl = mass_move_config["Inbound"]["pc_zipcoderawtable"]
    stg_mem_cov_d_tbl = mass_move_config["Inbound"]["mc_membercoveragerawtable"]
    massmove_pct_tbl = mass_move_config["Inbound"]["massmove_pct_table"]
    mem_cov_final_tbl =  mass_move_config["Inbound"]["mc_final_table"] 
    sync_process_names = mass_move_config["Inbound"]["StageSyncDependencyProcess"]
    mem_cov_sql_tbl_name = mass_move_config["Outbound"]['MemberCoverageSqlTable']
    prv_ctrt_trnsf_tbl_name = mass_move_config["Outbound"]["ProviderContractTransferSqltable"]
    interm_mem_cov_tbl = mass_move_config["Inbound"]["interm_mem_cov_table"]
    interm_prov_ctrt_tbl = mass_move_config["Inbound"]["interm_prov_ctrt_table"]
    union_table = mass_move_config["Inbound"]["union_tbl"]
    rejected_tbl = mass_move_config["Inbound"]["rej_tbl"]
    before_tbl=mass_move_config["Inbound"]["before_split"]
    massmove_reprt_tbl=mass_move_config["Inbound"]["massmove_reprt_tbl"]
   
    
except Exception as e:
    excep = 'Variable assignment from FileConfig: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)
           

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
       
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,ADLS Path Creation
try:
    # abfss path creation for inbound file.
    outbnd_temp_err_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_err_path_suffix)
    outbnd_temp_detail_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_detail_path_suffix)
    outbnd_temp_detail_csv_path_pct = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_detail_path_pct_suffix)

    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
    
except Exception as e:
    excep = 'ADLS path creation failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read data from stage table
try:
# Read the data from Provider Stage table(Adls) and select columns which are required for the process.
    prv_df = read_table_to_df(stage_prv_tbl)

# Read the data from ProviderContract Stage table(Adls) and select columns which are required for the process.
    prv_ctrt_df = read_table_to_df(stage_pc_tbl)

# Read the data from ProviderContractTransfer Stage table(Adls) and select columns which are required for the process. 
    prv_ctrt_trn_df = read_table_to_df(stage_pc_transfer_tbl)
   
# Read the data from ProviderContractTransfer Stage table(Adls) and select columns which are required for the process.
    prv_trn_zip_df = read_table_to_df(stage_pc_transferzc_tbl)
    

# Read the data from ProductAffiliation Stage table(Adls) and select columns which are required for the process.
    prd_affl_df = read_table_to_df(stg_prd_affil_tbl)

# Read the data from ProductSetAffliation Stage table(Adls) and select columns which are required for the process. 
    prd_set_affl_df = read_table_to_df(stg_prd_set_affil_tbl)
                    
# Read the data from ProductSetAssociation Stage table(Adls) and select columns which are required for the process.
    prd_set_ass_df = read_table_to_df(stg_prd_set_asso_tbl)
                    
# Read the data from MemberCoverage Stage table(Adls) and select columns which are required for the process.
    mem_cov_df = read_table_to_df(member_coverage_tbl)
    

# Read the data from MemberContact Stage table(Adls) and select columns which are required for the process.
    mem_con_df = read_table_to_df(member_contact_tbl)
   
    
# Read the data from Product Stage table(Adls) and select columns which are required for the process.
    prd_df = read_table_to_df(stg_prd_tbl)
    
# Read the data from Provider Contract Product affiliation Stage table(Adls) and select columns which are required for the process.
    prov_ctrt_prd_affl_df = read_table_to_df(stg_prv_ctrt_prd_affl)

# Read the data from Member Stage table(Adls) and select columns which are required for the process.
    mbr_df = read_table_to_df(stg_mbr_tbl)
except Exception as e:
    excep = 'Read sql table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Create list with necessary column
prov_con_cols = ["ProviderId","ProviderContractKey","ProviderContractId","ProviderSuffixCode","ProviderServiceTypeCode","ProviderSequenceNumber"]
prov_con_trns_cols = ["ProviderContractTransferKey","FromProviderContractKey","ToProviderContractKey","FromProviderId","FromProviderSuffixCode","FromProviderServiceTypeCode","FromProviderSequenceNumber","ToProviderId","ToProviderSuffixCode","ToProviderServiceTypeCode","ToProviderSequenceNumber","ContractTransferStartDate","ContractTransferEndDate","TransferStatusCode","ContractTransferCode","IdCardRequestIndicator","ProviderChangeProcessDate","FromProviderContractId","ToProviderContractId","OperatorName","CreatedBy","CreatedDateTime","ModifiedBy","ModifiedDateTime"]
prov_con_zip_cols = ["ToProviderContractKey","FromProviderContractId","ToProviderContractId","TransferStatusCode","ContractTransferCode","ProviderChangeProcessDate","ContractTransferStartDate","ContractTransferEndDate"]
mem_cov_cols = ["MemberCoverageKey","MemberKey","CoverageStartDate","CoverageEndDate","ProviderContractKey","GateKeeperProviderId","CIClassNumber","MemberCustomerNumber","MemberGroupNumber","ProductKey","ExtProdSeqNo","CoverageTypeCode","CoverageTypeCodeLabel","CoverageEndReasonCode","CoverageEndReasonCodeLabel","VendorSequenceNumber","GateKeeperProviderSuffixCode","GateKeeperProviderTypeCode","WokerCompensationOccurenceId","CreatedBy","CreatedDateTime","ModifiedBy","ModifiedDateTime"]
zip_cols = ["FromProviderContractKey","ZipCode"]
mem_con_cols = ["AddressTypeCode","MemberKey","ZipCode"]
prd_column = ["Productkey","MarketNumber"]
mbr_column=["MemberId","MemberKey"]
suc_rep_col=["MarketNumber","FromProviderId","FromProviderSuffixCode","MemberCustomerNumber","MemberGroupNumber","MemberId","RecordsSequenceNumber","ZipCode","ProviderId","ProviderSuffixCode","ProviderServiceTypeCode","ProviderSequenceNumber","BeforeAfterIndicator","CoverageStartDate","CoverageEndDate","Message","IdCardRequestIndicator","CoverageEndReasonCode","ActionCode","UpdateIndicator"]
err_rep_col=["MemberId","ZipCode","MemberCustomerNumber","MemberGroupNumber","FromProviderContractKey","ToProviderContractKey", "Comment"]

# COMMAND ----------

# DBTITLE 1,Select required columns
prv_ctrt_df=prv_ctrt_df.select(*prov_con_cols)
prv_ctrt_trn_df = prv_ctrt_trn_df.select(*prov_con_trns_cols)
mem_cov_df = mem_cov_df.select(*mem_cov_cols).withColumn("ExtProdSeqNo", col("ExtProdSeqNo").cast("Integer"))
prv_trn_zip_df = prv_trn_zip_df.select(*zip_cols)
prd_df = prd_df.select(*prd_column)
prv_df = read_table_to_df(stage_prv_tbl)
mbr_df=mbr_df.select(*mbr_column)
mem_con_df=mem_con_df.select(*mem_con_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Extract MassMove contracts

# COMMAND ----------

# DBTITLE 1,Get TransferStatusCode=CONF
#filter out records from provider contract transfer table where transfer status code is confirm(conf)
try:
    #Filter unprocessed records(CONF) and add derived indicator as BEFORE to get before picture of PCTransfer
    prv_ctrt_trn_df_conf =prv_ctrt_trn_df.filter(prv_ctrt_trn_df.TransferStatusCode == 'CONF')\
                                         .selectExpr("*"
                                                     ,"'BEFORE' as ActionCode")
   
    
    #update transfer status code to COMP from CONF
    prv_ctrt_comp_df=prv_ctrt_trn_df_conf.withColumn("TransferStatusCode", 
                                                               when(prv_ctrt_trn_df_conf.TransferStatusCode == 'CONF', 'COMP')
                                                               .otherwise(prv_ctrt_trn_df_conf.TransferStatusCode))
    prv_ctrt_comp_df=prv_ctrt_comp_df.select(*prov_con_trns_cols)
    #add derived indicator updaet for records which get converted to COMP from CONF
    prv_strct_comp_df_up= prv_ctrt_comp_df.selectExpr(*prov_con_trns_cols
                                                      ,"'UPDATE' as DerivedIndicator"
                                                      ,"'AFTER' as ActionCode")    
                                   
    
except Exception as e:
    excep = "Fetching records from provider contract transfer table failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Get TransferStatusCode!=CONF
#filter out records from provider contract transfer table where transfer status code is not equal to confirm(conf)
try:
    #using add_months function with nagtive value to subtract 10 years (120 months) from the current date for non CONF records
    prv_ctrt_chng_prc_dt = prv_ctrt_trn_df.filter((col('TransferStatusCode') != "CONF") & (col("ProviderChangeProcessDate") < add_months(current_date(), -120))).selectExpr("*","'DELETE' as DerivedIndicator","'Delete more than 10 yr old records' as ActionCode")
                                                                                                                                        
    #union of before & after(update/delete) df of PCTransfer
    pct_reprt=union_by_name([prv_ctrt_trn_df_conf,prv_strct_comp_df_up,prv_ctrt_chng_prc_dt])
    #write intermediate table
    write_df_as_delta_table(pct_reprt,massmove_pct_tbl)
    db_df = read_table_to_df(massmove_pct_tbl).filter(col("DerivedIndicator").isin(["UPDATE", "DELETE"]))
    db_df=db_df.select(*prov_con_trns_cols,"DerivedIndicator")
   
   
except Exception as e:
    excep = "Fetching records from provider contract transfer table failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Extract member coverage for 'FromContract'

# COMMAND ----------

# DBTITLE 1,Filter records where contract transfer code 2

try:
    #join with member coverage to fetch associated memebr records and Product table to get market number
    prv_ctrt_mem_cov_df = mem_cov_df.alias("mcc")\
                            .join(prd_df.alias("prd"),col('mcc.ProductKey')==col('prd.ProductKey'))\
                            .join(broadcast(prv_ctrt_comp_df.alias("pcc")), col('pcc.FromProviderContractKey')==col('mcc.ProviderContractKey'))\
                            .drop(prv_ctrt_comp_df.CreatedBy,prv_ctrt_comp_df.CreatedDateTime,prv_ctrt_comp_df.ModifiedBy,prv_ctrt_comp_df.ModifiedDateTime,mem_cov_df.ProviderContractKey)\
                            .drop(col('prd.ProductKey'))
                           
    #cache the dataframe
    prv_ctrt_mem_cov_df.cache()
    #filter records for Contract Transfer code 2
    getTransferCode_2 = prv_ctrt_mem_cov_df.filter(prv_ctrt_mem_cov_df.ContractTransferCode == 2)
    #join with ProviderContractTransferZipCode table to fetch zip code
    getTransferCode_2 = prv_trn_zip_df.alias("zip")\
                                      .join(broadcast(getTransferCode_2.alias("code2")),col('code2.FromProviderContractKey') == col('zip.FromProviderContractKey'))\
                                      .select(*getTransferCode_2,prv_trn_zip_df.ZipCode)
   
    #Joining with member contact table to select only member records with matching zip code
    mcn_2 = mem_con_df.alias("mcn").join(broadcast(getTransferCode_2.alias("mc2")),(col('mc2.ZipCode')==col('mcn.ZipCode')) & (col('mc2.MemberKey')==col('mcn.MemberKey'))).filter(mem_con_df.AddressTypeCode=='MAIL')
    mcn_2=mcn_2.select('mc2.*')
    
   
except Exception as e:
    excep = "Fetching records for Transfer status code 2 failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)



# COMMAND ----------

# DBTITLE 1,Filter records where contract transfer code 1
try:
    # filter based ContractTransferCode=1
    mc_1 = prv_ctrt_mem_cov_df.filter(prv_ctrt_mem_cov_df.ContractTransferCode == 1)
    
except Exception as e:
    excep = "Fetching records for Transfer status code 1  failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read Provider Contract, Affiliation & Association Tables
try:
    # Read ProviderContract, ProviderContractProductAffiliation, ProductSetAffiliation and ProductSetAssociation. And select only the required columns
    pc_df = read_table_to_df(stage_pc_tbl)\
                .selectExpr('ProviderContractKey as ProviderContractKey_pc'
                            ,'ProviderContractId as ProviderContractId_pc'
                            ,'ProviderKey as ProviderKey_pc'
                            ,'ProviderId as ProviderId_pc'
                            ,'ProviderSequenceNumber'
                            ,'ContractStartDate'
                            ,'ContractEndDate')
                
    pcpa_df = read_table_to_df(stg_prv_ctrt_prd_affl)\
                    .selectExpr("ProductAffiliationKey", "ProviderContractKey", "ProviderContractId")
    psaff_df = read_table_to_df(stg_prd_set_affil_tbl)\
                    .selectExpr("ProductAffiliationKey", "ProductSetKey")
    psass_df = read_table_to_df(stg_prd_set_asso_tbl)\
                    .selectExpr("ProductKey", "ProductSetKey")

except Exception as e:
    excep = 'Read Provider Contract, Affiliation & Association tables failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Filter records where contract transfer code 4
try:
    #filter based ContractTransferCode=4 
    
    getTransferCode_4 = prv_ctrt_mem_cov_df.filter(prv_ctrt_mem_cov_df.ContractTransferCode == 4)\
                                        #    .drop("ProviderContractID","ProviderContractKey","ProviderId","ProviderSequenceNumber")
    
    
    #Generate new gate keeper id for ContractTransferCode 4
    mcg_4 = getTransferCode_4.withColumn("DerivedGateKeeperProviderId",when(getTransferCode_4.ContractTransferCode == "4",
                                    ((col('MarketNumber').cast('Int')) * 10000).cast('String'))
                       .otherwise(getTransferCode_4.GateKeeperProviderId))\
                       .withColumn("GateKeeperProviderSuffixCode", lit("  "))\
                       .withColumn("DerivedIndicator", lit("UPDATE"))
    mcg_4 = mcg_4.drop(col('PRD.ProductKey'))
  
    prt_prov_df = prioritize_prv_type2Code(prv_df)
   
    prv_join_condition = ((col('Delta.DerivedGateKeeperProviderId') == col('PRV.ProviderId'))
                            & (trim(col('Delta.GateKeeperProviderSuffixCode')) == trim(col('PRV.SuffixCode'))))
    #Join delta dataframe with provider and get provider key.
    prov_joined_df = prt_prov_df.alias('PRV')\
                        .join(broadcast(mcg_4.alias('Delta')),prv_join_condition,'Left')\
                        .selectExpr('Delta.*','PRV.ProviderKey')
    #Filter out valid and invalid providers.
    valid_prv_df = prov_joined_df.filter(col('ProviderKey').isNotNull())
    
    invalid_prv_df = prov_joined_df.filter(col('ProviderKey').isNull())\
                                   .selectExpr("*", "'Provider not found in service fund domain table Provider.Provider' AS Comment", "'E8' As ErrorCode")
  
    # Contract Assignment                     
    pc_validated_df_ins,rejected_ins_df = assign_providercontract(valid_prv_df, pc_df,pcpa_df, psaff_df, psass_df,stage_pc_tbl)

    pc_validated_df_ins_pck = pc_validated_df_ins.withColumn("ToprovidercontractKey", col("ProviderContractKey"))
                                               
    #join with provider contract table to get ProviderSequenceNumber,ProviderServiceTypeCode,ProviderSuffixCode
    pc_validated_df_ins_up=pc_validated_df_ins_pck.alias("t4").join(prv_ctrt_df.alias("pc"),col('t4.ToProviderContractKey')==col('pc.ProviderContractKey')).drop(prv_ctrt_df.ProviderContractKey)
    final_pc4_df=pc_validated_df_ins_up.withColumn("ToProviderId", col("ProviderId"))\
                          .withColumn("ToProviderSuffixCode",col("ProviderSuffixCode"))\
                          .withColumn("ToProviderSequenceNumber",col("ProviderSequenceNumber"))\
                          .withColumn("ToProviderServiceTypeCode",col("ProviderServiceTypeCode"))
    #Union of transfer code 1,2,4
    union_df = union_by_name([mc_1,mcn_2,final_pc4_df, invalid_prv_df, rejected_ins_df])
   
except Exception as e:
    excep = "Fetching records for Transfer status code 4 failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Member Coverage Split

# COMMAND ----------

# DBTITLE 1,Check records in falling in member coverage overlap
try:
    #select only member coverage column from union_df to get before picture of member coverage
    bfr_mem_cov_split = union_df.withColumn("RecordsSequenceNumber",lit(1))\
                                .withColumn("ActionCode",lit(""))\
                                .withColumn("UpdateIndicator",lit("D"))\
                                .withColumn("BeforeAfterIndicator",lit("BEFORE"))\
                                .withColumn("ProviderContractKey",col("FromProviderContractKey"))\
                                .withColumn("ProviderId", col("FromProviderId"))\
                                .withColumn("ProviderSuffixCode",col("FromProviderSuffixCode"))\
                                .withColumn("ProviderServiceTypeCode",col("FromProviderServiceTypeCode"))\
                                .withColumn("ProviderSequenceNumber",col("FromProviderSequenceNumber"))\
                                .withColumn("Message",lit("Member moved successfully"))
                             
    bfr_mem_cov_split_mbr=mbr_df.alias("mbr").join(bfr_mem_cov_split.alias("bmcs"), col('bmcs.MemberKey') == col('mbr.MemberKey'))\
                                                         .drop(col('mbr.MemberKey'))
   
    write_df_as_delta_table(bfr_mem_cov_split_mbr,before_tbl)

    prv_ctrt_mem_cov_df.unpersist()
        
    #write df to table 
    bfr_mem_cov_df = read_table_to_df(before_tbl)\
                        .filter(col('Comment').isNull())
    
    bfr_mem_cov_df.cache()

    #check overlapping coverage
    ovrlp_cvrg = bfr_mem_cov_df.alias("MCO")\
                               .filter((col('MCO.CoverageStartDate') < col('MCO.ContractTransferStartDate'))\
                                        & (col('MCO.ContractTransferStartDate') <= col('MCO.CoverageEndDate')))
  
except Exception as e:
    excep = "Records checking for overlap condition failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Check records which doesn't fall under coverage overlap
try:
    #filtre out the records which are non overlapping and modify existing PCP(FromProviderContractKey) with new PCP(ToProviderContractKey)
    non_ovrlp_df = bfr_mem_cov_df.filter((bfr_mem_cov_df.CoverageStartDate >= bfr_mem_cov_df.ContractTransferStartDate)) 
    
    #Modify coverages with new PCP
    column_transformations_noc = {"ProviderContractKey": col("ToProviderContractKey"), 
                                  "ProviderId": col("ToProviderId"), 
                                  "ProviderSuffixCode": col("ToProviderSuffixCode"),
                                  "ProviderServiceTypeCode": col("ToProviderServiceTypeCode"), 
                                  "ProviderSequenceNumber": col("ToProviderSequenceNumber"),
                                  "GatekeeperProviderId": when((col("ContractTransferCode") == "4"), col("GatekeeperProviderId")).otherwise(col("ToProviderId")),
                                  "GateKeeperProviderSuffixCode": col("ToProviderSuffixCode"), 
                                  "CoverageEndReasonCode": when(((trim(col("CoverageEndReasonCode"))== '')&(col("CoverageEndDate")!="9999-12-31")), "SG").when(((trim(col("CoverageEndReasonCode"))!= '') & (col("CoverageEndDate") != "9999-12-31")), trim(col("CoverageEndReasonCode"))).when(col("CoverageEndDate") == "9999-12-31", "").otherwise(trim(col("CoverageEndReasonCode"))), 
                                   "DerivedIndicator": lit("UPDATE"), 
                                   "RecordsSequenceNumber": lit(2)}

    non_ovrlp_df_up=non_ovrlp_df.withColumns(column_transformations_noc)\
                                .select(*mem_cov_cols,"DerivedIndicator","FromProviderContractKey", 
                                     "ToProviderContractKey","ZipCode", "RecordsSequenceNumber", "ProviderId", "ProviderSuffixCode","ProviderServiceTypeCode", "ProviderSequenceNumber", "IdCardRequestIndicator","FromProviderId", "FromProviderSuffixCode","MarketNumber","MemberId")
except Exception as e:
    excep = "Records check for non overlapping condition failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)              

# COMMAND ----------

# DBTITLE 1,Member Coverage Split -  Term existing Member Coverage (End date)
try:
    # Generate the new coverage_end_date values
    end_date_upd = ovrlp_cvrg.withColumn("CoverageEndDate", date_sub("ContractTransferStartDate", 1)) \
                             .withColumn("GatekeeperProviderId",when((col("ContractTransferCode") == "4"), col("GatekeeperProviderId")).otherwise(col("GatekeeperProviderId")))\
                             .withColumn("GatekeeperProviderSuffixCode",when((col("ContractTransferCode") == "4"), col("FromProviderSuffixCode")).otherwise(col("FromProviderSuffixCode")))\
                             .withColumn("DerivedIndicator", lit("UPDATE")) \
                             .withColumn("RecordsSequenceNumber", lit(2)) \
                             .withColumn("ProviderContractKey", ovrlp_cvrg.FromProviderContractKey) \
                             .withColumn("ProviderId", col("FromProviderId"))\
                             .withColumn("ProviderSuffixCode",col("FromProviderSuffixCode"))\
                             .withColumn("ProviderServiceTypeCode",col("FromProviderServiceTypeCode"))\
                             .withColumn("ProviderSequenceNumber",col("FromProviderSequenceNumber"))\
                             .withColumn("CoverageEndReasonCode",
                                         when(((trim(col("CoverageEndReasonCode"))== '') & (col("CoverageEndDate") != 
                                         "9999-12-31")), lit("SG"))\
                                         .when(((trim(col("CoverageEndReasonCode"))!= '') & (col("CoverageEndDate") != "9999-12-31")), (trim(col("CoverageEndReasonCode"))))\
                                         .when(col("CoverageEndDate") == "9999-12-31", "").otherwise(trim(col("CoverageEndReasonCode"))))\
                             .select(*mem_cov_cols, "DerivedIndicator", "FromProviderContractKey", 
                                     "ToProviderContractKey","ZipCode", "RecordsSequenceNumber", "ProviderId", "ProviderSuffixCode","ProviderServiceTypeCode", "ProviderSequenceNumber", "IdCardRequestIndicator","FromProviderId", "FromProviderSuffixCode","MarketNumber","MemberId")
    
      
except Exception as e:
    excep = "Updating CoverageEndDate failed"+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep) 

# COMMAND ----------

# DBTITLE 1,Insert and Set New Coverage Member
try:
    # Define column transformations using a dictionary
    column_transformations = {
    "ProviderContractKey": col("ToProviderContractKey"),
    "ProviderId": col("ToProviderId"),
    "ProviderSuffixCode": col("ToProviderSuffixCode"),
    "ProviderServiceTypeCode": col("ToProviderServiceTypeCode"),
    "ProviderSequenceNumber": col("ToProviderSequenceNumber"),
    "CoverageStartDate": col("ContractTransferStartDate"),
    "CoverageEndDate": to_date(col("CoverageEndDate"), "yyyy-MM-dd"),
    "GatekeeperProviderId": when((col("ContractTransferCode") == "1") | (col("ContractTransferCode") == "2"), col("ToProviderId")).otherwise(col("DerivedGatekeeperProviderId")),
    "GateKeeperProviderSuffixCode": when((col("ContractTransferCode") == "1") | (col("ContractTransferCode") == "2"), col("ToProviderSuffixCode")).otherwise(col("GateKeeperProviderSuffixCode")).cast("varchar(20)"),
    "CoverageEndReasonCode": when(((trim(col("CoverageEndReasonCode"))== '')&(col("CoverageEndDate")!="9999-12-31")), "SG")
    .when(((trim(col("CoverageEndReasonCode"))!= '') & (col("CoverageEndDate") != "9999-12-31")), (trim(col("CoverageEndReasonCode"))))
    .when(col("CoverageEndDate") == "9999-12-31", "").otherwise("CoverageEndReasonCode"),
   "MemberCoverageKey": lit(None).cast("long"),
   "DerivedIndicator": lit("INSERT"),
   "RecordsSequenceNumber": lit(3)}
  
    insert_memcov = ovrlp_cvrg.withColumns(column_transformations)\
                              .select(*mem_cov_cols,"DerivedIndicator","FromProviderContractKey","ToProviderContractKey","ZipCode", "RecordsSequenceNumber","ProviderId","ProviderSuffixCode","ProviderServiceTypeCode","ProviderSequenceNumber","IdCardRequestIndicator","FromProviderId","FromProviderSuffixCode","MarketNumber","MemberId")
    #union of update,insert and non overlapping df
    union_member_coverage = union_by_name([end_date_upd,insert_memcov,non_ovrlp_df_up])
    union_memcov_PCP_mbr = union_member_coverage.selectExpr("*"
                                                   ,"'' as ActionCode"
                                                   ,"'A' as UpdateIndicator"
                                                   ,"'AFTER' as BeforeAfterIndicator"
                                                   ,"'' as Message")
    
    detail_reprt_df = union_by_name([union_memcov_PCP_mbr,non_ovrlp_df,ovrlp_cvrg])
    write_df_as_delta_table(detail_reprt_df,massmove_reprt_tbl)
except Exception as e:
    excep = "Inserting records with new PCP failed"+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ##ToContract PCP validation

# COMMAND ----------

# DBTITLE 1,Provider Contract Validation
try:
    pc_validated_df_up, rejected_updts_df = validate_providercontract(union_memcov_PCP_mbr,pc_df,pcpa_df,psaff_df,psass_df)
    union_bfr_aftr_mem_cov_splt = union_by_name([pc_validated_df_up,rejected_updts_df]).drop_duplicates()
    
    write_df_as_delta_table(union_bfr_aftr_mem_cov_splt,before_tbl, mode='append')
    bfr_mem_cov_df.unpersist()
    processed_df = read_table_to_df(before_tbl)
    processed_df.cache()
   
except Exception as e:
    excep = 'Provider Contract Product Validation failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Change column nullables and Write data to Azure SQL stage table
# try:
#     aftr_mem_cov_split_tbl = processed_df.filter((col('Comment').isNull()) & (col('BeforeAfterIndicator') == 'AFTER'))\
#                                 .select(*mem_cov_cols,'DerivedIndicator')
#     col_map = {
#         "CreatedBy" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedBy')).otherwise(lit(PIPELINE_NAME))
#         ,"CreatedDateTime" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedDateTime')).otherwise(lit(current_timestamp()))
#         ,"ModifiedBy" : when(col('DerivedIndicator') == 'UPDATE', lit(PIPELINE_NAME)).otherwise(lit(None))
#         ,"ModifiedDateTime" : when(col('DerivedIndicator').isin(['UPDATE', 'DELETE']), lit(current_timestamp())).otherwise(lit(None))
#         ,"ProcessName" : lit(process_name).cast("string")
#         ,"DeltaStatus" : lit(None).cast("string")
#     }
#     aftr_mem_cov_split_up = aftr_mem_cov_split_tbl.withColumns(col_map)
#     # Change column nullable to False.
#     delta_mem_cov= set_df_columns_not_nullable(spark,aftr_mem_cov_split_up,['MemberKey', 'ProviderContractKey', 'ProductKey','CoverageStartDate', 'CreatedBy','CreatedDateTime'])
    
#     # Change column nullable to True.
#     delta_col_mem_cov_df = set_df_columns_not_nullable(spark,delta_mem_cov,['ProcessName', 'CoverageTypeCode', 'CoverageTypeCodeLabel', 'VendorSequenceNumber', 'DerivedIndicator', 'CoverageEndDate'], True)
#     # Write data to Azure SQL stage table.
#     load_df_to_sf_sql_db_spark(delta_col_mem_cov_df, mem_cov_sql_tbl_name)
    
    
# except Exception as e:
#     excep = f'Write data to Azure SQL {mem_cov_sql_tbl_name} table failed: ' + str(e)
#     insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
#     raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Change column nullables and Write data to Azure SQL stage table(StageProviderContracTransfer)
# # prv_ctrt_up_dlt_df = read_table_to_df(massmove_pct_tbl)
# col_map = {
#         "CreatedBy" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedBy')).otherwise(lit(PIPELINE_NAME))
#         ,"CreatedDateTime" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedDateTime')).otherwise(lit(current_timestamp()))
#         ,"ModifiedBy" : when(col('DerivedIndicator').isin(['UPDATE','DELETE']), lit(PIPELINE_NAME)).otherwise(lit(None))
#         ,"ModifiedDateTime" : when(col('DerivedIndicator').isin(['UPDATE', 'DELETE']), lit(current_timestamp())).otherwise(lit(None))
#         ,"ProcessName" : substring(lit(process_name),1,20).cast("string")
#         ,"DeltaStatus" : lit(None).cast("string")
        
#     }
# prv_ctrt_trns_updt_dlt = db_df.withColumns(col_map)
# # # Change column nullable to False.
# delta_df= set_df_columns_not_nullable(spark,prv_ctrt_trns_updt_dlt,['CreatedBy','CreatedDateTime','ModifiedDateTime'])
# # # Change column nullable to True.
# delta_col_df = set_df_columns_not_nullable(spark,delta_df,['ProcessName'], True)
# # # Write data to Azure SQL stage table.
# load_df_to_sf_sql_db_spark(delta_col_df, 'ProviderContract.StageDBPProviderContractTransfer')

# COMMAND ----------

# MAGIC %md
# MAGIC ##Report/Outboud file Creation

# COMMAND ----------

# DBTITLE 1,Detail report creation
try:
    final_reprt=read_table_to_df(massmove_reprt_tbl).orderBy("MemberId","MemberCustomerNumber","CoverageStartDate")
    reprt_df = final_reprt.selectExpr('BeforeAfterIndicator','MemberId','MemberCustomerNumber','MemberGroupNumber','MarketNumber','ZipCode','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber','CoverageStartDate','CoverageEndDate','CoverageEndReasonCode','RecordsSequenceNumber','Message','UpdateIndicator')
    generate_report(reprt_df, outbnd_temp_detail_csv_path, outbnd_csv_path, success_file_name)
    
except Exception as e:
    excep = 'Write records to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Generate Outbound File
try:
    outbound_df=final_reprt.selectExpr('MarketNumber','FromProviderId','FromProviderSuffixCode','MemberCustomerNumber','MemberGroupNumber','MemberId','RecordsSequenceNumber','ZipCode','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber','BeforeAfterIndicator','CoverageStartDate','CoverageEndDate','Message','IdCardRequestIndicator','CoverageEndReasonCode','ActionCode','UpdateIndicator',"'' as Filler")
    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, outbound_df)
    
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(final_df, outbnd_temp_detail_csv_path, config)
    copy_file_to_outbnd_with_new_name(outbnd_temp_detail_csv_path, outbnd_csv_path, outbound_file_name)
    union_bfr_aftr_mem_cov_splt.unpersist()
except Exception as e:
    excep = 'Write records to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Error report creation
try:
    rej_df = processed_df.filter(col('Comment').isNotNull()).select(*err_rep_col)
    generate_report(rej_df, outbnd_temp_err_csv_path, outbnd_csv_path, err_file_name)
except Exception as e:
    excep = 'Write records to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Detail report creation for PCTransfer
try:
    rep_def = read_table_to_df(massmove_pct_tbl).select("ActionCode","TransferStatusCode","FromProviderContractId","ToProviderContractId","ContractTransferStartDate","ContractTransferEndDate","ContractTransferCode","IdCardRequestIndicator","ProviderChangeProcessDate","OperatorName").orderBy("FromProviderContractId","ToProviderContractId",ascending=False)
 
    generate_report(rep_def, outbnd_temp_detail_csv_path, outbnd_csv_path, PCT_Detail_Report)
except Exception as e:
    excep = 'Write records to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Insert success transaction to audit table and exit report file name
# Insert success entry to the audit table.
insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, None, process ="DBP")
# Exit outbound file names
outbound_file_name =  outbound_file_name
dbutils.notebook.exit(outbound_file_name)
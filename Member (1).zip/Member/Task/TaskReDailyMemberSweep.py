# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC ReDailyMemberSweep - Create an interface which will track all the changes in Primary Care Physician (PCP) and update in SF tables and synchronize the data using coverage process in case of discrepancies.
# MAGIC ###### Source Details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - Member coverage 
# MAGIC - Product 
# MAGIC - Member 
# MAGIC - MemberCoverage 
# MAGIC - CIMEMBER 
# MAGIC - Provider 
# MAGIC - ProviderContract
# MAGIC - ProviderContractControl
# MAGIC - GeoMarket
# MAGIC - GeoMarketCycle
# MAGIC - Re400prvjctDaily
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.redailymembersweep
# MAGIC ###### Target Details (File):
# MAGIC - redailymembersweep(txt File) 
# MAGIC ###### Created By: Supriya
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import json
from dateutil.relativedelta import relativedelta
from pyspark.sql.functions import year
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
     default_config = config_dict["DEFAULT"]
     default_out_config = default_config["Outbound"]
     default_in_config = default_config["Inbound"]
     reDailyMemberSweep = config_dict[job_name] 
     container_name = default_config["ContainerName"]
     ctrl_table_name = default_config["AuditTableName"]
     file_path_prefix = default_out_config["FilePathPrefix"]
     file_path_suffix = default_in_config['FilePathSuffix']
     file_path_prefix_in = default_in_config["FilePathSuffix"]
     config = default_out_config["Config"]
     prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
     curated_path_suffix = reDailyMemberSweep["Outbound"]["CuratedFilePathSuffix"]
     temp_path_suffix = reDailyMemberSweep["Outbound"]["TempFilePathSuffix"]
     outbnd_temp_err_path_suffix = reDailyMemberSweep["Outbound"]["TempFileErrorPathSuffix"]
     outbnd_temp_detail_path_suffix = reDailyMemberSweep["Outbound"]["TempFileDetailPathSuffix"]
     Mbr_extract_tbl_name = reDailyMemberSweep["Outbound"]["MemberExtractTableName"]
     edw_feed_tbl_name = reDailyMemberSweep["Outbound"]["Re0800TableName"]
     mbr_sweep_tbl_name = reDailyMemberSweep["Outbound"]["MbrSweepTableName"]
     outbnd_file_name = reDailyMemberSweep["Outbound"]["FileName"]
     err_file_name = reDailyMemberSweep["Outbound"]["ErrorFileName"]
     success_file_name = reDailyMemberSweep["Outbound"]["SuccessFileName"]
     cap_path = reDailyMemberSweep["Inbound"]["EdwCapitationFilePath"]
     re400ReprvjctDaily_tbl_name = reDailyMemberSweep["Inbound"]["Re400ReprvjctDailyTableName"]
     mbr_cvrg_tbl_name = reDailyMemberSweep["Inbound"]["StageMemberCoverageTableName"]
     prod_tbl_name = reDailyMemberSweep["Inbound"]["StageProductTableName"]
     prov_ctrt_tbl_name = reDailyMemberSweep["Inbound"]["StageProviderContractTableName"]
     prov_tbl_name = reDailyMemberSweep["Inbound"]["StageProviderTableName"]
     geo_mkt_tbl_name = reDailyMemberSweep["Inbound"]["StageGeoMarketTableName"]
     cust_tbl_name = reDailyMemberSweep["Inbound"]["StageCustomerTableName"]
     geo_mkt_cyc_tbl_name = reDailyMemberSweep["Inbound"]["StageGeoMarketCycleTableName"]
     prov_ctrct_ctrl_tbl_name = reDailyMemberSweep["Inbound"]["StageProviderContractControlTableName"]
     mbr_tbl_name=reDailyMemberSweep["Inbound"]["StageMemberTableName"]
     ci_mbr_tbl_name=reDailyMemberSweep["Inbound"]["StageCIMemberTableName"]
     sync_process_names = reDailyMemberSweep["Inbound"]["StageSyncDependencyProcess"]
    
except Exception as e:
     excep = 'Variable assignment from FileConfig: '+ str(e)
     output = {
		'NOTEBOOK_RUN_STATUS' : excep
     }
     dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check Product, Member and MemberCoverage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(ctrl_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account, prc_file_path_prefix, temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )

    capitation_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix_in, cap_path
    )

    outbnd_temp_err_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        outbnd_temp_err_path_suffix,
    )
    outbnd_temp_detail_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        outbnd_temp_detail_path_suffix,
    )
    # outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Reading config file failed: " + str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table
# Add required columns to the list from cimember table.
ci_mem_cols = [
    "CiGrpId",
    "CiBenSeqNbr",
    "CiClsNbr",
    "MbrGhGroup",
    "MbrPid",
    "MbrsubPid",
    "MbrUmid",
    "McaidId",
    "MbrUmidEffDate",
    "MbrGhSubGroup",
]
# Add required columns to the list from provider contract table.
prov_cont_req_cols = [
    "ProviderId",
    "ProviderContractId",
    "Providersuffixcode",
    "ProviderGrouperID",
    "ProviderContractKey",
    "ProviderKey",
]

# Add required columns to the list from provider table.
prov_req_cols = ["ProviderKey"]

# Add required columns to the list from product table.
prod_req_cols = [
    "ProductKey",
    "ExtProdSeqNo",
    "MarketNumber",
    "LineOfBusinessCode",
    "PlanNumber",
    "OptNumber",
]

# Add required columns to the list from member table.
mbr_req_cols = [
    "MemberKey",
    "MemberId",
    "SubscriberId",
    "MemberCustomerNumber",
    "HumanaIdentifier",
    "ClaimFundExceptionIndicator",
]

# Add required columns to the list from member coverage table.
mbr_cvrg_req_cols = [
    "MemberKey",
    "ProductKey",
    "ProviderContractKey",
    "CIClassNumber",
    "MemberCustomerNumber",
    "MemberGroupNumber",
    "GateKeeperProviderId",
    "GateKeeperProviderSuffixCode",
    "GateKeeperProviderTypeCode",
    "CoverageStartDate",
    "CoverageEndDate",
    "WokerCompensationOccurenceId",
    "CoverageEndReasonCode",
    "ModifiedBy",
    "ModifiedDateTime",
]

# Add required columns to the list from provider contract control table.
prv_ctrt_ctrl_req_cols = ["ProviderContractKey", "ControlTypeCode", "ControlTypeId"]

# Add required columns to the list from geo market cycle table.
prv_geo_mkt_cyc_rq_cols = ["CycleNumber", "GeoMarketKey"]

# Add required columns to the list from geo market table.
prv_geo_mk_rq_cols = ["GeoMarketKey", "GeoMarketId"]

# Add required columns to the list from Customer table.
cust_rq_cols=[ "CIGroupIdentifier","BenefitSequence","CIClassNumber","GHGroupIdentifier","EmployerGroupNumber"]

# COMMAND ----------

# DBTITLE 1,Read data from Stage ADLS.
try:

    # Read MemberCoverage from ADLS curated table and skip records when GateKeeperProviderTypeCode equals to wkc
    mbr_cvrg_df = read_table_to_df(mbr_cvrg_tbl_name).select(*mbr_cvrg_req_cols).filter(col("GateKeeperProviderTypeCode")!= "WKC")

    # Read CIMEMBER from ADLS curated table
    raw_ci_mbr_df = read_table_to_df(ci_mbr_tbl_name)

    # take only distinct records
    ci_mbr_df=ci_member_distinct(raw_ci_mbr_df).select(*ci_mem_cols)

    # Read Customer from ADLS curated table
    cust_df = read_table_to_df(cust_tbl_name).select(*cust_rq_cols)


    # Read MEMBER from ADLS curated table
    mbr_df = read_table_to_df(mbr_tbl_name).select(*mbr_req_cols)

    # Read PRODUCT from ADLS curated table
    prod_df = read_table_to_df(prod_tbl_name).select(*prod_req_cols)

    # Read ProviderContract from ADLS curated table
    prov_cont_df = read_table_to_df(prov_ctrt_tbl_name).select(*prov_cont_req_cols)

    # Read PROVIDER from ADLS curated table
    prov_df = read_table_to_df(prov_tbl_name).select(*prov_req_cols)

    # Read geo market cycle from ADLS curated table
    prov_geo_mkt_cyc_df = read_table_to_df(geo_mkt_cyc_tbl_name).select(*prv_geo_mkt_cyc_rq_cols)

    # Read geo market from ADLS curated table
    prov_geo_mkt_df = read_table_to_df(geo_mkt_tbl_name).select(*prv_geo_mk_rq_cols)

    # Read provider contract control from ADLS curated table
    prvdr_cntrl_df = read_table_to_df(prov_ctrct_ctrl_tbl_name).select(*prv_ctrt_ctrl_req_cols)

except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Fetch only 48 months data from MemberCoverage
# select the records if CoverageEndDate is greater than cutoff date
try:
    # Date Calculation: Subtract 36 months from current date.
    dt = date.today() - relativedelta(months=48)
    dts = str(dt)

    # Reclmmbr curated table is partitioned on CoverageEndYear. Get only the required partition.
    fltr_mbr_cvrg_df = mbr_cvrg_df.withColumn(
        "CoverageEndYear", year(mbr_cvrg_df["CoverageEndDate"].cast("date"))
    ).filter(
        col("CoverageEndYear") >= (dt.year)
    ) 
     # create a 48months_old_date column
    final_dt_df = fltr_mbr_cvrg_df.withColumn("RangeStartDate", to_date(lit(dts))) \
                               .withColumn("RangeEndDate", lit(date.today()))
   
    # take cut off date yyyymm with default date 1
    frmted_final_dt_df = final_dt_df.withColumn(
        "RangeStartDate", date_format(col("RangeStartDate"), "yyyy-MM-01")
    )
    # Filter CoverageEndDate is greater than cut off date
    current_df = frmted_final_dt_df.filter(col("CoverageEndDate") >= col("RangeStartDate"))
    

except Exception as e:
    excep = "calculation of cut off date failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Member, MemberCoverage 
try:
    # Join Member, MemberCoverage to get required fields
    joined_mbr_mbrcvrg_df = (
        current_df.alias("LH")
        .join(
            mbr_df.alias("RH"),
            (col("LH.MemberKey") == col("RH.MemberKey")),
            "left",
        )
        .select(
            "LH.*",
            "RH.MemberId",
            "RH.SubscriberId",
            "RH.HumanaIdentifier",
            "RH.ClaimFundExceptionIndicator",
        )
    ).drop("MemberKey")
except Exception as e:
    excep = "Join Member and MemberCoverage failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join the Member with Customer table to fetch Gh group fields
try:
    # join Member with Customer table to fetch Gh group fields
    calc_final_with_cust_df = (
        joined_mbr_mbrcvrg_df.alias("LH")
        .join(
            cust_df.alias("RH"),
            (col("RH.CIGroupIdentifier") == col("LH.MemberCustomerNumber"))
            & (col("RH.BenefitSequence") == col("LH.MemberGroupNumber"))
            & (col("RH.CIClassNumber") == col("LH.CIClassNumber")),
            "inner",
        )
        .select(
            "LH.*", col("RH.GHGroupIdentifier"), col("RH.EmployerGroupNumber")
        ).drop("MemberCustomerNumber","MemberGroupNumber")
    )
    calc_with_cust_df=calc_final_with_cust_df.selectExpr("*","GHGroupIdentifier as MemberCustomerNumber","EmployerGroupNumber as MemberGroupNumber").drop("GHGroupIdentifier","EmployerGroupNumber")
except Exception as e:
    excep = "join Member with customer table to fetch Gh group fields failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join with Ci Member to fetch McaidId, MbrUmid fields
try:
    # join Member with CiMember table to McaidId, MbrUmid fields
    calc_final_df = (
        calc_with_cust_df.alias("LH")
        .join(
            ci_mbr_df.alias("RH"),
            (col("RH.MbrGhGroup") == col("LH.MemberCustomerNumber"))
            & (col("RH.MbrPid") == col("LH.MemberId"))
            & (col("RH.MbrSubPid") == col("LH.SubscriberId")),
            "left",
        )
        .select(
            "LH.*",col("RH.McaidId"),"RH.MbrUmid"
        )
    )
    
except Exception as e:
    excep = "join Member with Ci Member table to fetch McaidId, MbrUmid failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join dataset with Product to fetch required fields
try:
    # Join dataset with Product to fetch required fields
    joined_prod_mbrcvrg_df = (
        calc_final_df.alias("LH")
        .join(
            prod_df.alias("RH"), (col("LH.ProductKey") == col("RH.ProductKey")), "left"
        )
        .select(
            "LH.*",
            "RH.ExtProdSeqNo",
            "RH.MarketNumber",
            "RH.LineOfBusinessCode",
            "RH.PlanNumber",
            "RH.OptNumber",
        )
        .withColumn(
            "MedicaidId",
            when(
                (col("LineOfBusinessCode") != "WKC")
                | (col("LineOfBusinessCode") != "MEF")
                | (col("LineOfBusinessCode") != "MEP"),
                col("McaidId"),
            ).otherwise(None),
        )
    ).drop(col("McaidId"), col("ProductKey"))

except Exception as e:
    excep = "Join dataset with Product failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join resulting dataset with provider contract to fetch required fields
try:
    # Join resulting dataset with provider contract 
    provctrct_with_mbrcvrg_df = (
        joined_prod_mbrcvrg_df.alias("LH")
        .join(
            prov_cont_df.alias("RH"),
            (col("LH.ProviderContractKey") == col("RH.ProviderContractKey")),
            "left",
        )
        .select("LH.*", "RH.ProviderContractId", "RH.ProviderGrouperID")
        
    )
except Exception as e:
    excep = "Join resulting dataset with provider contract failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter Provider contract control table if ControlTypeCode is GeoMkt
try:
    # Filter Provider contract control table if ControlTypeCode is GeoMkt
    prvdr_cntrl_fltr_df = prvdr_cntrl_df.filter(col("ControlTypeCode").isin(["GeoMkt"]))

    # Pivot ProviderContractControl Table
    prvdr_cntrl_pvt_df = pvt_cols(
        prvdr_cntrl_fltr_df, ["ProviderContractKey"], "ControlTypeCode", "ControlTypeId"
    )

    # Join GeoMarketCycle and GeoMarket table
    geo_cyc_df = (
        prov_geo_mkt_df.alias("LH")
        .join(
            prov_geo_mkt_cyc_df.alias("RH"),
            (col("LH.GeoMarketKey") == col("RH.GeoMarketKey")),
            "inner",
        )
        .select("LH.*", "RH.CycleNumber")
        .drop("GeoMarketKey")
    )

    # Fetch the Cycle number field
    final_pivot_df = (
        prvdr_cntrl_pvt_df.alias("LH")
        .join(
            geo_cyc_df.alias("RH"), (col("LH.GeoMkt") == col("RH.GeoMarketId")), "inner"
        )
        .select("LH.*", "RH.CycleNumber")
        .drop("GeoMkt")
    )

except Exception as e:
    excep = "Filter Provider contract control failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Fetch Cycle number
try:
    # Join above pivoted dataset with our final resulting dataset to get Cycle number
    final_df = (
        provctrct_with_mbrcvrg_df.alias("LH")
        .join(
            final_pivot_df.alias("RH"),
            (col("LH.ProviderContractKey") == col("RH.ProviderContractKey")),
            "left",
        )
        .select("LH.*", col("RH.CycleNumber"))
        .drop("ProviderContractKey")
    )
except Exception as e:
    excep = "Join pivoted dataset with final resulting dataset failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Add Filler column to the dataframe
try:
    final_filler_joined_df = final_df.withColumn("Filler", lit(""))
except Exception as e:
    excep = "Adding Filler column to the dataframe failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(final_filler_joined_df, Mbr_extract_tbl_name)

except Exception as e:
    excep = "Write to ADLS: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# MAGIC %md
# MAGIC HMO/PPO EDW Feed

# COMMAND ----------

# DBTITLE 1,Selecting required columns from Capitation fil
try:
    # Selecting required columns from Capitation file
    num_col = 36
    dtype_conv_lst = ["HIS_MBR_PID", "MBR_SUBPID", "HIS_MBR_UMID"]
    for i in range(1, num_col + 1):
        dtype_conv_lst.append(
            f"CAST(concat(HIS_PAY_PD_YR{i},HIS_PAY_PD_MM{i}) AS INT) AS PAY_PD_YR_YM_{i}"
        )
        dtype_conv_lst.append(
            f"array(CAST(HIS_HCF_HCC_A{i} AS FLOAT), CAST(HIS_HCF_HCC_B{i} AS FLOAT), CAST(HIS_HCF_HCC_D{i} AS FLOAT),CAST(HIS_MCARE_ID{i} AS STRING), CAST(HIS_PLAN{i} AS STRING),CAST(CAP_DSTFIL_SEG_ID{i} AS STRING),CAST(HIS_HCF_PBP{i} AS INT)) AS CombinedColumn_{i}"
        )

except Exception as e:
    excep = "Selecting required columns from Capitation file failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read re400, inbound file from ADLS curated table
try:
    # Read 400ReprvjctDaily processed output from ADLS table
    prvjct_df = read_table_to_df(re400ReprvjctDaily_tbl_name)

    # Read EDW_ITCAPHST_MCARE_BASE.TXT file from ADLS inbound folder
    df_capitation_sel = read_inbound_csv_file(capitation_path).selectExpr(*dtype_conv_lst)
    
    # Read Member extract from ADLS table
    mbr_extract_df=read_table_to_df(Mbr_extract_tbl_name).drop("RangeEndDate")

except Exception as e:
    excep = "Reading re400, inbound file from ADLS failed : "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate 36 months old data
# select the records if CoverageEndDate is greater than cutoff date
try:
    # Date Calculation: Subtract 36 months from current date.
    dt = date.today() - relativedelta(months=36)
    dts = str(dt)

    final_dt_df = mbr_extract_df.withColumn("RangeStartDate", to_date(lit(dts)))

    # take cut off date yyyymm with default date 1
    frmted_final_dt_df = final_dt_df.withColumn(
        "RangeStartDate", date_format(col("RangeStartDate"), "yyyy-MM-01")
    )
    # Filter CoverageEndDate is greater than cut off date
    current_df = frmted_final_dt_df.filter(col("CoverageEndDate") >= col("RangeStartDate"))
    current_df = current_df.drop("RangeStartDate","CoverageEndYear")

except Exception as e:
    excep = "calculation of cut off date failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Re0054, prvjct joined dataset with Re400 processed data.
try:

    # Join ouput of above step with Re400 processed data on ProviderContractKey.
    # add the scenario to write non matching records to one location
    re0054_prvjct_joined_df = (
        current_df.alias("LH")
        .join(
            prvjct_df.alias("RH"),
            (col("LH.ProviderContractId") == col("RH.ProviderContractId")),
            "inner",
        )
        .select(
            "LH.*",
            "RH.LedgerNumber",
            "RH.ClaimRule",
            "RH.IPAIndicator",
            "RH.OpenFundIndicator",
            "RH.ClmRprocInd",
            "RH.PcaFundedContractInd",
            "RH.ProviderServiceTypeCode",
            "RH.ProviderSequenceNumber",
            col("RH.ProviderGrouperId").alias("ReprvjctProviderGrouperId")
        )
    )
except Exception as e:
    excep = "Join re0054 and Re400 processed data failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Re0054 output with capitation inbound file
try:
    # Join re0054 output with capitation inbound file
    joined_df = re0054_prvjct_joined_df.alias("LH").join(
        df_capitation_sel.alias("RH"),
        (col("LH.MemberId") == (trim(col("RH.HIS_MBR_PID"))))
        & (col("LH.SubscriberId") == (trim(col("RH.MBR_SUBPID")))),
        "left",
    )
    # Adding column 'CoverageEndDateConvrted' to accomodate CoverageEndDate in yyyyMM format
    calc_re0054_prvjct_date = joined_df.withColumn(
        "CoverageEndDateConverted", expr("date_format(CoverageEndDate,'yyyyMM')")
    )
except Exception as e:
    excep = "Join with capitation file failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculation of CombinedColumn
try:
    # calculate CombinedColumn
    # 1. start from the First date of capitation file.
    # 2. if CoverageEndDate is greater than the 1st capitation Pay date column then set the value CombinedColumn_1
    # 3. if step is not satisfied compare CoverageEndDate with 2nd capitation Pay date column if yes then set the value to CombinedColumn_2.
    # 4. repeat till final occurance i.e 36th date column in capitation.
    # 5. As we are using switch case once condition satisfies it will update CombinedColumn_{i} ith column into final CombinedColumn.

    calc_col_lst = []
    str_col = (
        f"CASE WHEN CoverageEndDateConverted >= PAY_PD_YR_YM_1 THEN CombinedColumn_1"
    )
    for seq in range(2, 36):
        str_col += f" WHEN CoverageEndDateConverted >= PAY_PD_YR_YM_{seq} THEN CombinedColumn_{seq}"
    str_col += f" WHEN CoverageEndDateConverted>= PAY_PD_YR_YM_36 THEN CombinedColumn_36 ELSE array(CAST(00.0000 AS FLOAT), CAST(00.0000 AS FLOAT), CAST(00.0000 AS FLOAT),CAST(' ' AS STRING), CAST(' ' AS STRING),CAST(' ' AS STRING),CAST(' ' AS STRING)) END AS CombinedColumn"

    # Append the created string into a list
    calc_col_lst.append(str_col)

    # use calc_re0054_prvjct_date dataframe, on the basis of CoverageEndDateConverted column, above switch case scenarios will be checked and CombinedColumn will be updated.
    calc_df = calc_re0054_prvjct_date.selectExpr("*", *calc_col_lst)

except Exception as e:
    excep = "Comparison of CoverageEndDate with Captation Pay Date failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Segregate CombinedColumn values into different columns
try:
    # Split CombinedColumn into 7 required columns
    df_clmmbr_capitation_select = calc_df.selectExpr(
        "*",
        "CombinedColumn[0] as HcfaHccA",
        "CombinedColumn[1] as HcfaHccB",
        "CombinedColumn[2] as HcfaHccD",
        "CombinedColumn[3] as HcfaMcareId",
        "CombinedColumn[4] as HcfaMcoCtrctNo",
        "CombinedColumn[5] as HcfaSegId",
        "CombinedColumn[6] as HcfaPbp",
    ).drop("CombinedColumn")

    # Filter records where MemberId and SubPid are not present in capitation history file and set the default values.
    condition = (col("HIS_MBR_PID").isNull()) & (col("MBR_SUBPID").isNull())

    null_values_df = (
        df_clmmbr_capitation_select \
        .withColumn("HcfaHccA",when(condition, lit(format_string("%.4f", lit(0.0)))).otherwise(col("HcfaHccA")))
        .withColumn("HcfaHccB",when(condition, lit(format_string("%.4f", lit(0.0)))).otherwise(col("HcfaHccB")))
        .withColumn("HcfaHccD",when(condition, lit(format_string("%.4f", lit(0.0)))).otherwise(col("HcfaHccD")))
        .withColumn("HcfaMcareId",when(condition, lit("")).otherwise(col("HcfaMcareId")))
        .withColumn("HcfaMcoCtrctNo",when(condition, lit("")).otherwise(col("HcfaMcoCtrctNo")))
        .withColumn("HcfaSegId", when(condition, lit("")).otherwise(col("HcfaSegId")))
        .withColumn("HcfaPbp", when(condition, lit("")).otherwise(col("HcfaPbp")))
    )

except Exception as e:
    excep = "Splitting CombinedColumn failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select final output column
try:
    df_clmmbr_capitation_final = null_values_df.select(
        "MemberCustomerNumber",
        "MemberId",
        "SubscriberId",
        "MemberGroupNumber",
        "ExtProdSeqNo",
        "MarketNumber",
        "LineOfBusinessCode",
        "PlanNumber",
        "OptNumber",
        "GateKeeperProviderId",
        "GateKeeperProviderSuffixCode",
        "GateKeeperProviderTypeCode",
        "CoverageStartDate",
        "CoverageEndDate",
        "ModifiedDateTime",
        "ModifiedBy",
        "WokerCompensationOccurenceId",
        "CoverageEndReasonCode",
        "MedicaidId",
        "ProviderContractId",
        "ProviderGrouperID",
        "CycleNumber",
        "HumanaIdentifier",
        col("MbrUmid"),
        "HcfaMcareId",
        "ProviderServiceTypeCode",
        "LedgerNumber",
        "ClaimRule",
        "IPAIndicator",
        col("ReprvjctProviderGrouperId"),
        "ClmRprocInd",
        "PcaFundedContractInd",
        "OpenFundIndicator",
        "HcfaHccA",
        "HcfaHccB",
        "HcfaHccD",
        "HcfaMcoCtrctNo",
        "HcfaPbp",
        "HcfaSegId",
    )
except Exception as e:
    excep = "Selecting final output columns failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write data to ADLS
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_clmmbr_capitation_final, edw_feed_tbl_name)

    # Read data from stage layer.
    resweep_df = read_table_to_df(edw_feed_tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, resweep_df)

    # write dataframe as .txt file with position delimitor.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
		'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Move data from tmp path to Outbound folder 
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# MAGIC %md
# MAGIC Membership Report

# COMMAND ----------

try:
    # Read Member extract from ADLS table
    mbr_extract_df = read_table_to_df(Mbr_extract_tbl_name).select(
        "CoverageEndDate",
        "CoverageStartDate",
        "CycleNumber",
        "MemberId",
        "RangeStartDate",
        "RangeEndDate",
    )

except Exception as e:
    excep = "Read Member extract from ADLS table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate final Effective dates
try:
    # Filter records if CoverageEndDate is greater than cut off date
    # 1. If Coverage End Date greater than Cutoff Date (RangeStartDate), then check Effective date with Cutoff Date
    # 2. If (CoverageStartDate) is less than Cut-off Date (RangeStartDate), then take Cutoff Date as Effective date
    # 3. If (CoverageStartDate) is greater than Cut-off Date (RangeStartDate), then Set Effective Date as Effective date 
     
    current_df = frmted_final_dt_df.filter(
        col("CoverageEndDate") >= col("RangeStartDate")
    ).withColumn(
        "EffectiveDate",
        when(
            (col("CoverageStartDate") >= col("RangeStartDate")),
            col("CoverageStartDate"),
        ).otherwise(col("RangeStartDate")),
    )
    current_df = current_df.withColumn(
        "EffectiveDate", date_format(col("EffectiveDate"), "yyyy-MM")
    )
    calc_current_df = current_df.groupby("CycleNumber", "EffectiveDate").count()
    
except Exception as e:
    excep = "calculation of effective date failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read previous load data from Increment Curated table.
try:
    if spark.catalog.tableExists(mbr_sweep_tbl_name):
        # Read previous load data from Increment Curated table.
        old_df = read_table_to_df(mbr_sweep_tbl_name)   
    else: 
        # load the dataframe into the table for the first time.   
        write_df_as_delta_table(calc_current_df.filter(lit(1)==lit(0)), mbr_sweep_tbl_name)
except Exception as e:
    excep = "Identifying incremental data failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Compare previous day and current day data
try:
    joined_df = (
        old_df.alias("LH")
        .join(
            calc_current_df.alias("RH"),
            ["CycleNumber", "EffectiveDate"],
            "left",
        )
        .select(
            "LH.*",
            col("LH.count").alias("PreviousCount"),
            col("RH.count").alias("CurrentCount"),
        )
        .drop("count")
    )
    # Calculate difference in count
    calc_df = joined_df.withColumn(
        "Difference", ((col("PreviousCount") - col("CurrentCount")))
    )
    
    # Create a dataset if the difference is greater than 50
    error_df = calc_df.filter(col("Difference") > 50)
    
    # overwrite the table with latest data
    write_df_as_delta_table(calc_current_df, mbr_sweep_tbl_name, mode="overwrite")
except Exception as e:
    excep = "Identifying incremental data failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate Error file name
# Merge error file name and current timestamp
current_ts = datetime.now()
err_file_name_with_ts = f"{err_file_name}{current_ts.strftime('%Y%m%dT%H%MZ')}.txt"
success_file_name_with_ts = f"{success_file_name}{current_ts.strftime('%Y%m%dT%H%MZ')}.txt"

# COMMAND ----------

# DBTITLE 1,Error report creation
try:
    # create an error report
    generate_report(error_df, outbnd_temp_err_csv_path, outbnd_csv_path, err_file_name_with_ts)
except Exception as e:
    excep = 'Write records to error file failed: ' + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
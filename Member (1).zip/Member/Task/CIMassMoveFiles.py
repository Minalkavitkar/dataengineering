# Databricks notebook source
CIMassMove = [
    "IN_CI_GAG0Y_UNL.TXT",
    "IN_CI_GAG0Y_UNL_COT.TXT",
    "IN_CI_GAG4U_UNL.TXT",
    "IN_CI_GAG4U_UNL_COT.TXT",
    "IN_CI_GAG72_UNL.TXT",
    "IN_CI_GAG72_UNL_COT.TXT",
    "IN_CI_GHGXR_UNL.TXT",
    "IN_CI_GHGXR_UNL_COT.TXT",
    "IN_CI_IEG02_UNL.TXT",
    "IN_CI_IEG02_UNL_COT.TXT",
    "IN_CI_IEG0D_UNL.TXT",
    "IN_CI_IEG0D_UNL_COT.TXT",
    "IN_CI_IEG0E_UNL.TXT",
    "IN_CI_IEG0E_UNL_COT.TXT",
    "IN_CI_IEG21_UNL.TXT",
    "IN_CI_IEG21_UNL_COT.TXT",
    "IN_CI_IOBEN_UNL.TXT",
    "IN_CI_IOBEN_UNL_COT.TXT",
    "IN_CI_ITGEO_UNL.TXT",
    "IN_CI_ITGEO_UNL_COT.TXT",
    "IN_CI_PQG0M_UNL.TXT",
    "IN_CI_PQG0M_UNL_COT.TXT",
    "IN_CI_SFG1R_UNL.TXT",
    "IN_CI_SFG1R_UNL_COT.TXT",
    "IN_CI_SFG42_UNL.TXT",
    "IN_CI_SFG42_UNL_COT.TXT",
    "IN_CI_SFG49_UNL.TXT",
    "IN_CI_SFG49_UNL_COT.TXT",
    "IN_CI_SFG4A_UNL.TXT",
    "IN_CI_SFG4A_UNL_COT.TXT",
    "IN_CI_SFG4D_UNL.TXT",
    "IN_CI_SFG4D_UNL_COT.TXT",
    "IN_CI_SFG5K_UNL.TXT",
    "IN_CI_SFG5K_UNL_COT.TXT",
    "IN_CI_SFG5Z_UNL.TXT",
    "IN_CI_SFG5Z_UNL_COT.TXT",
    "IN_CI_SFG71_UNL.TXT",
    "IN_CI_SFG71_UNL_COT.TXT",
    "IN_CI_SFGID_UNL.TXT",
    "IN_CI_SFGID_UNL_COT.TXT",
    "IN_CI_SIG01.TXT",
    "IN_CI_SIG01_COT.TXT",
    "IN_CI_WAG08_UNL.TXT",
    "IN_CI_WAG08_UNL_COT.TXT"
]

# COMMAND ----------

try:
    ci_files = ','.join(CIMassMove)
    dbutils.notebook.exit(ci_files)
except Exception as e:
    raise Exception("getting table list to run failed: ",str(e))
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Customer Product is a process to collect the information of the new or updated customer and update their relationship with product.
# MAGIC
# MAGIC
# MAGIC ###### Strategy
# MAGIC - Below SQL table have small data hence no sync-up process used here.
# MAGIC   - Product.Product
# MAGIC   - Accounting.FinanceHeaderLedger
# MAGIC   - Member.CustomerProduct
# MAGIC
# MAGIC - Inserted/Modified records ar collected on a daily basis from CI Customer (Customer, BenefitTypePccurance), we need to compare that with CustomerProduct in SQL environment
# MAGIC   - if there is an existing relationship and there is a change in Product
# MAGIC     - update existing record endDate with new BenDtlEffDate -1
# MAGIC     - create a new records with new BenDtlEffDate to openEndDate
# MAGIC   - if there is no match insert as new records with startDate as 1901-01-01 to 9999-12-31
# MAGIC
# MAGIC
# MAGIC ###### Source Tables
# MAGIC - Customer - UC table
# MAGIC - BenefitTypeOccurance - UC table
# MAGIC - Product - Azure SQL domain table
# MAGIC - FinanceLedgerHeader - Azure SQL domain table
# MAGIC
# MAGIC ###### Target Tables
# MAGIC - StageDBPCustomerProduct - stage table
# MAGIC - CustomerProduct - domain table
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','pl_CustomerCoverage')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_NAME','CustomerFeedCoverageRE0016')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('LOAD_TYPE','')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# DBTITLE 1,Execution check if FullLoad then not required
try:
    if LOAD_TYPE == "FullLoad":
        dbutils.notebook.exit("This process is for Delta only")
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up local variables
audit_start_date_time = datetime.now() - timedelta(days=1)
job_type = 'DailyJobs'

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name

except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from File Config.
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)

    default_config = config_dict["DEFAULT"]
    config_dict_job = config_dict[job_name]
    
    container_name = default_config["ContainerName"]
    default_out_config = default_config["Outbound"]
    audit_table_name = default_config['AuditTableName']

    file_path_prefix = default_out_config["FilePathPrefix"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    config = default_out_config["Config"]

    # Inbound Tables
    CurCustTbl = config_dict_job['Inbound']['CurCustTbl']
    CurCustBenOccTbl = config_dict_job['Inbound']['CurCustBenOccTbl']
    SQLProduct = config_dict_job['Inbound']['SQLProduct']
    SQLLedgerHdr = config_dict_job['Inbound']['SQLLedgerHdr']
    SQLCustProd = config_dict_job['Inbound']['SQLCustProd']
    
    # Outbound Tables
    UCStageDBPCustProd = config_dict_job['Outbound']['UCStageDBPCustProd']
    SQLDBPStageCustProd = config_dict_job['Outbound']['SQLDBPStageCustProd']
    
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,select new/modified customer info and its respective benefits
try:    
    dfCustomer = spark.table(CurCustTbl)\
        .filter((to_date(col('CreatedDateTime')) == audit_start_date_time.date()) | (to_date(col('ModifiedDateTime')) == audit_start_date_time.date()))\
        .select("CIClassNumber","CIGroupIdentifier","BenefitSequence","SourceLOBCode","SellingLedger")
            
    dfCusBenOcc = spark.table(CurCustBenOccTbl)\
        .filter((to_date(col('CreatedDateTime')) == audit_start_date_time.date()) | (to_date(col('ModifiedDateTime')) == audit_start_date_time.date()))\
        .select("CIClassNumber","CIGroupIdentifier","BenefitSequence","SellingLedger","ProductPlanNumber","ProductOptionNumber","BenefitEffectiveDate")\
        .distinct()

    if dfCusBenOcc.rdd.isEmpty():
        excep = 'No data in customer'
        insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, excep)
        dbutils.notebook.exit(excep)
        
except Exception as e:
    excep = 'Customer and Benefit details collection:' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Select needed columns from Product & Ledger
try:
    dfSQLCustProd = read_sf_sql_tbl_to_df_spark(SQLCustProd)\
        .selectExpr('*',"md5(concat(MarketNumber, LineOfBusinessCode, PlanNumber, OptNumber)) as HashKey")

    dfProduct = read_sf_sql_tbl_to_df_spark(SQLProduct)\
        .selectExpr("ProductKey","ProductId","LineOfBusinessCode","MarketNumber","PlanNumber","OptNumber","ProductStartDate","ProductEndDate","ExtProdSeqNo")

    dfLedger = read_sf_sql_tbl_to_df_spark(SQLLedgerHdr).selectExpr("LedgerNumber","LineOfBusinessCode")
    dfLedger = dfLedger.withColumn('ProdCatCd', when(col('LineOfBusinessCode') == "WKC", lit("WKC"))\
                                                .when(col('LineOfBusinessCode') == "MEF", lit("PFS"))\
                                                .when(col('LineOfBusinessCode') == "MEP", lit("PPO"))\
                                                .otherwise(lit("HMO")))
    
except Exception as e:
    excep = 'Read data from azure sql for product and ledger:' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Minimum BenDtlEffDate derivation based on benefit 
try:
    benview1 = dfCusBenOcc.groupBy(["CIClassNumber","CIGroupIdentifier","BenefitSequence","SellingLedger","ProductPlanNumber","ProductOptionNumber"])\
        .agg(min('BenefitEffectiveDate').alias('ViewStartDate'))

except Exception as e:
    excep = 'Benefit derivation:' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Join Customer, Product and Ledger data to create equivalent structure as CustomerProduct
try:
    # Join Customer, Product and Ledger to create records equivalent for customerProduct table for INSERT and UPDATE
    dfCustBen = dfCustomer.alias('ci')\
        .join(benview1.alias('ben'), 
                (col('ci.CIClassNumber')==col('ben.CIClassNumber')) & 
                (col('ci.CIGroupIdentifier')==col('ben.CIGroupIdentifier')) & 
                (col('ci.BenefitSequence')==col('ben.BenefitSequence')), "left")\
        .selectExpr('ci.*','ben.ProductPlanNumber','ben.ProductOptionNumber','ben.ViewStartDate').distinct()
    # ,'ben.StartDate','ben.EndDate'
    
    dfcustLgr = dfCustBen.alias('cb')\
        .join(dfLedger.alias('lgr'), col('cb.SellingLedger') == col('lgr.LedgerNumber'), 'left')

    dfcustPrdLgr = dfcustLgr.alias('cbl')\
        .join(dfProduct.alias('prd'),  
            (col('cbl.SellingLedger') == col('prd.MarketNumber')) & 
            (col('cbl.ProductPlanNumber') == col('prd.PlanNumber')) &
            (col('cbl.ProductOptionNumber') == col('prd.OptNumber')) &
            (col('cbl.LineOfBusinessCode')==col('prd.LineOfBusinessCode')) , "left")\
        .selectExpr("cbl.*","prd.MarketNumber","prd.ProductKey","prd.PlanNumber","prd.OptNumber","prd.ProductStartDate","prd.ProductEndDate","prd.ExtProdSeqNo", "md5(concat(prd.MarketNumber,cbl.LineOfBusinessCode, prd.PlanNumber, prd.OptNumber)) as HashKey")
    
    dfcustPrdLgr_Valid = dfcustPrdLgr.filter(col('ProductKey').isNotNull())
    
except Exception as e:
    excep = 'Create the CustProdRecords:' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Map column names as per Azure SQL
col_mapping = {
    'ProductKey':'ProductKey',
    'ExtProdSeqNo':'ExtProdSeqNo',
    'CIGroupIdentifier':'MemberCustomerNumber',
    'BenefitSequence':'MemberGroupNumber',
    'CIClassNumber':'CIClassNumber',
    'ProdCatCd':'ProductCategoryCode',
    'LineOfBusinessCode':'LineOfBusinessCode',
    'ProductPlanNumber':'PlanNumber',
    'ProductOptionNumber':'OptNumber',
    'SellingLedger':'MarketNumber',
    'ViewStartDate':'ViewStartDate',
    'HashKey':'HashKey'
}

# COMMAND ----------

# DBTITLE 1,Map as per SQL
try:
    # Map the df columns to SQL Columns and addthe created and Modified audit columns
    col_mapped_df = add_tgt_audit_column(col_name_mapping(dfcustPrdLgr_Valid,col_mapping),PIPELINE_NAME)

    dtype_conv = {
        'PlanNumber':'STRING',
        'OptNumber':'STRING'
    }

    # Convert data type and add extra column to match table structure
    df_dtype_convrt = dtype_tgt_conversion(col_mapped_df,dtype_conv)
    df_add_cols = df_dtype_convrt.drop('ProductKey')

    df_process_data = set_df_columns_nullable(spark, df_add_cols, ['sourcesystemcode','ProcessName'])
    
except Exception as e:
    excep = 'RUN failed:'+str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Filter rows with Product change or new customer
try:
    # join cols with SQL CustomerProduct Data
    joinCols_udt = ['membercustomernumber','membergroupnumber','ciclassnumber','ProductCategoryCode']
    joinCols_isrt = ['membercustomernumber','membergroupnumber','ciclassnumber']

    # records for which product changed and hence will be terminated and new records will come inserted with new start date and open end date
    df_udt = df_process_data.alias('LH').join(dfSQLCustProd.alias('RH'), joinCols_udt,'left')\
        .filter((col('LH.ViewStartDate') >= col('RH.CustomerProductStartDate')) & (col('LH.ViewStartDate') <= col('RH.CustomerProductEndDate')) & (col('LH.HashKey') != col('RH.HashKey')))\
        .select('LH.*', lit('UPDATE').alias('DerivedIndicator'))\
        .drop('HashKey')

    # records with new customer
    df_isrt = df_process_data.alias('LH')\
        .join(dfSQLCustProd.alias('RH'), joinCols_isrt,'leftanti').select('LH.*', lit('INSERT').alias('DerivedIndicator'))\
        .drop('HashKey')


except Exception as e:
    excep = 'RUN failed:'+str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Align the columsn in updae and insert dataframes
align_cols = {
    'MemberCustomerNumber':'MemberCustomerNumber',
    'MemberGroupNumber':'MemberGroupNumber',
    'CIClassNumber':'CIClassNumber',
    'ProductCategoryCode':'ProductCategoryCode',
    'ExtProdSeqNo':'ExtProdSeqNo',
    'LineOfBusinessCode':'LineOfBusinessCode',
    'PlanNumber':'PlanNumber',
    'OptNumber':'OptNumber',
    'MarketNumber':'MarketNumber',
    'ViewStartDate':'ViewStartDate',
    'CreatedBy':'CreatedBy',
    'CreatedDateTime':'CreatedDateTime',
    'ModifiedBy':'ModifiedBy',
    'ModifiedDateTime':'ModifiedDateTime',
    'DerivedIndicator':'DerivedIndicator'
}

try:
    df_final_udt = col_name_mapping(df_udt,align_cols)
    df_final_isrt = col_name_mapping(df_isrt,align_cols)

    df_final_union = df_final_udt.union(df_final_isrt)

    stdt = '1901-01-01'
    enddt = '9999-12-31'
    stdtObj = datetime.strptime(stdt,'%Y-%m-%d').date()
    enddtObj = datetime.strptime(enddt,'%Y-%m-%d').date()
    
    withCols = {
        'CustomerProductKey':lit(None).cast('BIGINT'),
        'CustomerProductStartDate': when(col('DerivedIndicator') =='UPDATE', col('ViewStartDate'))\
            .when(col('DerivedIndicator') =='INSERT', lit(stdtObj)),
        'CustomerProductEndDate': lit(enddtObj),
        'sourcesystemcode':lit('LV').cast('STRING'),
        'ProcessName':lit('CustomerCoverageBRD').cast('STRING'),
        'DeltaStatus': lit(None).cast('STRING')
    }

    df_final = df_final_union.withColumns(withCols).drop('ViewStartDate')

except Exception as e:
    excep = 'RUN failed:'+str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Main try & Except block to call each function
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, UCStageDBPCustProd)
    
    # Read data from stage layer.
    df_re0016 = read_table_to_df(UCStageDBPCustProd)

    # change the columns to not null
    not_null_cols_lst = ['CreatedBy', 'CreatedDateTime']
    df_re0016_final = set_df_columns_not_nullable(spark, df_re0016, not_null_cols_lst)
    
    # load daa to curated table
    load_df_to_sf_sql_db_spark(df_re0016_final,SQLDBPStageCustProd)

except Exception as e:
    excep = 'RUN failed:'+str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)
else:
    excep = "RUN was successful"
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, excep)
    dbutils.notebook.exit(excep)
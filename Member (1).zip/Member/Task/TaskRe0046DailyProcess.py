# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Job RE0046 - This process will update the SF Customer Group Benefit data and keep it in sync with CI Customer Group Benefit data from CI application 
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - Member.BenefitTypeOccurrence
# MAGIC - Member.BenefitCopayOccur
# MAGIC - Member.StageCustomerProduct
# MAGIC
# MAGIC ###### Intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - Member.Re0046SyncUp
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import *
from datetime import date
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run Transform notebook
# MAGIC %run ../../Utility/Transform  

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Job name Assignment
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0046DailyProcess')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config
try:
  config_dict = get_file_config(file_conf_path)

except Exception as e:
  excep = "Read File Config failed: " + str(e)
  output = {"NOTEBOOK_RUN_STATUS": excep}
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
  default_config = config_dict["DEFAULT"]
  default_out_config = default_config["Outbound"]
  default_in_config = default_config["Inbound"]
  Re0046_config = config_dict[JOB_NAME]
  container_name = default_config["ContainerName"]
  file_path_prefix = default_out_config['FilePathPrefix']
  config = default_out_config["Config"]
  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  curated_path_suffix = Re0046_config["Outbound"]["CuratedFilePathSuffix"]
  cur_tbl_name = Re0046_config['Outbound']['TableName']
  stg_ben_typ_occ_tbl_name = Re0046_config["Inbound"]["StageBenefitTypeOccurrence"]
  stg_ben_copay_occ_tbl_name = Re0046_config["Inbound"]["StageBenefitCopayOccur"]
  stg_cust_prd_tbl_name = Re0046_config["Inbound"]["StageCustomerProduct"]
  stg_grdr_header_tbl_name = Re0046_config["Inbound"]["StageMemberGRDRHeaderTableName"]
  stg_grdr_detail_tbl_name = Re0046_config["Inbound"]["StageMemberGRDRDetailTableName"]
  sync_process_names = Re0046_config["Inbound"]["StageSyncProcessNames"]
  ctrl_table_name = default_config["AuditTableName"]
    
except Exception as e:
  excep = "Variable assignment from FileConfig: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(ctrl_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(
            f"Stage tables: {sync_process_names} are not in sync with Azure SQL table"
        )
except Exception as e:
    excep = "ControlTable check failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Curated
try:
    cur_delta_path = path_builder(
        container_name,
        storage_account,
        curated_path_suffix,
        path_prefix=prc_file_path_prefix,
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read data from Stage(ADLS) and Azure SQL table.
try:
    # Read BenefitTypeOccurrence from ADLS curated table
    ben_typ_occ_df = read_table_to_df(stg_ben_typ_occ_tbl_name).select(
        "BenefitTypeOccurenceKey",
        "CIGroupIdentifier",
        "BenefitSequence",
        "CIClassNumber",
        col("BenefitTypeSequenceNumber").cast("Int"),
        "BenTypeCode",
        "BenefitEffectiveDate",
        "BenefitENDDate",
        "BenCoverageID",
        lit("  ").alias("RiderOptNumber"),
    )

    # Read CustomerProduct from ADLS curated table
    cust_prd_df = (
        read_table_to_df(stg_cust_prd_tbl_name)
        .select("MemberCustomerNumber", "MemberGroupNumber", "CIClassNumber")
        .distinct()
    )

    # Read Provider from ADLS curated table
    ben_copay_df = read_table_to_df(stg_ben_copay_occ_tbl_name).select(
        "BenefitTypeOccurenceKey", "CopayTypeCode", "CopayAmount"
    )

    # Read ordr_header from ADLS curated table
    grdr_header_df = read_table_to_df(stg_grdr_header_tbl_name)

    # Read ordr_detail from ADLS curated table
    grdr_detail_df = read_table_to_df(stg_grdr_detail_tbl_name)

except Exception as e:
    excep = "Read data from Stage(ADLS): " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter Input data for latest 3 years
# Filter latest 3 years of data from CI
try:
    ben_typ_occ_df_dist = ben_typ_occ_df.select('CIGroupIdentifier','BenefitSequence','CIClassNumber','BenefitEffectiveDate').distinct()

    w = Window.partitionBy('CIGroupIdentifier','BenefitSequence','CIClassNumber')\
                .orderBy(col('BenefitEffectiveDate').desc())
                
    ben_typ_occ_df_fltr = (ben_typ_occ_df_dist.withColumn("rn", row_number().over(w))
        .filter(col("rn") <=3)
        .drop("rn")
    )
    #Join above dataframe back to BenefitTypeOccurance table to get all the columns:
    ben_typ_occ_df_final =  ben_typ_occ_df.alias('LH').join(
                            ben_typ_occ_df_fltr,['CIGroupIdentifier','BenefitSequence','CIClassNumber','BenefitEffectiveDate'],'inner')\
                            .select('LH.*')
except Exception as e:
    excep = "Filter latest 3 years of data failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if customer from BenefitTypeOccurrence is present in CustomerProduct table
try:
    # Check if customer from BenefitTypeOccurrence is present in CustomerProduct table:
    cond = (
        (col("LH.CIGroupIdentifier") == col("RH.MemberCustomerNumber"))
        & (col("LH.BenefitSequence") == col("RH.MemberGroupNumber"))
        & (col("LH.CIClassNumber") == col("RH.CIClassNumber"))
    )
    ben_type_occ_join_df = (
        ben_typ_occ_df_final.alias("LH")
        .join(cust_prd_df.alias("RH"), cond, "inner")
        .select("LH.*")
    )
except Exception as e:
    excep = "Check if customer from BenefitTypeOccurrence is present in CustomerProduct failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Split BenefitTypeOccurrence on the basis of RoderCode ('RX')
try:
  # Filter above BenefitTypeOccurrence final dataframe where BenTypeCode ='RX':
  ben_typ_occ_df_rx = ben_type_occ_join_df.filter(col('BenTypeCode')=='RX')

  # Take first occurance of each customer and benefitDate
  df_min = ben_typ_occ_df_rx.groupBy(
          "CIGroupIdentifier", "BenefitSequence", "CIClassNumber", "BenefitEffectiveDate"
      ).agg(min(col("BenefitTypeSequenceNumber")).alias("BenefitTypeSequenceNumber"))

  df_rx = ben_typ_occ_df_rx.alias('LH').join(df_min.alias('RH'),
                            ['CIGroupIdentifier','BenefitSequence','CIClassNumber','BenefitEffectiveDate','BenefitTypeSequenceNumber'],'inner').select('LH.*')

  # Filter BenefitTypeOccurrence final dataframe where BenTypeCode is not 'RX'
  ben_typ_occ_df_nonrx = ben_type_occ_join_df.select(
    "CIGroupIdentifier",
    "BenefitSequence",
    "CIClassNumber",
    "BenefitEffectiveDate",
    "BenTypeCode",
    "BenefitENDDate",
    "BenCoverageID",
    lit("  ").alias("RiderOptNumber")).filter(col("BenTypeCode") != "RX") 
except Exception as e:
  excep = "Split BenefitTypeOccurrence on the basis of RoderCode 'RX' failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,STEP1: Join BenefitTypeOccurence('RX') with BenefitCopay
try:
    df_join = (
        df_rx.alias("LH")
        .join(
            ben_copay_df.alias("RH"),
            col("LH.BenefitTypeOccurenceKey") == col("RH.BenefitTypeOccurenceKey"),"left"
        )
        .drop(col("LH.BenefitTypeOccurenceKey"))
    )
except Exception as e:
    excep = "Join BenefitTypeOccurence with BenefitCopay failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,STEP2: Get minimum non-zero CopayAmount and join with Step1 output
try:
    #Get minimum non-zero CopayAmount (If all values are 0 then put default value as 0)
    df_copay_amt_min = df_join.groupBy('BenefitTypeOccurenceKey').agg(
        when(
            count(when(col('CopayAmount') != 0,True)) == 0,lit(0))\
        .otherwise(
            when(
                min(when(col('CopayAmount') != 0, col('CopayAmount'))).isNull() , lit(0))\
                .otherwise(min(when(col('CopayAmount') != 0, col('CopayAmount')))
        )).alias('MinCopayAmt')
    )

    #Join above dataframe with Step1 output
    df_final = df_join.join(df_copay_amt_min,['BenefitTypeOccurenceKey'],'left')
except Exception as e:
    excep = "Get minimum non-zero CopayAmount and join with Step1 output failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Populate RxRiderGenKey and RxRiderBrdCopay
# Populate RxRiderGenKey and RxRiderBrdCopay
try: 
    df_ben_calc = df_final.withColumn("RxRiderGenCopay",when(col('CopayTypeCode').isin('G','F'),col('CopayAmount'))\
                                    .when(col('CopayTypeCode').isin('B','N'),lit(0))\
                                    .otherwise(col('MinCopayAmt')))\
                          .withColumn("RxRiderBrdCopay",when(col('CopayTypeCode').isin('B','N'),col('CopayAmount'))\
                                    .when(col('CopayTypeCode').isin('G','F'),lit(0)).otherwise(col('MinCopayAmt')))\
                                    .drop('MinCopayAmt','BenefitTypeOccurenceKey','CopayTypeCode','CopayAmount','BenefitTypeSequenceNumber')\
                                    .distinct()
except Exception as e:
    excep = 'Populate RxRiderGenKey and RxRiderBrdCopay failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Populate RxRiderGenKey and RxRiderBrdCopay for rider_type_code !='RX'
# Populate RxRiderGenKey and RxRiderBrdCopay for rider_type_code !='RX'
try: 
    df_non_rx = ben_typ_occ_df_nonrx.withColumn("RxRiderGenCopay",lit(0.0))\
                                  .withColumn("RxRiderBrdCopay",lit(0.0))
except Exception as e:
    excep = 'Populate RxRiderGenKey and RxRiderBrdCopay for nonRX rider_type_code failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Union of  RX and non RX typecodes data
#Union of RX and non RX typecodes dataframes
try:
    df_union = df_ben_calc.union(df_non_rx)
except Exception as e:
    excep = 'Union of RX and non RX typecodes dataframes failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column and datatype mapping dictionary
col_dtype_schema = {
'CIGroupIdentifier':'string'
,'BenefitSequence':'string'
,'CIClassNumber':'string'
,'BenTypeCode':'string'
,'BenefitEffectiveDate':'date'
,'BenefitENDDate':'date'
,'BenCoverageId':'string'
,'RiderOptNumber':'string'
,'RxRiderGenCopay':'decimal(20,6)'
,'RxRiderBrdCopay':'decimal(20,6)'
}

col_mapping = {
'CIGroupIdentifier':'GRDRCustomerNumber'
,'BenefitSequence':'GRDRGroupNumber'
,'CIClassNumber':'GRDRClassNumber'
,'BenTypeCode':'RiderCode'
,'BenefitEffectiveDate':'RiderStartDate'
,'BenefitENDDate':'RiderEndDate'
,'BenCoverageId':'RiderPlanNumber'
,'RiderOptNumber':'RiderOptNumber'
,'RxRiderGenCopay':'GenericCopayAmount'
,'RxRiderBrdCopay':'BrandCopayAmount'  
}

# COMMAND ----------

# DBTITLE 1,Column mapping and datatype conversion
try:
    dtype_trans_df = dtype_conversion(df_union, col_dtype_schema)
    final_col_map_df = col_name_mapping(dtype_trans_df, col_mapping)
except Exception as e:
    excep = "Column mapping and datatype conversion failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Column calculation.
try:
    # adding audit columns.
    curr_calc_df = final_col_map_df.selectExpr(
        "*",
        "md5(concat(GRDRCustomerNumber,GRDRGroupNumber,RiderStartDate,GRDRClassNumber)) as HashKey",
        "current_timestamp() as CreatedDateTime_hdr",
        "current_timestamp() as CreatedDateTime_dtl",
        f"'{PIPELINE_NAME}' as CreatedBy_hdr",
        f"'{PIPELINE_NAME}' as CreatedBy_dtl",
        "cast(null as timestamp)as ModifiedDateTime_hdr",
        "cast(null as timestamp)as ModifiedDateTime_dtl",
        "cast(null as string) as ModifiedBy_hdr",
        "cast(null as string) as ModifiedBy_dtl",
        "cast(null as string) as DerivedIndicator"
    )

except Exception as e:
    excep = "Column calculation failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join GRDR Header and Detail table
# Join GRDRHeader and MemberGRDRDetail table and select required columns:
try:   
    grdr_hdr_detail_df=grdr_header_df.alias("LH").join(grdr_detail_df.alias("RH"),(col("LH.MemberGRDRHeaderKey")==col("RH.MemberGRDRHeaderKey")),"left").select("LH.*",
    "RH.MemberGRDRDetailKey",
    "RH.RiderCode",
    "RH.RiderPlanNumber",
    "RH.RiderOptNumber",
    "RH.BrandCopayAmount",
    "RH.GenericCopayAmount",
    "RH.RiderStartDate",
    "RH.RiderEndDate",
    col("LH.CreatedDateTime").alias("CreatedDateTime_hdr"),
    col("LH.ModifiedBy").alias("ModifiedBy_hdr"),
    col("LH.CreatedBy").alias("CreatedBy_hdr"),
    col("LH.ModifiedDateTime").alias("ModifiedDateTime_hdr"),
    col("RH.CreatedBy").alias("CreatedBy_dtl"),
    col("RH.CreatedDateTime").alias("CreatedDateTime_dtl"),
    col("RH.ModifiedBy").alias("ModifiedBy_dtl"),
    col("RH.ModifiedDateTime").alias("ModifiedDateTime_dtl")
    )\
    .drop("MemberGRDRHeaderKey","DerivedIndicator","ModifiedBy","CreatedDateTime","ModifiedDateTime","CreatedBy","CiClsNbr",'RegrdrGenKey')
except Exception as e:
    excep = "Join GRDRHeader and MemberGRDRDetail table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create Hashkey using md5 function
try:
    #Create Hashkey using md5 function
    grdr_hdr_detail_df_final=grdr_hdr_detail_df.withColumn("HashKey",md5(concat((col("GRDRCustomerNumber")),(col("GRDRGroupNumber")),(col("RiderStartDate")),(col('GRDRClassNumber'))))).withColumn("DerivedIndicator",lit(''))
except Exception as e:
    excep = "Creation of  Hashkey failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Select latest 3 years of data from GRDR Header and Detail joined table
# Select the same 3 years of data from grdr table by joining it with filtered data of BenefitTypeOccurance (ben_typ_occ_df_fltr)
# To be used in Delete scenario
try:
    cond = (col('LH.GRDRCustomerNumber')==col('CIGroupIdentifier'))&(col('LH.GRDRGroupNumber')==col('BenefitSequence'))&(col('LH.GRDRGroupNumber')==col('BenefitSequence'))&(col('LH.GRDRClassNumber')==col('CIClassNumber'))&(col('RiderStartDate')==col('BenefitEffectiveDate'))
    
    grdr_hdr_detail_df_dlt = grdr_hdr_detail_df_final.alias('LH').join(ben_typ_occ_df_fltr,cond,'inner').select('LH.*')
except Exception as e:
    excep = "Selecting 3 years of data from grdr table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Function to getting column select list.
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Identify INSERT and Update records
try:
    # Create Column list. Which is used for processing.
    new_col_slt_lst = grdr_hdr_detail_df_final.columns
    col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(
        new_col_slt_lst
    )

    # Add suffix 'Old' to column name for existing data to avoid column ambiguous.
    old_renamed_df = grdr_hdr_detail_df_final.selectExpr(*col_select_lst)

    # Join previous day with current day data to identify delta data.
    old_joined_df = curr_calc_df.alias("LH").join(old_renamed_df.alias("RH"),(col("LH.HashKey") == col("RH.OldHashKey"))
                                        & (col("RiderCode")==col("OldRiderCode")) & (col("RiderPlanNumber")==(col("OldRiderPlanNumber"))), "left").selectExpr("*","OldMemberGRDRDetailKey as MemberGRDRDetailKey")                            
    ins_df = old_joined_df\
            .filter((col('OldHashKey').isNull()))\
            .withColumn('DerivedIndicator', lit('INSERT'))\
            .drop(*col_drop_lst)
            
    upds_df = old_joined_df\
            .filter((col('OldHashKey').isNotNull()))\
            .withColumn("DerivedIndicator",when((col("RiderPlanNumber").eqNullSafe(col("OldRiderPlanNumber")))
            & (col("GenericCopayAmount").eqNullSafe(col("OldGenericCopayAmount")))
            & (col("RiderEndDate").eqNullSafe(col("OldRiderEndDate")))
            & (col("BrandCopayAmount").eqNullSafe(col("OldBrandCopayAmount"))),
            lit("IGNORE"),
            ).otherwise(lit("UPDATE")))

    # Calculate ModifiedBy and ModifiedDateTime.
    # If it is update set the modifiedDateTime as current timestamp and modifiedBy as task name.
    col_maps = {
        "ModifiedDateTime_hdr": when(col("DerivedIndicator") == "UPDATE", lit(current_timestamp()))\
                                    .otherwise(col("OldModifiedDateTime_hdr")),
        "ModifiedBy_hdr": when(col("DerivedIndicator") == "UPDATE", lit(PIPELINE_NAME))\
                                    .otherwise(col("OldModifiedBy_hdr")),
        "CreatedBy_hdr": col("OldCreatedBy_hdr"),
        "CreatedDateTime_hdr": col("OldCreatedDateTime_hdr"),
        "ModifiedDateTime_dtl": when(col("DerivedIndicator") == "UPDATE", lit(current_timestamp()))\
                                    .otherwise(col("OldModifiedDateTime_dtl")),
        "ModifiedBy_dtl": when(col("DerivedIndicator") == "UPDATE", lit(PIPELINE_NAME))\
                            .otherwise(col("OldModifiedBy_dtl")),
        "CreatedBy_dtl": col("OldCreatedBy_dtl"),
        "CreatedDateTime_dtl": col("OldCreatedDateTime_dtl"),
    }

    calc_audit_col_upds_df = (
        upds_df.withColumns(col_maps)
        .drop("OldCreatedDateTime_hdr","OldModifiedBy_hdr","OldCreatedBy_hdr"
                ,"OldModifiedDateTime_hdr","OldCreatedDateTime_dtl","OldModifiedBy_dtl","OldCreatedBy_dtl","OldModifiedDateTime_dtl")
        .select(*new_col_slt_lst)
    )

except Exception as e:
    excep = "Identify Delta record failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Identify Delete records
try:
#DELETE1 - Deleting according to below condition:
# •	For particular Customer + RiderCode, if records are missing between the 3 year window in CI file, then will Delete it 

    #Creating Minimum effective date and max eff date columns
    df_ci_min_max = curr_calc_df.groupBy('GRDRCustomerNumber','GRDRGroupNumber','GRDRClassNumber','RiderCode')\
                    .agg(min(col('RiderStartDate')).alias('minEffDt'),max(col('RiderStartDate')).alias('maxEffDt'))

    cond2 = ((col("LH.OldGRDRCustomerNumber") == col("RH.GRDRCustomerNumber"))
                &(col('LH.OldGRDRGroupNumber') == col("RH.GRDRGroupNumber"))\
                &(col('LH.OldGRDRClassNumber') == col("RH.GRDRClassNumber")) 
                & (col('LH.OldRiderCode') == col("RH.RiderCode"))
                & (col('LH.OldRiderStartDate') >= col('RH.minEffDt')) 
                & (col('LH.OldRiderStartDate') <= col('RH.maxEffDt')))

    old_joined_df_delete_1 = old_renamed_df.alias("LH")\
                            .join(df_ci_min_max.alias("RH"),(cond2),"inner")\
                            .selectExpr('LH.*')

    cond3 = ((col("LH.OldHashKey") == col("RH.HashKey")) 
            & (col('LH.OldRiderCode') == col("RH.RiderCode")))

    
    del_ignr_df = old_joined_df_delete_1.alias("LH")\
                    .join(curr_calc_df.alias("RH"),(cond3),"left")\
                    .selectExpr('LH.*', 'RH.HashKey')\
                    .withColumn('OldDerivedIndicator', when(col('RH.HashKey').isNull(), 'DELETE'))\
                    .drop('HashKey')
                    
    rename_col_name_del_df = del_ignr_df\
                        .filter(col('OldDerivedIndicator').isNotNull())\
                        .selectExpr(*del_col_sel_lst)


    # Union Insert, Delete and Update dataframe.
    calc_df = ins_df.unionByName(rename_col_name_del_df).unionByName(calc_audit_col_upds_df).distinct()

# DELETE2 - To handle Delete and Insert (Update) scenario-
# If a (customer+ EffDate + RiderCode) gets new plan number in CI, then this will be inserted and corresponding existing database record will be deleted:
    cond4 = ((col("LH.HashKey") == col("RH.HashKey"))
                &(col('LH.RiderCode') == col("RH.RiderCode"))\
                &(col('LH.RiderPlanNumber') == col("RH.RiderPlanNumber"))
                & (col('RH.DerivedIndicator')=='IGNORE'))
    calc_df_anti = grdr_hdr_detail_df_dlt.alias('LH').join(calc_df.alias('RH'),cond4,'left_anti')
    calc_df_del = calc_df_anti.alias('LH').join(calc_df.alias('RH'),['HashKey','RiderCode'],'inner').filter(col('RH.DerivedIndicator')=='INSERT').select('LH.*').withColumn('DerivedIndicator',lit('DELETE'))

    calc_df_final = calc_df.unionByName(calc_df_del)
                 

    write_df_as_delta_table(calc_df_final, cur_tbl_name, mode = 'overwrite')

except Exception as e:
    excep = "Identify Delete records and failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to Azure SQL stage table MemberGRDRHeader
try:  
  # Read data from the curated table and filter only the Insert, Update and Delete records.
  hdr_df = spark.read.table(cur_tbl_name)\
              .filter(col('DerivedIndicator').isin(['INSERT']))\
              .selectExpr(
                  'GRDRCustomerNumber','GRDRGroupNumber','GRDRClassNumber','DerivedIndicator',
                  'CreatedBy_hdr as CreatedBy',
                  'CreatedDateTime_hdr as CreatedDateTime',
                  'ModifiedDateTime_hdr as ModifiedDateTime',
                  'ModifiedBy_hdr as ModifiedBy',
                  'cast(null as string) as DeltaStatus',
                  'cast(null as BigInt) as MemberGRDRHeaderKey', 
                  'cast(null as string) as ProcessName')
                       
  # To add the new customers coming from CI (BenefitTypeOccurance), we are ignoring existing customers from the SF GRDRHeader table
  # The DerivedIndicator for INSERT is mainly calculated for GRDRDetail table, that's why we are doing anti-join to avoid duplicate INSERT
  hdr_df_final = hdr_df.join(grdr_header_df,['GRDRCustomerNumber','GRDRGroupNumber','GRDRClassNumber'],'left_anti').distinct()

  # Convert the nullable values of the columns to match Azure SQL schema.
  hdr_upd_col_nullable_df = set_df_columns_not_nullable(spark, hdr_df_final, ['CreatedBy', 'CreatedDateTime'], nullable=False)

  # Load the data to azure sql stage table.
  load_df_to_sf_sql_db_spark(hdr_upd_col_nullable_df, 'Member.StageDBPMemberGRDRHeader')
    
except Exception as e:
  excep = 'Write processed data to Azure SQL StageDBPMemberGRDRHeader table failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to Azure SQL stage table MemberGRDRDetail
try:
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    dtl_df = spark.read.table(cur_tbl_name)\
                .filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE','DELETE']))\
                .selectExpr(
                    '*', 
                    'CreatedBy_dtl as CreatedBy',
                    'CreatedDateTime_dtl as CreatedDateTime',
                    'ModifiedDateTime_dtl as ModifiedDateTime',
                    'ModifiedBy_dtl as ModifiedBy',
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as MemberGRDRHeaderKey',
                    'cast(null as string) as ProcessName')\
                        .distinct()\
                .drop('CreatedBy_hdr', 'HashKey','ModifiedDateTime_hdr','ModifiedBy_hdr','CreatedDateTime_hdr','CreatedBy_dtl','ModifiedDateTime_dtl','ModifiedBy_dtl','CreatedDateTime_dtl','RegrdrGenKey')

    # Convert the nullable values of the columns to match Azure SQL schema.
    dtl_upd_col_nullable_df = set_df_columns_not_nullable(spark, dtl_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(dtl_upd_col_nullable_df, 'Member.StageDBPMemberGRDRDetail')
except Exception as e:
    excep = 'Write processed data to Azure SQL StageDBPMemberGRDRDetail table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
output = {
      'NOTEBOOK_RUN_STATUS' : 'Success'
}
dbutils.notebook.exit(json.dumps(output))
# Databricks notebook source
# MAGIC %md 
# MAGIC This process is a part of Customer feed and Coverage. The present notebook is used for the archival process of the whole CI CUSTOMER data including the delta records into CICustomer table.
# MAGIC
# MAGIC ##### Source File 
# MAGIC - CI_CUSTOMER
# MAGIC ##### Stage Table
# MAGIC - Member.StageCICustomer
# MAGIC ##### Target/Curated Table
# MAGIC - Member.CICustomer
# MAGIC ##### Business Keys
# MAGIC - 'CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate'
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "CI_CUSTOMER_STAGE"
buz_keys = ['CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate']

table_code='Member_CICustomer'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','FullLoad')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./CIStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing Environment Variable
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Select required table names
try:
  conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
  tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
  stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
  cur_tbl_name = table_name_selector(tbl_conf_df, table_code) 
except Exception as e:
    raise Exception("table configuration failed: ",str(e))


# COMMAND ----------

# DBTITLE 1,Loading data into Stage table 
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, ci_customer_schema, buz_keys)
except Exception as e:
    raise Exception("main function failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Function to load delta records
def delta_operation(cur_tbl_name,stage_tbl_name):

    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)

    dfall= read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')

    dfUpd =dfall.filter(dfall.DerivedIndicator.isin(["UPDATE","INSERT","DELETE"]))

    joinCols = ['CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate']

    dfCurCiCust = read_table_to_df(cur_tbl_name)
    withCols1 = {
        'ModifiedBy': lit(f'{PIPELINE_NAME}'),
        'ModifiedDateTime': current_timestamp()
    }
    dfUpdates1 = dfUpd.alias('LH').join(dfCurCiCust.alias('RH'), joinCols, "inner")\
        .selectExpr('LH.*','RH.CreatedBy','RH.CreatedDateTime')
    dfUpdates1 = dfUpdates1.withColumns(withCols1)

    withCol2 = {
        'CreatedBy': lit(f'{PIPELINE_NAME}'),
        'CreatedDateTime': current_timestamp(),
        'ModifiedBy': lit(None),
        'ModifiedDateTime': lit(None)
    }
    dfUpdates2 = dfUpd.alias('LH').join(dfCurCiCust.alias('RH'), joinCols, "leftanti")
    dfUpdates2 = dfUpdates2.withColumns(withCol2)

    dfUpdates = dfUpdates1.union(dfUpdates2)

    deltaTableCurated.alias('Curated')\
        .merge(
            dfUpdates.alias('Stage'),
            'Curated.CiGrpId = Stage.CiGrpId AND Curated.GrpNbrBen = Stage.GrpNbrBen AND Curated.CiClsNbr = Stage.CiClsNbr AND Curated.BenDtlEffDate = Stage.BenDtlEffDate')\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
    
    deltaTableCurated.delete(condition= "DerivedIndicator='DELETE'")

# COMMAND ----------

# DBTITLE 1,Load data based on LOAD_TYPE
#If it is full load we will be overwrite data to customer table.
try:
    if LOAD_TYPE == 'FullLoad':
        
        #Reading data from stage table where Status is 'S'
        ci_customer_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')

        # Converting column names according to doamin tables and adding audit columns to dataframe
        col_mapped_df = add_tgt_audit_column(ci_customer_stage_df, PIPELINE_NAME,LOAD_TYPE)

        #Insert Full data into Curated table
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":'Member_CICustomer'})
        write_to_curated(col_mapped_df,cur_tbl_name)
        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        delta_operation(cur_tbl_name,stage_tbl_name)
        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
except Exception as e:
    raise Exception("Please check the load_type. Its not valid", str(e))

# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Below are the major features involved in the membership process:
# MAGIC - Queue preparation
# MAGIC - Customer conversion (GH to CI)
# MAGIC - Customer product validation
# MAGIC - Member validation
# MAGIC - Member coverage overlap
# MAGIC - Provider calculation for PPO
# MAGIC - Provider validation
# MAGIC - Customer product split
# MAGIC - Provider contract assignment
# MAGIC - Load processed to SQL table.
# MAGIC - Archive processed data to history table
# MAGIC - Report creation(Error / Success)
# MAGIC ###### Source details (Inbound Files):
# MAGIC - IN_GH_REGX165_CCYYMMDD.TXT
# MAGIC - IN_GH671_SERV_FUND_CCYYMMDD.TXT
# MAGIC
# MAGIC ###### Stage and main Tables used by the process:
# MAGIC
# MAGIC - provider_main_dev_000.mainframe_servicefund.Member_Customer
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageCustomerProduct,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMember,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMemberCoverage,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Provider_StageProvider,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProduct,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContract,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContractProductAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAssociation
# MAGIC
# MAGIC ###### Intermediate table details
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_MemberCoverageAdjustment
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_MemberCoverageCustomerProductSplit
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_MemberCoverageProcessed
# MAGIC
# MAGIC ###### Target details (Azure SQL Stage table):
# MAGIC - Member.StageDBPMemberCoverage
# MAGIC
# MAGIC ###### Report details:
# MAGIC - MemberCoverageError{CurrentTimestamp}.txt
# MAGIC - MemberCoverageSuccess{CurrentTimestamp}.txt
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper Notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest Notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load Notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import MemberCoverage Notebook
# MAGIC %run ../../Utility/MemberCoverage

# COMMAND ----------

# DBTITLE 1,Import Necessary Libraries
from pyspark.sql.functions import input_file_name, current_date, current_timestamp, lit, col, row_number, lpad, sha1, concat_ws, lag,lead
from delta.tables import DeltaTable
from pyspark.sql.window import Window
from delta.tables import *
from datetime import datetime
import json

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# DBTITLE 1,Parameter Cell.
dbutils.widgets.text('JOB_NAME','')
dbutils.widgets.text('PIPELINE_NAME','')
dbutils.widgets.text('PIPELINE_RUN_ID','')
dbutils.widgets.text('RERUN', '')
dbutils.widgets.text('INBOUND_TYPE', '')
dbutils.widgets.text('JOB_TYPE', '')

JOB_NAME = dbutils.widgets.get('JOB_NAME')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')
INBOUND_TYPE = dbutils.widgets.get('INBOUND_TYPE')
RERUN = dbutils.widgets.get('RERUN')
JOB_TYPE = dbutils.widgets.get('JOB_TYPE')
audit_start_date_time = datetime.now()
job_type = JOB_TYPE
process_name = "DBP#" + job_type + "#" + JOB_NAME + "#" + INBOUND_TYPE
audit_name = "DBP#" + job_type + "#" + PIPELINE_NAME + "#" + INBOUND_TYPE
job_name = JOB_NAME + "#" + INBOUND_TYPE

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read File Config.
# Fixed width function to save output file in csv format for GG processe
try:
    config_dict = get_file_config(file_conf_path)
except Exception as e:
    excep = 'Reading file config failed: ' + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    # Default Config
    default_config = config_dict["DEFAULT"]
    default_in_config = default_config["Inbound"]
    default_out_config = default_config["Outbound"]
    mem_cov_config = config_dict[JOB_NAME]

    file_path_prefix = default_out_config["FilePathPrefix"]
    proc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    outbnd_temp_err_path_suffix = mem_cov_config["Outbound"]["TempFileErrorPathSuffix"]
    outbnd_temp_success_path_suffix = mem_cov_config["Outbound"]["TempFileSuccessPathSuffix"]
    in_file_path_suffix = default_in_config["FilePathSuffix"]
    container_name = default_config["ContainerName"]
    # Inbound file names.
    gh671_file_name = mem_cov_config["Inbound"]["GH671FileName"]
    gx165_file_name = mem_cov_config["Inbound"]["GHREGX165FileName"]
    prodrev_file_name = mem_cov_config["Inbound"]["ProdrevFileName"]
    re00017_file_name = mem_cov_config["Inbound"]["Re0007FileName"]
    # Stage tables used by the process.
    raw_tbl_name = mem_cov_config["Inbound"]["RawTableName"]
    stage_tbl_name = mem_cov_config["Inbound"]["StageTableName"]
    history_tbl_name = mem_cov_config["Inbound"]["HistoryTableName"]
    audit_table_name = default_config["AuditTableName"]
    mem_cov_adj_table_name = mem_cov_config["Inbound"]["MemberCoverageSplit"]
    mem_cov_proc_table_name = mem_cov_config["Inbound"]["MemberCoverageProcessed"]
    cust_prd_split_table_name = mem_cov_config["Inbound"]["CustomerProductSplit"]
    prodrev_stage_table_name = mem_cov_config["Inbound"]["StageProdrev"]
    # Member stage tables.
    customer_tbl_name = mem_cov_config["Inbound"]["Customer"]
    customer_product_tbl_name = mem_cov_config["Inbound"]["StageCustomerProduct"]
    member_table_name = mem_cov_config["Inbound"]["StageMember"]
    mem_cov_table_name = mem_cov_config["Inbound"]["StageMemberCoverage"]
    # Provider stage table.
    provider_table_name = mem_cov_config["Inbound"]["StageProvider"]
    # Provider Contract stage Table.
    pc_table_name  = mem_cov_config["Inbound"]["StageProviderContract"]
    pc_prd_affil_table_name  = mem_cov_config["Inbound"]["StageProviderContractProductAffiliation"]
    # Product stage tables.
    prod_table_name = mem_cov_config["Inbound"]["StageProduct"]
    pc_prd_set_affil_table_name  = mem_cov_config["Inbound"]["StageProductSetAffiliation"]
    pc_prd_set_asso_table_name  = mem_cov_config["Inbound"]["StageProductSetAssociation"]
    mem_cov_sql_tbl_name = mem_cov_config["Outbound"]['MemberCoverageSqlTable']
    if INBOUND_TYPE == 'MemberCoverageDelta':
        err_file_name = mem_cov_config["Outbound"]["ErrorFileName"]
        success_file_name = mem_cov_config["Outbound"]["SuccessFileName"]
    elif INBOUND_TYPE == 'CustomerCoverageDelta':
        err_file_name = mem_cov_config["Outbound"]["CustomerDeltaErrorFileName"]
        success_file_name = mem_cov_config["Outbound"]["CustomerDeltaSuccessFileName"]
    sync_process_names = mem_cov_config["Inbound"]["StageSyncDependencyProcess"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Validate last run
# We don't have any date or timestamp values in the file name. So, to handle the pipeline failure, we added the rerun parameter. The value can be 1 or 0.
# If the value is 0, we are validating the last-run status. If the last run is successful, we will proceed with the current run. If the last run status is failure, we will fail the current run.
# If the value is 1, we are not considering the last run. We will proceed with the current run.
try:
    audit_tbl_df = read_table_to_df(audit_table_name)\
                    .filter(col('ProcessName') == process_name)
    if audit_tbl_df.count() > 0 and int(RERUN) == 0:
        last_run_status = audit_tbl_df\
                        .orderBy(col('StartDateTime').desc())\
                        .select('Status').collect()[0][0]
        if last_run_status != 'Success':
            raise Exception("Previous run encountered a failure")
    else:
        pass
except Exception as e:
    excep = "Unable to proceed with the execution as the previous attempt encountered a failure. To retry the pipeline for the same file Provide the value of 1 for the RERUN parameter."
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# Check, Is table already present in catalog
if spark.catalog.tableExists(stage_tbl_name):
    # Get the version number
    stg_tbl_delta_hist_df = spark.sql(f"DESCRIBE HISTORY {stage_tbl_name} LIMIT 1")
    stg_hist_version_num = stg_tbl_delta_hist_df.select('version').collect()[0][0]
else:
    # Set version number to -1
    stg_hist_version_num = -1

# COMMAND ----------

def handle_member_coverage_exception(run_id, module, job_name, job_type,start_date_time, status ,audit_table_name, error_message,version_num, stage_table_name):
    try:
        if version_num > -1:
            time_travel_to_specific_delta_version(version_num, stage_table_name)
        insert_entry_to_audit_table(run_id, module, job_name, job_type, start_date_time, status ,audit_table_name, error_message)
    except Exception as e:
        raise Exception("handle_member_coverage_exception failed:", str(e))

def update_record_to_queue(src_df, stage_tbl_name, set_dict, inbound_type):
    '''
        Description:
        This function is used to update StageMemberCoverageQueue only when IsProcessed is null.
        :param src_df: [Type: pyspark.sql.dataframe.Dataframe] source data.
        :param stage_tbl_name: [Type: String] Stage table name(StageMemberCoverageQueue).
        :param set_dict: [Type: Dictionary] Columns to update.
    '''
    try:
        stg_mem_cov_table = DeltaTable.forName(spark, stage_tbl_name)
        updates_df = src_df

        stg_mem_cov_table.alias('coverage') \
        .merge(
            updates_df.alias('updates'),
            "coverage.Id = updates.Id") \
        .whenMatchedUpdate(
            condition = f"coverage.IsProcessed IS NULL AND coverage.InboundType = '{inbound_type}'",
            set = set_dict) \
        .execute()

    except Exception as e:
        raise Exception("update_invalid_record_to_queue failed:", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest data to raw table.

# COMMAND ----------

# DBTITLE 1,ADLS path creation and load data to raw table.
try:
    inbnd_base_path = abfss_path_builder(container_name, storage_account, in_file_path_suffix)
    outbnd_temp_err_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_err_path_suffix)
    outbnd_temp_success_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_success_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)

    if INBOUND_TYPE == 'MemberCoverageDelta':
        # Create abffs path for inbound files.
        gh671_inbnd_file_path = f"{inbnd_base_path}{gh671_file_name}"
        gx165_inbnd_file_path = f"{inbnd_base_path}{gx165_file_name}"
        prodrev_inbnd_file_path = f"{inbnd_base_path}{prodrev_file_name}"

        # Read gh671 and gx165 text file from ADLS.
        gh671_raw_df = read_inbound_csv_file(gh671_inbnd_file_path)
        gx165_raw_df = read_inbound_csv_file(gx165_inbnd_file_path)

        # Combine both the files and add audit columns.
        raw_df = gh671_raw_df.unionByName(gx165_raw_df)
        
    elif INBOUND_TYPE == 'CustomerCoverageDelta':
        # Create abffs path for inbound files.
        re00017_inbnd_file_path = f"{inbnd_base_path}{re00017_file_name}"
        # Read RE0007 text file from ADLS.
        raw_df = read_inbound_csv_file(re00017_inbnd_file_path)

    # Add audit columns.
    raw_audit_cols_df = raw_df\
                .selectExpr(
                    f"'{PIPELINE_RUN_ID}' as RUN_ID", 
                    "*",
                    f"'{INBOUND_TYPE}' AS INBOUND_TYPE",
                    "current_date() as LOAD_DATE", 
                    "current_timestamp() as LOAD_TIMESTAMP",
                    "_metadata.file_name as FILE_NAME")
                
    # Write as managed delta table.
    write_df_as_delta_table(raw_audit_cols_df, raw_tbl_name)

    # Remove unused data files.
    raw_delta_table = DeltaTable.forName(spark, raw_tbl_name)
    raw_delta_table.vacuum(0)

except Exception as e:
    excep = 'ADLS path creation and load data to raw table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Queue

# COMMAND ----------

# DBTITLE 1,Datatype mapping.
# Business key
buz_keys = ['ReenrchgPcaFinRptLedgrNbr','ReenrchgMbrEnrlCustNbr','ReenrchgMbrpid', 'ReenrchgSubpid','ReenrchgMbrProvEffCymd']

# Schema definition.
member_coverage_stage_schema = {
    'REENRCHG_PCA_FIN_RPT_LEDGR_NBR' : "string",
    'REENRCHG_MBR_ENRL_CUST_NBR' : "string",
    'REENRCHG_MBR_ENRL_GRP_NBR' : "string",
    'REENRCHG_MBRPID' : "string",
    'REENRCHG_SUBPID' : "string",
    'REENRCHG_GK_PROV_ID_NBR' : "integer",
    'REENRCHG_GK_PROV_SUFF_CD' : "string",
    'REENRCHG_GK_PROV_TY_CD' : "string",
    'REENRCHG_MBR_PROV_EFF_CYMD' : "date",
    'REENRCHG_MBR_PROV_END_CYMD' : "date",
    'REENRCHG_PROCESS_AGAIN_COUNTER' : "integer",
    'REENRCHG_WORKCMP_OCCUR_P_ID' : "Decimal(20,6)",
    'REENRCHG_PREV_PCP_END_REAS_CD' : "string",
    'REENRCHG_CURR_PCP_END_REAS_CD' : "string",
    'REENRCHG_PCP_REASON_INDICATOR' : "string",
    'RUN_ID' : "string",
    'INBOUND_TYPE' : "string"
}

prodrev_stage_schema = {
    'RETBVSDT_TABLE_ID'  : "string"
    ,'RETBVSDT_ENTRY_ID' : "string"
    ,'RETBVSDT_STATUS' : "string"
    ,'RETBVSDT_SHORT_AREA' : "string"
    ,'RETBVSDT_LONG_AREA' : "string"
    ,'RETBVSDT_EFF_CYMD' : "integer"
    ,'RETBVSDT_LAST_CHG_CYMD' : "integer"
    ,'RETBVSDT_ID' : 'string'
}

# COMMAND ----------

# DBTITLE 1,Functions
def identify_duplicates_records(df):
    '''
    Description:
    This function is used to identify and create seperate dataframe for duplicates records..
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :returns dup_df, cleansed_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        colms = df.columns
        colms.remove('ReenrchgCurrPcpEndReasCd')
        window_spec = Window.partitionBy(*colms).orderBy(lit(1))
        df = df.withColumn('RN', row_number().over(window_spec))
        dup_df = df.filter(col('RN') > 1).drop('RN')
        cleansed_df =  df.filter(col('RN') == 1).drop('RN')
        return dup_df, cleansed_df
    except Exception as e:
        raise Exception("identify_duplicates_records failed:" + str(e))


def check_overlap_dates_for_input_transaction(df):
    '''
    Description:
    This function is used to identify duplicate records based on business key and create seperate dataframe for duplicates records..
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param buz_keys: [Type: list].
    :returns dup_df, cleansed_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        # Define window specification
        window_spec = Window.partitionBy('ReenrchgPcaFinRptLedgrNbr','ReenrchgMbrEnrlCustNbr','ReenrchgMbrpid', 'ReenrchgSubpid').orderBy("ReenrchgMbrProvEffCymd", "ReenrchgMbrProvEndCymd")

        # Find the previous end date for each row
        df = df.withColumn("PrevEndDate", lag("ReenrchgMbrProvEndCymd").over(window_spec))\
                .withColumn("AfterStartDate", lead("ReenrchgMbrProvEffCymd").over(window_spec))
        # Check for overlapping date
        df = df.withColumn("OverlapPrev", when((col("ReenrchgMbrProvEffCymd") <= col("PrevEndDate")) & (col("ReenrchgMbrProvEndCymd") >= col("PrevEndDate")), lit(1)).otherwise(lit(0)))\
            .withColumn("OverlapAfter", when((col("ReenrchgMbrProvEffCymd") <= col("AfterStartDate")) & (col("ReenrchgMbrProvEndCymd") >= col("AfterStartDate")), lit(1)).otherwise(lit(0))).drop('PrevEndDate', 'AfterStartDate')
        # Define window specification
        dup_df = df.filter((col('OverlapAfter') == 1) | (col('OverlapPrev') == 1)).drop('OverlapAfter','OverlapPrev')
        cleansed_df = df.filter((col('OverlapAfter') == 0) & (col('OverlapPrev') == 0)).drop('OverlapAfter','OverlapPrev')
        return dup_df, cleansed_df
    except Exception as e:
        raise Exception("identify_duplicates_records_on_buz_keys failed:" + str(e))

def find_records_enddate_before_effectivedate(df):
    ''' 
    Description:
    This function is used to identify error records when end date is before than the effective date.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :returns filtered_invalid_dates_df, cleansed_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        filtered_invalid_dates_df = df.filter(col('ReenrchgMbrProvEffCymd') > col('ReenrchgMbrProvEndCymd'))
        cleansed_df = df.filter(col('ReenrchgMbrProvEffCymd') <= col('ReenrchgMbrProvEndCymd'))
        return filtered_invalid_dates_df, cleansed_df
    except Exception as e:
        raise Exception("find_records_enddate_before_effectivedate failed:" + str(e))

def apply_custom_scd_type(src_df, stage_tbl_name, valid_set_dict, rej_set_set, inbound_type):
    '''
        Description:
        This function is used to update StageMemberCoverageQueue only when IsProcessed is null.
        :param src_df: [Type: pyspark.sql.dataframe.Dataframe] source data.
        :param stage_tbl_name: [Type: String] Stage table name(StageMemberCoverageQueue).
        :param valid_set_dict: [Type: Dictionary] Columns to update for valid records.
        :param rej_set_set: [Type: Dictionary] Columns to update for rejected records.
    '''
    try:
        stg_mem_cov_table = DeltaTable.forName(spark, stage_tbl_name)
        updates_df = src_df

        stg_mem_cov_table.alias('coverage') \
        .merge(
            updates_df.alias('updates'),
            "coverage.Id = updates.Id") \
        .whenMatchedUpdate(
            condition = f"coverage.IsProcessed is null and updates.IsRejected = 'N' and coverage.InboundType = '{inbound_type}'",
            set = valid_set_dict) \
        .whenMatchedUpdate(
            condition = f"coverage.IsProcessed is null and updates.IsRejected = 'Y' and coverage.InboundType = '{inbound_type}'",
            set = rej_set_set) \
        .execute()

    except Exception as e:
        raise Exception("apply_custom_scd_type failed:", str(e))


def create_select_list(colms):
    col_list = []
    for colm in colms:
        col_list.append(f"{colm} AS Old{colm}")
    return col_list

def delete_data_from_table(table_name, delete_condition):
    delta_table = DeltaTable.forName(spark, table_name)
    deltaTable.delete(delete_condition)

# Adding audit columns for invalid record dataframe.
def add_columns_for_invalid_records(df, inbound_type, comment = 'Invalid Record', error_code = 'E999'):
    try:
        col_map = {                
            "CIGroupIdentifier" : lit(None).cast("string"),
            "CIClassNumber" : lit(None).cast("string"),
            "BenefitSequence" : lit(None).cast("string"),
            "IsProcessed" : lit("Y"),
            "ProcessedDate" : current_date(),
            "LoadDate" : current_date(),
            "LastReceivedDate" : lit(None).cast('date'),
            "ErrorCode" : lit(error_code),
            "Comment" : lit(comment),
            "CreatedDateTime" : current_timestamp(),
            "CreatedBy" : lit(PIPELINE_NAME),
            "ModifiedDateTime" : current_timestamp(),
            "ModifiedBy" : lit(PIPELINE_NAME)
        }
      
        col_added_df = df.withColumns(col_map)
        return col_added_df
    except Exception as e:
        raise Exception("add_columns_for_invalid_records failed:" + str(e))

def left_anti_or_semi_join(left_df, right_df, join_cond_type, join_type):
    if join_cond_type == 'Type1':
        join_condition = ['CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber', 'MemberId', 'SubscriberId']
    elif join_cond_type == 'Type2':
        join_condition = ['Id']
    elif join_cond_type == 'Type3':
        join_condition = ['NewDistId']
    else:
        raise Exception('Invalid Join Condition Type')
    df = left_df.join(right_df, join_condition, join_type)
    return df


# COMMAND ----------

# DBTITLE 1,Ingest Prodrev to stage table.
try:
    if INBOUND_TYPE == 'MemberCoverageDelta':
        prodrev_raw_df = read_inbound_csv_file(prodrev_inbnd_file_path)
        # Remove leading and trailing spaces of all column values.
        prodrev_removed_space_df = trim_leading_trailing_space(prodrev_raw_df)
        # Convert data type.
        prodrev_dtype_trans_df = data_type_conversion(prodrev_removed_space_df, prodrev_stage_schema)\
                                .selectExpr(
                                    f"'{PIPELINE_RUN_ID}' as RunId", 
                                    "*",
                                    "current_date() as LoadDate", 
                                    "current_timestamp() as LoadTimestamp",
                                    "_metadata.file_name as FileName")
        write_df_as_delta_table(prodrev_dtype_trans_df, prodrev_stage_table_name)
except Exception as e:
    excep = 'Ingest Prodrev to stage table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Data Validation
try:

  cleansed_recs_col_map = {
      "CIGroupIdentifier" : lit(None).cast("string"),
      "CIClassNumber" : lit(None).cast("string"),
      "BenefitSequence" : lit(None).cast("string"),
      "IsProcessed" : lit(None).cast("string"),
      "ProcessedDate" : lit(None).cast("date"),
      "LoadDate" : current_date(),
      "LastReceivedDate" : lit(None).cast("date"),
      "ErrorCode" : lit(None).cast("string"),
      "Comment" : lit(None).cast("string"),
      "CreatedDateTime" : current_timestamp(),
      "CreatedBy" : lit(PIPELINE_NAME),
      "ModifiedDateTime" : lit(None).cast("timestamp"),
      "ModifiedBy" : lit(None).cast("string")
  }

  # Read data from raw table.
  mem_cov_dlt_df = read_table_to_df(raw_tbl_name)
  # Remove leading and trailing spaces of all column values.
  removed_space_df = trim_leading_trailing_space(mem_cov_dlt_df)
  # Convert data type.
  dtype_trans_df = data_type_conversion(removed_space_df, member_coverage_stage_schema)
  # Add Hash key called Id - SHA1
  id_calc_df = dtype_trans_df.withColumn('Id', sha1(concat_ws("", *buz_keys)))

  if INBOUND_TYPE == 'MemberCoverageDelta':
    
    # Read data from prodrev stage table.
    prodrev_stage_df = read_table_to_df(prodrev_stage_table_name)\
                        .filter((col('RetbvsdtTableId') == 'CASLTCGP') & (substring(col('RetbvsdtShortArea'),1,5) != 'ILSVA') & (substring(col('RetbvsdtShortArea'),1,3) != 'HUM'))\
                        .selectExpr('substring(RetbvsdtEntryId,2) as RetbvsdtEntryId')\
                        .drop_duplicates()

    prodrev_joined_df = id_calc_df.alias('LH')\
                              .join(prodrev_stage_df.alias('RH'), col('LH.ReenrchgMbrEnrlCustNbr') == col('RH.RetbvsdtEntryId'), 'left')

    non_ltcgp_filtered_df = prodrev_joined_df.filter(col('RetbvsdtEntryId').isNull()).drop('RetbvsdtEntryId')

    ltcgp_filtered_df = prodrev_joined_df.filter(col('RetbvsdtEntryId').isNotNull()).drop('RetbvsdtEntryId')
    ltcgp_filtered_df = add_columns_for_invalid_records(ltcgp_filtered_df,INBOUND_TYPE, "LTCGP Customer", "E13")

  elif INBOUND_TYPE == 'CustomerCoverageDelta':
    non_ltcgp_filtered_df = id_calc_df
    ltcgp_filtered_df = spark.createDataFrame(data = [], schema = StructType([]))

  # Identify duplicates records, retain one for the processing and reject the remaining. 
  dup_df, cleansed_df = identify_duplicates_records(non_ltcgp_filtered_df)
  # Check overlap dates for input transaction.
  buz_keys_dup_df, buz_keys_cleansed_df = check_overlap_dates_for_input_transaction(cleansed_df)
  # Identify records when coverage start date greater than coverage end date.
  invalid_cov_df, valid_cov_df = find_records_enddate_before_effectivedate(buz_keys_cleansed_df)
  
  # Add comment and error code column to rejected records.
  dup_df = add_columns_for_invalid_records(dup_df,INBOUND_TYPE, "Duplicate transactions in the input file", "E1")
  buz_keys_dup_df = add_columns_for_invalid_records(buz_keys_dup_df,INBOUND_TYPE, "Member Coverage dates conflict with another transaction in the input file", "E2")
  error_coverage_df = add_columns_for_invalid_records(invalid_cov_df,INBOUND_TYPE, "Member coverage effective date is greater than end date", "E3")
  

  # Add audit columns to cleansed data.
  cleansed_df = valid_cov_df.withColumns(cleansed_recs_col_map)
  # Union all rejected records.
  invalid_records_combined_df = union_by_name([dup_df, buz_keys_dup_df, error_coverage_df, ltcgp_filtered_df])
  
except Exception as e:
    excep = 'Add audit columns and load data to raw table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Upsert Stage Member Coverage Queue.
try:
    if spark.catalog.tableExists(stage_tbl_name):
        stg_mem_cov_table = DeltaTable.forName(spark, stage_tbl_name)
        updates_df = cleansed_df
        # Rows to INSERT new coverage of existing member coverage
        new_coverage_to_insert_df = updates_df.alias("updates")\
        .join(stg_mem_cov_table.toDF().alias("coverage"), ['Id']) \
        .where(f"coverage.IsProcessed IS NULL AND coverage.InboundType = '{INBOUND_TYPE}'").selectExpr('updates.*')

        # Stage the update by unioning two df of rows
        # 1. Rows that will be inserted in the whenNotMatched clause
        # 2. Rows that will either update the coverages of existing member coverage or insert the new coverage of new member coverage
        staged_updates_df = (
        new_coverage_to_insert_df
        .selectExpr("NULL as mergeKey", "updates.*")  
        .unionByName(updates_df.selectExpr('Id as mergeKey', "*"))  # Rows for 2.
        )

        # Apply SCD Type 2 operation using merge
        stg_mem_cov_table.alias("coverages").merge(
        staged_updates_df.alias("staged_updates"),
            "coverages.Id = mergeKey") \
        .whenMatchedUpdate(
            condition = f"coverages.IsProcessed IS NULL AND coverages.InboundType = '{INBOUND_TYPE}'",
            set = {
                "IsProcessed": "'Y'",
                "ProcessedDate" : current_date(),
                "LastReceivedDate": current_date(),
                "Comment" : "null",
                "ErrorCode" : "null",
                "ModifiedDateTime" : "staged_updates.CreatedDateTime",
                "ModifiedBy" : "staged_updates.CreatedBy"
            }
        ).whenNotMatchedInsertAll().execute()

        write_df_as_delta_table(invalid_records_combined_df, stage_tbl_name,part_col = 'InboundType,IsProcessed',mode='append')
    else:
        raw_trans_df = union_by_name([cleansed_df, invalid_records_combined_df])
        write_df_as_delta_table(raw_trans_df,stage_tbl_name, part_col = 'InboundType,IsProcessed')
except Exception as e:
    excep = 'Upsert Stage Member Coverage Queue failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## CI Customer Conversion

# COMMAND ----------

# DBTITLE 1,Column name mapping
col_map_dict = {
    "ReenrchgPcaFinRptLedgrNbr" : "LedgerNumber",
    "ReenrchgMbrEnrlCustNbr" : "GHGroupIdentifier",
    "ReenrchgMbrEnrlGrpNbr" : "EmployerGroupNumber",
    "ReenrchgMbrpid" : "MemberId",
    "ReenrchgSubpid" : "SubscriberId",
    "ReenrchgGkProvIdNbr" : "GateKeeperProviderId",
    "ReenrchgGkProvSuffCd" : "GateKeeperProviderSuffixCode",
    "ReenrchgGkProvTyCd" : "GateKeeperProviderTypeCode",
    "ReenrchgMbrProvEffCymd" : "MemberProvEffDate",
    "ReenrchgMbrProvEndCymd" : "MemberProvEndDate",
    "ReenrchgWorkcmpOccurPId" : "WokerCompensationOccurenceId",
    "ReenrchgCurrPcpEndReasCd" : "CoverageEndReasonCode",
    "Id" : "Id",
    "InboundType" : "InboundType"
}

# COMMAND ----------

# DBTITLE 1,Read StageMemberCoverageQueue, StageCustomer and StageCustomerProduct tables.
try:
    # Filter only unprocessed records from stage table.
    stg_mem_cov_df = read_table_to_df(stage_tbl_name)\
                        .filter((col('IsProcessed').isNull()) & (col('InboundType') == INBOUND_TYPE))
    # Read data from customer table.
    customer_df = read_table_to_df(customer_tbl_name)

    # Read data from customer product table
    customer_product_df = read_table_to_df(customer_product_tbl_name)\
                            .selectExpr("*","concat(LineOfBusinessCode, MarketNumber, PlanNumber, OptNumber) AS ProductId")

    # Read data from product table.
    product_df = read_table_to_df(prod_table_name)\
                    .select("ProductKey", "ExtProdSeqNo", "ProductId")

    # Column name conversion
    col_name_trans_stg_df = col_name_mapping(stg_mem_cov_df, col_map_dict)
    
    #Get minimum date from delta table
    min_coveragedate = col_name_trans_stg_df.select(min('MemberProvEffDate')).first()[0]
except Exception as e:
    excep = 'Read StageMemberCoverageQueue, StageCustomer and StageCustomerProduct tables failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Update CI Identifiers to the stage table.
try:
    ci_converted_df = switchable_gh_ci_conversion(col_name_trans_stg_df, customer_df)
    # Seperate Valid and invalid customer records.
    valid_customer_df = ci_converted_df.filter(col('IsCustomerFound') == 'Y')
    invalid_customer_df = ci_converted_df.filter(col('IsCustomerFound') == 'N').select('Id')

    # Dictonary contains columns to update in stage member coverage queue table.
    ci_identifier_set_dict = {
        "CIGroupIdentifier": "updates.CIGroupIdentifier",
        "CIClassNumber": "updates.CIClassNumber",
        "BenefitSequence" : "updates.BenefitSequence"
        }

    # Update CI Identifier's to the stage member coverage queue table.
    update_record_to_queue(valid_customer_df, stage_tbl_name, ci_identifier_set_dict, INBOUND_TYPE)

    # Add comment and error code columns to invalid customer df.
    invalid_customer_cols_added_df = add_comment_error_cols_to_df(invalid_customer_df,f'Customer not found in service fund {customer_tbl_name}', 'E4')
except Exception as e:
    excep = 'Update CI Identifiers to the stage table: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Product validation

# COMMAND ----------

# DBTITLE 1,Agg customer product and check active customer product present for member coverage.
try:
    cust_prod_join_condition = (col('CP.ProductId') == col('P.ProductId'))
    # Join Customer with CustomerProduct on the above condition and join with Product to get ProductKey and ExtProdSeqNo and select only the required columns.
    cust_prod_joined_df = customer_product_df.alias('CP')\
                                .join(product_df.alias('P'), cust_prod_join_condition, 'inner')\
                                .selectExpr("CP.MemberCustomerNumber AS CIGroupIdentifier"
                                        ,"CP.MemberGroupNumber AS BenefitSequence"
                                        ,"CP.CIClassNumber"
                                        ,"CP.ProductId"
                                        ,"P.ProductKey"
                                        ,"P.ExtProdSeqNo"
                                        ,"CP.MarketNumber"
                                        ,"CP.CustomerProductStartDate"
                                        ,"CP.CustomerProductEndDate"
                                        ,"CP.ProductCategoryCode")
                                

    not_consecutive_calc_df = cust_prod_joined_df.selectExpr("*", "CASE WHEN (CustomerProductStartDate <> LAG(CustomerProductEndDate) OVER (PARTITION BY CIGroupIdentifier, BenefitSequence, CIClassNumber,MarketNumber ORDER BY CustomerProductStartDate) + INTERVAL 1 DAY) = true THEN 1 ELSE 0 END AS NotConsecutive")

    cal_group_no_df = not_consecutive_calc_df.selectExpr("*", "SUM(NotConsecutive) OVER (PARTITION BY CIGroupIdentifier, BenefitSequence, CIClassNumber,MarketNumber ORDER BY 1) AS GroupNo")


    calc_st_ed_date_df = cal_group_no_df.groupBy("CIGroupIdentifier", "BenefitSequence", "CIClassNumber", "MarketNumber", "GroupNo")\
                                .agg(min("CustomerProductStartDate").alias("CustomerProductStartDate")
                                ,max("CustomerProductEndDate").alias("CustomerProductEndDate")).drop('GroupNo')
                            
    # Get Min ProductStartDate and Max ProductEndDate for each customer.
    join_condition = ((col('INP.LedgerNumber') == col('CP.MarketNumber')) 
                      & (col('INP.CIGroupIdentifier') == col('CP.CIGroupIdentifier')) 
                      & (col('INP.BenefitSequence') == col('CP.BenefitSequence')) 
                      & (col('INP.CIClassNumber') == col('CP.CIClassNumber'))
                      & (col('INP.MemberProvEffDate') >= col('CP.CustomerProductStartDate'))
                      & (col('INP.MemberProvEndDate') <= col('CP.CustomerProductEndDate')))
    
    joined_cp_df = valid_customer_df.alias('INP').join(calc_st_ed_date_df.alias('CP'), join_condition, 'Left')\
                        .selectExpr('INP.*', 'CP.CIGroupIdentifier AS CIGroup')
    
    valid_cp_df = joined_cp_df.filter(col('CIGroup').isNotNull())
    invalid_cp_df = joined_cp_df.filter(col('CIGroup').isNull())
    invalid_cp_cols_added_df = add_comment_error_cols_to_df(invalid_cp_df,f'CustomerProduct not found in service fund domain table {customer_product_tbl_name}', 'E5')
except Exception as e:
    excep = 'Agg customer product and check active customer product present for member coverage failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Member Validation

# COMMAND ----------

# DBTITLE 1,Read member table and join with delta dataframe member dataframe.
try:
    valid_member_df, invalid_member_df = member_validation(valid_cp_df, member_table_name)

    invalid_member_df = invalid_member_df.select('Id')

    # Add comment and error code columns to invalid customer df.
    invalid_member_cols_added_df = add_comment_error_cols_to_df(invalid_member_df,f'Member not found in service fund domain table{create_sql_tbl_name_from_dbk_stage_tbl_name(member_table_name)}', 'E6')
except Exception as e:
    excep = 'Read member table and join with delta dataframe member dataframe failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Member Coverage overlap

# COMMAND ----------

# DBTITLE 1,Read data from member coverage table and rename columns
try:
    
    member_coverage_df = read_table_to_df(mem_cov_table_name)\
                    .withColumn('GateKeeperProviderId', col('GateKeeperProviderId').cast('int'))

    # Create a select list to rename the columns
    mem_cov_col_list = create_select_list(member_coverage_df.columns)

    # Convert the column names by passing the select list to selectExpr.
    col_name_convtd_mem_cov_df = member_coverage_df.selectExpr(*mem_cov_col_list)
    
except Exception as e:
    excep = 'Read data from member coverage table and rename columns failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Required Column list
select_list = ['CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber', 'MemberId','SubscriberId', 'LedgerNumber', 'GateKeeperProviderId','MemberKey', 'GateKeeperProviderSuffixCode', 'GateKeeperProviderTypeCode', 'WokerCompensationOccurenceId', 'CoverageEndReasonCode', 'Id', "GHGroupIdentifier", "EmployerGroupNumber", "IsCoverageOverlap", "IsNewCoverage", "InboundType"] + col_name_convtd_mem_cov_df.columns

old_select_list = ['Id', 'OldMemberCoverageKey AS MemberCoverageKey','MemberKey','OldProviderContractKey AS ProviderContractKey','OldProductKey AS ProductKey','OldExtProdSeqNo AS ExtProdSeqNo','OldCoverageTypeCode AS CoverageTypeCode','OldCoverageTypeCodeLabel AS CoverageTypeCodeLabel',"to_date(CoverageStartDate, 'yyyy-MM-dd') AS CoverageStartDate","to_date(CoverageEndDate, 'yyyy-MM-dd') AS CoverageEndDate","CASE WHEN trim(OldCoverageEndReasonCode) = '' THEN 'SG' ELSE OldCoverageEndReasonCode END AS CoverageEndReasonCode",'OldCoverageEndReasonCodeLabel AS CoverageEndReasonCodeLabel','OldVendorSequenceNumber AS VendorSequenceNumber','OldGateKeeperProviderId AS GateKeeperProviderId','OldGateKeeperProviderSuffixCode AS GateKeeperProviderSuffixCode','OldGateKeeperProviderTypeCode AS GateKeeperProviderTypeCode','OldWokerCompensationOccurenceId AS WokerCompensationOccurenceId','OldCIClassNumber AS CIClassNumber','OldMemberCustomerNumber AS MemberCustomerNumber','OldMemberGroupNumber AS MemberGroupNumber','RecordType',"'Y' as IsCoverageOverlap", "'N' as IsNewCoverage", "'UPDATE-DEST' AS DerivedIndicator", "OldCreatedDateTime AS CreatedDateTime", "OldCreatedBy AS CreatedBy", "LedgerNumber","OldModifiedDateTime AS ModifiedDateTime", "OldModifiedBy AS ModifiedBy", "'Exists' AS SelectedProvider", "InboundType"]

updt_ins_select_list = ['Id',"CASE WHEN DerivedIndicator = 'UPDATE' THEN OldMemberCoverageKey ELSE null END AS MemberCoverageKey",'MemberKey',"CASE WHEN DerivedIndicator = 'UPDATE' THEN OldProviderContractKey ELSE null END AS ProviderContractKey",'CIGroupIdentifier as MemberCustomerNumber','BenefitSequence as MemberGroupNumber','CIClassNumber','GateKeeperProviderId','GateKeeperProviderSuffixCode','GateKeeperProviderTypeCode','WokerCompensationOccurenceId','CoverageEndReasonCode',"to_date(CoverageStartDate, 'yyyy-MM-dd') AS CoverageStartDate","to_date(CoverageEndDate, 'yyyy-MM-dd') AS CoverageEndDate",'DerivedIndicator', 'RecordType', 'IsCoverageOverlap', 'IsNewCoverage', "CASE WHEN DerivedIndicator = 'UPDATE' THEN OldCreatedDateTime else current_timestamp() END AS CreatedDateTime", f"CASE WHEN DerivedIndicator = 'UPDATE' THEN OldCreatedBy ELSE '{PIPELINE_NAME}' END AS CreatedBy", "'PCP' AS CoverageTypeCode", "'Primary Care Physician' AS CoverageTypeCodeLabel", "0 AS VendorSequenceNumber", "null AS CoverageEndReasonCodeLabel", "LedgerNumber", "OldGateKeeperProviderId", "OldGateKeeperProviderSuffixCode", "OldCoverageEndReasonCode", "OldModifiedDateTime AS ModifiedDateTime", "OldModifiedBy AS ModifiedBy", "InboundType"]

# COMMAND ----------

# DBTITLE 1,Processing null coverages
try:
    if INBOUND_TYPE == 'MemberCoverageDelta':
        # Filter out only the null coverages.
        null_cov_df = valid_member_df.filter((col('MemberProvEffDate') == col('MemberProvEndDate')))

        # Member Coverage join condition
        null_cov_join_condition = ((col('LH.MemberKey') == col('RH.MemberKey'))
                                &(col('LH.BenefitSequence') == col('RH.MemberGroupNumber'))
                                &(col('LH.CIClassNumber') == col('RH.CIClassNumber'))
                                &(col('LH.MemberProvEffDate') == col('RH.CoverageStartDate')))

        # Get the matching record and add DerivedIndicator, RecordType, IsCoverageOverlap, IsNewCoverage, ModifiedBy and ModifiedDateTime.
        null_cov_processed_df = null_cov_df.alias('LH')\
                                .join(member_coverage_df.alias('RH'), null_cov_join_condition, 'left')\
                                .selectExpr("LH.Id","RH.*")

        null_cov_filtered_df = null_cov_processed_df.filter(col('MemberCoverageKey').isNotNull())\
                                .selectExpr("*", "'CN' AS RecordType", "'DELETE' AS DerivedIndicator", "'N' AS IsCoverageOverlap", "'N' AS IsNewCoverage")

        rejected_null_cov = null_cov_processed_df.filter(col('MemberCoverageKey').isNull())\
                                .selectExpr("Id", f"'Member Coverage not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(mem_cov_table_name)}' as Comment", "'E7' as ErrorCode", "'Y' AS IsProcessed", "current_date() AS ProcessedDate", "'Y' as IsRejected")

        write_df_as_delta_table(null_cov_filtered_df, mem_cov_adj_table_name, part_col = 'DerivedIndicator')

        filtered_member_df = valid_member_df.filter(col('MemberProvEffDate') != col('MemberProvEndDate'))

        # Combine invalid customer and member dataframe.
        rejected_records_dfs = union_by_name([invalid_customer_cols_added_df,invalid_member_cols_added_df,invalid_cp_cols_added_df,rejected_null_cov, null_cov_filtered_df.selectExpr("Id", "'N' as IsRejected", "'Y' AS IsProcessed", "current_date() AS ProcessedDate").drop_duplicates()])
    elif INBOUND_TYPE == 'CustomerCoverageDelta':
        # Null coverage processing is not applicable for customer coverage delta.
        filtered_member_df = valid_member_df
        if spark.catalog.tableExists(mem_cov_adj_table_name):
            spark.sql(f"TRUNCATE TABLE {mem_cov_adj_table_name}")
        # Combine invalid customer and member dataframe.
        rejected_records_dfs = union_by_name([invalid_customer_cols_added_df,invalid_member_cols_added_df,invalid_cp_cols_added_df.selectExpr("*", "CAST(null as date) as ProcessedDate", "CAST(null as string) as IsProcessed")])
except Exception as e:
    excep = 'Processing null coverages failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)
                        

# COMMAND ----------

# DBTITLE 1,updating rejected null coverage, customer and member records to stage member coverage queue table.
try:
    invalid_records_set_dict = {
                    "IsProcessed" : "updates.IsProcessed",
                    "ProcessedDate" : "updates.ProcessedDate",
                    "Comment" : f"updates.Comment",
                    "ErrorCode" : f"updates.ErrorCode",
                    "ModifiedDateTime" : current_timestamp(),
                    "ModifiedBy" : f"'{PIPELINE_NAME}'"
                }
    valid_records_set_dict = {
                    "IsProcessed" : "updates.IsProcessed",
                    "ProcessedDate" : "updates.ProcessedDate",
                    "Comment" : "null",
                    "ErrorCode" : "null",
                    "ModifiedDateTime" : current_timestamp(),
                    "ModifiedBy" : f"'{PIPELINE_NAME}'"
                }

    # Update rejected records to queue.
    apply_custom_scd_type(rejected_records_dfs, stage_tbl_name, valid_records_set_dict,invalid_records_set_dict, INBOUND_TYPE)
except Exception as e:
    excep = 'Identify Overlap and Non-Overlap coverages. failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Identify new and exists member coverages.
try:    
    join_condition = ((col('LH.MemberKey') == col('RH.OldMemberKey')))

    # Left Anti join delta dataframe with member coverage to identify new coverages. And add IsNewCoverage and IsCoverageOverlap indicator columns.
    new_coverage_df = filtered_member_df.alias('LH')\
                            .join(col_name_convtd_mem_cov_df.alias('RH'), join_condition, 'leftAnti')\
                            .selectExpr('CIGroupIdentifier','BenefitSequence','CIClassNumber','MemberId','SubscriberId','LedgerNumber','GateKeeperProviderId','GateKeeperProviderSuffixCode','GateKeeperProviderTypeCode','WokerCompensationOccurenceId','CoverageEndReasonCode', "GHGroupIdentifier", "EmployerGroupNumber", "'INSERT' as DerivedIndicator", 'MemberProvEffDate as CoverageStartDate', 'MemberProvEndDate as CoverageEndDate',"MemberKey","Id","'C0' as RecordType", "'N' AS IsCoverageOverlap", "'Y' AS IsNewCoverage", "InboundType")

    # Left Anti join new_coverage_df with delta dataframe to identify exists coverages. And add DistId column.
    removed_new_cov_df = left_anti_or_semi_join(filtered_member_df,new_coverage_df,'Type2', 'LeftAnti')\
                            .selectExpr("*", "row_number() OVER(PARTITION BY 1 ORDER BY MemberKey ASC, MemberProvEffDate ASC) AS DistId")
except Exception as e:
    excep = 'Identify new and exists member coverages failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Identify Overlap and Non-Overlap coverages.
try:
    join_condition = (((col('LH.MemberKey') == col('RH.OldMemberKey')))
                        & ((col('LH.MemberProvEffDate') <= col('RH.OldCoverageEndDate')))
                        & ((col('LH.MemberProvEndDate') >= col('RH.OldCoverageStartDate')))
                        & ((col('RH.OldCoverageTypeCode') == 'PCP')))

    col_name_convtd_mem_cov_df = col_name_convtd_mem_cov_df.filter((col('CoverageEndDate') >= min_coveragedate))
                                                                   
    # Join exists coverage dataframe with member coverage to identify overlap coverages. And add IsNewCoverage and IsCoverageOverlap columns.
    exists_coverage_df = removed_new_cov_df.alias('LH')\
                            .join(col_name_convtd_mem_cov_df.alias('RH'),join_condition,'left')\
                            .selectExpr("LH.*"
                                        ,"RH.*"
                                        ,"CASE WHEN RH.OldMemberCoverageKey IS NULL THEN 'N' ELSE 'Y' END AS IsCoverageOverlap"
                                        ,"CASE WHEN RH.OldMemberCoverageKey IS NULL THEN 'INSERT' ELSE null END AS DerivedIndicator"
                                        ,"'N' AS IsNewCoverage")

    exists_coverage_df.cache()
    
    # Filter out non overlap coverage and add Derived Indicator.
    non_overlap_cov_df = exists_coverage_df.filter(((col('IsCoverageOverlap') == 'N')))\
                            .selectExpr(*select_list
                                        ,"MemberProvEffDate as CoverageStartDate"
                                        ,"MemberProvEndDate as CoverageEndDate"
                                        ,"'INSERT' as DerivedIndicator"
                                        ,"'CE' as RecordType")
    
    # Calculate NewDistId (Unique Id for each overlap join set).
    ws = Window.partitionBy('MemberKey', 'OldCoverageStartDate').orderBy(lit(1))
    min_rn_overlap_cov_df = exists_coverage_df.filter((col('IsCoverageOverlap') == 'Y'))\
                            .withColumn('NewDistId', min('DistId').over(ws))\
                            .drop('DistId')
                            
    ws = Window.partitionBy('Id').orderBy(lit(1))
    overlap_cov_inter_df = min_rn_overlap_cov_df.withColumn('NewDistId', min('NewDistId').over(ws))

    ws = Window.partitionBy('MemberKey', 'OldCoverageStartDate').orderBy(lit(1))
    overlap_cov_df = overlap_cov_inter_df.withColumn('NewDistId', min('NewDistId').over(ws))
except Exception as e:
    excep = 'Identify Overlap and Non-Overlap coverages. failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC In the table below, you'll find examples specifically related to matching coverage start dates. Additionally, there are two other scenarios to consider
# MAGIC   - DeltaCoverageStartDate is the lesser than ExistsCoverageStartDate - Replace the exists coverage record with delta record.
# MAGIC   - DeltaCoverageStartDate is the greater than ExistsCoverageStartDate - End the Exists Coverage with DeltaCoverageStartDate - 1 and insert the Delta record. 

# COMMAND ----------

# MAGIC %md
# MAGIC |Member | Customer | DeltaCoverageStartDate | DeltaCoverageEndDate | OldCoverageStartDate | OldCoverageEndDate| NewDistId | ConditionCategory | DerivedIndicator|
# MAGIC | ----------- | ----------- | ----------- | ----------- | ----------- | ----------- |  ----------- | ----------- |  ----------- | 
# MAGIC | M1 | C1 | 01-01-2023 | 31-01-2023 | 01-01-2023 | 31-12-9999| 1 | C1 | UPDATE |
# MAGIC ||||||||
# MAGIC | M3 | C3 | 01-01-2023 | 31-12-2024 | 01-01-2023 | 30-06-2023 |3| C1 | UPDATE |
# MAGIC | M3 | C3 | 01-01-2023 | 31-12-2024 | 01-07-2023 | 31-12-2023 |3| C1 | UPDATE |
# MAGIC | M3 | C3 | 01-01-2023 | 31-12-2024 | 01-01-2024 | 31-12-9999 |3| C1 | UPDATE |

# COMMAND ----------

# DBTITLE 1,Handling single overlap coverage
try:
    # One source transaction overlap with one target.
    # One source transaction overlap with multiple target.

    # Calculate distinct count based on the NewDistId and Coverage dates. 
    agg_col_calc_df = overlap_cov_df.groupBy('NewDistId')\
                            .agg(countDistinct('MemberProvEffDate', 'MemberProvEndDate').alias('SrcDistCnt'))

    # Join agg_col_calc_df with overlap_cov_df on NewDistId to get NewDistId.
    agg_col_joined_df = overlap_cov_df.join(agg_col_calc_df, ['NewDistId'], 'inner')

    # Filter out records when SrcDistCnt = 1. Add row number for start asc and start date desc. These two columns are useful when updates are received for split records and to identifying the first and last rows of each overlap.

    # Refer above table for an example.
    src_dt_same_df = agg_col_joined_df.filter(col('SrcDistCnt') == 1)\
                        .selectExpr("*"
                                    ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate ASC) AS StDtRn"
                                    ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate DESC) AS EdDtRn"
                                    ,"lag(OldCoverageEndDate,1,OldCoverageEndDate) OVER (PARTITION BY NewDistId ORDER BY OldCoverageStartDate) AS BeforeDate"
                                    ,"lead(OldCoverageStartDate,1) OVER (PARTITION BY NewDistId ORDER BY OldCoverageStartDate) AS AfterDate")
                        
    # Calculate Coverage Start, Coverage End and Derived Indicator columns.
    src_dt_same_upd_df = src_dt_same_df\
                        .selectExpr(*select_list
                                    ,"CASE WHEN MemberProvEffDate <= OldCoverageStartDate AND StDtRn = 1 THEN MemberProvEffDate WHEN MemberProvEffDate > OldCoverageStartDate THEN OldCoverageStartDate ELSE DATEADD(day, 1, BeforeDate) END AS CoverageStartDate"
                                    ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN DATEADD(day, -1, MemberProvEffDate) WHEN EdDtRn = 1 THEN MemberProvEndDate ELSE OldCoverageEndDate END AS CoverageEndDate"
                                    ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN 'UPDATE-DEST' ELSE 'UPDATE' END as DerivedIndicator"
                                    ,"NewDistId"
                                    ,"'C1' as RecordType")

    # When the coverage start date is greater than existing coverage start date. we have to terminate the existing coverage with (DeltaCoverageStart - 1) and insert delta record.
    src_dt_same_ins_df = src_dt_same_df.filter((col('MemberProvEffDate') > col('OldCoverageStartDate')) & (col('StDtRn') == 1))\
                        .selectExpr(*select_list
                                    ,"MemberProvEffDate AS CoverageStartDate"
                                    ,"CASE WHEN AfterDate IS NULL THEN MemberProvEndDate ELSE DATEADD(day,-1,AfterDate) END AS CoverageEndDate"
                                    ,"'INSERT' as DerivedIndicator"
                                    ,"NewDistId"
                                    ,"'C2' as RecordType")

    # Union the processed dataframe.  
    src_dt_same_append_df = src_dt_same_upd_df.unionByName(src_dt_same_ins_df)

except Exception as e:
    excep = 'Handling single overlap coverage failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC |Member | Customer | DeltaCoverageStartDate | DeltaCoverageEndDate | OldCoverageStartDate | OldCoverageEndDate| NewDistId | ConditionCategory | DerivedIndicator|
# MAGIC | ----------- | ----------- | ----------- | ----------- | ----------- | ----------- |  ----------- | ----------- |  ----------- | 
# MAGIC | M2 | C2 | 01-01-2023 | 31-01-2023 | 01-01-2023 | 31-12-9999| 2 | C8 | UPDATE |
# MAGIC | M2 | C2 | 01-02-2023 | 28-02-2023 | 01-01-2023 | 31-12-9999| 2 | C3 | INSERT |
# MAGIC | M2 | C2 | 01-03-2023 | 31-03-2023 | 01-01-2023 | 31-12-9999| 2 | C3 | INSERT |
# MAGIC ||||||||
# MAGIC | M4 | C4 | 01-01-2023 | 31-03-2023 | 01-01-2023 | 30-04-2023 |4| C4 | UPDATE |
# MAGIC | M4 | C4 | 01-04-2023 | 31-12-9999 | 01-01-2023 | 30-04-2023 |4| C3 | IGNORE |
# MAGIC | M4 | C4 | 01-04-2023 | 31-12-9999 | 01-05-2023 | 31-12-9999 |4| C4 | UPDATE |
# MAGIC ||||||||
# MAGIC | M5 | C5 | 01-01-2023 | 31-07-2023 | 01-01-2023 | 31-03-2023 |5| C8 | UPDATE |
# MAGIC | M5 | C5 | 01-01-2023 | 31-07-2023 | 01-04-2023 | 31-12-9999 |5| C8 | UPDATE |
# MAGIC | M5 | C5 | 01-08-2023 | 31-12-9999 | 01-04-2023 | 31-12-9999 |5| C3 | INSERT |

# COMMAND ----------

# DBTITLE 1,Handling ignore scenarios(Overlap duplicates)
try:
   # Multiple source transaction overlap with one target transaction(Only insert are handled).
   # Overlap duplicates are handled.

   # Filter out SrcDistCnt > 1 (Sample Record type - Receive updates to end exists coverage and insert new coverage (Example - Member M2), Duplicates overlap(Example - Member M4 and M5))
   src_dt_diff_df = agg_col_joined_df.filter(col('SrcDistCnt') > 1)\
                           .drop('StDtRn', 'EdDtRn')\
                           .selectExpr("*"
                                       ,"row_number() OVER(PARTITION BY NewDistId, OldCoverageStartDate, OldCoverageEndDate ORDER BY MemberProvEffDate ASC) AS StDtRN")

   # Seperate insert and update records.                  
   src_dt_diff_upt_df = src_dt_diff_df.filter(col('StDtRN') == 1).drop('StDtRN')
   src_dt_diff_ins_df = src_dt_diff_df.filter(col('StDtRN') > 1)

   # Left anti join src_dt_diff_ins_df with src_dt_diff_upt_df to remove duplicate overlap(Example -  Member M4)
   final_src_dt_diff_ins_df = left_anti_or_semi_join(src_dt_diff_ins_df, src_dt_diff_upt_df, 'Type2', 'LeftAnti')\
                           .selectExpr(*select_list
                              ,"MemberProvEffDate AS CoverageStartDate"
                              ,"MemberProvEndDate AS CoverageEndDate"
                              ,"'INSERT' AS DerivedIndicator"
                              ,"NewDistId"
                              ,"'C3' as RecordType")
except Exception as e:
   excep = 'Handling ignore scenarios(Overlap duplicates) failed: ' + str(e)
   handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
   raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC |Member | Customer | DeltaCoverageStartDate | DeltaCoverageEndDate | OldCoverageStartDate | OldCoverageEndDate| NewDistId | ConditionCategory | DerivedIndicator|
# MAGIC | ----------- | ----------- | ----------- | ----------- | ----------- | ----------- |  ----------- | ----------- |  ----------- | 
# MAGIC | M6 | C6 | 01-10-2019 | 30-11-2023 | 01-10-2019 | 31-12-2021 |6| C4 | UPDATE |
# MAGIC | M6 | C6 | 01-10-2019 | 30-11-2023 | 01-01-2022 | 31-12-2022 |6| C4 | UPDATE |
# MAGIC | M6 | C6 | 01-10-2019 | 30-11-2023 | 01-01-2023 | 31-12-2023 |6| C4 | UPDATE |
# MAGIC | M6 | C6 | 01-12-2023 | 31-12-9999 | 01-01-2023 | 31-12-2023 |6| C3 | IGNORE |
# MAGIC | M6 | C6 | 01-12-2023 | 31-12-9999 | 01-01-2024 | 31-12-9999 |6| C6 | UPDATE |

# COMMAND ----------

# DBTITLE 1,Handling multiple source coverage is overlap with single existing coverage
try:
    # Mutliple source transaction overlap with multiple target transaction.
        # Again identify single source overlap with multiple target and mutiple source transaction overlap with single tagrget transaction.

    agg_col_calc_df = src_dt_diff_upt_df.groupBy('NewDistId')\
                            .agg(countDistinct('MemberProvEffDate', 'MemberProvEndDate').alias('DistCnt'))

    # Calculate count
    agg_col_joined_df = src_dt_diff_upt_df.join(agg_col_calc_df, ['NewDistId'], 'inner')\
                            .selectExpr("*"
                                        ,"count(NewDistId) OVER(PARTITION BY NewDistId, MemberProvEffDate ORDER BY 1) AS CCount"
                                        ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate ASC) AS StDtRn")

    # take only the mutiple source transaction overlap with single target transaction.                        
    src_dt_diff_df  = agg_col_joined_df.filter(col('DistCnt') > 1).drop("StDtRn")
    
    mul_src_diff_df = src_dt_diff_df.filter(col('CCount') > 1)\
                            .selectExpr("*"
                                        ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate ASC) AS StDtRn"
                                        ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate DESC) AS EdDtRn")
                            
    single_src_diff_df = src_dt_diff_df.filter(col('CCount') == 1)\
                            .selectExpr("*"
                                        ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate ASC) AS StDtRn"
                                        ,"row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate DESC) AS EdDtRn")


    src_dt_diff_upd_df = mul_src_diff_df\
                        .selectExpr(*select_list
                        ,"CASE WHEN MemberProvEffDate < OldCoverageStartDate AND StDtRn = 1 THEN MemberProvEffDate ELSE OldCoverageStartDate END AS CoverageStartDate"
                            ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN DATEADD(day, -1, MemberProvEffDate) WHEN EdDtRn = 1 THEN MemberProvEndDate ELSE OldCoverageEndDate END AS CoverageEndDate"
                            ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN 'UPDATE-DEST' ELSE 'UPDATE' END AS DerivedIndicator"
                            ,"NewDistId"
                            ,"'C4' as RecordType")

    src_dt_diff_ins_df = mul_src_diff_df.filter((col('MemberProvEffDate') > col('OldCoverageStartDate')) & (col('StDtRn') == 1))\
                        .selectExpr(*select_list
                        ,"MemberProvEffDate AS CoverageStartDate"
                        ,"MemberProvEndDate AS CoverageEndDate"
                        ,"'INSERT' AS DerivedIndicator"
                        ,"NewDistId"
                        ,"'C5' as RecordType")

    src_dt_diff_append_df = src_dt_diff_upd_df.unionByName(src_dt_diff_ins_df)

    mul_src_diff_upd_df = single_src_diff_df\
                        .selectExpr(*select_list
                         ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN OldCoverageStartDate ELSE MemberProvEffDate END AS CoverageStartDate"
                        ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN DATEADD(day, -1, MemberProvEffDate) ELSE MemberProvEndDate END AS CoverageEndDate"
                        ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN 'UPDATE-DEST' ELSE 'UPDATE' END AS DerivedIndicator"
                        ,"NewDistId"
                        ,"'C6' as RecordType")

    mul_src_diff_ins_df = single_src_diff_df.filter((col('MemberProvEffDate') > col('OldCoverageStartDate')) & (col('StDtRn') == 1))\
                        .selectExpr(*select_list
                        ,"MemberProvEffDate AS CoverageStartDate"
                        ,"MemberProvEndDate AS CoverageEndDate"
                        ,"'INSERT' AS DerivedIndicator"
                        ,"NewDistId"
                        ,"'C7' as RecordType")

    mul_src_diff_append_df = mul_src_diff_upd_df.unionByName(mul_src_diff_ins_df)

except Exception as e:
    excep = 'Handling multiple source coverage is overlapping with single existing coverage failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,handling one input coverage overlap with multiple existing coverage
try:
    src_same_df  = agg_col_joined_df.filter(col('DistCnt') == 1)\
                        .selectExpr("*","row_number() OVER(PARTITION BY NewDistId ORDER BY OldCoverageStartDate DESC) AS EdDtRn",
                                        "lag(OldCoverageEndDate,1,OldCoverageEndDate) OVER (PARTITION BY NewDistId ORDER BY StDtRn) AS AfterDate",
                                        "lead(OldCoverageStartDate,1) OVER (PARTITION BY NewDistId ORDER BY StDtRn) AS BeforeDate")

    src_same_upd_df = src_same_df\
                        .selectExpr(*select_list
                            ,"CASE WHEN MemberProvEffDate <= OldCoverageStartDate AND StDtRn = 1 THEN MemberProvEffDate WHEN  MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN OldCoverageStartDate ELSE DATEADD(day,1,AfterDate) END AS CoverageStartDate"
                            ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN DATEADD(day, -1, MemberProvEffDate) WHEN EdDtRn = 1 THEN MemberProvEndDate ELSE OldCoverageEndDate END AS CoverageEndDate"
                            ,"CASE WHEN MemberProvEffDate > OldCoverageStartDate AND StDtRn = 1 THEN 'UPDATE-DEST' ELSE 'UPDATE' END AS DerivedIndicator"
                            ,"NewDistId"
                            ,"'C8' as RecordType")

    src_same_ins_df = src_same_df.filter((col('MemberProvEffDate') > col('OldCoverageStartDate')) & (col('StDtRn') == 1))\
                        .selectExpr(*select_list
                        ,"MemberProvEffDate AS CoverageStartDate"
                        ,"CASE WHEN BeforeDate IS NULL THEN MemberProvEndDate WHEN MemberProvEndDate > OldCoverageStartDate THEN DATEADD(day,-1,BeforeDate) ELSE MemberProvEndDate END AS CoverageEndDate"
                        ,"'INSERT' AS DerivedIndicator"
                        ,"NewDistId"
                        ,"'C9' as RecordType")

    remove_duplicate_ins_df = src_same_ins_df.join(src_same_upd_df,['MemberKey', 'CoverageStartDate', 'CoverageEndDate'],'leftAnti')

    src_same_append_df = src_same_upd_df.unionByName(remove_duplicate_ins_df)

    memb_cov_adjst_dfs = [src_dt_same_append_df, final_src_dt_diff_ins_df, src_dt_diff_append_df, src_same_append_df, non_overlap_cov_df, new_coverage_df, mul_src_diff_append_df]

    mem_cov_adjst_df = union_by_name(memb_cov_adjst_dfs)
except Exception as e:
    excep = 'handling one input coverage overlapping with multiple existing coverage failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write processed data to intermediate table
try:
    # Filter derived indicator = 'UPDATE-DEST' and select CoverageEndDate(derived column) and rest of the columns from member coverage table.
    updt_old_df = mem_cov_adjst_df.filter(col('DerivedIndicator') == 'UPDATE-DEST')\
                        .selectExpr(*old_select_list)
    # Filter derived indicator = 'INSERT' or 'UPDATE and select required column from inbound file.
    updt_ins_df = mem_cov_adjst_df.filter(col('DerivedIndicator').isin(['UPDATE', 'INSERT']))\
                        .selectExpr(*updt_ins_select_list)
    final_df = union_by_name([updt_old_df, updt_ins_df])
    # Write member coverage adjusted data to delta table.
    write_df_as_delta_table(final_df, mem_cov_adj_table_name, part_col = 'DerivedIndicator', mode='append')
    # clear cached data.
    exists_coverage_df.unpersist()

except Exception as e:
    excep = 'Identify Overlap and Non-Overlap coverages failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Join with customer product  tables, and senect required columns
try:
    
    # read member coverage adjusted table
    mem_cov_adj_uni_df = read_table_to_df(mem_cov_adj_table_name)\
                        .filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE']))\
                        .drop('ProductKey', 'ExtProdSeqNo')

    not_consecutive_calc_df = cust_prod_joined_df.selectExpr("*", "CASE WHEN (CustomerProductStartDate <> LAG(CustomerProductEndDate) OVER (PARTITION BY CIGroupIdentifier, BenefitSequence, CIClassNumber,MarketNumber, ProductCategoryCode, ProductId, ProductKey, ExtProdSeqNo ORDER BY CustomerProductStartDate) + INTERVAL 1 DAY) = true THEN 1 ELSE 0 END AS NotConsecutive")

    cal_group_no_df = not_consecutive_calc_df.selectExpr("*", "SUM(NotConsecutive) OVER (PARTITION BY CIGroupIdentifier, BenefitSequence, CIClassNumber,MarketNumber, ProductCategoryCode, ProductId, ProductKey, ExtProdSeqNo ORDER BY 1) GroupNo")


    calc_st_ed_date_df = cal_group_no_df.groupBy("CIGroupIdentifier", "BenefitSequence", "CIClassNumber", "MarketNumber", "ProductCategoryCode", "ProductId", "ProductKey", "ExtProdSeqNo", "GroupNo").agg(min("CustomerProductStartDate").alias("CustomerProductStartDate")
                                ,max("CustomerProductEndDate").alias("CustomerProductEndDate")).drop('GroupNo')

    # Join with CustomerProduct table to get LineOfBusiness.
    join_condition = ((col('M.MemberCustomerNumber') == col('CP.CIGroupIdentifier'))
                        & (col('M.MemberGroupNumber') == col('CP.BenefitSequence'))
                        & (col('M.CIClassNumber') == col('CP.CIClassNumber'))
                        & (col('M.LedgerNumber') == col('CP.MarketNumber'))
                        & (col('M.CoverageStartDate') <= col('CP.CustomerProductEndDate'))
                        & (col('M.CoverageEndDate') >= col('CP.CustomerProductStartDate')))

    mem_joined_cust_prod_df = mem_cov_adj_uni_df.alias('M')\
                                .join(calc_st_ed_date_df.alias('CP'), join_condition, 'left')\
                                .selectExpr("M.*"
                                            ,"CP.CustomerProductStartDate"
                                            ,"CP.CustomerProductEndDate"
                                            ,"CP.ProductCategoryCode"
                                            ,"CP.ProductKey"
                                            ,"CP.ExtProdSeqNo")
except Exception as e:
    excep = 'Join with customer and customer product  tables, and senect required columns failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Provider Selection

# COMMAND ----------

# DBTITLE 1,Provider selection for new and exists member coverage.
try:                    
    # Calculate GateKeeperProviderId, GateKeeperProviderSuffixCode and GateKeeperProviderTypeCode using SelectedProvider indicator.
    col_maps = {
        "GateKeeperProviderId" : when(col('SelectedProvider') == 'CI', col('GateKeeperProviderId'))\
                                    .when((col('SelectedProvider') == 'Dummy Provider'), col('LedgerNumber') * 10000)\
                                        .when(col('SelectedProvider') == 'Exists', col('OldGateKeeperProviderId')).cast('int'),
        "GateKeeperProviderSuffixCode" : when(col('SelectedProvider') == 'CI', col('GateKeeperProviderSuffixCode'))\
                                            .when(col('SelectedProvider') == 'Dummy Provider', lit("  "))\
                                                .when(col('SelectedProvider') == 'Exists', col('OldGateKeeperProviderSuffixCode')).cast('string')
    }
    # calculate SelectedProvider indicator.
    new_cov_prov_selection_df = mem_joined_cust_prod_df\
                .withColumn('SelectedProvider', when((col('ProductCategoryCode') == 'PPO') \
                                    & ((col('GateKeeperProviderId').like('%0000')) | col('GateKeeperProviderId').isNull()) \
                                    & (~col('OldGateKeeperProviderId').like('%0000')), lit('Exists'))\
                                .when((col('ProductCategoryCode') != 'HMO')\
                                    & (col('GateKeeperProviderId').isNull()), lit('Dummy Provider'))\
                    .otherwise(lit('CI')))\
                .withColumns(col_maps)
except Exception as e:
    excep = 'Provider selection for new and exists member coverage failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Provider Validation

# COMMAND ----------

# DBTITLE 1,Validate provider and get ProviderKey.
try:
    # When there are two records with the same provider Id and Suffix Code, one being a doctor and the other a hospital, prioritize the doctor record in this case.

    provider_df = read_table_to_df(provider_table_name)\
                    .selectExpr('ProviderKey',"cast(ProviderId AS int) AS ProviderId", 'SuffixCode', 'Type2Code')

    prt_prov_df = prioritize_prv_type2Code(provider_df)

    prv_join_condition = ((col('Delta.GateKeeperProviderId') == col('PRV.ProviderId'))
                            & (trim(col('Delta.GateKeeperProviderSuffixCode')) == trim(col('PRV.SuffixCode'))))
    
    # Join delta dataframe with provider and get provider key.
    prov_joined_df = new_cov_prov_selection_df.alias('Delta')\
                        .join(prt_prov_df.alias('PRV'),prv_join_condition,'Left')\
                        .selectExpr('Delta.*','PRV.ProviderKey')

    prov_joined_df.cache()
    # Filter out valid and invalid providers.
    valid_prv_df = prov_joined_df.filter(col('ProviderKey').isNotNull())
    invalid_prv_df = prov_joined_df.filter(col('ProviderKey').isNull())\
                    .select("Id").drop_duplicates()

    # Add comment and error code column to invalid_prv_df.
    invalid_prv_cols_added_df = add_comment_error_cols_to_df(invalid_prv_df,f'Provider not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(provider_table_name)}', 'E8')

    # Update Rejected provider to stage member coverage queue table.
    invalid_records_set_dict = {
                    "Comment" : f"updates.Comment",
                    "ErrorCode" : f"updates.ErrorCode",
                    "ModifiedDateTime" : current_timestamp(),
                    "ModifiedBy" : f"'{PIPELINE_NAME}'"
                }

    # Update rejected records to queue.
    update_record_to_queue(invalid_prv_cols_added_df, stage_tbl_name, invalid_records_set_dict, INBOUND_TYPE)
except Exception as e:
    excep = 'Validate provider and get ProviderKey failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Product Split

# COMMAND ----------

# DBTITLE 1,Split coverage by customer product and write it to delta table
try:
    # Split member coverage by customer product.
    cust_prd_splitted_df = split_member_coverage_by_customer_product(valid_prv_df)
    # Write to table.
    write_df_as_delta_table(cust_prd_splitted_df, cust_prd_split_table_name,part_col = 'DerivedIndicator')
    # Remove cached dataframe
    prov_joined_df.unpersist()
except Exception as e:
    excep = 'Split coverage by customer product and write it to delta table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Provider Contract Assigment

# COMMAND ----------

# DBTITLE 1,Read Provider Contract, Affiliation & Association Tables
try:
    # Read ProviderContract, ProviderContractProductAffiliation, ProductSetAffiliation and ProductSetAssociation. And select only the required columns
    pc_df = read_table_to_df(pc_table_name)\
                .filter((col('ContractStartDate') != col('ContractEndDate')) & (col('ContractEndDate') >= min_coveragedate) & (col('ProviderServiceTypeCode').isin(['PCP', 'FFS'])))\
                .selectExpr('ProviderContractKey as ProviderContractKey_pc'
                            ,'ProviderContractId as ProviderContractId_pc'
                            ,'ProviderKey as ProviderKey_pc'
                            ,'ProviderId as ProviderId_pc'
                            ,'ProviderSequenceNumber'
                            ,'ContractStartDate'
                            ,'ContractEndDate')
                
    pcpa_df = read_table_to_df(pc_prd_affil_table_name)\
                    .selectExpr("ProductAffiliationKey", "ProviderContractKey", "ProviderContractId")
    psaff_df = read_table_to_df(pc_prd_set_affil_table_name)\
                    .selectExpr("ProductAffiliationKey", "ProductSetKey")
    psass_df = read_table_to_df(pc_prd_set_asso_table_name)\
                    .selectExpr("ProductKey", "ProductSetKey")

    cust_prd_splitted_df = read_table_to_df(cust_prd_split_table_name)

    cust_prd_splitted_df.cache()
except Exception as e:
    excep = 'Read Provider Contract, Affiliation & Association tables failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Provider Contract Assignment.
try:
    # Contract assigments are done only for new coverages.
    dlt_upt_ins_df = cust_prd_splitted_df.filter((col('DerivedIndicator').isin(['INSERT', 'UPDATE'])))

    # Contract Assignment
    pc_assigned_df, rejected_upt_ins_df = assign_providercontract(dlt_upt_ins_df, pc_df, pcpa_df, psaff_df, psass_df, pc_table_name)
    rejected_upt_ins_df = rejected_upt_ins_df.select("Id", "Comment", "ErrorCode", "MemberKey", "CoverageStartDate")

    upt_ins_rej_cond = ((col('LH.MemberKey') == col('UI.MemberKey')) 
                        & (col('LH.CoverageStartDate') > col('UI.CoverageStartDate')))

    pc_processed_df = pc_assigned_df.alias('LH')\
                            .join(rejected_upt_ins_df.alias('UI'), upt_ins_rej_cond, 'left')\
                            .selectExpr("LH.*", "UI.MemberKey as MemberKeyRej")

    rejected_processed_df = pc_processed_df.filter((col('MemberKeyRej').isNotNull()))\
                    .selectExpr("Id", "'Cannot process this coverage as dependent coverage transaction failed' as Comment", "'E12' as ErrorCode")

    pc_processed_df = pc_processed_df.filter((col('MemberKeyRej').isNull())).drop('MemberKeyRej')
except Exception as e:
    excep = 'Provider Contract Assignment failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,remove duplicates from rejected records
try:
    # Update Comment and ErrorCode in StageMemberCoverageQueue table for rejected records.
    rejected_records_dfs = [rejected_upt_ins_df.select("Id", "Comment", "ErrorCode"), rejected_processed_df]

    # RecordType - Getting updates for split records. If records rejected in this scenario there will be duplicates. Row number was added for deduplication.
    ws = Window.partitionBy("Id").orderBy('ErrorNo')
    rejected_records_df = union_by_name(rejected_records_dfs)\
                            .selectExpr("*", "substring(ErrorCode, 2, length(ErrorCode)) AS ErrorNo")                       

    rejected_records_df = rejected_records_df.selectExpr("*"
                                    ,"row_number() OVER(PARTITION BY Id ORDER BY ErrorNo) AS ErrorRn")\
                                    .filter(col('ErrorRn') == 1).drop('ErrorNo', 'ErrorRn')
except Exception as e:
    excep = 'Update rejected records to queue failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Update process status to Member Coverage Queue table.
try:
    # Dictonary contains columns for rejected transaction to update in stage member coverage queue table.
    invalid_set_dict = {
                    "Comment" : f"updates.Comment",
                    "ErrorCode" : f"updates.ErrorCode",
                    "ModifiedDateTime" : current_timestamp(),
                    "ModifiedBy" : f"'{PIPELINE_NAME}'"
                }

    # Dictonary contains columns for processed transaction to update in stage member coverage queue table.
    valid_set_dict = {
                    "ProcessedDate": current_date(),
                    "IsProcessed": "'Y'",
                    "Comment" : "null",
                    "ErrorCode" : "null",
                    "ModifiedDateTime" : current_timestamp(),
                    "ModifiedBy" : f"'{PIPELINE_NAME}'"
    }
    
    removed_dup_df = pc_processed_df.join(rejected_records_df, ['Id'], 'LeftAnti')

    prc_rej_union_df = union_by_name([removed_dup_df.selectExpr('Id', "'N' as IsRejected"), rejected_records_df.selectExpr('*', "'Y' as IsRejected")]).drop_duplicates()

    # Update processed and rejeced transaction to StageMemberCoverageQueue table.
    apply_custom_scd_type(prc_rej_union_df, stage_tbl_name, valid_set_dict, invalid_set_dict, INBOUND_TYPE)
    
except Exception as e:
    excep = f'Update process status to Member Coverage Queue table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Add columns and write to ProviderContractSplit delta table.
try:
    # Add CreatedBy, CreatedDateTime, ModifiedBy, ModifiedDateTime, ProcessName, CoverageTypeCode, CoverageTypeCodeLabel, VendorSequenceNumber, CoverageEndReasonCodeLabel and DeltaStatus to dataframe.
    col_map = {
        "CreatedBy" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedBy')).otherwise(audit_name)
        ,"CreatedDateTime" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedDateTime')).otherwise(current_timestamp())
        ,"ModifiedBy" : when(col('DerivedIndicator').isin(['UPDATE', 'DELETE']), \
                                when((col('ModifiedBy').contains('#mbr_attr_of')) & (col('SelectedProvider') == 'Exists'), f"{audit_name}'#mbr_attr_of'")\
                                .otherwise(lit(audit_name)))\
                        .otherwise(None)
        ,"ModifiedDateTime" : when(col('DerivedIndicator').isin(['UPDATE', 'DELETE']), current_timestamp()).otherwise(None)
        ,"ProcessName" : lit(process_name).cast("string")
        ,"DeltaStatus" : lit(None).cast("string")
        ,"GateKeeperProviderId" : lpad(col("GateKeeperProviderId"), 9, '0')
    }

    
    mem_cov_upt_adj_df = read_table_to_df(mem_cov_adj_table_name)\
                        .filter(col('DerivedIndicator').isin(['UPDATE-DEST', 'DELETE']))\
                        .withColumn('DerivedIndicator', when(col('DerivedIndicator') == 'UPDATE-DEST', lit('UPDATE')).otherwise(lit('DELETE')))

    
    pc_processed_df = pc_processed_df.withColumn('CoverageEndReasonCode', expr("CASE WHEN DerivedIndicator = 'INSERT' THEN CASE WHEN CoverageEndDate = '9999-12-31' THEN '  ' WHEN trim(CoverageEndReasonCode) = '' THEN 'MT' ELSE CoverageEndReasonCode END WHEN DerivedIndicator = 'UPDATE' THEN CASE WHEN CoverageEndDate = '9999-12-31' THEN '  ' WHEN trim(OldCoverageEndReasonCode) = '' AND trim(CoverageEndReasonCode) = '' THEN 'SG' WHEN trim(CoverageEndReasonCode) = '' THEN OldCoverageEndReasonCode  ELSE CoverageEndReasonCode END ELSE OldCoverageEndReasonCode END"))

    mem_cov_processed_df = union_by_name([mem_cov_upt_adj_df,pc_processed_df])\
                            .withColumns(col_map)

    # Write to ProviderContractSplit table. 
    write_df_as_delta_table(mem_cov_processed_df, mem_cov_proc_table_name)
    
    # Remove cached dataframe
    cust_prd_splitted_df.unpersist()

except Exception as e:
    excep = f'Add columns and write to ProviderContractSplit delta table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Change column nullables and Write data to Azure SQL stage table
try:
    # Read from ProviderContractSplit table.
    prv_ctrt_splitted_df = read_table_to_df(mem_cov_proc_table_name)\
                    .drop('SelectedProvider', 'RecordType', 'IsCoverageOverlap', 'IsNewCoverage', 'LedgerNumber', 'ProviderKey', 'Id', 'IsProviderChanged', 'OldGateKeeperProviderId', 'OldGateKeeperProviderSuffixCode', 'OldCoverageEndReasonCode', 'InboundType')

    # Change column nullable to False.
    delta_df= set_df_columns_not_nullable(spark,prv_ctrt_splitted_df,['MemberKey', 'ProviderContractKey', 'ProductKey','CoverageStartDate', 'CreatedBy','CreatedDateTime'])
    
    # Change column nullable to True.
    delta_col_df = set_df_columns_not_nullable(spark,delta_df,['ProcessName', 'CoverageTypeCode', 'CoverageTypeCodeLabel', 'VendorSequenceNumber', 'DerivedIndicator', 'CoverageEndDate'], True)
    
    # Write data to Azure SQL stage table.
    load_df_to_sf_sql_db_spark(delta_col_df, mem_cov_sql_tbl_name)
except Exception as e:
    excep = f'Write data to Azure SQL {mem_cov_sql_tbl_name} table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Archive Processed data to history table

# COMMAND ----------

# DBTITLE 1,Read processed data from stage table and move to history table
try:
  stg_mem_cov_df = read_table_to_df(stage_tbl_name)\
                        .filter((col('IsProcessed') == 'Y') & (col('InboundType') == INBOUND_TYPE))

  stg_filtered_df = stg_mem_cov_df\
                        .withColumn("Comment" , when(col('ErrorCode').isin(['E1','E2','E3', 'E7', 'E13']), col('Comment'))\
                                      .otherwise(None).cast('string'))\
                        .withColumn("ErrorCode" , when(col('ErrorCode').isin(['E1','E2','E3', 'E7']), col('ErrorCode'))\
                                      .otherwise(None).cast('string'))

  # Write data to HistoryMemberCoverageTable.
  write_df_as_delta_table(stg_filtered_df, history_tbl_name, part_col='LoadDate, RunId',mode='append')
  
  # Remove processsed data from the StageMemberCoverageQueueTable.
  deltaTable = DeltaTable.forName(spark, stage_tbl_name)
  deltaTable.delete((col('IsProcessed') == 'Y') & (col('InboundType') == INBOUND_TYPE))
except Exception as e:
    excep = 'Read processed data from stage table and move to history table failed: ' + str(e)
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Error Report Creation

# COMMAND ----------

# DBTITLE 1,Write rejected records to error report
try:
    
    stg_mem_cov_df = read_table_to_df(stage_tbl_name)\
                            .filter((col('IsProcessed').isNull()) & (col('InboundType') == INBOUND_TYPE))\
                            .withColumn('Reprocess', lit('Y'))

    hist_mem_cov_df = read_table_to_df(history_tbl_name)\
                            .filter((col('LoadDate') == current_date()) & (col('ErrorCode').isin(['E1','E2','E3', 'E7'])) & (col('RunId') == PIPELINE_RUN_ID) & (col('InboundType') == INBOUND_TYPE))\
                            .withColumn('Reprocess', lit('N'))

    union_df = union_by_name([stg_mem_cov_df,hist_mem_cov_df])\
                .selectExpr('ReenrchgPcaFinRptLedgrNbr','ReenrchgMbrEnrlCustNbr','ReenrchgMbrEnrlGrpNbr','CIGroupIdentifier','CIClassNumber',
                    'BenefitSequence','ReenrchgMbrpid','ReenrchgSubpid','ReenrchgGkProvIdNbr','ReenrchgGkProvSuffCd','ReenrchgGkProvTyCd','ReenrchgMbrProvEffCymd','ReenrchgMbrProvEndCymd','ReenrchgProcessAgainCounter','ReenrchgWorkcmpOccurPId','ReenrchgPrevPcpEndReasCd','ReenrchgCurrPcpEndReasCd','ReenrchgPcpReasonIndicator','LoadDate','Reprocess','ErrorCode','Comment')
                
    # Report generation
    generate_report(union_df, outbnd_temp_err_csv_path, outbnd_csv_path, err_file_name)
except Exception as e:
    excep = 'Write rejected records to outbound file failed: ' + str(e)
    filter_con = f"LoadDate = current_date() AND RunId = '{PIPELINE_RUN_ID}'"
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    delete_data_from_table(history_tbl_name, filter_con)
    raise Exception(excep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Success Report Creation

# COMMAND ----------

# DBTITLE 1,Write processed records to success report
try:
    hist_mem_cov_df = read_table_to_df(history_tbl_name)\
                            .filter((col('ErrorCode').isNull()) & (col('RunId') == PIPELINE_RUN_ID) & (col('InboundType') == INBOUND_TYPE))\
                            .selectExpr('ReenrchgPcaFinRptLedgrNbr','ReenrchgMbrEnrlCustNbr','ReenrchgMbrEnrlGrpNbr','CIGroupIdentifier','CIClassNumber','BenefitSequence','ReenrchgMbrpid','ReenrchgSubpid','ReenrchgGkProvIdNbr','ReenrchgGkProvSuffCd','ReenrchgGkProvTyCd','ReenrchgMbrProvEffCymd','ReenrchgMbrProvEndCymd','ReenrchgProcessAgainCounter','ReenrchgWorkcmpOccurPId','ReenrchgPrevPcpEndReasCd','ReenrchgCurrPcpEndReasCd','ReenrchgPcpReasonIndicator','ProcessedDate','LoadDate',"'Processed' AS Comment")
    # Report generation
    generate_report(hist_mem_cov_df, outbnd_temp_success_csv_path, outbnd_csv_path, success_file_name)
except Exception as e:
    excep = 'Write processed records to success outbound file failed: ' + str(e)
    filter_con = f"LoadDate = current_date() AND RunId = '{PIPELINE_RUN_ID}'"
    handle_member_coverage_exception(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type , audit_start_date_time, 'Failed' ,audit_table_name, excep,stg_hist_version_num, stage_tbl_name)
    delete_data_from_table(history_tbl_name, filter_con)
    raise Exception(excep)

# COMMAND ----------

# Insert success entry to the audit table.
insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Success' ,audit_table_name, None, process ="DBP")
# Exit outbound file names
concated_outbound_file_names =  err_file_name+','+success_file_name
dbutils.notebook.exit(concated_outbound_file_names)
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0047 - The main purpose of this job is to create a process to update SF Customer Member Benefit data and keep it in sync with CI Customer Member Benefit data from CI application
# MAGIC ###### Source Details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - IN_CI_ITOSBSNP_CCYYMMDD.TXT
# MAGIC - Member.Member
# MAGIC - Member.MemberCoverage
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.Re0047DailyProcess
# MAGIC
# MAGIC ###### Target Details:
# MAGIC - Member.StageDBPMemberORDRHeader
# MAGIC - Member.StageDBPMemberORDRRDetail
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import ingest notebook
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0047DailyProcess')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')


# COMMAND ----------

# DBTITLE 1,import necessary packages.
import json
from pyspark.sql.types import DecimalType
from pyspark.sql.functions import max, lit, monotonically_increasing_id

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    default_in_config = default_config["Inbound"]
    re0047_config = config_dict[JOB_NAME]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    file_path_suffix = default_in_config['FilePathSuffix']
    config = default_out_config["Config"]
    curated_path_suffix = re0047_config["Outbound"]["CuratedFilePathSuffix"]
    tbl_name = re0047_config["Outbound"]["TableName"]
    inbound_file = re0047_config["Inbound"]["InFile"]
    mbr_tbl_name = re0047_config["Inbound"]["StageMember"]
    mbr_cvrg_tbl_name = re0047_config["Inbound"]["StageMemberCoverage"]
    ordr_header_tbl_name = re0047_config["Inbound"]["ORDRHeaderTableName"]
    ordr_detail_tbl_name = re0047_config["Inbound"]["ORDRDetailTableName"]   
    sync_process_names = re0047_config["Inbound"]["StageSyncDependencyProcess"]
    ctrl_table_name = default_config["AuditTableName"]

except Exception as e:
    excep = "Variable assignment from FileConfig: ", str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(ctrl_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    curated_delta_path = abfss_path_builder(
        container_name, storage_account,  file_path_prefix,curated_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
    inbnd_file_path = abfss_path_builder(
        container_name, storage_account, file_path_suffix,inbound_file
    )
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read data from ADLS.
try:
    # Read inbound from ADLS 
    inbound_file_df = read_inbound_csv_file(inbnd_file_path)

    # Read ordr_header from stage table
    ordr_header_df = read_table_to_df(ordr_header_tbl_name).distinct()

    # Read ordr_detail from stage table
    ordr_detail_df = read_table_to_df(ordr_detail_tbl_name).distinct()

    # Read Member from stage table
    mbr_df = read_table_to_df(mbr_tbl_name)
    
    # Read MemberCoverage from stage table
    mbr_cvrg_df = read_table_to_df(mbr_cvrg_tbl_name)
    
except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter and select distinct records of MemberCoverage 
try:
    # Do groupBy on MemberKey and CI fields in Member Coverage 
    filtered_mbr_cvrg_df=mbr_cvrg_df.select("MemberKey","MemberCustomerNumber","MemberGroupNumber","CIClassNumber").groupBy("MemberKey","MemberCustomerNumber","MemberGroupNumber","CIClassNumber").count()

    #select distinct records
    filtered_mbr_cvrg_df=filtered_mbr_cvrg_df.distinct()

except Exception as e:
    excep = "Filter and select distinct records of MemberCoverage failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1, Join Member and MemberCoverage table to get MemberId
try:
    # Join Member and MemberCoverage table to get MemberId
    mbr_with_mbrcvrg_df = (
        filtered_mbr_cvrg_df.alias("LH")
        .join(mbr_df.alias("RH"), (col("LH.MemberKey") == col("RH.MemberKey")), "left")
        .select("LH.MemberKey", "RH.MemberId","RH.SubscriberId","LH.MemberCustomerNumber","LH.MemberGroupNumber","LH.CIClassNumber")    
    )
except Exception as e:
    excep = "Join Member and MemberCoverage table to get MemberId failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter Coverage dates
try:
    filtered_inbnd_df=inbound_file_df.filter(trim(col("OSB_EFF_DATE"))!=trim(col("OSB_END_DATE")))

except Exception as e:
    excep = "Filter Coverage dates failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter RiderCodes DEN/VIS/HER
try:
  #Filter RiderCodes DEN/VIS/HER
    calc_inbnd_df=filtered_inbnd_df.filter((trim(col("OSB_ITEM_TYPE_CD(1)"))=='DEN') | (trim(col("OSB_ITEM_TYPE_CD(1)"))=='VIS') | (trim(col("OSB_ITEM_TYPE_CD(1)"))=='HER'))

except Exception as e:
    excep = "Filter RiderCodes failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join the final dataset with Member table 
try:
    # join the final dataset with Member table to check if member exists not not
    calc_final_df = (
        calc_inbnd_df.alias("LH")
        .join(
            mbr_with_mbrcvrg_df.alias("RH"),
            (col("LH.OSB_CI_GRP_NBR") == col("RH.MemberCustomerNumber"))
            & (col("LH.OSB_CI_BENEFIT") == col("RH.MemberGroupNumber"))
            & (col("LH.OSB_CLASS_NBR") == col("RH.CIClassNumber"))
            & (col("LH.OSB_MBR_PERS_ID") == col("RH.MemberId"))
            & (col("LH.OSB_SUB_PERS_ID") == col("RH.SubscriberId")),
            "inner",
        ).select("LH.*",col("LH.OSB_GH_GRP_NBR").alias("ORDRCustomerNumber"),col("LH.OSB_SUBGROUP").alias("GroupNumber"))
    )
except Exception as e:
    excep = "Join the final dataset with Member table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename column names to match domain table column names
try:
        calc_final_df=calc_final_df.select(
        "ORDRCustomerNumber",
        col("GroupNumber").alias("ORDRGroupNumber"),
        col("OSB_CLASS_NBR").alias("ORDRClassNumber"),
        col("OSB_MBR_PERS_ID").alias("MemberId"),
        col("OSB_SUB_PERS_ID").alias("SubscriberId"),
        col("OSB_ITEM_TYPE_CD(1)").alias("RiderCode"),
        col("OSB_EFF_DATE").alias("RiderStartDate"),
        col("OSB_END_DATE").alias("RiderEndDate"),
        col("OSB_DEN_CD").alias("RiderPlanNumber")
        )
except Exception as e:
    excep = "Join the final dataset with Member table failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ORDRHeader and ORDR Detail
try:
    #Join ORDRHeader and ORDR Detail
    ordr_hdr_detail_df=ordr_header_df.alias("LH").join(ordr_detail_df.alias("RH"),(col("LH.MemberORDRHeaderKey")==col("RH.MemberORDRHeaderKey")),"left").select("LH.*",
    "RH.MemberORDRDetailKey",
    "RH.RiderCode",
    "RH.RiderPlanNumber",
    "RH.RiderOptNumber",
    "RH.BrandCopayAmount",
    "RH.GenericCopayAmount",
    "RH.RiderStartDate",
    "RH.RiderEndDate",
    col("RH.CreatedDateTime").alias("CreatedDateTime_dtl"),
    col("RH.ModifiedBy").alias("ModifiedBy_dtl"),
    col("LH.CreatedDateTime").alias("CreatedDateTime_hdr"),
    col("LH.ModifiedBy").alias("ModifiedBy_hdr"),
    col("LH.CreatedBy").alias("CreatedBy_hdr"),
    col("LH.ModifiedDateTime").alias("ModifiedDateTime_hdr"),
    col("LH.CreatedBy").alias("CreatedBy_dtl"),
    col("LH.ModifiedDateTime").alias("ModifiedDateTime_dtl"),
    ).drop("MemberORDRHeaderKey","DerivedIndicator","ModifiedBy","CreatedDateTime","ModifiedDateTime","CreatedBy")
except Exception as e:
    excep = "Join ORDRHeader and ORDR Detail failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
col_dtype_schema = {
    "ORDRCustomerNumber": "STRING",
    "ORDRGroupNumber": "STRING",
    "ORDRClassNumber":"STRING",
    "MemberId": "STRING",
    "SubscriberId": "STRING",
    "SourceSystemCode": "STRING",
    "RiderCode": "STRING",
    "RiderPlanNumber": "STRING",
    "RiderOptNumber": "STRING",
    "BrandCopayAmount": "DECIMAL(20,6)",
    "GenericCopayAmount": "DECIMAL(20,6)",
    "RiderStartDate": "DATE",
    "RiderEndDate": "DATE",
    "CreatedDateTime_dtl": "TIMESTAMP",
    "ModifiedBy_dtl": "STRING",
    "CreatedDateTime_hdr": "TIMESTAMP",
    "ModifiedBy_hdr": "STRING",
    "CreatedBy_hdr": "STRING",
    "ModifiedDateTime_hdr": "TIMESTAMP",
    "CreatedBy_dtl": "STRING",
    "ModifiedDateTime_dtl": "TIMESTAMP",
}

# COMMAND ----------

# DBTITLE 1,Trim leading and trailing spaces of datasets
try:
    #Trim leading and trailing spaces of joined tables dataset.
    dtype_df=trim_leading_trailing_space(ordr_hdr_detail_df)
    
    #Trim leading and trailing spaces of inbound files dataset.
    inbnd_dtype_df=trim_leading_trailing_space(calc_final_df)
      
except Exception as e:
    excep = "Trim leading and trailing spaces of datasets failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create Hashkey
try:
    #Create Hashkey using md5 function
    ordr_hdr_detail_df=dtype_df.withColumn("HashKey",md5(concat(col("ORDRCustomerNumber"), col("ORDRGroupNumber"),col("ORDRClassNumber"),col("MemberId"),col("SubscriberId"), col("RiderStartDate")))).withColumn("DerivedIndicator",lit(''))

    #Datatype conversion
    dtype_tbls_df = dtype_conversion(ordr_hdr_detail_df, col_dtype_schema)
    
except Exception as e:
    excep = "Creation of  Hashkey failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Add columns to create CI customer dataset
try:
    #Add columns to create CI customer dataset
    calc_final_df1=inbnd_dtype_df.withColumn("RiderOptNumber",lit("")).withColumn("GenericCopayAmount",lit("0").cast(DecimalType(20,6))).withColumn("BrandCopayAmount",lit("0").cast(DecimalType(20,6)))
    
except Exception as e:
    excep = "Adding columns to create CI customer dataset failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Add columns to balance schema
try:
    #Add columns to balance schema
    curr_calc_df =calc_final_df1.selectExpr(
    "*", 
    "'LV' as SourceSystemCode",
    "md5(concat(ORDRCustomerNumber, ORDRGroupNumber,ORDRClassNumber,MemberId,SubscriberId, RiderStartDate)) as HashKey",
    "current_timestamp() as CreatedDateTime_hdr",
    "current_timestamp() as CreatedDateTime_dtl",
    f"'{PIPELINE_NAME}' as CreatedBy_hdr",
    f"'{PIPELINE_NAME}' as CreatedBy_dtl",
    "cast(null as timestamp)as ModifiedDateTime_hdr",
    "cast(null as timestamp)as ModifiedDateTime_dtl",
    "cast(null as string) as ModifiedBy_hdr",
    "cast(null as string) as ModifiedBy_dtl",
    "cast(null as string) as DerivedIndicator",
    )
    # Datatypeconversion
    dtype_curr_df = dtype_conversion(curr_calc_df, col_dtype_schema)
except Exception as e:
    excep = "Add columns to balance schema failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create Column list, which is used for processing.
def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,Create Column list
try:
    # Create Column list. Which is used for processing.
    new_col_slt_lst = ordr_hdr_detail_df.columns
    col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)
except Exception as e:
    excep = "Create Column list failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Add suffix 'Old' to column name for existing data to avoid column ambiguous.
try:
    # Add suffix 'Old' to column name for existing data to avoid column ambiguous.
    old_renamed_df = ordr_hdr_detail_df.selectExpr(*col_select_lst)
    
except Exception as e:
    excep = "Add suffix 'Old' to column name for existing data to avoid column ambiguous failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Delta Processing
try:
    # Join previous day with current day data to identify delta data.
    old_joined_df = curr_calc_df.alias("LH").join(old_renamed_df.alias("RH"),(col("LH.HashKey") == col("RH.OldHashKey"))
                                        & (col("RiderCode")==col("OldRiderCode")) & (col("RiderPlanNumber")==(col("OldRiderPlanNumber"))), "left").selectExpr("*","OldMemberORDRDetailKey as MemberORDRDetailKey")                            
    ins_df = old_joined_df\
            .filter((col('OldHashKey').isNull()))\
            .withColumn('DerivedIndicator', lit('INSERT'))\
            .drop(*col_drop_lst)
            
    upds_df = old_joined_df\
            .filter((col('OldHashKey').isNotNull()))\
            .withColumn("DerivedIndicator",when((col("RiderPlanNumber").eqNullSafe(col("OldRiderPlanNumber")))
            & (col("GenericCopayAmount").eqNullSafe(col("OldGenericCopayAmount")))
            & (col("RiderEndDate").eqNullSafe(col("OldRiderEndDate")))
            & (col("BrandCopayAmount").eqNullSafe(col("OldBrandCopayAmount"))),
            lit("IGNORE"),
            ).otherwise(lit("UPDATE")))

    # Calculate ModifiedBy and ModifiedDateTime.
    # If it is update set the modifiedDateTime as current timestamp and modifiedBy as task name.
    col_maps = {
        "ModifiedDateTime_hdr": when(col("DerivedIndicator") == "UPDATE", lit(current_timestamp()))\
                                    .otherwise(col("OldModifiedDateTime_hdr")),
        "ModifiedBy_hdr": when(col("DerivedIndicator") == "UPDATE", lit(PIPELINE_NAME))\
                                    .otherwise(col("OldModifiedBy_hdr")),
        "CreatedBy_hdr": col("OldCreatedBy_hdr"),
        "CreatedDateTime_hdr": col("OldCreatedDateTime_hdr"),
        "ModifiedDateTime_dtl": when(col("DerivedIndicator") == "UPDATE", lit(current_timestamp()))\
                                    .otherwise(col("OldModifiedDateTime_dtl")),
        "ModifiedBy_dtl": when(col("DerivedIndicator") == "UPDATE", lit(PIPELINE_NAME))\
                            .otherwise(col("OldModifiedBy_dtl")),
        "CreatedBy_dtl": col("OldCreatedBy_dtl"),
        "CreatedDateTime_dtl": col("OldCreatedDateTime_dtl"),
    }

    calc_audit_col_upds_df = (
        upds_df.withColumns(col_maps)
        .drop("OldCreatedDateTime_hdr","OldModifiedBy_hdr","OldCreatedBy_hdr"
                ,"OldModifiedDateTime_hdr","OldCreatedDateTime_dtl","OldModifiedBy_dtl","OldCreatedBy_dtl","OldModifiedDateTime_dtl")
        .select(*new_col_slt_lst)
    )


except Exception as e:
    excep = "Identify Delta record failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
#DELETE1 - Deleting according to below condition:
# For particular Customer + RiderCode, if records are missing between the 3 year window in CI file, then wil Delete it 

    #Creating Minimum effective date and max eff date columns
    df_ci_min_max = curr_calc_df.groupBy('ORDRCustomerNumber','ORDRGroupNumber','ORDRClassNumber','RiderCode')\
                    .agg(min(col('RiderStartDate')).alias('minEffDt'),max(col('RiderStartDate')).alias('maxEffDt'))

    cond2 = ((col("LH.OldORDRCustomerNumber") == col("RH.ORDRCustomerNumber"))
                &(col('LH.OldORDRGroupNumber') == col("RH.ORDRGroupNumber"))\
                &(col('LH.OldORDRClassNumber') == col("RH.ORDRClassNumber")) 
                & (col('LH.OldRiderCode') == col("RH.RiderCode"))
                & (col('LH.OldRiderStartDate') >= col('RH.minEffDt')) 
                & (col('LH.OldRiderStartDate') <= col('RH.maxEffDt')))

    old_joined_df_delete_2 = old_renamed_df.alias("LH")\
                            .join(df_ci_min_max.alias("RH"),(cond2),"inner")\
                            .selectExpr('LH.*')

    cond3 = ((col("LH.OldHashKey") == col("RH.HashKey")) 
            & (col('LH.OldRiderCode') == col("RH.RiderCode")))

    
    del_ignr_df = old_joined_df_delete_2.alias("LH")\
                    .join(curr_calc_df.alias("RH"),(cond3),"left")\
                    .selectExpr('LH.*', 'RH.HashKey')\
                    .withColumn('OldDerivedIndicator', when(col('RH.HashKey').isNull(), 'DELETE'))\
                    .drop('HashKey')
                    
    rename_col_name_del_df = del_ignr_df\
                        .filter(col('OldDerivedIndicator').isNotNull())\
                        .selectExpr(*del_col_sel_lst)


    # Union Insert, Delete and Update dataframe.
    calc_df = ins_df.unionByName(rename_col_name_del_df).unionByName(calc_audit_col_upds_df).distinct()

# DELETE2 - To handle Delete and Insert (Update) scenario-
# If a (customer+ EffDate + RiderCode) gets new plan number in CI, then this will be inserted and corresponding existing database record will be deleted:

    cond4 = ((col("LH.HashKey") == col("RH.HashKey"))
                &(col('LH.RiderCode') == col("RH.RiderCode"))\
                &(col('LH.RiderPlanNumber') == col("RH.RiderPlanNumber"))
                & (col('RH.DerivedIndicator')=='IGNORE'))
    calc_df_anti = ordr_hdr_detail_df.alias('LH').join(calc_df.alias('RH'),cond4,'left_anti')
    calc_df_del = calc_df_anti.alias('LH').join(calc_df.alias('RH'),['HashKey','RiderCode'],'inner').filter(col('RH.DerivedIndicator')=='INSERT').select('LH.*').withColumn('DerivedIndicator',lit('DELETE'))

    calc_df_final = calc_df.unionByName(calc_df_del)
                 
    # write_df_as_delta_table(calc_df_final, cur_tbl_name, mode = 'overwrite')

except Exception as e:
    excep = "Identify Delete records and failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Load data to stage table MemberORDRHeader
try:
    # Delete is not handle. Once we get the confirmation. We need to add 'DELETE to isin function'
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    hdr_df = read_table_to_df(tbl_name).filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE','DELETE']))\
                .selectExpr(
                    '*', 
                    'CreatedBy_hdr as CreatedBy',
                    'CreatedDateTime_hdr as CreatedDateTime',
                    'ModifiedDateTime_hdr as ModifiedDateTime',
                    'ModifiedBy_hdr as ModifiedBy',
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as MemberORDRHeaderKey', 
                    'cast(null as string) as ProcessName')\
                    .drop('CreatedBy_dtl', 'HashKey','ModifiedDateTime_dtl','ModifiedBy_dtl','CreatedDateTime_dtl','RiderCode','RiderStartDate','RiderEndDate','RiderPlanNumber','RiderOptNumber','GenericCopayAmount','BrandCopayAmount','CreatedBy_hdr','CreatedDateTime_hdr','ModifiedDateTime_hdr','ModifiedBy_hdr')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    hdr_upd_col_nullable_df = set_df_columns_not_nullable(spark, hdr_df, ['CreatedBy', 'CreatedDateTime'], nullable=False)

    hdr_upd_col_nullable_df1 = set_df_columns_not_nullable(spark, hdr_upd_col_nullable_df, ['DerivedIndicator'], nullable=True)
    
    # Load the data to azure sql stage table.
    # load_df_to_sf_sql_db_spark(hdr_upd_col_nullable_df1, 'Member.StageDBPMemberORDRHeader')
    
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

hdr_upd_col_nullable_df1.count()

# COMMAND ----------

# DBTITLE 1,Load data to stage table MemberORDRDetail
try:
    # Delete is not handle. Once we get the confirmation. We need to add 'DELETE to isin function'
    # Read data from the curated table and filter only the Insert, Update and Delete records.
    dtl_df = read_table_to_df(tbl_name)\
                .filter(col('DerivedIndicator').isin(['INSERT', 'UPDATE','DELETE']))\
                .selectExpr(
                    '*', 
                    'CreatedBy_dtl as CreatedBy',
                    'CreatedDateTime_dtl as CreatedDateTime',
                    'ModifiedDateTime_dtl as ModifiedDateTime',
                    'ModifiedBy_dtl as ModifiedBy',
                    'cast(null as string) as DeltaStatus',
                    'cast(null as BigInt) as MemberORDRHeaderKey',
                    'cast(null as BigInt) as MemberORDRDetailKey', 
                    'cast(null as string) as ProcessName')\
                .drop('CreatedBy_hdr', 'HashKey','ModifiedDateTime_hdr','ModifiedBy_hdr','CreatedDateTime_hdr','ReordrGenKey','CreatedBy_dtl','ModifiedDateTime_dtl','ModifiedBy_dtl','CreatedDateTime_dtl')
    
    # Convert the nullable values of the columns to match Azure SQL schema.
    dtl_upd_col_nullable_df = set_df_columns_not_nullable(spark, dtl_df, ['CreatedBy_dtl', 'CreatedDateTime_dtl'], nullable=False)

    # Load the data to azure sql stage table.
    load_df_to_sf_sql_db_spark(dtl_upd_col_nullable_df, 'Member.StageDBPMemberORDRDeatil')
except Exception as e:
    excep = 'Write processed data to Azure SQL stage table failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

output = {
      'NOTEBOOK_RUN_STATUS' : 'Success'
}
dbutils.notebook.exit(json.dumps(output))
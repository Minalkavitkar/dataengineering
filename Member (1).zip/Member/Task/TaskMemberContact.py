# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Objective
# MAGIC - This notebook sync main catalog of CiMember table into Member.MemberContact in SQL
# MAGIC
# MAGIC ##### Source Files 
# MAGIC - CI_Member
# MAGIC
# MAGIC ##### Target Table
# MAGIC - Member.MemberContact
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper Notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest Notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load Notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,setting global parameters
dbutils.widgets.text('PIPELINE_NAME','NB_TaskSyncMemberContact')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_TYPE', 'DailyJobs')
job_type = dbutils.widgets.get('JOB_TYPE')

dbutils.widgets.text('JOB_NAME','SyncMemberContact')
job_name = dbutils.widgets.get('JOB_NAME')

audit_start_date_time = datetime.now()

# COMMAND ----------

# DBTITLE 1,Getting the tables names and load into the dataframe
try: 
    file_conf_path = env_file_config_path
    config_dict = get_file_config(file_conf_path)
    audit_table_name = config_dict["DEFAULT"]["AuditTableName"]
    sync_membercon_config = config_dict["SyncMemberContact"]
    stage_member_tbl_name = sync_membercon_config["Inbound"]["stage_member_tbl_name"]
    stage_membercon_tbl_name = sync_membercon_config["Inbound"]["stage_membercon_tbl_name"]
    membercon_cur_tbl_name = sync_membercon_config["Inbound"]["membercontact_cur_tbl_name"]
    cur_cimember = sync_membercon_config["Inbound"]["cimember_cur_tbl_name"]
    member_cur_tbl_name = sync_membercon_config["Inbound"]["member_cur_tbl_name"]

    member_stage_df = read_table_to_df(stage_member_tbl_name)
    membercontact_stage_df =  read_table_to_df(stage_membercon_tbl_name)
    cimember_df = read_table_to_df(cur_cimember)
    member_cur_df = read_table_to_df(member_cur_tbl_name)
except Exception as e:
    excep = 'Reading table name or loading into dataframe failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# seelct necessary columns
col_lst = [
    'MbrPid',
    'CiGrpId',
    'MbrSubPid',
    'MailStreetAddr1',
    'MailStreetAddr2',
    'MailCityName',
    'MailZipCd',
    'MailZipPlusCd',
    'MailFipsCntyCd',
    'MailFipsCntryCd',
    'MailAdminDivCd',
    'ResiStreetAddr1',
    'ResiStreetAddr2',
    'ResiCityName',
    'ResiZipCd',
    'ResiZipPlusCd',
    'ResiFipsCntyCd',
    'ResiFipsCntryCd',
    'ResiAdminDivCd',
    'CellPhoneNbr',
    'HomePhoneNbr',
    'WorkPhoneNbr',
    'MailFipsCntyName',
    'ResiFipsCntyName',
    col('MailFipsCntyName').alias('MailFipsCntyName1'), 
    col('ResiFipsCntyName').alias('ResiFipsCntyName1'),
    'MbrUmidEffDate',
    'platformcd'
]

try:
    selected_df = cimember_df.select(*col_lst).distinct()

    srcsys_col_added_df  = selected_df.withColumn('platformcd',when((col('platformcd')=='HP') | (col('platformcd')=='LV') | (col('platformcd')=='Y'),lit('CI'))\
                                .when((col('platformcd')=='EM'),lit('MTV')).otherwise(lit('CI')))
except Exception as e:
    excep = 'selecting necessary cols : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,extracting unique members
try:
    window_spec = Window.partitionBy("MbrPid","CiGrpId","MbrSubPid")\
        .orderBy(desc('MbrUmidEffDate'))
    rn_clac_df = srcsys_col_added_df.withColumn('RN', row_number().over(window_spec))
    valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN','MbrUmidEffDate')
except Exception as e:
    excep = 'extracting unique members failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,dividing a member into two for mail type
col_map_mail_type = {
    'MbrPid':'MemberId',
    'CiGrpId':'MemberCustomerNumber',
    'MbrSubPid':'SubscriberId',
    'platformcd':'SourceSystemCode',
    'MailStreetAddr1':'StreetAddress1',
    'MailStreetAddr2':'StreetAddress2',
    'MailCityName':'CityName',
    'MailFipsCntyName':'CountyName',
    'MailZipCd':'ZipCode',
    'MailZipPlusCd':'ZipPlusCode',
    'MailFipsCntyCd':'FIPSCountyCode',
    'MailFipsCntryCd':'FIPSCountryCode',
    'MailFipsCntyName1':'FIPSCountyName',
    'MailAdminDivCd':'AdminDivisionCode',
    'CellPhoneNbr':'CellPhoneNumber',
    'HomePhoneNbr':'HomePhoneNumber',
    'WorkPhoneNbr':'WorkPhoneNumber'
}

col_map_rasi_type = {
    'MbrPid':'MemberId',
    'CiGrpId':'MemberCustomerNumber',
    'MbrSubPid':'SubscriberId',
    'platformcd':'SourceSystemCode',
    'ResiStreetAddr1':'StreetAddress1',
    'ResiStreetAddr2':'StreetAddress2',
    'ResiCityName':'CityName',
    'ResiFipsCntyName':'CountyName',
    'ResiZipCd':'ZipCode',
    'ResiZipPlusCd':'ZipPlusCode',
    'ResiFipsCntyCd':'FIPSCountyCode',
    'ResiFipsCntryCd':'FIPSCountryCode',
    'ResiFipsCntyName1':'FIPSCountyName',
    'ResiAdminDivCd':'AdminDivisionCode',
    'CellPhoneNbr':'CellPhoneNumber',
    'HomePhoneNbr':'HomePhoneNumber',
    'WorkPhoneNbr':'WorkPhoneNumber'
}

try:
    withCol1 = {
        'OtherPhoneNumber':lit(None).cast("STRING"),
        'AddressTypeCode': lit('MAIL')
    }

    withCol2 = {
        'OtherPhoneNumber':lit(None).cast("STRING"),
        'AddressTypeCode': lit('RESI')
    }
    mail_df = col_name_mapping(valid_df,col_map_mail_type)
    mail_df = mail_df.withColumns(withCol1)

    resi_df = col_name_mapping(valid_df,col_map_rasi_type)
    resi_df = resi_df.withColumns(withCol2)

    mail_resi_union_df= mail_df.unionAll(resi_df)

except Exception as e:
    excep = 'dividing records into two mail type failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

try:
    col_added_df  = mail_resi_union_df.selectExpr(
                            "*", 
                            "md5(concat(MemberId, SubscriberId, MemberCustomerNumber,SourceSystemCode, AddressTypeCode)) as HashKey",
                            "current_timestamp() as CreatedDateTime",
                            f"'{PIPELINE_NAME}' as CreatedBy",
                            "cast(null as timestamp)as ModifiedDateTime",
                            "cast(null as string) as ModifiedBy"
                            )
    
    symbols_removed_mapping = {
                "StreetAddress1": regexp_replace("StreetAddress1","�","?"),
                "StreetAddress2": regexp_replace("StreetAddress2","�","?")
                }

    symbols_removed_df = col_added_df.withColumns(symbols_removed_mapping)
                                    
except Exception as e:
    excep = 'cols addition failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,get member unique key with memberkey
try:
    join_cond  = (col('LH.MemberKey') == col('RH.MemberKey')) 

    mem_contact_joined_df = membercontact_stage_df.alias("LH").join(member_stage_df.alias("RH"),join_cond, "left")\
                .select("LH.*","RH.MemberId", "RH.SubscriberId", "RH.MemberCustomerNumber","RH.SourceSystemCode")

except Exception as e:
    excep = 'get member unique keys failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

try:
    new_col_slt_lst = symbols_removed_df.columns
    col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)

    old_renamed_df = mem_contact_joined_df.selectExpr("*","md5(concat(MemberId, SubscriberId, MemberCustomerNumber,SourceSystemCode, AddressTypeCode)) as HashKey")\
                                        .selectExpr(*col_select_lst)
                                
    old_joined_df = symbols_removed_df.alias('LH').join(old_renamed_df.alias('RH'),(col("LH.HashKey") == col("RH.OldHashKey")), "full")

    ins_df = old_joined_df\
            .filter((col('OldHashKey').isNull()))\
            .withColumn('DerivedIndicator', lit('INSERT'))\
            .drop(*col_drop_lst,"HashKey")

    update_rec_check_col_lst = [
                        'StreetAddress1',
                        'StreetAddress2',
                        'CityName',
                        'CountyName',
                        'ZipCode',
                        'ZipPlusCode',
                        'FIPSCountyCode',
                        'FIPSCountryCode',
                        'FIPSCountyName',
                        'AdminDivisionCode',
                        'CellPhoneNumber',
                        'HomePhoneNumber',
                        'WorkPhoneNumber',
                        'OtherPhoneNumber'
                        ]
    

    upd_cond_lst = []
    for colm in update_rec_check_col_lst:
        upd_cond_lst.append('(col("'+colm+'").eqNullSafe(col("Old'+colm+'")))')
    upd_cond = ' & '.join(upd_cond_lst)
    upds_df_code = f'upds_df = old_joined_df.filter((col("HashKey").isNotNull()) & (col("OldHashKey").isNotNull())).withColumn("DerivedIndicator", when('+upd_cond+',lit("IGNORE")).otherwise(lit("UPDATE")))'
    exec(upds_df_code)
    
    col_maps = {'ModifiedDateTime' : (when(col('DerivedIndicator') == 'UPDATE', lit(current_timestamp())).otherwise(col('OldModifiedDateTime'))),
                'ModifiedBy' : (when(col('DerivedIndicator') == 'UPDATE', lit(PIPELINE_NAME)).otherwise(col('OldModifiedBy'))),
                'CreatedBy' : col('OldCreatedBy'),
                'CreatedDateTime' : col('OldCreatedDateTime')
                }
                
    calc_audit_col_upds_df = upds_df.withColumns(col_maps)\
                            .select(*new_col_slt_lst, "DerivedIndicator").filter(col("DerivedIndicator")!="IGNORE")\
                            .drop("HashKey")

    delta_df = ins_df.unionByName(calc_audit_col_upds_df)
    delta_df.cache()
except Exception as e:
    excep = 'delta load prepare failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,load into stage table
try:
    mapping = {
            'ProcessName' : lit(None).cast('STRING'),
            'DeltaStatus' : lit(None).cast('STRING'),
            'MemberKey':lit(None).cast("BIGINT"),
            'MemberContactKey':lit(None).cast("BIGINT")
        }
        
    mapped_df= delta_df.withColumns(mapping)
    not_nullable_set_df = set_df_columns_not_nullable(spark,mapped_df,['SourceSystemCode','MemberCustomerNumber','CreatedBy','CreatedDateTime'])
    nullable_set_df = set_df_columns_nullable(spark,not_nullable_set_df , ['AddressTypeCode','DerivedIndicator'])

    load_df_to_sf_sql_db_spark(nullable_set_df, "Member.StageMemberContact")
except Exception as e:
    excep = 'loading into stage failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,delta processing for main catalog table
try:
    member_cur_join_cond = (
                            (col('LH.MemberId') == col('RH.MemberId')) &
                            (col('LH.SubscriberId') == col('RH.SubscriberId')) & 
                            (col('LH.MemberCustomerNumber') == col('RH.MemberCustomerNumber')) & 
                            (col('LH.SourceSystemCode') == col('RH.SourceSystemCode'))
                            )


    joined_with_member_df = delta_df.alias("LH").join(member_cur_df.alias("RH"),member_cur_join_cond, "left")\
                                    .select("LH.*","RH.MemberKey")
    
    if len(membercontact_stage_df.head(1)) == 0:
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":'Member_MemberContact'})
    conditions = ['MemberId','MemberCustomerNumber','SubscriberId','SourceSystemCode','AddressTypeCode']
    not_update_lst = ["CreatedBy","CreatedDateTime"]
    delta_processing_with_cascade_delete(membercon_cur_tbl_name, joined_with_member_df, conditions,not_update_lst)
except Exception as e:
    excep = 'loading into main catalog failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,successfull exit notebook
# Insert success entry to the audit table.
insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Success' ,audit_table_name,None)
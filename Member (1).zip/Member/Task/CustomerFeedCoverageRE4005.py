# Databricks notebook source
# MAGIC %md
# MAGIC ##### Generation of HMOPPO and Error file on a daily basis for all Customer records
# MAGIC ##### Source tables
# MAGIC - Customer Batch table
# MAGIC - BenefitTypeOccurrence Batch table
# MAGIC - Product Azure SQL domain table
# MAGIC - FinanceLedgerHeader Azure SQL domain table
# MAGIC ###### Target Details (File):
# MAGIC - Error_ddmmyyyy.txt (Text file)
# MAGIC - HmoPpoCustomer_ddmmyyyy.txt (Text file)
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','pl_CustomerCoverage')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_NAME','CustomerFeedCoverageRE4005')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('LOAD_TYPE','')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Run transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Run load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up local variables
audit_start_date_time = datetime.now()
job_type = 'DailyJobs'

# COMMAND ----------

# DBTITLE 1,Get details from environment helper & File Config & Fixed Width File Config..
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
    fixed_hmoppo_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == 'CustomerCoverageHmpPpo')
    fixed_error_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == 'CustomerCoverageError')
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)

    default_config = config_dict["DEFAULT"]
    container_name = default_config["ContainerName"]

    default_out_config = default_config["Outbound"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    config = default_out_config["Config"]


    config_dict_job = config_dict[job_name]
    temp_file_path_suffix_hmoppo = config_dict_job["Outbound"]["TempFilePathSuffixHmoPpo"]
    temp_file_path_suffix_Error = config_dict_job["Outbound"]["TempFilePathSuffixError"]
    outbnd_file_name_hmoppo = config_dict_job["Outbound"]["FileNameHmoPpo"]
    outbnd_file_name_error = config_dict_job["Outbound"]["FileNameError"]

    # Inbound Tables
    CurCustTbl = config_dict_job['Inbound']['CurCustTbl']
    CurCustBenOccTbl = config_dict_job['Inbound']['CurCustBenOccTbl']
    SQLProduct = config_dict_job['Inbound']['SQLProduct']
    SQLLedgerHdr = config_dict_job['Inbound']['SQLLedgerHdr']
    
    # Outbound Tables
    StageRE4005  = config_dict_job["Outbound"]["StageRE4005"]
    audit_table_name = default_config['AuditTableName']
    
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read tables into dataframe
# def read_tables_to_df(LOAD_TYPE,LatestSuccessDate):
try:    
    dfCustomer = read_table_to_df(CurCustTbl)\
        .selectExpr("CIClassNumber","CIGroupIdentifier","BenefitSequence","SourceLOBCode","SellingLedger","GHGroupIdentifier","EmployerGroupNumber")

    dfCusBenOcc = read_table_to_df(CurCustBenOccTbl)\
        .selectExpr("CIClassNumber","CIGroupIdentifier","BenefitSequence","SellingLedger","ProductPlanNumber","ProductOptionNumber","BenefitEffectiveDate","BenefitENDDate")
        
    # MAX of BenefitEffectiveDate, works as HMOPPO CUSTVS_GRP_EFF_DATE_CYMD
    benvw1 = dfCusBenOcc.groupBy('CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber').agg(max("BenefitEffectiveDate").alias('BenefitEffectiveDate'))

    benjoinCols = ['CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber', 'BenefitEffectiveDate']
    benview1 = benvw1.alias('LH')\
        .join(dfCusBenOcc.alias('RH'), benjoinCols, 'left')\
        .selectExpr('LH.CIGroupIdentifier','LH.BenefitSequence','LH.CIClassNumber','LH.BenefitEffectiveDate','RH.ProductPlanNumber','RH.ProductOptionNumber')


    dfProduct = read_sf_sql_tbl_to_df_spark(SQLProduct)\
            .selectExpr("ProductKey","ProductId","LineOfBusinessCode","MarketNumber","PlanNumber","OptNumber","ProductStartDate","ProductEndDate","ExtProdSeqNo")

    dfLedger = read_sf_sql_tbl_to_df_spark(SQLLedgerHdr).selectExpr("LedgerNumber","LineOfBusinessCode")
    
except Exception as e:
    excep = "read data to df:" + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep) 

# COMMAND ----------

# DBTITLE 1,Column mapping for required output files
col_map_hmo_ppo = {
    'GHGroupIdentifier':'CUSTVS_CUST_NBR',
    'EmployerGroupNumber':'CUSTVS_GRP_NBR',
    'LineOfBusinessCode':'CUSTVS_LOB',
    'ProductPlanNumber':'CUSTVS_PLAN',
    'ProductOptionNumber':'CUSTVS_OPTION',
    'SellingLedger':'CUSTVS_MARKET',
    'ProductKey':'CUSTVS_PROD_SEQ_NBR',
    'ChgEffDate':'CUSTVS_CHG_EFF_DATE_CYMD',
    'BenefitEffectiveDate':'CUSTVS_GRP_EFF_DATE_CYMD',
    'WmprWorkcmpFacNbr':'CUSTVS_EMPR_WORKCMP_FAC_N',
    'WkcCustStatus':'CUSTVS_WKC_CUST_STATUS'
}

col_map_error = {
    'SellingLedger':'MARKET',
    'CIGroupIdentifier':'CUST_NBR',
    'BenefitSequence':'GROUP_NBR',
    'LineOfBusinessCode':'GH_LOB',
    'GroupEffCymdDate':'GROUP_EFF_CYMD_DATE',
    'WmprWorkcmpFacNbr':'EMPR_WORKCMP_FAC_NBR',
    'WkcCustStatus':'WKC_CUST_STATUS',
    'ProductPlanNumber':'PLAN',
    'ProductOptionNumber':'OPT',
    'ProdSeqNbr':'PROD_SEQ_NBR',
    'Error_Code':'Error_Code'
}

# COMMAND ----------

# DBTITLE 1,Join Customer, Benefit, Product & Ledger for HMO PPO & Error
# def join_all_tables(dfCustomer, benview1, dfProduct, dfLedger):
try:
    dfCustBen = dfCustomer.alias('ci')\
        .join(benview1.alias('ben'),
            (col('ci.CIClassNumber')==col('ben.CIClassNumber')) & 
            (col('ci.CIGroupIdentifier')==col('ben.CIGroupIdentifier')) & 
            (col('ci.BenefitSequence')==col('ben.BenefitSequence')), "left")\
        .selectExpr('ci.*','ben.ProductPlanNumber','ben.ProductOptionNumber','ben.BenefitEffectiveDate').distinct()


    dfcustLgr = dfCustBen.alias('cb')\
        .join(dfLedger.alias('lgr'), col('cb.SellingLedger') == col('lgr.LedgerNumber'), 'left')

    dfcustPrdLgr = dfcustLgr.alias('cbl')\
        .join(dfProduct.alias('prd'),  
            (col('cbl.SellingLedger') == col('prd.MarketNumber')) & 
            (col('cbl.ProductPlanNumber') == col('prd.PlanNumber')) &
            (col('cbl.ProductOptionNumber') == col('prd.OptNumber')) &
            (col('cbl.LineOfBusinessCode')==col('prd.LineOfBusinessCode')), "left")\
        .select('cbl.CIGroupIdentifier','cbl.BenefitSequence','cbl.CIClassNumber','cbl.GHGroupIdentifier','cbl.EmployerGroupNumber','cbl.SellingLedger','cbl.SourceLOBCode','cbl.ProductPlanNumber','cbl.ProductOptionNumber','cbl.BenefitEffectiveDate','prd.LineOfBusinessCode','prd.ProductKey','prd.ExtProdSeqNo',lit("LV").alias("sourcesystemcode"), lit('CustomerFeedCoverageRE4005').alias('ProcessName'))

    # return dfcustPrdLgr
except Exception as e:
    excep = "join all tables:" +str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep) 

# COMMAND ----------

# def load_data_cur_table(LOAD_TYPE, dfcustPrdLgr, StageRE4005,minTS):
try:
    if LOAD_TYPE == 'FullLoad':
        # Recreate the table so as to restart the identy column and to truncate the table
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":'Member_StageRE4005'})

        dffull = add_tgt_audit_column(dfcustPrdLgr,PIPELINE_NAME)
        write_to_curated(dffull,StageRE4005)

    elif LOAD_TYPE == 'DeltaLoad':
        StRE4005 = read_table_to_df(StageRE4005)
        joinCols = ['CIGroupIdentifier','BenefitSequence','CIClassNumber','GHGroupIdentifier','EmployerGroupNumber']

        cwithCols1 = {
            'ModifiedBy': lit(f'{PIPELINE_NAME}'),
            'ModifiedDateTime': lit(f'{audit_start_date_time}')
        }
        df1 = dfcustPrdLgr.alias('LH').join(StRE4005.alias('RH'), joinCols, "inner").selectExpr('LH.*','RH.CreatedBy','RH.CreatedDateTime')
        df1 = df1.withColumns(cwithCols1)
        
        withCols2 = {
            'CreatedBy': lit(f'{PIPELINE_NAME}'),
            'CreatedDateTime': lit(f'{audit_start_date_time}'),
            'ModifiedBy': lit(None),
            'ModifiedDateTime': lit(None)
        }
        df2 = dfcustPrdLgr.alias('LH').join(StRE4005.alias('RH'), joinCols, "leftanti")
        df2 = df2.withColumns(withCols2)

        dfFinal = df1.union(df2)

        deltatable = DeltaTable.forName(spark,StageRE4005)
        deltatable.alias('LH')\
            .merge(dfFinal.alias('RH'), 'LH.CIGroupIdentifier = RH.CIGroupIdentifier AND LH.BenefitSequence = RH.BenefitSequence AND LH.CIClassNumber = RH.CIClassNumber AND LH.GHGroupIdentifier = RH.GHGroupIdentifier AND LH.EmployerGroupNumber = RH.EmployerGroupNumber')\
            .whenMatchedUpdateAll()\
            .whenNotMatchedInsertAll()\
            .execute()

except Exception as e:
    excep = "Curated table load or merge:"+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Add derived columns for output files
# def add_derived_cols(dfRE4005):
try:
    dfRE4005 = read_table_to_df(StageRE4005)
    
    dfValid = dfRE4005.filter(col('ProductKey').isNotNull())

    derCol1 = {
    'WmprWorkcmpFacNbr':lit("00000"),
    'WkcCustStatus':lit("N"),
    'ChgEffDate':lit('00000000')
    }

    dfHmoPpo = dfValid.withColumns(derCol1)

    derCols = {
        'GroupEffCymdDate':lit(None),
        'WmprWorkcmpFacNbr':lit('00000'),
        'WkcCustStatus':lit("N"),
        'ProdSeqNbr':lit(None),
        'Error_Code':lit("No Product, hence ProductKey and GroupEffCymdDate not available")
    }

    dfNullRecords = dfRE4005.filter(col('ProductKey').isNull())\
        .selectExpr('SellingLedger','CIGroupIdentifier','BenefitSequence','LineOfBusinessCode','ProductPlanNumber','ProductOptionNumber')

    dfError = dfNullRecords.withColumns(derCols)

    # return dfHmoPpo, dfError
        
except Exception as e:
    excep = "HmoPpo Date columns:" +str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep) 

# COMMAND ----------

# DBTITLE 1,Function to create paths for output files
def pathCreation(temp_file_path_suffix, prc_file_path_prefix, file_path_prefix):
    try:
        temp_csv_path = abfss_path_builder(
            container_name, storage_account, prc_file_path_prefix, temp_file_path_suffix
        )

        outbnd_csv_path = abfss_path_builder(
            container_name, storage_account, path_prefix=file_path_prefix
        )

        return temp_csv_path, outbnd_csv_path
    except Exception as e:
        raise Exception("Path creation failed:",str(e))

# COMMAND ----------

# DBTITLE 1,Function to write the output files to ADLS
def outbound_file_creator(config,df,fixed_df,temp_csv_path, outbnd_csv_path, outbnd_file_name):
    try:
        final_df = convert_col_to_fixed_width(fixed_df, df)

        # write dataframe as single csv file with "|" seperator.
        write_outbnd_file_to_adls(final_df, temp_csv_path, config)

        # ourput file to OutBound Adls location
        copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
    except Exception as e:
        raise Exception("Outbound file genration failed:",str(e))

# COMMAND ----------

# DBTITLE 1,Main Try & Except the functions to create path and load to ALDS
try:
    temp_csv_path, outbnd_csv_path = pathCreation(temp_file_path_suffix_hmoppo, prc_file_path_prefix, file_path_prefix)
    outbound_file_creator(config,col_name_mapping(dfHmoPpo,col_map_hmo_ppo),fixed_hmoppo_df, temp_csv_path, outbnd_csv_path, outbnd_file_name_hmoppo)

    # write the error file to outbound location
    temp_csv_path, outbnd_csv_path = pathCreation(temp_file_path_suffix_Error, prc_file_path_prefix, file_path_prefix)
    outbound_file_creator(config,col_name_mapping(dfError,col_map_error),fixed_error_df, temp_csv_path, outbnd_csv_path, outbnd_file_name_error)

except Exception as e:
    excep = "Run Failed:" +str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)
else:
    excep = "RUN was successful"
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, excep)
    
    fileNamesList = [outbnd_file_name_hmoppo,outbnd_file_name_error]
    fileNames = ','.join(fileNamesList)
    
    output = {
        'OUTBOUND_FILE_NAMES':fileNames,
        'OUTBOUND_FOLDER_PATH_SUFFIX':'outbound'
    }

    dbutils.notebook.exit(output)
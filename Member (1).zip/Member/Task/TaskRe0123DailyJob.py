# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC #### Provider Delegate file is generated with minimum and maximum coverage dates and customer details.
# MAGIC
# MAGIC ##### To acheive the requirement below steps has been followed.
# MAGIC
# MAGIC * Step 1: Extract all the PPO provider contract details from the respective files where HumanaClaimPaymentCode & PrePaymentServiceIndicator is not equals to 'Y'.
# MAGIC * Step 2: Extract Customer Number , min & max member coverage effective/end date for the matching provider contract.
# MAGIC * Step 3: Remove the duplicate records based on the Customer Number , min & max member coverage effective/end date.
# MAGIC * Step 4 : Generate Provider Delegate file and place into outbound folder.

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Source table 
# MAGIC - ProviderContract.ProviderContract (MF table : TRE2341)
# MAGIC - ProviderContract.ProviderContractPaymentTerm  (MF table : TRE2328)
# MAGIC - ProviderContract.ProviderContractFund  (MF table : TRE2345)
# MAGIC - Member.MemberCoverage  (MF table : TRE2320)
# MAGIC
# MAGIC ##### Outbound File
# MAGIC - Re0123DailyProcess.txt

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe0123SyncUp')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import ingest notebook
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    Re0123Daily = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = Re0123Daily["Outbound"]["TempFilePathSuffix"]   
    curated_path_suffix = Re0123Daily['Outbound']['CuratedFilePathSuffix']
    tbl_name = Re0123Daily['Outbound']['TableName']
    outbnd_file_name = Re0123Daily["Outbound"]["FileName"]

    stg_mbr_cov_tbl_name = Re0123Daily["Inbound"]["StageMemberCoverage"]
    stg_prov_con_tbl_name = Re0123Daily["Inbound"]["StageProviderContract"]
    stg_prov_con_fnd_tbl_name = Re0123Daily["Inbound"]["StageProviderContractFund"]
    stg_prov_con_pymt_term_tbl_name = Re0123Daily["Inbound"]["StageProviderContractPaymentTerm"]
    sync_process_names = Re0123Daily["Inbound"]["StageSyncProcessNames"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account,
        file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try: 
    # Read the data from Member Coverage Stage table(Adls).
    df_mbr_cov = read_table_to_df(stg_mbr_cov_tbl_name)
    # Read the data from ProviderContract Stage table(Adls).
    df_prov_con = read_table_to_df(stg_prov_con_tbl_name)
    # Read the data from ProviderContractFund Stage table(Adls).
    df_prov_con_fnd = read_table_to_df(stg_prov_con_fnd_tbl_name)
    # Read the data from ProviderContractPaymentTerm Stage table(Adls).
    df_prov_con_pytm_term = read_table_to_df(stg_prov_con_pymt_term_tbl_name)
except Exception as e:
    excep = "Read Sql Tables: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting Required Columns from Respective Tables
try:
    df_prov_con_fltr = df_prov_con.filter(
        col("ProductLineOfBusinessCode").isin("MEP", "MEF")
    ).select(
        "ProviderContractKey",
        "ProviderId",
        "ProviderSuffixCode",
        "ProviderServiceTypeCode",
        "ProviderSequenceNumber",
    ) 

    df_prov_con_fnd_fltr = df_prov_con_fnd.filter(
        col("PrePaymentServiceIndicator") != "Y"
    ).select(
        "ProviderContractKey"
    )  

    df_prov_con_pytm_term_fltr = df_prov_con_pytm_term.filter(
        col("HumanaClaimPaymentCode") != "Y"
    ).select(
        "ProviderContractKey"
    )  

    df_mbr_cov_fltr = df_mbr_cov.select(
        "ProviderContractKey",
        "MemberCustomerNumber",
        "CoverageStartDate",
        "CoverageEndDate",
    )  

except Exception as e:
    excep = "column selection: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Extract PPO Provider Contract details
try:
    df_prov_con_pay_term = (
    df_prov_con_fltr.alias("LH1")
    .join(
        df_prov_con_pytm_term_fltr.alias("RH1"),
        df_prov_con_fltr["ProviderContractKey"] == df_prov_con_pytm_term_fltr["ProviderContractKey"],
    )
    .select("LH1.*")
    )

    df_prov_con_fnd = (
        df_prov_con_fltr.alias("LH2")
        .join(
            df_prov_con_fnd_fltr.alias("RH2"),
            df_prov_con_fltr["ProviderContractKey"] == df_prov_con_fnd_fltr["ProviderContractKey"],
        )
        .select("LH2.*")
    )

    df_ppo_ext = df_prov_con_pay_term.unionAll(df_prov_con_fnd)
except Exception as e:
    excep = ("Join ProviderConctract ProviderConctractFund and ProviderConctractPaymentTerm: "+ str(e))
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Extract Customer Number , min and max eff/end date, based on the matching provider contract.
try:
    # Extract Customer Number , min and max eff/end date, based on the matching provider contract.
    df_prov_con_mbr_dtl = (
        df_ppo_ext.alias("LH3")
        .join(
            df_mbr_cov_fltr.alias("RH3"),
            df_ppo_ext["ProviderContractKey"] == df_mbr_cov_fltr["ProviderContractKey"],
        )
        .select(
            "LH3.ProviderContractKey",
            "RH3.MemberCustomerNumber",
            "RH3.CoverageStartDate",
            "RH3.CoverageEndDate",
        )
    )

    df_min_max_mbr_cov = df_prov_con_mbr_dtl.groupby(
        "MemberCustomerNumber", "ProviderContractKey"
    ).agg(
        min(col("CoverageStartDate")).alias("MinCoverageStartDate"),
        max(col("CoverageEndDate")).alias("MaxCoverageEndDate"),
    )

    # Remove duplicate records based on the customer number and effective/end date.

    df_final = df_min_max_mbr_cov.select(
        "MemberCustomerNumber", "MinCoverageStartDate", "MaxCoverageEndDate"
    ).distinct()
except Exception as e:
    excep = ("Join ProviderContract, MemberCoverage: "+ str(e))
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_final, tbl_name)
    # Read data from stage area.
    re0123_df = spark.read.table(tbl_name)
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0123_df)
    # write dataframe as .txt file as position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }
# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Below are the major features involved in the membership process:
# MAGIC - Ingest data to stage table
# MAGIC - Customer conversion (GH to CI)
# MAGIC - Member validation
# MAGIC - Member coverage overlap
# MAGIC - Provider validation
# MAGIC - Provider contract assignment
# MAGIC - Load processed to SQL table
# MAGIC - Report creation(Error / Success)
# MAGIC ###### Source details (Inbound Files):
# MAGIC - IN_MASS_MEMB_ATTR_WEB_TAB.TXT
# MAGIC
# MAGIC ###### Stage and main Tables used by the process:
# MAGIC
# MAGIC - provider_main_dev_000.mainframe_servicefund.Member_Customer
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMember,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_StageMemberCoverage,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Provider_StageProvider,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContract,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.ProviderContract_StageProviderContractProductAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAffiliation,
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Product_StageProductSetAssociation
# MAGIC
# MAGIC ###### Intermediate table details
# MAGIC - provider_staging_dev_000.mainframe_servicefund.Member_PcpAttributionProcessed
# MAGIC
# MAGIC ###### Target details (Azure SQL Stage table):
# MAGIC - Member.StageDBPMemberCoverage
# MAGIC
# MAGIC ###### Report details:
# MAGIC - MemberPCPAttributionErrorReport.txt
# MAGIC - MemberPCPAttributionSuccessReport.txt
# MAGIC - MemberPCPAttributionDetailReport.txt
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper Notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest Utilities Notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform Utilities Notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load Utilities Notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import MemberCoverage Utilities Notebook
# MAGIC %run ../../Utility/MemberCoverage

# COMMAND ----------

# DBTITLE 1,Import Neccessary Libraries
from pyspark.sql.functions import input_file_name, current_date, current_timestamp, lit, col, row_number, lpad, sha1, concat_ws, to_timestamp
from delta.tables import DeltaTable
from pyspark.sql.window import Window
from delta.tables import *
import json

# COMMAND ----------

# DBTITLE 1,Read Parameters
dbutils.widgets.text('JOB_NAME','')
dbutils.widgets.text('PIPELINE_NAME','')
dbutils.widgets.text('PIPELINE_RUN_ID','')
dbutils.widgets.text('JOB_TYPE', '')

JOB_NAME = dbutils.widgets.get('JOB_NAME')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')
JOB_TYPE = dbutils.widgets.get('JOB_TYPE')
audit_start_date_time = datetime.now()
job_type = JOB_TYPE
process_name = "DBP#" + job_type + "#" + JOB_NAME
audit_name = "DBP#" + job_type + "#" + PIPELINE_NAME
attr_audit_name = audit_name + "#mbr_attr_of"

# COMMAND ----------

# DBTITLE 1,Spark Config
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read file config.
try:
    config_dict = get_file_config(file_conf_path)
except Exception as e:
    excep = 'Reading file config failed: ' + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable definition from config file..
try:
    # Default configuration
    default_config = config_dict["DEFAULT"]
    default_in_config = default_config["Inbound"]
    default_out_config = default_config["Outbound"]
    pcp_attr_config = config_dict[JOB_NAME]
    # Path details.
    config = default_out_config['Config']
    container_name = default_config["ContainerName"]
    in_file_path_suffix = default_in_config["FilePathSuffix"]
    out_file_path_prefix = default_out_config["FilePathPrefix"]
    proc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    membattr_inbnd_file_name = pcp_attr_config["Inbound"]["PCPAttrFileName"]
    # Main table names.
    audit_table_name = default_config["AuditTableName"]
    customer_tbl_name = pcp_attr_config["Inbound"]["CustomerTableName"]
    # Stage table names.
    member_table_name = pcp_attr_config["Inbound"]["StageMemberTableName"]
    mem_cov_table_name = pcp_attr_config["Inbound"]["StageMemberCoverageTableName"]
    provider_table_name = pcp_attr_config["Inbound"]["StageProviderTableName"]
    pc_table_name  = pcp_attr_config["Inbound"]["StageProviderContractTableName"]
    pc_prd_affil_table_name  = pcp_attr_config["Inbound"]["StageProviderContractProductAffiliationTableName"]
    pc_prd_set_affil_table_name  = pcp_attr_config["Inbound"]["StageProductSetAffiliationTableName"]
    pc_prd_set_asso_table_name  = pcp_attr_config["Inbound"]["StageProductSetAssociationTableName"]
    pcp_attr_processed_table_name = pcp_attr_config["Inbound"]["ProcessedTableName"]
    prd_table_name = pcp_attr_config["Inbound"]["StageProductTableName"]
    # PCP Attribution curated table name.
    mem_cov_sql_tbl_name = pcp_attr_config["Outbound"]['MemberCoverageSqlTable']
    # PCP Attribution curated table.
    pcp_stage_tbl_name = pcp_attr_config["Inbound"]["StageTableName"]
    # Report details
    err_file_name = pcp_attr_config["Outbound"]["ErrorFileName"]
    success_file_name = pcp_attr_config["Outbound"]["SuccessFileName"]
    detail_file_name = pcp_attr_config["Outbound"]["DetailFileName"]
    outbnd_temp_err_path_suffix = pcp_attr_config["Outbound"]["TempFileErrorPathSuffix"]
    outbnd_temp_success_path_suffix = pcp_attr_config["Outbound"]["TempFileSuccessPathSuffix"]
    outbnd_temp_detail_path_suffix = pcp_attr_config["Outbound"]["TempFileDetailPathSuffix"]
    sync_process_names = pcp_attr_config["Inbound"]["StageSyncDependencyProcess"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read Fixed width config file
try:
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == JOB_NAME)
except Exception as e:
    excep = 'Read Fixed width config file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep) 

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Inbound and outbund ADLS path creation.
try:
    inbnd_base_path = abfss_path_builder(container_name, storage_account, in_file_path_suffix)
    membattr_inbnd_file_path = f"{inbnd_base_path}{membattr_inbnd_file_name}"
    outbnd_temp_err_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_err_path_suffix)
    outbnd_temp_success_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_success_path_suffix)
    outbnd_temp_detail_csv_path = abfss_path_builder(container_name, storage_account,proc_file_path_prefix, outbnd_temp_detail_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, out_file_path_prefix)
except Exception as e:
    excep = 'ADLS path creation failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Business key and schema definition
# Business key
buz_keys = ['ProdMktNbr','SrcAltCustId','SrcAltCustBenId','MemberId', 'SubscriberId','MbrProvEffCymdDate']

# Schema definition.
raw_schema = {
    'PROD_MKT_NBR' : "string",
    'SRC_ALT_CUST_ID' : "string",
    'SRC_ALT_CUST_BEN_ID' : "string",
    'MEMBER_ID' : "string",
    'SUBSCRIBER_ID' : "string",
    'PROV_ID' : "string",
    'PROV_SUFFIX' : "string",
    'PROV_TYPE' : "string",
    'MBR_PROV_EFF_CYMD_DATE' : "date",
    'MBR_PROV_END_CYMD_DATE' : "date",
    'PREV_END_REAS_CD' : "string",
    'CURR_END_REAS_CD' : "string",
    'PANEL_REASON' : "string",
    'IDCARD_IND' : "string",
    "HMO_PPO_IND" : "string"
}

# COMMAND ----------

# DBTITLE 1,Functions for data validation
def identify_duplicates_records(df):
    '''
    Description:
    This function is used to identify and create seperate dataframe for duplicates records..
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :returns trans_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        window_spec = Window.partitionBy(*df.columns).orderBy(lit(1))
        col_maps = {
            "RN" :  row_number().over(window_spec),
            "Comment" : when((col('RN') > 1), 'Duplicate transactions in the input file'),
            "ErrorCode" : when((col('RN') > 1), 'E1')
        }
        trans_df = df.withColumns(col_maps).drop('RN')
        return trans_df
    except Exception as e:
        raise Exception("identify_duplicates_records failed:" + str(e))

def check_overlap_dates_for_input_transaction(df):
    '''
    Description:
    This function is used to identify duplicate records based on business key and create seperate dataframe for duplicates records..
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :param buz_keys: [Type: list].
    :returns trans_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        rej_df = df.filter(col('Comment').isNotNull())
        val_df = df.filter(col('Comment').isNull())
        # Define window specification
        window_spec = Window.partitionBy('ProdMktNbr','SrcAltCustId','SrcAltCustBenId','Memberid', 'Subscriberid').orderBy('MbrProvEffCymdDate', 'MbrProvEndCymdDate')

        # Find the previous end date for each row
        val_df = val_df.withColumn("PrevEndDate", lag("MbrProvEndCymdDate").over(window_spec))\
                .withColumn("AfterStartDate", lead("MbrProvEffCymdDate").over(window_spec))
        # Check for overlapping date
        val_df = val_df.withColumn("OverlapPrev", when((col("MbrProvEffCymdDate") <= col("PrevEndDate")) & (col("MbrProvEndCymdDate") >= col("PrevEndDate")), lit(1)).otherwise(lit(0)))\
            .withColumn("OverlapAfter", when((col("MbrProvEffCymdDate") <= col("AfterStartDate")) & (col("MbrProvEndCymdDate") >= col("AfterStartDate")), lit(1)).otherwise(lit(0))).drop('PrevEndDate', 'AfterStartDate')
        # Define window specification

        col_maps = {
            "Comment" : when(((col('OverlapAfter') == 1) | (col('OverlapPrev') == 1)), "Member Coverage dates conflict with another transaction in the input file").otherwise(col('Comment')),
            "ErrorCode" : when(((col('OverlapAfter') == 1) | (col('OverlapPrev') == 1)), "E2").otherwise(col('ErrorCode'))
        }
        trans_df = val_df.withColumns(col_maps).drop('OverlapAfter', 'OverlapPrev')
        final_df = trans_df.unionByName(rej_df)
        return final_df
    except Exception as e:
        raise Exception("identify_duplicates_records_on_buz_keys failed:" + str(e))

def find_records_effectivedate_greater_or_equal_enddate(df):
    ''' 
    Description:
    This function is used to identify error records when end date is before than the effective date.
    :param df: [Type: pyspark.sql.dataframe.Dataframe].
    :returns trans_df: [Type: pyspark.sql.dataframe.Dataframe].
    '''
    try:
        col_maps = {
            "Comment" : when((col('MbrProvEffCymdDate') > col('MbrProvEndCymdDate')) & (col('Comment').isNull()), 'Member coverage effective date is greater than end date')\
                    .when((col('MbrProvEffCymdDate') == col('MbrProvEndCymdDate')) & (col('Comment').isNull()), 'Member coverage effective date is equal to end date').otherwise(col('Comment')),
            "ErrorCode" : when((col('MbrProvEffCymdDate') > col('MbrProvEndCymdDate')) & (col('Comment').isNull()), 'E3')\
                        .when((col('MbrProvEffCymdDate') == col('MbrProvEndCymdDate')) & (col('Comment').isNull()), 'E16')\
                        .otherwise(col('ErrorCode'))
        }
        trans_df = df.withColumns(col_maps)
        return trans_df
    except Exception as e:
        raise Exception("find_records_enddate_before_effectivedate failed:" + str(e))

def create_select_list(colms):
    col_list = []
    for colm in colms:
        col_list.append(f"{colm} AS Old{colm}")
    return col_list

def apply_custom_scd_type(src_df, stage_tbl_name, valid_set_dict, rej_set_set):
    '''
        Description:
        This function is used to update StageMemberCoverageQueue only when IsProcessed is null.
        :param src_df: [Type: pyspark.sql.dataframe.Dataframe] source data.
        :param stage_tbl_name: [Type: String] Stage table name(StageMemberCoverageQueue).
        :param valid_set_dict: [Type: Dictionary] Columns to update for valid records.
        :param rej_set_set: [Type: Dictionary] Columns to update for rejected records.
    '''
    try:
        stg_mem_cov_table = DeltaTable.forName(spark, stage_tbl_name)
        updates_df = src_df

        stg_mem_cov_table.alias('coverage') \
        .merge(
            updates_df.alias('updates'),
            "coverage.Id = updates.Id") \
        .whenMatchedUpdate(
            condition = f"coverage.Comment is null and updates.IsRejected = 'N'",
            set = valid_set_dict) \
        .whenMatchedUpdate(
            condition = f"coverage.Comment is null and updates.IsRejected = 'Y'",
            set = rej_set_set) \
        .execute()

    except Exception as e:
        raise Exception("apply_custom_scd_type failed:", str(e))

# COMMAND ----------

# DBTITLE 1,Ingest data to stage table.
try:

    col_maps = {
            "CIGroupIdentifier" : lit(None).cast("string"),
            "BenefitSequence" : lit(None).cast("string"),
            "CIClassNumber" : lit(None).cast("string")
    }
    #reading the member attribution inbound file.
    pcp_file_df = read_inbound_csv_file(membattr_inbnd_file_path)
    # Remove leading and trailing spaces of all column values.
    removed_space_df = trim_leading_trailing_space(pcp_file_df)
    # Convert data type.
    dtype_trans_df = data_type_conversion(removed_space_df, raw_schema)
    # Add Hash key called Id - SHA1
    id_calc_df = dtype_trans_df.withColumn('Id', sha1(concat_ws("", *buz_keys)))


    cleansed_df = identify_duplicates_records(id_calc_df)
    # Check overlap dates for input transaction.
    buz_keys_dup_cleansed_df = check_overlap_dates_for_input_transaction(cleansed_df)
    # Identify records when coverage start date greater than coverage end date.
    valid_cov_df = find_records_effectivedate_greater_or_equal_enddate(buz_keys_dup_cleansed_df)\
                            .withColumns(col_maps)

    # Write data to Stage table
    write_df_as_delta_table(valid_cov_df,pcp_stage_tbl_name)

    # Remove unused data files.
    raw_delta_table = DeltaTable.forName(spark, pcp_stage_tbl_name)
    raw_delta_table.vacuum(0)
except Exception as e:
    excep = 'Ingest data to stage table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Column name mapping
col_map_dict = {
    "ProdMktNbr" : "LedgerNumber",
    "SrcAltCustId" : "GHGroupIdentifier",
    "SrcAltCustBenId" : "EmployerGroupNumber",
    "MemberId" : "MemberId",
    "SubscriberId" : "SubscriberId",
    "ProvId" : "ProvId",
    "ProvSuffix" : "ProvSuffix",
    "ProvType" : "ProvType",
    "MbrProvEffCymdDate" : "MemberProvEffDate",
    "MbrProvEndCymdDate" : "MemberProvEndDate",
    "CurrEndReasCd" : "CoverageEndReasonCode",
    "PrevEndReasCd" : "PrevEndReasCd",
    "PanelReason" : "PanelReason",
    "IdcardInd" : "IdCardInd",
    "HmoPpoInd" : "HmoPpoInd",
    "Id" : "Id"
}

# COMMAND ----------

# DBTITLE 1,GH to CI customer
try:
    # Filter only unprocessed records from stage table.
    stg_pcp_attr_df = read_table_to_df(pcp_stage_tbl_name)\
                        .filter(col('Comment').isNull())

    # Read data from customer table.
    customer_df = read_table_to_df(customer_tbl_name)

    # Column name conversion.
    col_name_trans_stg_df = col_name_mapping(stg_pcp_attr_df, col_map_dict)

    # Compute min of MemberProvEffDate.
    min_coveragedate = col_name_trans_stg_df.select(min('MemberProvEffDate')).first()[0]

    # Convert CI to GH customer.
    ci_converted_df = switchable_gh_ci_conversion(col_name_trans_stg_df, customer_df)

    cust_add_col_map = {
    "Comment" : when(col("IsCustomerFound") == 'N', f"Customer not found in service fund {customer_tbl_name}"), 
    "ErrorCode" : when(col("IsCustomerFound") == 'N', "E4")
    }
    # Add Comment and ErrorCode for customer not found transaction
    valid_customer_df = ci_converted_df.withColumns(cust_add_col_map)
except Exception as e:
    excep = 'Ingest data to stage table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Member Validation
try:
    # Read member stage table and select only the required the columns.
    member_df = read_table_to_df(member_table_name)\
                .selectExpr('MemberKey'
                            ,'MemberId'
                            ,'SubscriberId'
                            ,'MemberCustomerNumber')

    mem_join_condition = ((col('LH.MemberId') == col('RH.MemberId')) 
                        & (col('LH.CIGroupIdentifier') == col('RH.MemberCustomerNumber'))
                        & (col('LH.SubscriberId') == col('RH.SubscriberId'))
                        & (col('LH.Comment').isNull()))

    # Join the delta data frame with member dateframe on above condition.            
    member_validation_df = valid_customer_df.alias('LH')\
                            .join(member_df.alias('RH'),mem_join_condition,'left')\
                            .selectExpr('LH.*', "RH.MemberKey")
    mem_add_col_map = {
        "Comment" : when((col("MemberKey").isNull()) & (col('Comment').isNull()), f"Member not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(member_table_name)}")\
                        .otherwise(col("Comment")), 
        "ErrorCode" : when((col("MemberKey").isNull()) & (col('Comment').isNull()), "E6")\
                        .otherwise(col("ErrorCode"))
    }
                            
    # Filter only the coverage where member found.
    col_added_member_df = member_validation_df.withColumns(mem_add_col_map)
    valid_member_df = col_added_member_df.withColumn("IsRejected",when(col('Comment').isNull(), lit('N')).otherwise(lit('Y')))
    valid_member_df.cache()
except Exception as e:
    excep = 'Member validation failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Updating CI Identifier to stage table
try:
    # Dictonary contains CI Identifier columns to update in stage table for successful transaction.
    ci_identifier_set_dict = {
    "CIGroupIdentifier": "updates.CIGroupIdentifier",
    "CIClassNumber": "updates.CIClassNumber",
    "BenefitSequence" : "updates.BenefitSequence"
    }

    # Dictonary contains columns to update in stage table for rejected transaction.
    rejected_trans_set_dict = {
    "Comment": "updates.Comment",
    "ErrorCode": "updates.ErrorCode"
    }

    # Update CI Identifier's to the stage table.
    apply_custom_scd_type(valid_member_df, pcp_stage_tbl_name, ci_identifier_set_dict, rejected_trans_set_dict)
except Exception as e:
    excep = 'Updating CI Identifier to stage table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Identify overlap records
try:
    filtered_member_df = valid_member_df.filter(col('Comment').isNull())
    # Read data from stage member coverage table.
    member_coverage_df = read_table_to_df(mem_cov_table_name)\
                            .filter((col('CoverageEndDate') >= min_coveragedate) & (col('CoverageTypeCode') == 'PCP'))

    # Create a select list to rename the columns
    mem_cov_col_list = create_select_list(member_coverage_df.columns)
                    

    # Convert the column names by passing the select list to selectExpr.
    col_name_convtd_mem_cov_df = member_coverage_df.selectExpr(*mem_cov_col_list)

    join_condition = (((col('LH.MemberKey') == col('RH.OldMemberKey')))
                        & ((col('LH.MemberProvEffDate') <= col('RH.OldCoverageEndDate')))
                        & ((col('LH.MemberProvEndDate') >= col('RH.OldCoverageStartDate')))
                        & ((col('LH.Comment').isNull())))
                                                                    
    # Join exists coverage dataframe with member coverage to identify overlap coverages. And add IsNewCoverage and IsCoverageOverlap columns.
    exists_coverage_df = filtered_member_df.alias('LH')\
                            .join(col_name_convtd_mem_cov_df.alias('RH'),join_condition,'left')\
                            .selectExpr("LH.Id","LH.ProvId","LH.ProvSuffix", "LH.ProvType","LH.MemberProvEffDate","LH.MemberProvEndDate","LH.CoverageEndReasonCode","LH.Comment", "LH.LedgerNumber", "LH.GHGroupIdentifier", "LH.EmployerGroupNumber", "LH.MemberId", "LH.PanelReason" ,"LH.ErrorCode","LH.IdCardInd","RH.*")

                            

    mem_cov_add_col_map = {
        "Comment" : when((col("OldMemberCoverageKey").isNull()) & (col('Comment').isNull()), f"Member Coverage not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(mem_cov_table_name)}")\
                        .otherwise(col("Comment")), 
        "ErrorCode" : when((col("OldMemberCoverageKey").isNull()) & (col('Comment').isNull()), "E7")\
                        .otherwise(col("ErrorCode"))
    }

    overlap_coverage_df = exists_coverage_df.withColumns(mem_cov_add_col_map)

    overlap_coverage_df.cache()
except Exception as e:
    excep = 'Identify overlap records failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

def find_overlap_records(df, table_name):
    # Define window specification
    window_spec = Window.partitionBy('OldMemberKey').orderBy('OldCoverageStartDate', 'OldCoverageEndDate')

    # Find the previous end date for each row
    df = df.selectExpr("*", "lag(OldCoverageEndDate) over(partition by OldMemberKey order by OldCoverageStartDate, OldCoverageEndDate) AS PrevEndDate", "lead(OldCoverageEndDate) over(partition by OldMemberKey order by OldCoverageStartDate, OldCoverageEndDate) AS AfterStartDate")
    # Check for overlapping date
    df = df.withColumn("OverlapPrev", when((col("OldCoverageStartDate") <= col("PrevEndDate")) & (col("OldCoverageEndDate") >= col("PrevEndDate")), lit(1)).otherwise(lit(0)))\
        .withColumn("OverlapAfter", when((col("OldCoverageStartDate") <= col("AfterStartDate")) & (col("OldCoverageEndDate") >= col("AfterStartDate")), lit(1)).otherwise(lit(0))).drop('PrevEndDate', 'AfterStartDate')
    # Define window specification

    col_maps = {
        "Comment" : when(((col('OverlapAfter') == 1) | (col('OverlapPrev') == 1)), f"Single input transaction trying to update the PCP of multiple member coverage records in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(table_name)}").otherwise(col('Comment')),
        "ErrorCode" : when(((col('OverlapAfter') == 1) | (col('OverlapPrev') == 1)), "E17").otherwise(col('ErrorCode'))
    }
    trans_df = df.withColumns(col_maps).drop('OverlapAfter', 'OverlapPrev')

    col_maps = {
        "Comment" : when((col('MemberProvEndDate') != col('MaxEndDate')) & (col('Comment').isNull()), f"Input transaction end date does not match the end date of member coverage in service fund {create_sql_tbl_name_from_dbk_stage_tbl_name(table_name)}").otherwise(col('Comment')),
        "ErrorCode" : when((col('MemberProvEndDate') != col('MaxEndDate')) & (col('Comment').isNull()), "E19").otherwise(col('ErrorCode'))
    }
    final_df = trans_df.withColumns(col_maps)
    return final_df

# COMMAND ----------

try:
  # Filter out only the overlap transaction
  valid_transaction_df = overlap_coverage_df.filter(col('Comment').isNull())
  # Filter out non overlapping transaction
  rejected_transaction_df = overlap_coverage_df.filter(col('Comment').isNotNull())\
                              .selectExpr("Id", "Comment", "ErrorCode")
  # Identify multiple source transaction are overlapping with single target to reject it.
  calc_overlap_count_df = valid_transaction_df.selectExpr("*", 
                              "COUNT(1) OVER(PARTITION BY OldMemberKey, MemberProvEffDate ORDER BY 1) AS SrcOverlapCnt", 
                              "COUNT(1) OVER(PARTITION BY OldMemberKey, OldCoverageStartDate ORDER BY 1) AS TgtOverlapCnt", 
                              "MIN(OldCoverageStartDate) OVER(PARTITION BY OldMemberKey, MemberProvEffDate ORDER BY 1) AS MinStartDate", 
                              "MAX(OldCoverageEndDate) OVER(PARTITION BY OldMemberKey, MemberProvEffDate ORDER BY 1) AS MaxEndDate")
  calc_overlap_count_df = calc_overlap_count_df.withColumn("IsCoverageOverlap", when((col('MemberProvEffDate') == col('MinStartDate')) & (col('MemberProvEndDate') == col('MaxEndDate')), lit(0)).otherwise(lit(1)))

  overlap_filtered_df = calc_overlap_count_df.filter((col('SrcOverlapCnt') == 1) & (col('TgtOverlapCnt') == 1) & (col('MemberProvEndDate') == col('OldCoverageEndDate')))

  # Reject transactions when multiple input transaction overlap with single target transaction.
  multiple_target_overlap_df = calc_overlap_count_df.filter((col('SrcOverlapCnt') > 1))
  
  identified_overlap_rec_df = find_overlap_records(multiple_target_overlap_df, mem_cov_table_name)

  multiple_target_overlap_df = identified_overlap_rec_df.filter(col('Comment').isNotNull())\
                                .selectExpr("Id", "Comment", "ErrorCode")\
                                .drop_duplicates()

  # Reject transactions when one input transaction overlap with multiple target transaction.
  multiple_source_overlap_df = calc_overlap_count_df.filter((col('TgtOverlapCnt') > 1) & (col('SrcOverlapCnt') == 1))\
                              .selectExpr("Id", f"'Multiple PCP update transactions for same member in the incoming file. Only one PCP update per member allowed' AS Comment", "'E18' AS ErrorCode")
                              


  # Reject records when input transaction end date does not match with exists member coverage end date.
  end_date_not_match_df =  calc_overlap_count_df.filter((col('SrcOverlapCnt') == 1) & (col('TgtOverlapCnt') == 1) & (col('MemberProvEndDate') != col('OldCoverageEndDate'))).selectExpr("Id", f"'Input transaction end date does not match the end date of member coverage in service fund {create_sql_tbl_name_from_dbk_stage_tbl_name(mem_cov_table_name)}' AS Comment", "'E19' AS ErrorCode")

  overlap_filtered_df = overlap_filtered_df.unionByName(identified_overlap_rec_df.filter(col('Comment').isNull()), allowMissingColumns=True)
except Exception as e:
    excep = 'Identify overlap records failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Member coverage split
try:
    win_spec = Window.partitionBy('OldMemberKey', 'MemberProvEffDate').orderBy('OldCoverageStartDate', 'OldCoverageEndDate')
    overlap_filtered_df = overlap_filtered_df\
                                        .withColumn("RowNo", row_number().over(win_spec))

    select_list = ['Id', 'OldMemberCoverageKey AS MemberCoverageKey','OldMemberKey AS MemberKey','OldProviderContractKey AS ProviderContractKey','OldProductKey AS ProductKey','OldExtProdSeqNo AS ExtProdSeqNo','OldCoverageTypeCode AS CoverageTypeCode','OldCoverageTypeCodeLabel AS CoverageTypeCodeLabel',"OldCoverageEndReasonCode",'OldCoverageEndReasonCodeLabel AS CoverageEndReasonCodeLabel','OldVendorSequenceNumber AS VendorSequenceNumber','OldWokerCompensationOccurenceId AS WokerCompensationOccurenceId','OldCIClassNumber AS CIClassNumber','OldMemberCustomerNumber AS MemberCustomerNumber','OldMemberGroupNumber AS MemberGroupNumber',"CoverageEndReasonCode","OldCreatedDateTime AS CreatedDateTime", "OldCreatedBy AS CreatedBy","OldModifiedDateTime AS ModifiedDateTime", "OldModifiedBy AS ModifiedBy", "OldGateKeeperProviderId", "OldGateKeeperProviderSuffixCode", "LedgerNumber", "GHGroupIdentifier", "EmployerGroupNumber", "MemberId", "PanelReason", "IsCoverageOverlap", "IdCardInd"]

    newpcp_df = overlap_filtered_df.selectExpr(*select_list, "CASE WHEN RowNo = 1 AND MemberProvEffDate <= OldCoverageStartDate THEN OldCoverageStartDate WHEN RowNo > 1 THEN OldCoverageStartDate ELSE MemberProvEffDate END as CoverageStartDate", "OldCoverageEndDate AS CoverageEndDate", "CASE WHEN RowNo = 1 AND MemberProvEffDate > OldCoverageStartDate THEN 'INSERT' ELSE 'UPDATE' END AS DerivedIndicator", "'NewProvider' AS Action", "ProvId AS GateKeeperProviderId","ProvSuffix AS GateKeeperProviderSuffixCode","ProvType AS GateKeeperProviderTypeCode").drop('ProviderKey', 'ProviderContractKey')

    termdates_df = overlap_filtered_df.filter((col('RowNo') == 1) & (col('MemberProvEffDate') > col('OldCoverageStartDate'))).selectExpr(*select_list, "OldCoverageStartDate AS CoverageStartDate", "to_date(DATEADD(day, -1, MemberProvEffDate), 'yyyy-MM-dd') AS CoverageEndDate", "'UPDATE' AS DerivedIndicator", "'TermEndDate' AS Action", "OldGateKeeperProviderId AS GateKeeperProviderId","OldGateKeeperProviderSuffixCode AS GateKeeperProviderSuffixCode","OldGateKeeperProviderTypeCode AS GateKeeperProviderTypeCode")
except Exception as e:
    excep = 'Member coverage split failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Validate provider and get ProviderKey
try:
    # When there are two records with the same provider Id and Suffix Code, one being a doctor and the other a hospital, prioritize the doctor record in this case.

    provider_df = read_table_to_df(provider_table_name)\
                    .selectExpr('ProviderKey',"cast(ProviderId AS int) AS ProviderId", 'SuffixCode', 'Type2Code')

    prt_prov_df = prioritize_prv_type2Code(provider_df)

    prv_join_condition = ((col('Delta.GateKeeperProviderId') == col('PRV.ProviderId'))
                            & (trim(col('Delta.GateKeeperProviderSuffixCode')) == trim(col('PRV.SuffixCode'))))
    
    # Join delta dataframe with provider and get provider key.
    prov_joined_df = newpcp_df.alias('Delta')\
                        .join(prt_prov_df.alias('PRV'),prv_join_condition,'Left')\
                        .selectExpr('Delta.*','PRV.ProviderKey')

    # Filter out valid and invalid providers.
    valid_prv_df = prov_joined_df.filter(col('ProviderKey').isNotNull())
    invalid_prv_df = prov_joined_df.filter(col('ProviderKey').isNull())\
                    .selectExpr('Id', f"'Provider not found in service fund domain table {create_sql_tbl_name_from_dbk_stage_tbl_name(provider_table_name)}' AS Comment", "'E8' AS ErrorCode")
except Exception as e:
    excep = 'Validate provider and get ProviderKey failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read Provider Contract, Affiliation & Association tables
try:
    # Read ProviderContract, ProviderContractProductAffiliation, ProductSetAffiliation and ProductSetAssociation. And select only the required columns
    pc_filtered_df = read_table_to_df(pc_table_name)\
                .filter((col('ContractStartDate') != col('ContractEndDate')) & (col('ContractEndDate') >= min_coveragedate) & (col('ProviderServiceTypeCode').isin(['PCP', 'FFS'])))

    pc_df = pc_filtered_df.selectExpr('ProviderContractKey as ProviderContractKey_pc'
                            ,'ProviderContractId as ProviderContractId_pc'
                            ,'ProviderKey as ProviderKey_pc'
                            ,'ProviderId as ProviderId_pc'
                            ,'ProviderSequenceNumber'
                            ,'ContractStartDate'
                            ,'ContractEndDate')          
                
    pcpa_df = read_table_to_df(pc_prd_affil_table_name)\
                    .selectExpr("ProductAffiliationKey", "ProviderContractKey", "ProviderContractId")
    psaff_df = read_table_to_df(pc_prd_set_affil_table_name)\
                    .selectExpr("ProductAffiliationKey", "ProductSetKey")
    psass_df = read_table_to_df(pc_prd_set_asso_table_name)\
                    .selectExpr("ProductKey", "ProductSetKey")
except Exception as e:
    excep = 'Read Provider Contract, Affiliation & Association tables failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Provider Contract Assignment
try:
    # Contract Assignment
    pc_assigned_df, rejected_upt_ins_df = assign_providercontract(valid_prv_df, pc_df, pcpa_df, psaff_df, psass_df, pc_table_name)
    rejected_upt_ins_df = rejected_upt_ins_df.select("Id", "Comment", "ErrorCode")

    # Join product table to get the LineOfBusinessCode. which is used in populating the ModifiedDateTime.
    prd_df = read_table_to_df(prd_table_name)\
                .selectExpr("ProductKey", "LineOfBusinessCode")

    pc_assigned_df = pc_assigned_df.join(prd_df, ['ProductKey'], 'inner')
except Exception as e:
    excep = 'Provider Contract Assignment failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Remove partially processed transaction
try:
    rejected_df = union_by_name([rejected_upt_ins_df, invalid_prv_df])

    termdates_df = termdates_df.join(rejected_df, ['Id'], 'leftAnti')
except Exception as e:
    excep = 'Remove partially processed transaction failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write processed transaction to delta table
try:
    # Add CreatedBy, CreatedDateTime, ModifiedBy, ModifiedDateTime, ProcessName, CoverageTypeCode, CoverageTypeCodeLabel, VendorSequenceNumber, CoverageEndReasonCodeLabel and DeltaStatus to dataframe.
    col_map = {
        "CreatedBy" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedBy')).otherwise(lit(audit_name))
        ,"CreatedDateTime" : when(col('DerivedIndicator') == 'UPDATE', col('CreatedDateTime')).otherwise(lit(current_timestamp()))
        ,"ModifiedBy" : when((col('Action') == 'TermEndDate') & (col('ModifiedBy').contains('#mbr_attr_of')), lit(attr_audit_name))\
                        .when((col('LineOfBusinessCode').isin(['MEP', 'MEF'])), lit(attr_audit_name))\
                        .otherwise(lit(audit_name))
        ,"ModifiedDateTime" : lit(current_timestamp())
        ,"ProcessName" : lit(process_name).cast("string")
        ,"DeltaStatus" : lit(None).cast("string")
        ,"GateKeeperProviderId" : lpad(col("GateKeeperProviderId"), 9, '0')
        ,"BeforeAfterCd" : lit('/AFTER')
    }

    pcp_attributed_df = union_by_name([termdates_df, pc_assigned_df, rejected_df, rejected_transaction_df, multiple_target_overlap_df,multiple_source_overlap_df, end_date_not_match_df])\
                            .withColumns(col_map)
    
    col_dropped_df = overlap_coverage_df.drop('ProvId','ProvSuffix','ProvType','MemberProvEffDate','MemberProvEndDate','CoverageEndReasonCode','Comment','ErrorCode','OldCreatedBy','OldCreatedDateTime','OldModifiedBy','OldModifiedDateTime')

    col_list = [f"{colm} AS {colm.replace('Old', '')}" for colm in col_dropped_df.columns]
    before_pict_df = col_dropped_df.selectExpr(*col_list, "'BEFORE' AS BeforeAfterCd")

    calc_cov_end_reas_df = pcp_attributed_df.withColumn('CoverageEndReasonCode', expr("CASE WHEN CoverageEndDate = '9999-12-31' THEN '  ' WHEN Action = 'TermEndDate' AND trim(OldCoverageEndReasonCode) = '' THEN 'SG' WHEN Action = 'TermEndDate' AND trim(OldCoverageEndReasonCode) <> '' THEN OldCoverageEndReasonCode WHEN CoverageEndDate <> '9999-12-31' THEN 'MT' END")).drop('OldCoverageEndReasonCode', 'IsCoverageOverlap')

    before_after_union_df = calc_cov_end_reas_df.unionByName(before_pict_df, allowMissingColumns = True)

    # Write to ProviderContractSplit table. 
    write_df_as_delta_table(before_after_union_df, pcp_attr_processed_table_name)

    valid_member_df.unpersist()
    overlap_coverage_df.unpersist()

except Exception as e:
    excep = f'Write processed transaction to delta table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write data to Azure SQL table
try:
    prv_ctrt_splitted_df = read_table_to_df(pcp_attr_processed_table_name)

    prv_ctrt_splitted_df.cache()

    after_filtered_df = prv_ctrt_splitted_df.filter((col('BeforeAfterCd') == '/AFTER') & (col('Comment').isNull()))

    # Read from ProviderContractSplit table.
    processed_df = after_filtered_df\
                    .drop('ProviderKey', 'Id', 'Action','Comment', 'ErrorCode', 'OldCoverageEndReasonCode', 'OldGateKeeperProviderId',
                            'OldGateKeeperProviderSuffixCode','LedgerNumber', 'GHGroupIdentifier', 'EmployerGroupNumber', 
                            'MemberId', 'PanelReason','BeforeAfterCd', 'LineOfBusinessCode', 'IdCardInd')

    # Change column nullable to False.
    delta_df= set_df_columns_not_nullable(spark,processed_df,['MemberKey', 'ProviderContractKey', 'ProductKey','CoverageStartDate', 'CreatedBy','CreatedDateTime'])
    
    # Change column nullable to True.
    delta_col_df = set_df_columns_not_nullable(spark,delta_df,['ProcessName', 'CoverageTypeCode', 'CoverageTypeCodeLabel', 'VendorSequenceNumber', 'DerivedIndicator', 'CoverageEndDate'], True)
    
    # Write data to Azure SQL stage table.
    load_df_to_sf_sql_db_spark(delta_col_df, mem_cov_sql_tbl_name)
except Exception as e:
    excep = f'Write data to Azure SQL table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Get rejected transaction from processed table
try:
    # Read rejected transaction from Member_MemberPcpAttributionProcessed.
    prc_rejected_df = prv_ctrt_splitted_df.filter((col('Comment').isNotNull()) & (col('BeforeAfterCd') == '/AFTER'))
    # Read Stage table from Member_StageMemberPcpAttribution.
    stg_pcp_attr_df = read_table_to_df(pcp_stage_tbl_name)
    # Filter non rejected from stage table.
    stg_valid_df = stg_pcp_attr_df.filter(col('Comment').isNull()).drop('Comment', 'ErrorCode')
    # Filter rejected from stage table.
    stg_rejected_df = stg_pcp_attr_df.filter(col('Comment').isNotNull())
    # Join stage table and get all the input columns for the report.
    prc_rejected_df = prc_rejected_df.alias('LH').join(stg_valid_df.alias('RH'), ['Id'], 'inner')\
                            .selectExpr("RH.*", 'LH.Comment', 'LH.ErrorCode')
    prc_valid_df = stg_valid_df.join(prc_rejected_df, ['Id'], 'leftAnti')
except Exception as e:
    excep = f'Get rejected transaction from processed table failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write rejected records to outbound file
try:
    rejected_union_df = union_by_name([prc_rejected_df,stg_rejected_df])\
                .selectExpr('ProdMktNbr', 'SrcAltCustId', 'SrcAltCustBenId', 'CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber','MemberId', 'SubscriberId', 'ProvId', 'ProvSuffix', 'ProvType', 'MbrProvEffCymdDate', 'MbrProvEndCymdDate', 'PrevEndReasCd', 'CurrEndReasCd', 'PanelReason', 'IdCardInd', 'HmoPpoInd', 'Comment', 'ErrorCode')
                
    # Report generation
    generate_report(rejected_union_df, outbnd_temp_err_csv_path, outbnd_csv_path, err_file_name)
except Exception as e:
    excep = 'Write rejected records to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write processed records to success outbound file
try:
    processed_df =  prc_valid_df\
                           .selectExpr('ProdMktNbr', 'SrcAltCustId', 'SrcAltCustBenId', 'CIGroupIdentifier', 'BenefitSequence', 'CIClassNumber' ,'MemberId', 'SubscriberId', 'ProvId', 'ProvSuffix', 'ProvType', 'MbrProvEffCymdDate', 'MbrProvEndCymdDate', 'PrevEndReasCd', 'CurrEndReasCd', 'PanelReason', 'IdCardInd', 'HmoPpoInd', "'Processed' as Comment")
    # Report generation
    generate_report(processed_df, outbnd_temp_success_csv_path, outbnd_csv_path, success_file_name)
except Exception as e:
    excep = 'Write processed records to success outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Create detail report
try:
    # Read the data from the Member_MemberPcpAttributionProcessed table and select only the required columns.
    col_selected_df = prv_ctrt_splitted_df.selectExpr('Id','Action','ProviderContractKey','CoverageStartDate','CoverageEndDate','BeforeAfterCd','LedgerNumber', 'GHGroupIdentifier', 'EmployerGroupNumber', 'MemberId', 'PanelReason', 'OldGateKeeperProviderId', 'OldGateKeeperProviderSuffixCode', 'IdCardInd')

    # Processed table will contain after (sucess and rejected) transaction and before transaction.
    # Get only the after rejected transaction.
    rejected_trans_df = col_selected_df.filter((col('Comment').isNotNull()) & (col('BeforeAfterCd') == '/AFTER'))
    # Get only the "before transaction".
    before_df = col_selected_df.filter((col('BeforeAfterCd') == 'BEFORE'))
    # Get only the after success transaction.
    after_df = col_selected_df.filter((col('BeforeAfterCd') == '/AFTER') & (col('Comment').isNull()))
    # We are fetching the "before transaction" before member coverage split. So we need to remove the members which are reject on member coverage validation, provider validation and pcp assigment.
    rej_removed_before_df = before_df.join(rejected_trans_df, ['Id'], 'leftanti')
    # Union before adn after data
    before_after_df = rej_removed_before_df.unionByName(after_df)

    # Join provider contract to get 'ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber'
    pc_filtered_df = pc_filtered_df.select('ProviderContractKey', 'ProviderId', 'ProviderSuffixCode', 'ProviderServiceTypeCode', 'ProviderSequenceNumber') 
    pc_joined_df = before_after_df.join(pc_filtered_df, ['ProviderContractKey'], 'inner')

    wind_spec = Window.partitionBy('MemberId', 'GHGroupIdentifier').orderBy(desc('BeforeAfterCd'), asc('MemberId'), asc('GHGroupIdentifier'), asc('EmployerGroupNumber'), asc('CoverageStartDate'))

    col_map = {
        'OldProviderId' : when(col('BeforeAfterCd') == 'BEFORE', col('ProviderId')).otherwise(col('OldGateKeeperProviderId')),
        'OldProviderSuffixCode' : when(col('BeforeAfterCd') == 'BEFORE', col('ProviderSuffixCode')).otherwise(col('OldGateKeeperProviderSuffixCode')),
        'UpdateInd' : when(col('BeforeAfterCd') == 'BEFORE', lit('D')).otherwise(lit('A')),
        'MemberZipCd' : lit(None),
        'ActionCode' : lit(None),
        'SeqNo' : row_number().over(wind_spec),
        'Filler' : lit(None),
        'Message' : when(col('BeforeAfterCd') == 'BEFORE', lit('MEMBER MOVED SUCCESSFULLY')).otherwise(None)

    }

    detail_report_df = pc_joined_df.withColumns(col_map).drop('ProviderContractKey', 'Id', 'Action','OldGateKeeperProviderId', 'OldGateKeeperProviderSuffixCode')
except Exception as e:
    excep = 'Create detail report failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Write detail report to outbound file
try:
  # Convert all column to fixed width using config.
  final_df = convert_col_to_fixed_width(fixed_config_df, detail_report_df)
  # Write dataframe as .txt file with position delimitor.
  write_outbnd_file_to_adls(final_df, outbnd_temp_detail_csv_path, config)
  # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
  copy_file_to_outbnd_with_new_name(outbnd_temp_detail_csv_path, outbnd_csv_path, detail_file_name)

  prv_ctrt_splitted_df.unpersist()
except Exception as e:
    excep = 'Write detail report to outbound file failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Insert success transaction to audit table and exit report file name
# Insert success entry to the audit table.
insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, None, process ="DBP")
# Exit outbound file names
concated_outbound_file_names =  err_file_name+','+success_file_name+','+detail_file_name
dbutils.notebook.exit(concated_outbound_file_names)
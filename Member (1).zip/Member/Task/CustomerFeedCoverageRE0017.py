# Databricks notebook source
# MAGIC %md
# MAGIC ##### The process RE0017 creates an outbound file containing the effected members of the New Customers or Customers whose Product was changes.
# MAGIC ##### This outbound file will be used by MemberCoverage Job
# MAGIC ##### Source Tables
# MAGIC - StageDBPCustomerProduct - UC outbound table from RE0016
# MAGIC
# MAGIC ##### Target Tables
# MAGIC - Outbound UC table - catalog_name.schema_name.RE0017
# MAGIC - Outbound File - RE0017.txt
# MAGIC
# MAGIC ##### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','pl_CustomerCoverage')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_NAME','CustomerFeedCoverageRE0017')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('LOAD_TYPE','')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')

# COMMAND ----------

try:
    if LOAD_TYPE == "FullLoad":
        dbutils.notebook.exit("This process is for Delta only")
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Environment Variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Setting up local variables
audit_start_date_time = datetime.now()
job_type = 'DailyJobs'

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict["DEFAULT"]

    default_out_config = default_config["Outbound"]
    default_in_config = default_config["Inbound"]
    container_name = default_config["ContainerName"]
    audit_table_name = default_config["AuditTableName"]
    
    re0017_config = config_dict[job_name]

    file_path_suffix = default_in_config["FilePathSuffix"]

    config = default_out_config["Config"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]

    UCCustomer = re0017_config["Inbound"]["UCCustomer"]

    outboundUCRE0017 = re0017_config["Outbound"]["outboundUCRE0017"]
    TempFilePathSuffix0017 = re0017_config["Outbound"]["TempFilePathSuffix0017"]
    file_path_prefix_0017 = re0017_config["Outbound"]["FilePathPrefix_0017"]
    outbnd_file_name = re0017_config["Outbound"]["outbnd_file_name"]

except Exception as e:
    excep = 'Variable assignment from FileConfig: '+str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Sync stage CustomerProduct table for MemberCoverage split process
try:
   dbutils.notebook.run('../Orchestrate/StageTableSyncExecute',0, {'TABLE_NAMES' : 'CustomerProduct', 'PIPELINE_RUN_ID': PIPELINE_RUN_ID, 'JOB_TYPE': job_type, 'PIPELINE_NAME': PIPELINE_NAME})
except Exception as e:
    excep = 'Sync Process Failed: '+ str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Read UC table
try:
    df_customer = read_table_to_df(UCCustomer)
except Exception as e:
    excep = "Reading config file failed: " + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        TempFilePathSuffix0017
    )

    # Outbound location is not dataprocessing/outbound
    # Outbound location for this job is dataprocessing/inbound as this file will be used by MemberCoverage split process
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix_0017
    )

except Exception as e:
    excep = "Reading config file failed: " + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Column mapping as per outbound file
col_map = {
    'MarketNumber':'REENRCHG_PCA_FIN_RPT_LEDGR_NBR',
    'GHGroupIdentifier':'REENRCHG_MBR_ENRL_CUST_NBR',
    'EmployerGroupNumber':'REENRCHG_MBR_ENRL_GRP_NBR',
    'MemberId':'REENRCHG_MBRPID',
    'ProviderId':'REENRCHG_GK_PROV_ID_NBR',
    'ProviderSuffixCode':'REENRCHG_GK_PROV_SUFF_CD',
    'ProviderServiceTypeCode':'REENRCHG_GK_PROV_TY_CD',
    'CoverageStartDate_format':'REENRCHG_MBR_PROV_EFF_CYMD',
    'CoverageEndDate_format':'REENRCHG_MBR_PROV_END_CYMD',
    'ProcessAgain':'REENRCHG_PROCESS_AGAIN_COUNTER',
    'WokerCompensationOccurenceId':'REENRCHG_WORKCMP_OCCUR_P_ID',
    'PrevPcpEndReasCd':'REENRCHG_PREV_PCP_END_REAS_CD',
    'CoverageEndReasonCode':'REENRCHG_CURR_PCP_END_REAS_CD',
    'PcpReasInd':'REENRCHG_PCP_REASON_INDICATOR',
    'SubscriberId':'REENRCHG_SUBPID'
}

# COMMAND ----------

# DBTITLE 1,Get the Customer GH Values
try:
    qry_df_0017 = query_re0017()
    df_effected_members = read_sf_sql_tbl_to_df_spark(query=qry_df_0017)

    df_GH_cust = df_effected_members.alias('LH').join(df_customer.alias('RH'), (col('LH.MemberCustomerNumber') == col('RH.CIGroupIdentifier')) & (col('LH.MemberGroupNumber') == col('RH.BenefitSequence')) & (col('LH.CIClassNumber') == col('RH.CIClassNumber')), 'inner')\
        .select('LH.*', 'RH.GHGroupIdentifier', 'RH.EmployerGroupNumber', date_format('LH.CoverageStartDate','yyyyMMdd').alias('CoverageStartDate_format'), date_format('LH.CoverageEndDate','yyyyMMdd').alias('CoverageEndDate_format'))\
        .drop('LH.MemberCustomerNumber', 'LH.MemberGroupNumber', 'LH.CIClassNumber','LH.CoverageStartDate', 'LH.CoverageEndDate')
    
    withCols = {
        'ProcessAgain': lit(None).cast('STRING'),
        'PrevPcpEndReasCd': lit(None).cast('STRING'),
        'PcpReasInd': lit(None).cast('STRING')
    }

    df_extra_cols = df_GH_cust.withColumns(withCols)

    write_df_as_delta_table(df_extra_cols,outboundUCRE0017)

except Exception as e:
    excep = "Effected Member query retrieval failed: " + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,Create Outbound file
try:
    # Read the outbound table and rename columns names as per outbound file
    df_0017_table = read_table_to_df(outboundUCRE0017)
    df_final = col_name_mapping(df_0017_table, col_map)

    # create outbound file with "|" separator
    generate_report(df_final, temp_csv_path, outbnd_csv_path, outbnd_file_name)
    
except Exception as e:
    excep = "Run failed: " + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)
else:
    excep = "RUN was successful"
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, JOB_NAME, job_type, audit_start_date_time, 'Success' ,audit_table_name, excep)
    dbutils.notebook.exit(excep)
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Monthly Job RE3002-OpenFundPaidCoverageExtract to create service fund open fund period extract
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC - Member.StageMember
# MAGIC - MemberCoverage.StageMemberCoverage
# MAGIC - Product.StageProduct
# MAGIC - Provider.StageProvider
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - ProviderContractStageProviderContractGeoMktAffiliation
# MAGIC - Product.ProductGeoMarketAffiliation
# MAGIC - Accounting.StageFinanceLedgerHeader
# MAGIC - Accounting.StageFinanceLedgerFundPeriod
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC - SFOpenFundPeriod.txt
# MAGIC - SFOpenFundPaidCoverageExtract.txt
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import required libraries
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
  file_conf_path = env_file_config_path
  fxd_wdth_path = env_fxd_wdt_file_config_path
  storage_account = env_storage_account_name
except Exception as e:
  excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
  job_name = JOB_NAME
  config_dict =  get_file_config(file_conf_path)
  fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
  var="FileNm"
  fixed_config_ext_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == f"{job_name}{var}")

except Exception as e:
  excep = 'Read File Config and Fixed Width File Config: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict['DEFAULT']
  default_out_config = default_config['Outbound']
  op_fund_paid_cvg_config = config_dict[job_name]

  container_name = default_config['ContainerName']
  file_path_prefix = default_out_config['FilePathPrefix']
  config = default_out_config['Config']

  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  temp_path_suffix1 = op_fund_paid_cvg_config["Outbound"]["TempFilePathSuffix1"]   
  temp_path_suffix2 = op_fund_paid_cvg_config["Outbound"]["TempFilePathSuffix2"] 
  curated_path_suffix1 = op_fund_paid_cvg_config["Outbound"]["CuratedFilePathSuffix1"]
  curated_path_suffix2 = op_fund_paid_cvg_config["Outbound"]["CuratedFilePathSuffix2"]
  outbnd_file_name1 = op_fund_paid_cvg_config["Outbound"]["FileName1"]
  outbnd_file_name2 = op_fund_paid_cvg_config["Outbound"]["FileName2"]
  
  cust_tbl = op_fund_paid_cvg_config["Inbound"]["StgCustTbl"]
  ci_mbr_tbl = op_fund_paid_cvg_config["Inbound"]["StgCiMbrTbl"]
  stg_member = op_fund_paid_cvg_config["Inbound"]["StageMember"]
  stg_member_cov = op_fund_paid_cvg_config["Inbound"]["StageMemberCoverage"]
  stg_product = op_fund_paid_cvg_config["Inbound"]["StageProduct"]
  stg_provider = op_fund_paid_cvg_config["Inbound"]["StageProvider"]
  stg_provider_cntrct_ctrl = op_fund_paid_cvg_config["Inbound"]["StageProviderContractControl"]
  stg_provider_contract = op_fund_paid_cvg_config["Inbound"]["StageProviderContract"]
  stg_productgeomarketaffiliation = op_fund_paid_cvg_config["Inbound"]["StageProductGeoMarketAffiliation"]
  stg_providercontractgeomktaffiliation = op_fund_paid_cvg_config["Inbound"]["StageProviderContractGeoMktAffiliation"]
  stg_geomarketaffiliation = op_fund_paid_cvg_config["Inbound"]["StageGeoMarketAffiliation"]
  stg_finledgerhdr = op_fund_paid_cvg_config["Inbound"]["StageFinanceLedgerHeader"]
  stg_finledgerfndprd = op_fund_paid_cvg_config["Inbound"]["StageFinanceLedgerFundPeriod"]
  Re3002CoverageExtrctTbl = op_fund_paid_cvg_config["Outbound"]["TableName"]
  sync_process_names = op_fund_paid_cvg_config["Inbound"]["StageSyncProcessNames"]
  ctrl_table_name = default_config["AuditTableName"]
    
except Exception as e:
  excep = 'Variable assignment from FileConfig: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
  prc_status = start_process_check(ctrl_table_name, sync_process_names)
  if prc_status != True:
      dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
  excep = "ControlTable check failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    cur_delta_path1 = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        curated_path_suffix1
    )
    cur_delta_path2 = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        curated_path_suffix2
    )
    temp_csv_path1 = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix1     
    )
    temp_csv_path2 = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix2  
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account, 
        path_prefix=file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

df_member_cols=[
    'MemberKey',
    'MemberCustomerNumber',
    'MemberId',
    'SubscriberId',
    'MemberBirthDate',
    'MemberLastName',
    'MemberFirstName',
    'MemberMiddleName',    
]
df_member_cov_cols=[
    'MemberKey',
    'ProductKey',
    'ProviderContractKey',
    'CIClassNumber',
    'CoverageStartDate',
    'CoverageEndDate',
    'WokerCompensationOccurenceId',
    'CoverageEndReasonCode',
    'MemberGroupNumber',
    'ExtProdSeqNo'
]
df_product_cols=[
    'ProductKey',
    'MarketNumber',
    'LineOfBusinessCode',
    'PlanNumber',
    'OptNumber',
]
df_fin_ledger_hdr_cols=[
    'FinanceLedgerHeaderKey',
    'LedgerNumber'
]
df_provider=[
    'ProviderKey',
    'ProviderId',
]
df_fin_ledger_fndprd_cols=[
    'FinanceLedgerHeaderKey',
    'FundPeriodBeginDate',
    'FundPeriodStatusCode'
]
df_prv_contrct_cols=[
    'ProviderContractKey',
    'ProviderKey',
    'ProviderGrouperId'
]
df_prvdrcntrct_geomktaffltn_cols=[
    'ProviderContractGeoMktAffilKey',
    'ProviderContractKey', 
    'GeoMarketAffiliationKey'
]
df_geomktaffltn_cols=[
    'GeoMarketAffiliationKey'
]
ci_mbr_cols=[
    'CiGrpId',
    'CiBenSeqNbr',
    'CiClsNbr',
    'MbrPid',
    'MbrSubPid',
    'MbrGhGroup',
    'MbrGhSubGroup'
]
df_prv_cntrct_ctrl=[
    'ProviderContractKey',
    'ControlTypeCode',
    'ControlTypeId'
]

# COMMAND ----------

try: 
  # Read the data from member Stage table(Adls).
  df_member = read_table_to_df(stg_member).select(*df_member_cols)
  
  # Read the data from MeberCoverage Stage table(Adls).
  df_member_cov = read_table_to_df(stg_member_cov).select(*df_member_cov_cols)
  
  # Read the data from Product Stage table(Adls).
  df_product = read_table_to_df(stg_product).select(*df_product_cols)\
    .filter(col('LineOfBusinessCode').isin('MER','MRO'))
  
  # Read the data from Provider Stage table(Adls).
  df_provider = read_table_to_df(stg_provider).select(*df_provider)
  
  # Read the data from Provider_contract Stage table(Adls).
  df_provider_contract = read_table_to_df(stg_provider_contract).select(*df_prv_contrct_cols)
  
  # # Read the data from Productgeomarketaffiliation Stage table(Adls).
  df_prdct_geomrktaffltn = read_table_to_df(stg_productgeomarketaffiliation).select(*df_geomktaffltn_cols)

  # Read the data from Geomarketaffiliation Stage table(Adls).    
  df_geomarketaffiliation = read_table_to_df(stg_geomarketaffiliation).select(*df_geomktaffltn_cols)
  
  # Read the data from Providercontractgeomktaffiliation Stage table(Adls).
  df_prvdrcntrct_geomktaffltn = read_table_to_df(stg_providercontractgeomktaffiliation).select(*df_prvdrcntrct_geomktaffltn_cols)

  # Read the data from FinanceLedgerHeader Stage table(Adls).    
  df_finledgerhdr = read_table_to_df(stg_finledgerhdr).select(*df_fin_ledger_hdr_cols)

  # Read the data from Geomarketaffiliation Stage table(Adls).    
  df_finledgerfundprd = read_table_to_df(stg_finledgerfndprd).select(*df_fin_ledger_fndprd_cols)

  # Read the data from ProviderGrouper Stage table(Adls).    
  df_prv_cntrct_ctrl = read_table_to_df(stg_provider_cntrct_ctrl).select(*df_prv_cntrct_ctrl)
       
except Exception as e:
  excep = "Read Sql Tables: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Joining all the required tables:
try:         
  df_member_data = df_member.alias("m")\
    .join(df_member_cov.alias("mc"), "MemberKey", "inner")\
    .join(df_product.alias("prod"), "ProductKey", "inner")
              
  df_provider_data = df_provider.alias("prv")\
    .join(df_provider_contract.alias("pc"), 'ProviderKey', "inner")\
    .join(df_prvdrcntrct_geomktaffltn.alias("pcgma"), 'ProviderContractKey', "inner")\
    .join(df_prv_cntrct_ctrl.alias("prg"),'ProviderContractKey','inner')\
    .join(df_geomarketaffiliation.alias("gma"), 'GeoMarketAffiliationKey', "inner")\
    .join(df_prdct_geomrktaffltn.alias("pgma"), 'GeoMarketAffiliationKey', "inner")\
    .filter(col('ControlTypeCode')=='LedgerNumber')
  
  df_fin_ledger = df_finledgerhdr.alias("flh").join(df_finledgerfundprd.alias("flfp"),"FinanceLedgerHeaderKey")\
    .filter(col('FundPeriodStatusCode').isin('O','P'))\
    .groupBy(col('LedgerNumber'))\
    .agg(min('FundPeriodBeginDate').alias('FundPeriodBeginDate'))   
  
  df_all_join=df_member_data.join(df_provider_data, "ProviderContractKey", "inner")\
    .join(df_fin_ledger,col("LedgerNumber")==col("ControlTypeId"), "inner")
      
except Exception as e:
  excep = ("Joining tables failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read from CiMember and Customer
try:
  df_select = df_all_join.select('*',add_months(current_date(),1).alias('FundPeriodEndDate'))\
    .withColumn('FundPeriodBeginDate_s',date_format('FundPeriodBeginDate','yyyyMM'))\
    .withColumn('FundPeriodEndDate_s',date_format('FundPeriodEndDate','yyyyMM'))\
    .withColumn('CoverageStartDate_s',date_format('CoverageStartDate','yyyyMM'))\
    .withColumn('CoverageEndDate_s',date_format('CoverageEndDate','yyyyMM'))
  
  ci_mbr_df = read_table_to_df(ci_mbr_tbl).select(*ci_mbr_cols)

  cust_df = read_table_to_df(cust_tbl)
    
except Exception as e:
  excep = "column selection: " + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check member coverage falls under open fund period
try:
  df_sf_opn_fund_prd = df_select.\
  filter(((col('CoverageStartDate_s') >= col('FundPeriodBeginDate_s')) & (col('CoverageStartDate_s') <= col('FundPeriodEndDate_s'))) | ((col('CoverageEndDate_s') >= col('FundPeriodBeginDate_s')) & (col('CoverageEndDate_s') <= col('FundPeriodEndDate_s'))) | ((col('CoverageStartDate_s') < col('FundPeriodBeginDate_s')) & (col('CoverageEndDate_s') > col('FundPeriodEndDate_s')))).\
  withColumn('CoverageStartDate',expr("""case 
                                      when CoverageStartDate_s < FundPeriodBeginDate_s then FundPeriodBeginDate 
                                      else CoverageStartDate end""")).\
  withColumn('CoverageEndDate',expr("case when CoverageEndDate_s > CoverageEndDate_s then FundPeriodEndDate else CoverageEndDate end"))\
  .drop('FundPeriodBeginDate','FundPeriodEndDate','FundPeriodBeginDate_s','FundPeriodEndDate_s','CoverageStartDate_s','CoverageEndDate_s') 

                            
except Exception as e:
  excep = "Update member coverage begin and end date failed: " + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output)) 

# COMMAND ----------

# DBTITLE 1,CI to GH field Conversion
try:
    # join the final dataset with CiCustomer, for non joined records join with CIMember table to get MbrGhGroup field
    df_open_fund_gh_converted = (
        df_sf_opn_fund_prd.alias("LH")
        .join(cust_df.alias("CC"),
            (col("LH.MemberCustomerNumber") == col("CC.CIGroupIdentifier"))
            & (col("LH.MemberGroupNumber") == col("CC.BenefitSequence"))
            & (col("LH.CIClassNumber") == col("CC.CIClassNumber")),"left")  
        ).select('LH.*',col('CC.GHGroupIdentifier'),col('CC.EmployerGroupNumber').alias('MbrGhSubGroup')).drop(col('CIClassNumber'),col('GhGrpId'),col('GhEmprGrpNbr'),col('MemberGroupNumber'))
    
    final_df = df_open_fund_gh_converted.withColumn('UpdtDt',lpad(lit(' '),6,' ')).withColumn('RecUpdtId',lpad(lit(' '),8,' ')).withColumn('Filler',lpad(lit(' '),150,' '))
    
except Exception as e:
    excep = "Join result with CiCustomer and CIMember failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter Columns and Drop Duplicate
try:
  window_spec=Window.partitionBy('GHGroupIdentifier','MemberId','SubscriberId').orderBy('GHGroupIdentifier','MemberId','CoverageStartDate')
  partitioned_df=final_df.select('*',col('LH.LedgerNumber').alias('LedgerNumber'))\
  .withColumn('rn',row_number().over(window_spec)).filter(col('rn')==1)
  
  table_df=partitioned_df.select('GHGroupIdentifier','SubscriberId','MemberId','CoverageStartDate','MemberBirthDate','LineOfBusinessCode','MemberLastName','MemberFirstName','MemberMiddleName','ProviderContractKey')
  
  df_sf_op_fnd_paid_cvg_ext=partitioned_df.select('GHGroupIdentifier','MemberId','CoverageStartDate')

except Exception as e:
  excep = "column selection for SF open fund paid coverage extract failed: " + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Output Column Mapping
col_schema={
    'GHGroupIdentifier' : 'string'
    ,'MemberId' : 'string'
    ,'MemberBirthDate' : 'date'
    ,'CoverageStartDate' : 'date'
    ,'CoverageEndDate' : 'date'
    ,'MemberCustomerNumber' : 'string'
    ,'MemberLastName' : 'string'
    ,'MemberFirstName' : 'string'
    ,'MemberMiddleName' : 'string'
    ,'MbrGhSubGroup' : 'string'
    ,'ExtProdSeqNo' : 'integer'
    ,'MarketNumber' : 'string'
    ,'LineOfBusinessCode' : 'string'
    ,'PlanNumber' : 'string'
    ,'OptNumber' : 'string'
    ,'ProviderId' : 'string'
    ,'TypeCode' : 'string'
    ,'UpdtDt' : 'date'
    ,'RecUpdtId' : 'string'
    ,'WokerCompensationOccurenceId' : 'integer'
    ,'CoverageEndReasonCode' : 'string'
    ,'Filler' : 'string'
}

col_mapping={
    "GHGroupIdentifier":"WsMemberCustomerNbr"
    ,"Memberid":"WsMemberMbrPid"
    ,"Memberbirthdate":"WsMemberDob"
    ,"Coveragestartdate":"WsMemPvdrEffDate"
    ,"Coverageenddate":"WsMemPvdrTermDate"
    ,"MemberCustomerNumber":"WsGhEnrEmprIdNbr"
    ,"Memberlastname":"WsMemberLastName"
    ,"Memberfirstname":"WsMemberFirstName"
    ,"Membermiddlename":"WsMemberMiddleName"
    ,"Mbrghsubgroup":"WsMemberGroupNbr"
    ,"Extprodseqno":"WsMemberProdSeqNbr"
    ,"Marketnumber":"WsMemberMarketNbr"
    ,"Lineofbusinesscode":"WsMemberLobCode"
    ,"Plannumber":"WsMemberPlanNbr"
    ,"Optnumber":"WsMemberOptionNbr"
    ,"Providerid":"WsMemberProviderId"
    ,"Typecode":"WsMemberProviderType"
    ,"Updtdt":"WsMemberLcd"
    ,"Recupdtid":"WsMemberLcSource"
    ,"Wokercompensationoccurenceid":"WsMemberWorkcmpOccurP"
    ,"Coverageendreasoncode":"WsMemberPcpEndReasCd"
    ,"Filler":"WsMemberDbkeyReProv"
}

col_schema2={
    'GHGroupIdentifier' : 'string'
    ,'MemberId' : 'string'
    ,'SubscriberId' : 'string'
    ,'CoverageStartDate' : 'date'
    ,'MemberBirthDate':'date'
    ,'LineOfBusinessCode':'string'
    ,'MemberLastName':'string'
    ,'MemberFirstName':'string'
    ,'MemberMiddleName':'string'
    ,'ProviderContractKey':'string'
}

col_mapping2={
    "GHGroupIdentifier":"WsMemberCustomerNbr"
    ,"MemberId":"WsMemberMbrPid"
    ,"CoverageStartDate":"WsMemPvdrEffCc"
    ,'SubscriberId' : 'SubscriberId'
    ,'MemberBirthDate':'wsMemberDob'
    ,'LineOfBusinessCode':'WsMemberLobCode'
    ,'MemberLastName':'WsMemberLastName'
    ,'MemberFirstName':'WsMemberFirstName'
    ,'MemberMiddleName':'WsMemberMiddleName'
    ,'ProviderContractKey':'ProviderContractKey'
}

col_schema1={
    'GHGroupIdentifier' : 'string'
    ,'MemberId' : 'string'
    ,'CoverageStartDate' : 'date'
}

col_mapping1={
    "GHGroupIdentifier":"WsMemberCustomerNbr"
    ,"Memberid":"WsMemberMbrPid"
    ,"CoverageStartDate":"WsMemPvdrEffCc"
}

# COMMAND ----------

# DBTITLE 1,Trim and Transform dafaframe as per schema
try: 

  df_opn_fnd_ext_trim = trim_leading_trailing_space(df_sf_op_fnd_paid_cvg_ext)
  df_opn_fnd_ext_trans = dtype_conversion(df_opn_fnd_ext_trim, col_schema1)
  final_ext_col_map_df = col_name_mapping(df_opn_fnd_ext_trans, col_mapping1)  

  df_table_trim = trim_leading_trailing_space(table_df)
  df_table_trans = dtype_conversion(df_table_trim, col_schema2)
  final_table_map_df = col_name_mapping(df_table_trans, col_mapping2)   

  write_df_as_delta_table(final_table_map_df,Re3002CoverageExtrctTbl, mode = 'overwrite')
  
except Exception as e:
  excep = 'Datatype and column mapping failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
  # Convert dataframe to fixed width length column.
  df_write_sf_opn_fund_cbg_ext = convert_col_to_fixed_width(fixed_config_ext_df, final_ext_col_map_df)
  
  # write dataframe as .txt file as position delimited.
  write_outbnd_file_to_adls(df_write_sf_opn_fund_cbg_ext, temp_csv_path2, config)
except Exception as e:
  excep = 'Write to ADLS: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving and renaming the .csv file to outbound folder.
try:
    #Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path2, outbnd_csv_path, outbnd_file_name2)
    fileNamesList = [outbnd_file_name1,outbnd_file_name2]
    fileNames = ','.join(fileNamesList)

except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : fileNames,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
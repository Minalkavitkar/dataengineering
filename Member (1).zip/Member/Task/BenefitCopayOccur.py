# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - Member.CICustomer
# MAGIC ##### Curated Tables
# MAGIC - Member.BenefitCopayOccur
# MAGIC ##### Target Table
# MAGIC - No Domain Table
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
table_code = 'Member_BenefitCopayOccur'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Import required python libraries
import re

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_cicustomer = table_name_selector(tbl_conf_df, 'CI_CUSTOMER_STAGE')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    bentyocr_tbl_name=table_name_selector(tbl_conf_df,'Member_BenefitTypeOccurrence')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
try:
    cicustomer_stage_df = read_table_to_df(stage_cicustomer)\
                    .filter((col('Status') == 'S'))
except Exception as e:
    raise Exception("Table not found",str(e))

# COMMAND ----------

# DBTITLE 1,Creating list of coPay Amt,CoinsPct & LineInd for every occurrence
try:
    ben_lst = []
    slt_lst = [] + ['CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate','DerivedIndicator']
    for x in cicustomer_stage_df.columns:
        if x.startswith('CopayTyCd'):
            ben_lst.append(x)

            temp = re.compile("([a-zA-Z]+)([0-9]+)")
            res = temp.match(x).groups()[1]
            CopayAmt = "CopayAmt"+res
            CopayCoinsPct = "CopayCoinsPct"+res
            CopayLineInd =  "CopayLineInd"+res

            slt_lst.append(f"concat({x},',',{CopayAmt}, ',' , {CopayCoinsPct}, ',' , {CopayLineInd}) as {x}")


except Exception as e:
    raise Exception("Collect all ")

# COMMAND ----------

# DBTITLE 1,Create dataframe based on the calculated columns
try:
    df1 = cicustomer_stage_df.selectExpr(*slt_lst)

    df_unpivot=df1.unpivot(['CiGrpId','GrpNbrBen','CiClsNbr','BenDtlEffDate','DerivedIndicator'], ben_lst, "TypeName","TypeValue")
except Exception as e:
    raise Exception("Read Customer data and join with stage table records as per Copay:", str(e))

# COMMAND ----------

# DBTITLE 1,Derive and rename columns as per SQL
try:
    split_df= df_unpivot.select(expr('CiGrpId AS CIGroupIdentifier'),
                            expr('CAST(GrpNbrBen AS INT) AS BenefitSequence'),
                            expr('CAST(CiClsNbr AS INT) AS CIClassNumber'),
                            'BenDtlEffDate',
                            substring(split(col("TypeName"),"CopayTyCd").getItem(1),-1,1).alias("CopaySequenceNumber"),
                            substring(split(col("TypeName"),"CopayTyCd").getItem(1),-3,2).alias("BenefitTypeSequenceNumber"),
                            'DerivedIndicator',
                            split(col('TypeValue'),',').getItem(0).alias('CopayTypeCode'),
                            split(col('TypeValue'),',').getItem(1).alias('CopayAmount'),
                            split(col('TypeValue'),',').getItem(2).alias('CopayCoinsPCT'),
                            split(col('TypeValue'),',').getItem(3).alias('CopayLineInd'))
except Exception as e:
    raise Exception ("Failed in split column",str(e))
                            

# COMMAND ----------

# DBTITLE 1,Reading data from benefitype table
try:
    BenefitType_df= read_table_to_df(bentyocr_tbl_name).select('BenefitTypeOccurenceKey','CIClassNumber','CIGroupIdentifier','BenefitSequence','BenefitEffectiveDate','BenefitTypeSequenceNumber')
except Exception as e:
    raise Exception ("Table not found",str(e))

# COMMAND ----------

# DBTITLE 1,Joining with BenefitTypeOccurance table
try:
    join_df= split_df.alias('LH').join(BenefitType_df.alias('RH'),
                                        (col('LH.CIClassNumber')==col('RH.CIClassNumber'))&
                                        (col('LH.CIGroupIdentifier')==col('RH.CIGroupIdentifier'))&
                                        (col('LH.BenefitSequence')==col('RH.BenefitSequence'))&
                                        (col('LH.BenDtlEffDate')==col('RH.BenefitEffectiveDate'))&
                                        (col('LH.BenefitTypeSequenceNumber')==col('RH.BenefitTypeSequenceNumber')),'inner')\
                                    .select('LH.CopaySequenceNumber','LH.CopayTypeCode','LH.CopayAmount','LH.CopayCoinsPCT','LH.CopayLineInd','RH.BenefitTypeOccurenceKey','LH.DerivedIndicator')
except Exception as e:
    raise Exception('joining or filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Change dataType as per SQL
try:
    col_map = {
        'CopaySequenceNumber': col('CopaySequenceNumber').cast(IntegerType()),
        'CopayAmount':col('CopayAmount').cast(DecimalType(10,4))
    }

    add_col_df = join_df.withColumns(col_map)
except Exception as e:
    raise Exception("Change DataType:", str(e))

# COMMAND ----------

# DBTITLE 1,Adding audit columns
try:
    final_df = add_tgt_audit_column(add_col_df, PIPELINE_NAME,LOAD_TYPE)
except Exception as e:
    raise Exception("Add audit columns:", str(e))

# COMMAND ----------

# DBTITLE 1,Merge function in case of Delta data
def delta_operation(cur_tbl_name,final_df):
    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)

    dfUpdates =final_df.filter(final_df.DerivedIndicator.isin(["UPDATE","INSERT","DELETE"]))

    deltaTableCurated.alias('Curated')\
        .merge(
            dfUpdates.alias('Stage'),
            'Curated.BenefitTypeOccurenceKey = Stage.BenefitTypeOccurenceKey AND Curated.CopaySequenceNumber = Stage.CopaySequenceNumber')\
        .whenMatchedUpdate(set={
            'BenefitTypeOccurenceKey':'Stage.BenefitTypeOccurenceKey',
            'CopaySequenceNumber':'Stage.CopaySequenceNumber',
            'CopayTypeCode':'Stage.CopayTypeCode',
            'CopayAmount':'Stage.CopayAmount',
            'CopayCoinsPCT':'Stage.CopayCoinsPCT',
            'CopayLineInd':'Stage.CopayLineInd',
            'DerivedIndicator':'Stage.DerivedIndicator',
            'ModifiedBy':f"'{PIPELINE_NAME}'",
            'ModifiedDateTime':current_timestamp()
            })\
        .whenNotMatchedInsert(values={
            'BenefitTypeOccurenceKey':'Stage.BenefitTypeOccurenceKey',
            'CopaySequenceNumber':'Stage.CopaySequenceNumber',
            'CopayTypeCode':'Stage.CopayTypeCode',
            'CopayAmount':'Stage.CopayAmount',
            'CopayCoinsPCT':'Stage.CopayCoinsPCT',
            'CopayLineInd':'Stage.CopayLineInd',
            'DerivedIndicator':'Stage.DerivedIndicator',
            'CreatedBy':f"'{PIPELINE_NAME}'",
            'CreatedDateTime':current_timestamp()
        })\
        .execute()


# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
#If it is full load we will be overwrite data to BenefitCopay table.
try:
    if LOAD_TYPE == 'FullLoad':
        dbutils.notebook.run('./MemberDDL',60,{"TABLE_NAMES":"Member_BenefitCopayOccur"})
        write_to_curated(final_df,cur_tbl_name)

        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        delta_operation(cur_tbl_name,final_df)
        
        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception("Please check the load_type. Its not valid", str(e))  
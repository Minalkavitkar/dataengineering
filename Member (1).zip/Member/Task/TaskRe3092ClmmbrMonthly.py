# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE3092 -  It’s a process to get the member data and get the capitation history details from Service Fund end to process and generate 36 months membership data.  
# MAGIC
# MAGIC ###### Source Details (Stage layer Adls - Unmanaged delta table, Inbound files):
# MAGIC
# MAGIC - Member.ReclmmbrDailyFull
# MAGIC - EDW_ITCAPHST_MCARE_BASE.TXT
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.ReClmmbrMonthly
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenRe401EdwMonthlyFile.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import necessary packages.
from pyspark.sql.functions import *
from datetime import date
import json

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.

# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col("JobName") == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig.
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    default_in_config = default_config["Inbound"]
    clmmbrMonthly_config = config_dict[job_name]

    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config['FilePathPrefix']
    file_path_prefix_in = default_in_config["FilePathSuffix"]
    config = default_out_config["Config"]

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = clmmbrMonthly_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = clmmbrMonthly_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = clmmbrMonthly_config["Outbound"]["TableName"]
    outbnd_file_name = clmmbrMonthly_config["Outbound"]["FileName"]
    
    reclmmbrdaily_tbl_name = clmmbrMonthly_config["Inbound"]["ReclmmbrDailyTableName"]
    cap_path = clmmbrMonthly_config["Inbound"]["EdwCapitationFilePath"]
except Exception as e:
    excep = "Variable assignment from FileConfig: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Curated and temp.
try: 
    temp_csv_path = abfss_path_builder(container_name, storage_account, prc_file_path_prefix, temp_path_suffix)
    capitation_path = abfss_path_builder(container_name,storage_account,file_path_prefix_in,cap_path)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read data from Stage(ADLS) and Azure SQL table.
try:
    # Read ReclmmbrDaily from ADLS curated table
    ReclmmbrDaily_df = read_table_to_df(reclmmbrdaily_tbl_name)
    # Read EDW_ITCAPHST_MCARE_BASE.TXT file from ADLS inbound folder
    df_capitation = read_inbound_csv_file(capitation_path)
except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting required columns from Capitation file
try:
#Selecting columns required for the process from Capitation file
    num_col = 36
    dtype_conv_lst = ['HIS_MBR_PID','MBR_SUBPID']
    for i in range(1,num_col+1):
        dtype_conv_lst.append(f"CAST(concat(HIS_PAY_PD_YR{i},HIS_PAY_PD_MM{i}) AS INT) AS PAY_PD_YR_YM_{i}")
        dtype_conv_lst.append(f"array(CAST(HIS_HCF_HCC_A{i} AS FLOAT), CAST(HIS_HCF_HCC_B{i} AS FLOAT), CAST(HIS_HCF_HCC_D{i} AS FLOAT), CAST(HIS_PLAN{i} AS STRING),CAST(HIS_HCF_PBP{i} AS INT)) AS CombinedColumn_{i}")

    df_capitation_sel = df_capitation.selectExpr(*dtype_conv_lst)
except Exception as e:
    excep = 'Selecting required columns from Capitation file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate cutoff date
try:
    # Calculate cut off date to fetch only 36 months data
    current_date_ccyy=current_date()
    cutoff_date=add_months(current_date_ccyy, -36)
except Exception as e:
    excep = 'calculation of cut off date failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate date to take only last 36 months data.
# Date Calculation: Subtract 36 months from current date.
try:
    # select the records if CoverageEndDate is greater than cutoff date
    ReclmmbrDaily_filtered_df = ReclmmbrDaily_df.filter(col('CoverageEndYear') >= year(cutoff_date))
    ReclmmbrDaily_df = ReclmmbrDaily_filtered_df.filter(col("CoverageEndDate")>cutoff_date)
except Exception as e:
    excep = 'filter 36 months records: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting required columns from ReClmmbrDaily
#Select only required columns from ReClmmbrDaily:
try:
    reclmmbr_cols = ReclmmbrDaily_df.select(
    'ProviderGrouperId'
    ,'GHGroupIdentifier'
    ,'MemberId'
    ,'SubscriberId'
    ,'GateKeeperProviderTypeCode'
    ,'CoverageStartDate'
    ,'CoverageEndDate'
    ,substring(col('RectrtGkProvIdGfld'),1,9).alias('ProvIdNbr')
    ,substring(col('RectrtGkProvIdGfld'),10,2).alias('ProvSuffCd')
    ,'ProviderServiceTypeCode'
    ,'ProviderSequenceNumber'
    ,'MarketNumber'
    ,'LineOfBusinessCode'
    ,'PlanNumber'
    ,'OptNumber'
    ,'CycleNumber'
    ,'LedgerNumber'
    ,'ClaimRule'
    ,'IPAIndicator'
    ,'GeoMarketId'
    ,'ClmRprocInd'
    ,'ClaimFundExceptionIndicator'
    ,'ProductKey'
    ,'EmployerGroupNumber'
    ,'ActiveInd'
    ,'WokerCompensationOccurenceId'
    ,'CoverageEndReasonCode'
    ,'HumanaIdentifier'
    )
except Exception as e:
    excep = 'Selecting required columns from ReClmmbrDaily failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Splitting ReClmmbrDaily file into 2 files on the basis of LOB
try:
    #File1 : Selecting records of ReClmmbrDaily if LOB in ('MER','MRO')
    df_clmmbr_reqd_lob = reclmmbr_cols.filter(col('LineOfBusinessCode').isin('MER','MRO'))
    #File2 : Selecting records of ReClmmbrDaily if LOB is not in ('MER','MRO') --To be used in Cell 21
    df_clmmbr_othr_lob = reclmmbr_cols.filter(~col('LineOfBusinessCode').isin('MER','MRO'))
except Exception as e:
    excep = 'Splitting ReClmmbrDaily file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join File1 of previous step with capitation file
try:
    #Join File1 of previous step with capitation file
    df_join = df_clmmbr_reqd_lob.alias('LH').join(df_capitation_sel.alias('RH'),(col('LH.MemberId')==col('RH.HIS_MBR_PID')) & (col('LH.SubscriberId')==col('RH.MBR_SUBPID')),'left')
    #Adding column 'CoverageEndDateConvrtd' to accomodate CoverageEndDate in yyyyMM format
    reclmmbr_cols_date = df_join.withColumn('CoverageEndDateConvrtd',expr("date_format(CoverageEndDate,'yyyyMM')"))
except Exception as e:
    excep = 'Join with capitation file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Compare CoverageEndDate with Captation Pay Date to select corresponding HCFA fields
try:
    calc_col_lst = []
    str_col = f'CASE WHEN CoverageEndDateConvrtd >= PAY_PD_YR_YM_1 THEN CombinedColumn_1'
    for seq in range(2,36):
        str_col += f" WHEN CoverageEndDateConvrtd = PAY_PD_YR_YM_{seq} THEN CombinedColumn_{seq}"
    str_col += f" WHEN CoverageEndDateConvrtd = PAY_PD_YR_YM_36 THEN CombinedColumn_36 END AS CombinedColumn"
    calc_col_lst.append(str_col)

    calc_df = reclmmbr_cols_date.selectExpr('LH.*',*calc_col_lst)
except Exception as e:
    excep = 'Comparison of CoverageEndDate with Captation Pay Date failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Selecting final output columns
try:   
    #Select all the final output columns:
    df_clmmbr_capitation_select = calc_df.selectExpr(
            "*",
            "CombinedColumn[0] as HcfaHccA",
            "CombinedColumn[1] as HcfaHccB",
            "CombinedColumn[2] as HcfaHccD",
            "CombinedColumn[3] as HcfaMcoCtrctNo",
            "CombinedColumn[4] as HcfaPbp",
        ).drop("CombinedColumn")
except Exception as e:
    excep = 'Selecting final output columns failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Union the Clmmbr_Capitation output with filtered LOB capitation file to get default values in HCFA fileds
try:
    #Union the Clmmbr_Capitation output with filtered LOB capitation file to get default values in HCFA fileds
    df_clmmbr_capitation_final = df_clmmbr_capitation_select.unionByName(df_clmmbr_othr_lob,allowMissingColumns=True)
except Exception as e:
    excep = 'Union the Clmmbr_Capitation output with filtered LOB capitation file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_clmmbr_capitation_final, tbl_name)
    # Read data from stage layer.
    re3092_df = read_table_to_df(tbl_name)
    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re3092_df)
    #write dataframe as .txt file with position delimitor.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
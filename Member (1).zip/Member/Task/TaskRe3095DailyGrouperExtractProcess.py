# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE3095 - The main purpose of this job is to create an interface to create a REMBRRST Stage area table on cloud and fetch 36 months records from ReclmmbrDaily and GrouperExtract
# MAGIC ###### Source Details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - Member.ReclmmbrDailyFull
# MAGIC - Provider.GrouperExtract
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.Re3095DailyGrouperExtractProcess
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenRE406REMBRRST.csv (CSV File) 
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,import necessary packages.
import json
from pyspark.sql.functions import *
from datetime import date
from dateutil.relativedelta import relativedelta

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict["DEFAULT"]
    default_out_config = default_config["Outbound"]
    re3095_config = config_dict[JOB_NAME]
    container_name = default_config["ContainerName"]
    file_path_prefix = default_out_config["FilePathPrefix"]
    config = default_out_config["Config"]
    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re3095_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re3095_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re3095_config["Outbound"]["TableName"]
    outbnd_file_name = re3095_config["Outbound"]["FileName"]
    reclmmbrdaily_tbl_name = re3095_config["Inbound"]["ReclmmbrDailyTableName"]
    grouper_extract_tbl_name = re3095_config["Inbound"]["GrouperExtractTableName"]
    ci_mbr_tbl_name=re3095_config["Inbound"]["StageCIMemberTableName"]
    
except Exception as e:
    excep = "Variable assignment from FileConfig: ", str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name, storage_account,prc_file_path_prefix, temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
except Exception as e:
    excep = 'Reading config file failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from reclmmbrdaily table.
clmmbr_daily_req_cols = [
    "ProviderGrouperId",
    "MemberId",
    "SubscriberId",
    "CoverageStartDate",
    "CoverageEndDate",
    "GhCust",
    "CoverageEndYear"
]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from reclmmbrdaily table.
ci_mbr_req_cols = [
    "MbrPid",
    "MbrSubPid",
    "MemLastName",
    "MemFirstName",
    "GhMemBirthDate",
    "MbrGhGroup"
]

# COMMAND ----------

# DBTITLE 1,Read data from ADLS.
try:
    # Read ReclmmbrDaily from ADLS curated table
    reclmmbr_daily_df = read_table_to_df(reclmmbrdaily_tbl_name) .select(*clmmbr_daily_req_cols)

    # Read CI_Member from ADLS curated table
    ci_mbr_df = read_table_to_df(ci_mbr_tbl_name).select(*ci_mbr_req_cols).distinct()

    # Read GrouperExtract from ADLS curated table
    grouper_extract_df = read_table_to_df(grouper_extract_tbl_name).select("ProviderGrouperId")

except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate last 36 months records
# select the records if CoverageEndDate is greater than cutoff date
try:
    # Date Calculation: Subtract 36 months from current date.
    dt = date.today() - relativedelta(months=36)
    dts = str(dt)
    # Reclmmbr curated table is partitioned on CoverageEndYear. Get only the required partition.
    reclmmbr_df = reclmmbr_daily_df.filter(col("CoverageEndYear") >= (dt.year))

    reclmmbr_dt_df = reclmmbr_df.withColumn("date", to_date(lit(dts)))

    frmted_reclmmbr_dt_df = reclmmbr_dt_df.withColumn(
        "date", date_format(col("date"), "yyyy-MM-01")
    )
    current_df = frmted_reclmmbr_dt_df.filter(col("CoverageEndDate") >= col("date"))
    current_df=current_df.drop("date")
except Exception as e:
    excep = "filter 36 months records: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join reclmmbr_daily with Ci_Member to take member details.
try:
    final_joined_df = (
        current_df.alias("LH")
        .join(
            ci_mbr_df.alias("RH"),
            (
                (col("LH.MemberId") == col("RH.MbrPid")) & (col("LH.SubscriberId") == col("RH.MbrSubPid"))
                & (col("LH.GhCust") == col("RH.MbrGhGroup"))
            ),
            "left",
        )
        .select(
            "LH.ProviderGrouperId",
            "LH.MemberId",
            "LH.SubscriberId",
            col("RH.MemLastName").alias("MemberLastName"),
            col("RH.MemFirstName").alias("MemberFirstName"),
            "LH.CoverageStartDate",
            "LH.CoverageEndDate",
            col("RH.GhMemBirthDate").alias("MemberBirthDate"),
            "LH.GhCust",
        )
    )
except Exception as e:
    excep = "Join reclmmbr_daily with Ci_Member failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ReclmmbrDaily with GrouperExtract
try:
    # join ReclmmbrDaily with GrouperExtract and get the data if ProviderGrouperId matches
    rembrrst_df = final_joined_df.alias("LH").join(
        grouper_extract_df.alias("RH"), ["ProviderGrouperId"], "inner"
    )

except Exception as e:
    excep = "Join ReclmmbrDaily with GrouperExtract failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(rembrrst_df, tbl_name)

    # Read data from stage layer.
    re3095_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re3095_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the csv file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Objective
# MAGIC - This notebook sync main catalog of CiMember table into Member.Member in SQL
# MAGIC
# MAGIC ##### Source Files 
# MAGIC - CI_Member
# MAGIC
# MAGIC ##### Target Table
# MAGIC - Member.Member
# MAGIC
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper Notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest Notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load Notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,setting global parameters
dbutils.widgets.text('PIPELINE_NAME','NB_TaskSyncMember')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('PIPELINE_RUN_ID','')
PIPELINE_RUN_ID = dbutils.widgets.get('PIPELINE_RUN_ID')

dbutils.widgets.text('JOB_TYPE', 'DailyJobs')
job_type = dbutils.widgets.get('JOB_TYPE')

dbutils.widgets.text('JOB_NAME','SyncMember')
job_name = dbutils.widgets.get('JOB_NAME')

audit_start_date_time = datetime.now()

# COMMAND ----------

# DBTITLE 1,Getting the tables names and load into the dataframe
try: 
    file_conf_path = env_file_config_path
    config_dict = get_file_config(file_conf_path)
    audit_table_name = config_dict["DEFAULT"]["AuditTableName"]
    sync_member_config = config_dict["SyncMember"]
    stage_table_name = sync_member_config["Inbound"]["stage_table_name"]
    cur_cimember = sync_member_config["Inbound"]["cimember_cur_tbl_name"]
    member_cur_tbl_name = sync_member_config["Inbound"]["member_cur_tbl_name"]
    tre2319_tbl_name = sync_member_config["Inbound"]["tre2319_full_tbl_name"]
    child_tbl_detail_config = sync_member_config["child_tbl_detail_config"]

    member_stage_df = read_table_to_df(stage_table_name)
    cimember_df = read_table_to_df(cur_cimember)
    tre2319_df =  read_table_to_df(tre2319_tbl_name)
except Exception as e:
    excep = 'Reading table name or loading into dataframe failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,select the neccessary columns and renamining
# select necessary columns
ci_member_col_lst = [
    "MbrPid",
    "MbrSubPid",
    "MbrGhGroup",
    "CiGrpId",
    "MbrUmid",
    "MemFirstName",
    "MemLastName",
    "MemMiName",
    "MemSexCd",
    "MemMiName",
    "MemSexCd",
    "GhMemBirthDate",
    "MbrUmidEffDate",
    "platformcd"
]

# Column renaming as per domain tables
column_mapping = {
    "MbrPid" : "MemberId"
    ,"MbrSubPid" : "SubscriberId"
    ,"MbrGhGroup":"MbrGhGroup"
    ,"CiGrpId" : "MemberCustomerNumber"
    ,"MbrUmid" : "HumanaIdentifier"
    ,"MemFirstName" : "MemberFirstName"
    ,"MemLastName" : "MemberLastName"
    ,"MemMiName" : "MemberMiddleName"
    ,"MemSexCd" : "MemberSexCode"
    ,"GhMemBirthDate" : "MemberBirthDate"
    ,"MbrUmidEffDate" : "MbrUmidEffDate"
    ,"platformcd":"SourceSystemCode"
}

try:
    selected_member_df = cimember_df.select(*ci_member_col_lst).distinct()
    col_mapped_df = col_name_mapping(selected_member_df,column_mapping)
except Exception as e:
    excep = 'selecting necessary cols or cols renaming failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,extracting unique members
try:
  window_spec = Window.partitionBy("MemberId", "MemberCustomerNumber",'SubscriberId').orderBy(desc('MbrUmidEffDate'), desc('HumanaIdentifier'))
  rn_clac_df = col_mapped_df.withColumn('RN', row_number().over(window_spec))
  valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN', 'MbrUmidEffDate')
  orphan_df = rn_clac_df.filter(col('RN') > 1)
except Exception as e:
    excep = 'extracting unique members failed: ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,deriving source system code and audit cols added
try:
    srcsys_col_added_df  = valid_df.withColumn('SourceSystemCode',when((col('SourceSystemCode')=='HP') | (col('SourceSystemCode')=='LV') | (col('SourceSystemCode')=='Y'),lit('CI'))\
                                        .when((col('SourceSystemCode')=='EM'),lit('MTV')).otherwise(lit('CI')))

    audit_col_added_df =srcsys_col_added_df.selectExpr(
                            "*", 
                            "md5(concat(MemberId, SubscriberId, MemberCustomerNumber, SourceSystemCode)) as HashKey",
                            "current_timestamp() as CreatedDateTime",
                            f"'{PIPELINE_NAME}' as CreatedBy",
                            "cast(null as timestamp)as ModifiedDateTime",
                            "cast(null as string) as ModifiedBy"
                            )
    
    symbols_removed_df = audit_col_added_df.withColumn("MemberLastName", regexp_replace("MemberLastName","�","?"))
                                    
except Exception as e:
    excep = 'cols addition failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,join with tre2319 and get ClaimFundExceptionIndicator
try:
    # join_cond = (col('LH.MemberId') == col('RH.MbrPid')) &\
    #                     (col('LH.MbrGhGroup') == col('RH.MbrEnrlCustNbr')) &\
    #                     (col('LH.SubscriberId') == col('RH.MbrSubPid'))

    # joined_df = symbols_removed_df.alias("LH").join(tre2319_df.alias("RH"),join_cond, "left")\
    #                 .selectExpr("LH.*","RH.ClmFundExcpInd as ClaimFundExceptionIndicator")

    selected_df = symbols_removed_df.drop("MbrGhGroup")    
except Exception as e:
    excep = 'get ClaimFundExceptionIndicator failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

def col_names_lst_creation(colms):
    # Create Column list. Which is used for processing.
    col_select_lst, col_drop_lst, del_col_sel_lst = [], [], []
    for colm in colms:
        col_select_lst.append(f"{colm} as Old{colm}")
        col_drop_lst.append(f"Old{colm}")
        del_col_sel_lst.append(f"Old{colm} as {colm}")
    return col_select_lst, col_drop_lst, del_col_sel_lst

# COMMAND ----------

# DBTITLE 1,delta load preparation
try:
    new_col_slt_lst = selected_df.columns
    col_select_lst, col_drop_lst, del_col_sel_lst = col_names_lst_creation(new_col_slt_lst)

    old_renamed_df = member_stage_df.selectExpr("*","md5(concat(MemberId, SubscriberId, MemberCustomerNumber, SourceSystemCode)) as HashKey")\
                                        .selectExpr(*col_select_lst)
                                
    old_joined_df = selected_df.alias('LH').join(old_renamed_df.alias('RH'),(col("LH.HashKey") == col("RH.OldHashKey")), "full")

    ins_df = old_joined_df\
            .filter((col('OldHashKey').isNull()))\
            .withColumn('DerivedIndicator', lit('INSERT'))\
            .drop(*col_drop_lst,"HashKey")

    dels_df = old_joined_df\
            .filter((col('HashKey').isNull()))\
            .withColumn('DerivedIndicator', lit('DELETE'))\
            .selectExpr(*del_col_sel_lst,"DerivedIndicator")\
            .drop("HashKey")

    dels_df.cache()

    update_rec_check_col_lst = [ 
        'HumanaIdentifier', 
        'MemberFirstName', 
        'MemberLastName', 
        'MemberMiddleName', 
        'MemberSexCode', 
        'MemberBirthDate'
        # 'ClaimFundExceptionIndicator'
        ]
    
    upd_cond_lst = []
    for colm in update_rec_check_col_lst:
        upd_cond_lst.append('(col("'+colm+'").eqNullSafe(col("Old'+colm+'")))')
    upd_cond = ' & '.join(upd_cond_lst)
    upds_df_code = f'upds_df = old_joined_df.filter((col("HashKey").isNotNull()) & (col("OldHashKey").isNotNull())).withColumn("DerivedIndicator", when('+upd_cond+',lit("IGNORE")).otherwise(lit("UPDATE")))'
    exec(upds_df_code)
    
    col_maps = {'ModifiedDateTime' : (when(col('DerivedIndicator') == 'UPDATE', lit(current_timestamp())).otherwise(col('OldModifiedDateTime'))),
                'ModifiedBy' : (when(col('DerivedIndicator') == 'UPDATE', lit(PIPELINE_NAME)).otherwise(col('OldModifiedBy'))),
                'CreatedBy' : col('OldCreatedBy'),
                'CreatedDateTime' : col('OldCreatedDateTime')
                }
                
    calc_audit_col_upds_df = upds_df.withColumns(col_maps)\
                            .select(*new_col_slt_lst, "DerivedIndicator").filter(col("DerivedIndicator")!="IGNORE")\
                            .drop("HashKey")

    ins_upd_df = ins_df.unionByName(calc_audit_col_upds_df)
    ins_upd_df.cache()
    delta_df = ins_upd_df.unionByName(dels_df)
except Exception as e:
    excep = 'delta load prepare failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,load into stage table
try:
    mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'MemberKey':lit(None).cast("BIGINT"),
        'ClaimFundExceptionIndicator':lit(None).cast("String")
        }
        
    mapped_df= delta_df.withColumns(mapping)
    not_null_set_df = set_df_columns_not_nullable(spark, set_df_columns_nullable(spark,mapped_df,['DerivedIndicator']),['SourceSystemCode','MemberCustomerNumber','CreatedBy','CreatedDateTime'])

    load_df_to_sf_sql_db_spark(not_null_set_df, "Member.StageMember")
except Exception as e:
    excep = 'loading into stage failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,delta processing for main catalog table
try:
    if len(member_stage_df.head(1)) == 0:
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":'Member_Member'})
    conditions = ['MemberCustomerNumber', 'MemberId', 'SubscriberId', 'SourceSystemCode ']
    not_update_lst = ["CreatedBy","CreatedDateTime","ClaimFundExceptionIndicator"]
    delta_processing_with_cascade_delete(member_cur_tbl_name, ins_upd_df, conditions,not_update_lst, dels_df, child_tbl_detail_config)
except Exception as e:
    excep = 'loading into main catalog failed : ' + str(e)
    insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Failed' ,audit_table_name, excep)
    raise Exception(excep)


# COMMAND ----------

# DBTITLE 1,successfull exit notebook
# Insert success entry to the audit table.
insert_entry_to_audit_table(PIPELINE_RUN_ID, PIPELINE_NAME, job_name, job_type, audit_start_date_time, 'Success' ,audit_table_name,None)
# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC #### Country information is generated i.e. Country name, state code , country and placed into outbound folder.
# MAGIC
# MAGIC ##### To acheive the requirement below steps has been followed.
# MAGIC
# MAGIC * Step 1: Establish the connection to ADLS storage account, Read file SIG08_FILE and create a "StageSig08" Delta Lake Unity Catalog Table.
# MAGIC * Step 2: Extract Country, State Code and County name details form "StageSig08 Delta Lake Unity Catalog Table.
# MAGIC * Step 3: Create a County Info Delta Lake Unity Catalog Table.
# MAGIC * Step 4 : Generate County Info file and place into outbound folder.

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - SIG08_FILE
# MAGIC ##### Stage Table 
# MAGIC - StageSig08
# MAGIC ##### Target Table 
# MAGIC - CountyInfo
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running load functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "SIG08_FILE"

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','Nb_MemberCI')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Getting config & stage table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(env_table_details_config_path)
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Loading inbound file to Table
#loading file to stage table
try:
    main_function_dp_ci(conf, stage_tbl_name, CISig08_schema)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    Re0569Daily = config_dict[job_name]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = Re0569Daily["Outbound"]["TempFilePathSuffix"]   
    curated_path_suffix = Re0569Daily['Outbound']['CuratedFilePathSuffix']
    tbl_name = Re0569Daily['Outbound']['TableName']
    outbnd_file_name = Re0569Daily["Outbound"]["FileName"]

    stg_Sig08_tbl_name = Re0569Daily["Inbound"]["StageSig08"]
    
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Temporary and outbound Path creation
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account,
        file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Reading file from staging table
try: 
    # Read the data from StageSig08 Stage table.
    df_cnty_info = read_table_to_df(stg_Sig08_tbl_name)
    
except Exception as e:
    excep = "Read Sql Tables: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Extract Country Name, State Code, Country from SIG08 file
df_cnty_info_ext = (
    df_cnty_info.select("CntyName", "StateCd", "FipsCntyCd")
    .withColumnRenamed("CntyName", "CountryName")
    .withColumnRenamed("StateCd", "StateCode")
    .withColumnRenamed("FipsCntyCd", "Country")
)

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(df_cnty_info_ext, tbl_name)
    # # Read data from stage area.
    re0569_df = spark.read.table(tbl_name)
    # # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0569_df)
    # # write dataframe as .txt file as position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Rename the file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }
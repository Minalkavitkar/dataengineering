# Databricks notebook source
# MAGIC %md 
# MAGIC This notebook is a part of Customer feed and Coverage. the present notebook looks into StageCiCustomer table and derived the distinct CI Customers based on the business keys ('CiGrpId, GrpNbrBen, CiClsNbr')
# MAGIC ##### Source Files/Tables
# MAGIC - CI Customer (file)
# MAGIC - Member.StageCiCustomer (table)
# MAGIC ##### Target/Curated Tables
# MAGIC - Member.Customer
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
table_code = 'Member_Customer'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member')   
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_cicustomer = table_name_selector(tbl_conf_df, 'CI_CUSTOMER_STAGE')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table & Validating
try:
    cicustomer_df = read_table_to_df(stage_cicustomer)\
        .filter((col('Status') == 'S'))
except Exception as e:
    raise Exception("validating the table failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Renaming the columns with column mapping and adding audit columns
col_mapping ={
    "CiClsNbr":"CIClassNumber"
    ,"CiGrpId":"CIGroupIdentifier"
    ,"GhGrpId":"GHGroupIdentifier"
    ,"GrpNbrBen":"BenefitSequence"
    ,"EmprName":"EmployerName"
    ,"EmprAltFacNbr":"EmployerAlternateFacilityNum"
    ,"GrpInsPayerCd":"GroupInsurancePayerCode" 
    ,"GrpMemCnt":"GroupMemberCount"
    ,"GrpDepCnt":"GroupDependentCount" 
    ,"LimboGrpEffDate":"LimboGroupEffectiveDate"
    ,"MaxStudentAge":"MaximumStudentAgeNumber" 
    ,"MaxDependentAge":"MaximumDependentAgeNumber" 
    ,"GrpBillRoute":"GroupBillRouteCode"
    ,"GrpEffDate":"GroupEffectiveDate"
    ,"GrpCancelDate":"GroupCancelDate"
    ,"GkInd":"GateKeeperIndicator" 
    ,"CiPartyKey":"CIPartyKey" 
    ,"CustAgrmtKey":"CustomerAgreementKey"
    ,"LineOfBusiness":"SourceLOBCode"
    ,"GhEmprGrpNbr":"EmployerGroupNumber" 
    ,"CiPlatformCd":"SourcePlatformCode"
    ,"EmprFacIdNbr":"SellingLedger"
    ,"Ind1":"Ind1"
    ,"DerivedIndicator":"DerivedIndicator"
}

# COMMAND ----------

# DBTITLE 1,Adding derived & Audit columns and map the columns as per SQL
try:
    col_map = {
        "SourceSystemCode": lit('LV')
    }
    
    col_dtype_change = {
        'CIClassNumber':'STRING',
        'BenefitSequence':'STRING',
        'EmployerAlternateFacilityNum':'STRING',
        'CIPartyKey':'STRING',
        'CustomerAgreementKey':'STRING'
    }

    col_map_df = col_name_mapping(cicustomer_df,col_mapping)
    audit_col_df = add_tgt_audit_column(col_map_df, PIPELINE_NAME,LOAD_TYPE)
    add_col_df1 = dtype_tgt_conversion(audit_col_df, col_dtype_change)
    add_col_df = add_col_df1.withColumns(col_map)

except Exception as e:
    raise Exception("column renaming or adding failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Function to load the delta records
def delta_operation(cur_tbl_name,valid_df):
    
    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)

    dfUpdates =valid_df.filter(valid_df.DerivedIndicator.isin(["UPDATE","INSERT","DELETE"]))

    deltaTableCurated.alias('Curated')\
        .merge(
            dfUpdates.alias('Stage'),
            'Curated.CIGroupIdentifier = Stage.CIGroupIdentifier AND Curated.BenefitSequence = Stage.BenefitSequence AND Curated.CIClassNumber = Stage.CIClassNumber'
        )\
        .whenMatchedUpdate(set={
            'CIClassNumber':'Stage.CIClassNumber',
            'CIGroupIdentifier':'Stage.CIGroupIdentifier',
            'GHGroupIdentifier':'Stage.GHGroupIdentifier',
            'BenefitSequence':'Stage.BenefitSequence',
            'SellingLedger':'Stage.SellingLedger',
            'EmployerName':'Stage.EmployerName',
            'EmployerAlternateFacilityNum':'Stage.EmployerAlternateFacilityNum',
            'GroupInsurancePayerCode':'Stage.GroupInsurancePayerCode',
            'GroupMemberCount':'Stage.GroupMemberCount',
            'GroupDependentCount':'Stage.GroupDependentCount',
            'LimboGroupEffectiveDate':'Stage.LimboGroupEffectiveDate',
            'MaximumStudentAgeNumber':'Stage.MaximumStudentAgeNumber',
            'MaximumDependentAgeNumber':'Stage.MaximumDependentAgeNumber',
            'GroupBillRouteCode':'Stage.GroupBillRouteCode',
            'GroupEffectiveDate':'Stage.GroupEffectiveDate',
            'GroupCancelDate':'Stage.GroupCancelDate',
            'GateKeeperIndicator':'Stage.GateKeeperIndicator',
            'CIPartyKey':'Stage.CIPartyKey',
            'CustomerAgreementKey':'Stage.CustomerAgreementKey',
            'SourceLOBCode':'Stage.SourceLOBCode',
            'EmployerGroupNumber':'Stage.EmployerGroupNumber',
            'SourcePlatformCode':'Stage.SourcePlatformCode',
            'SourceSystemCode':'Stage.SourceSystemCode',
            'DerivedIndicator':'Stage.DerivedIndicator',
            'ModifiedBy':f"'{PIPELINE_NAME}'",
            'ModifiedDateTime':current_timestamp()
            }
            ).whenNotMatchedInsert(values={
                'CIClassNumber':'Stage.CIClassNumber',
                'CIGroupIdentifier':'Stage.CIGroupIdentifier',
                'GHGroupIdentifier':'Stage.GHGroupIdentifier',
                'BenefitSequence':'Stage.BenefitSequence',
                'SellingLedger':'Stage.SellingLedger',
                'EmployerName':'Stage.EmployerName',
                'EmployerAlternateFacilityNum':'Stage.EmployerAlternateFacilityNum',
                'GroupInsurancePayerCode':'Stage.GroupInsurancePayerCode',
                'GroupMemberCount':'Stage.GroupMemberCount',
                'GroupDependentCount':'Stage.GroupDependentCount',
                'LimboGroupEffectiveDate':'Stage.LimboGroupEffectiveDate',
                'MaximumStudentAgeNumber':'Stage.MaximumStudentAgeNumber',
                'MaximumDependentAgeNumber':'Stage.MaximumDependentAgeNumber',
                'GroupBillRouteCode':'Stage.GroupBillRouteCode',
                'GroupEffectiveDate':'Stage.GroupEffectiveDate',
                'GroupCancelDate':'Stage.GroupCancelDate',
                'GateKeeperIndicator':'Stage.GateKeeperIndicator',
                'CIPartyKey':'Stage.CIPartyKey',
                'CustomerAgreementKey':'Stage.CustomerAgreementKey',
                'SourceLOBCode':'Stage.SourceLOBCode',
                'EmployerGroupNumber':'Stage.EmployerGroupNumber',
                'SourcePlatformCode':'Stage.SourcePlatformCode',
                'SourceSystemCode':'Stage.SourceSystemCode',
                'DerivedIndicator':'Stage.DerivedIndicator',
                'CreatedBy':f"'{PIPELINE_NAME}'",
                'CreatedDateTime':current_timestamp()
                }
            ).execute()



# COMMAND ----------

# DBTITLE 1,Load data as per LOAD_TYPE
#If it is full load we will be overwrite data to customer table.
try:
    if LOAD_TYPE == 'FullLoad':

        valid_df = remove_dup_records_simple(add_col_df, ['CIGroupIdentifier','BenefitSequence','CIClassNumber'],'GroupCancelDate')
        valid_cust_df = remove_dup_records_simple(valid_df, ['GHGroupIdentifier','EmployerGroupNumber'],'GroupCancelDate').drop('DerivedIndicator','Ind1')

        dbutils.notebook.run('./MemberDDL',60,{"TABLE_NAMES":"Member_Customer"})

        write_to_curated(valid_cust_df,cur_tbl_name)
        
        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        win_spec = Window.partitionBy('CIGroupIdentifier','BenefitSequence','CIClassNumber','Ind1')\
                    .orderBy(desc('GroupCancelDate'))
        rn_clac_df = add_col_df.withColumn('RN', row_number().over(win_spec))
        valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN')
        orphan_df = rn_clac_df.filter(col('RN') > 1)

        delta_operation(cur_tbl_name,valid_df)

        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
except Exception as e:
    raise Exception("main try and except failed: ", str(e))  

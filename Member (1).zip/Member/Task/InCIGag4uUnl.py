# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - IN_CI_GAG4U_UNL
# MAGIC ##### Target Table 
# MAGIC - StageCIGag4u
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running load functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
#  As of now the business keys are not used still, if required in future, hence are mentioned here
file_conf_key = "IN_CI_GAG4U_UNL"
buz_keys = ['BILL_SORT_KEY']


# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','Nb_MemberCI')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

# DBTITLE 1,Getting config & stage table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(env_table_details_config_path)
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Loading inbound file to Table
#loading stage table
try:
    main_function_dp_ci(conf, stage_tbl_name, CIGag4u_schema)
except Exception as e:
    raise Exception("Stage load failed: ",str(e))
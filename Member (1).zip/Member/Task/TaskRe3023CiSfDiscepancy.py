# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - The main purpose of this job is to create SF and CI member discrepancy report.
# MAGIC
# MAGIC ###### Source Details (inbound file):
# MAGIC - PRODITN.CI.SNAPSHOT.IT452.SORT.DEMO 
# MAGIC - provider_staging_dev_000.mainframe_servicefund.member_re3002_op_fnd_paid_cvg_ext
# MAGIC
# MAGIC ###### Target Details (outbound file):
# MAGIC - SF and CI member discrepancy report

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import AdlsHelper notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Ingest notebook.
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import Transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import Load notebook.
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Assignment.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

dbutils.widgets.text('PIPELINE_NAME','NB_TaskRe3023CiSfDiscepancy')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')

# COMMAND ----------

try:
  file_conf_path = env_file_config_path
  fxd_wdth_path = env_fxd_wdt_file_config_path
  storage_account = env_storage_account_name
except Exception as e:
  excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format for GG processe
try:
  job_name = JOB_NAME
  config_dict = get_file_config(file_conf_path)
  fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
  excep = 'Read File Config and Fixed Width File Config: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict['DEFAULT']
  default_out_config = default_config['Outbound']
  default_in_config = default_config["Inbound"]
  re3023_config = config_dict[job_name]

  container_name = default_config['ContainerName']
  file_path_prefix = default_out_config['FilePathPrefix']
  file_path_suffix = default_in_config['FilePathSuffix']
  ctrl_table_name = default_config["AuditTableName"]
  config = default_out_config['Config']

  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"] 
  temp_path_suffix = re3023_config["Outbound"]["TempFilePathSuffix"]   
  curated_path_suffix = re3023_config['Outbound']['CuratedFilePathSuffix']
  outbnd_file_name = re3023_config["Outbound"]["FileName"]
  Re3023Tbl = re3023_config["Outbound"]["TableName"]
  
  sync_process_names = re3023_config["Inbound"]["StageSyncDependencyProcess"]
  stg_sf_tbl = re3023_config['Inbound']['re3002_op_fnd_paid_cvg_ext']
  stg_mbr_cvg = re3023_config['Inbound']['StageMemberCoverageTbl']
  stg_mbr = re3023_config['Inbound']['StageMemberTbl']
  stg_prv_cntrct= re3023_config['Inbound']['StagePrvdrCntrctTbl']
  stg_product= re3023_config['Inbound']['StageProductTbl']
  stg_prv_cntrct_cntl= re3023_config['Inbound']['StageProviderContractControl']
  stg_geomkt= re3023_config['Inbound']['StageGeoMarket']
  stg_geomktcyc= re3023_config['Inbound']['StageGeoMarketCycle']
  inbound_ci_file= re3023_config['Inbound']['CiFileName']    

except Exception as e:
  raise Exception("Variable assignment from FileConfig", str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
  prc_status = start_process_check(ctrl_table_name, sync_process_names)
  if prc_status != True:
      dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
  excep = "ControlTable check failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation.
try:
  cur_delta_path = abfss_path_builder(container_name,storage_account,curated_path_suffix,prc_file_path_prefix)
  ci_file_path = path_builder(container_name,storage_account,inbound_ci_file,path_prefix=file_path_suffix)
  temp_csv_path = abfss_path_builder(container_name,storage_account,prc_file_path_prefix,temp_path_suffix)
  outbnd_csv_path = abfss_path_builder(container_name,storage_account,path_prefix=file_path_prefix)
    
except Exception as e:
  excep = "Path creation: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

ci_schema = {
    "WK_A_SFG1R_5Z_BEN_SEQ_NBR" : "STRING",
    "WK_A_SFG1R_5Z_CLASS_NBR" : "STRING",
    "WK_A_IOG1W_CI_GRP_ID" : "STRING",
    "WK_A_IEG2Z_MEM_SUB_PID": "STRING",
    "WK_A_IEG2Z_PERS_PID": "STRING",
    "WK_A_SFG49_COV_EFF_DATE": "Date",
    "WK_A_SFG49_COV_END_DATE": "Date",
    "WK_A_IEG2Z_BIRTH_YEAR" : "STRING",
    "WK_A_IEG2Z_BIRTH_MONTH": "STRING",    
    "WK_A_IEG2Z_BIRTH_DAY" : "STRING",
    "WK_A_CERT_AUTH_TYPE_CD" : "STRING",
    "WK_A_IEG2Z_MEDICARE_ID" : "STRING"
}

# COMMAND ----------

# DBTITLE 1,Read inbound files and tables from adls.
try:
  # Read inbound file from adls and select only the required column.
  df_ci_snapshot = read_inbound_csv_file(ci_file_path)
  df_stg_mbr_cvg = read_table_to_df(stg_mbr_cvg)
  df_stg_mbr = read_table_to_df(stg_mbr)
  df_provider_cntrct = read_table_to_df(stg_prv_cntrct).select('ProviderContractKey','ProviderContractId','ProviderGrouperId')
  df_product = read_table_to_df(stg_product).select('ProductKey','LineOfBusinessCode') 
  df_prv_cntrct_cntl = read_table_to_df(stg_prv_cntrct_cntl).select("ProviderContractKey","ControlTypeCode","ControlTypeId")
  df_geomkt = read_table_to_df(stg_geomkt).select("GeoMarketKey","GeoMarketId") 
  df_geomktcyc = read_table_to_df(stg_geomktcyc).select("GeoMarketKey","CycleNumber")
  df_sf_tbl =read_table_to_df(stg_sf_tbl)
        
except Exception as e:
  excep = 'Read inbound file from adls: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Remove leading, trailing spaces and data type conversion
try:
  # Remove leading anf trailing spaces 
  df_ci_trim = trim_leading_trailing_space(df_ci_snapshot)

  # Datatype conversion 
  ci_converted = dtype_conversion(df_ci_trim, ci_schema)
  
except Exception as e:
  excep = 'Remove leading, trailing spaces and data type conversion failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))        

# COMMAND ----------

# DBTITLE 1,Filter Null coverage, Check CI member exist in SF
try:

  df_ci_skip_null_cov=ci_converted.select('*').filter(col('WkASfg49CovEffDate') != col('WkASfg49CovEndDate'))
  
  df_mbr_data= df_stg_mbr_cvg.alias('mc').join(df_stg_mbr.alias('m'), 'MemberKey','inner').dropDuplicates(['MemberCustomerNumber','memberId']).\
  select('m.MemberKey','m.MemberId','m.SubscriberId','mc.MemberCustomerNumber','mc.MemberGroupNumber','mc.CIClassNumber','mc.ProductKey','m.MemberFirstName','m.MemberLastName','m.MemberMiddleName')
  
  df_join=df_mbr_data.join(df_product.alias('p'),'ProductKey','inner').drop('ProductKey')

  df_ci_in_sf = df_ci_skip_null_cov.alias('f')\
  .join(df_join,
          (col('f.WkAIog1WCiGrpId') == col('mc.MemberCustomerNumber')) &
          (col('f.WkAIeg2ZMemSubPid') == col('m.SubscriberId')) &
          (col('f.WkAIeg2ZPersPid') == col('m.MemberId')), 'left').drop('f.WkAIog1WCiGrpId','f.WkAIeg2ZMemSubPid','f.WkAIeg2ZPersPid')
  
  df_ci_filtered=df_ci_in_sf.filter(col('m.MemberId').isNotNull())
  
  df_ci_not_in_sf = df_ci_in_sf.filter(col('m.MemberId').isNull())

except Exception as e:

  excep = 'CI- SF join failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Get Required Columns From SF Table
try:
  df_opn_fnd_sf=df_sf_tbl.select('*',col('WsMemPvdrEffCc').alias('FundBeginDt')).withColumn('FundEndDate',to_date(add_months(current_date(),1),'yyyyMMdd')).drop(col('WsMemPvdrEffCc'))
    
  df_opn_fnd_sf= df_opn_fnd_sf.withColumn('FundBeginDt',date_format(col('FundBeginDt'),'yyyyMM')).withColumn('FundEndDate',date_format(col('FundEndDate'),'yyyyMM'))

  df_prv_cntrct_cntl=df_prv_cntrct_cntl.filter(col('ControlTypeCode').isin('GeoMkt'))

  df_prv_cntrct_info = df_geomkt.alias('gm').join(df_prv_cntrct_cntl.alias('pcc'),col('pcc.ControlTypeId') == col('gm.GeoMarketId'),'inner')\
    .join(df_geomktcyc.alias('gc'), col('gc.GeoMarketKey') == col('gm.GeoMarketKey'),'inner')\
    .join(df_provider_cntrct.alias('pc'),col('pcc.ProviderContractKey') == col('pc.ProviderContractKey'),'inner')

  df_opn_fnd_sf= df_opn_fnd_sf.join(df_prv_cntrct_info, "ProviderContractKey","inner")

  df_opn_fnd_sf_part = df_opn_fnd_sf.drop('ProviderContractKey','GeoMarketKey','GeoMarketId','ControlTypeCode','ControlTypeId')
    
except Exception as e:

  excep = 'CI- SF join failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join with Open fund Coverage extract File
try:
  ci_sf_join = df_ci_filtered\
    .join(df_opn_fnd_sf_part,(col('WsMemberMbrPid')==col('memberId'))
      & (col('WsMemberCustomerNbr')==col('MemberCustomerNumber'))
      & (col('m.SubscriberId') == col('m.SubscriberId')) ,'inner')
    
  ci_sf_join = ci_sf_join.withColumn('WkASfg49CovEffDt',date_format(col('WkASfg49CovEffDate'),'yyyyMM'))\
    .withColumn('WkASfg49CovEndDt',date_format(col('WkASfg49CovEndDate'),'yyyyMM')).drop(col('WkASfg49CovEffDate'),col('WkASfg49CovEndDate'))
    
  ci_sf_join_col_rename = ci_sf_join.withColumn('WkASfg49CovEffDate',col('WkASfg49CovEffDt').cast('int')).withColumn('WkASfg49CovEndDate',col('WkASfg49CovEndDt').cast('int'))

except Exception as e:

  excep = 'Join with Open fund Coverage extract file failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check CI coverage falls under open fund period
try:
     
  ci_filter_df_converted=ci_sf_join_col_rename.filter(((col('WkASfg49CovEffDate') >= col('FundBeginDt')) & (col   ('WkASfg49CovEffDate')<= col('FundEndDate'))) |  (((col('WkASfg49CovEndDate') >= col('FundBeginDt')) & (col('WkASfg49CovEndDate') <= col('FundEndDate'))))).\
  withColumn('WkASfg49CovEffDate',expr('case when WkASfg49CovEffDate < FundBeginDt then FundBeginDt else WkASfg49CovEffDate end')).\
  withColumn('WkASfg49CovEndDate',expr('case when WkASfg49CovEndDate > FundEndDate then FundEndDate else WkASfg49CovEndDate end')).drop(col('FundBeginDt'),col('FundEndDate'),col('WkASfg49CovEffDt'),col('WkASfg49CovEndDt')) 

  ci_wihout_filter_converted=df_ci_not_in_sf.alias('ns').join(df_opn_fnd_sf_part.alias('dd'),\
    (col('dd.WsMemberCustomerNbr')==col('ns.MemberCustomerNumber'))
        & (col('dd.WsMemberMbrPid') ==col('ns.MemberId'))
        & (col('dd.SubscriberId') ==col('ns.SubscriberId')), 'inner')\
  .withColumn('WkASfg49CovEffDate',expr('case when ns.WkASfg49CovEffDate < dd.FundBeginDt then dd.FundBeginDt else ns.WkASfg49CovEffDate end')).\
  withColumn('WkASfg49CovEndDate',expr('case when ns.WkASfg49CovEndDate > dd.FundEndDate then dd.FundEndDate else ns.WkASfg49CovEndDate end')).drop(col('dd.FundBeginDt'),col('dd.FundEndDate'),col(''))  

  combine_ci_df=ci_filter_df_converted.union(ci_wihout_filter_converted)       
  
  ci_col_added= combine_ci_df.withColumn("dob",concat_ws("",col('WkAIeg2ZBirthYear'),col('WkAIeg2ZBirthMonth'),col('WkAIeg2ZBirthDay'))).drop(col('WkAIeg2ZBirthYear'),col('WkAIeg2ZBirthMonth'),col('WkAIeg2ZBirthDay')).drop('WkAIeg2ZBirthYear','WkAIeg2ZBirthMonth','WkAIeg2ZBirthDay')

  ci_col_added = ci_col_added.select('WkASfg49CovEffDate','WkASfg49CovEndDate','WkACertAuthTypeCd','WkAIeg2ZMedicareId','MemberId','MemberCustomerNumber','MemberFirstName','MemberLastName','MemberMiddleName','LineOfBusinessCode','m.SubscriberId','dob','WkAIog1WCiGrpId','WsMemberMbrPid')

except Exception as e:

  excep = 'CI and SF transformation failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Expanding Months
try:
    df_ci_months_list = ci_col_added.\
    withColumn("ci_eff_dt", expr("""sequence(
        to_date(WkASfg49CovEffDate,'yyyyMM'),to_date(WkASfg49CovEndDate,'yyyyMM'),interval 1 month)"""))
    ci_normalized_months = df_ci_months_list.withColumn('ci_eff_dt',explode_outer(col('ci_eff_dt')))
    ci_normalized_months = ci_normalized_months.withColumn('ci_eff_dt',date_format(col('ci_eff_dt'),'MMM-yy'))
    
    df_sf_months_list = df_opn_fnd_sf_part.withColumn("sf_eff_dt", expr("""sequence(
        to_date(FundBeginDt,'yyyyMM'),to_date(FundEndDate,'yyyyMM'),interval 1 month)"""))
    sf_normalized_months = df_sf_months_list.withColumn('sf_eff_dt',explode_outer('sf_eff_dt'))
    sf_normalized_months = sf_normalized_months.withColumn('sf_eff_dt',date_format(col('sf_eff_dt'),'MMM-yy'))

except Exception as e:

    excep = 'CI and SF expanding failed: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Find CI Member not present in SF and vice versa
try:
    ci_cols = ci_normalized_months.withColumn('WsMemberCustomerNbr',lit(None)).\
        withColumn('WsMemberMbrPid',lit(None)).\
        withColumn('WsMemberFirstName',lit(None)).\
        withColumn('WsMemberLastName',lit(None)).\
        withColumn('WsMemberMiddleName',lit(None)).\
        withColumn('WsMemberDob',lit(None)).\
        withColumn('CycleNumber',lit(None)).\
        withColumn('sf_eff_dt',lit(None)).\
        withColumn('WsMemberLobCode',lit(None)).\
        withColumn('FundBeginDt',lit(None)).\
        withColumn('ProviderContractId',lit(None)).withColumn('ProviderGrouperId',lit(None)).drop('WkASfg49CovEndDate','WkAIog1WCiGrpId')

    sf_cols = sf_normalized_months.withColumn('WkACertAuthTypeCd',lit(None)).\
        withColumn('WkAIeg2ZMedicareId',lit(None)).\
        withColumn('MemberCustomerNumber',lit(None)).\
        withColumn('Memberid',lit(None)). \
        withColumn('MemberFirstName',lit(None)).\
        withColumn('MemberLastName',lit(None)).\
        withColumn('MemberMiddleName',lit(None)).\
        withColumn('dob',lit(None)).\
        withColumn('ci_eff_dt',lit(None)).\
        withColumn('LineOfBusinessCode',lit(None)).\
        withColumn('WkASfg49CovEffDate',lit(None)).\
        drop('FundEndDate')

    df_ids_in_ci = ci_cols.select('Memberid','MemberCustomerNumber','SubscriberId','ci_eff_dt').subtract(sf_cols.select('WsMemberMbrPid','WsMemberCustomerNbr','SubscriberId','sf_eff_dt')).withColumn('Info',lit('Member Not in SF'))

    df_ids_in_sf = sf_cols.select('WsMemberMbrPid','WsMemberCustomerNbr','SubscriberId','sf_eff_dt').subtract(ci_cols.select('Memberid','WsMemberCustomerNbr','SubscriberId','ci_eff_dt')).withColumn('Info',lit('Member Not in CI'))

    ci_df = df_ids_in_ci.join(ci_cols,['MemberId','MemberCustomerNumber','SubscriberId','ci_eff_dt']) 

    sf_df = df_ids_in_sf.join(sf_cols,['WsMemberMbrPid','WsMemberCustomerNbr','SubscriberId','sf_eff_dt'])   

except Exception as e:
    excep = 'SF and CI comparison failed: ' + str(e)
    output = {
                'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Find unmatched DOB and create output file
try:
  df_mismatched_dob = ci_normalized_months.alias('ci').join(sf_normalized_months.alias('sf'),(col('ci.MemberId') == col('sf.WsMemberMbrPid')) & (col('ci.MemberCustomerNumber') ==col('sf.WsMemberCustomerNbr')) & (col('ci.SubscriberId') == col('sf.SubscriberId'))).filter(col('sf.wsMemberDob')!=col('ci.dob')).\
  drop('WkASfg49CovEndDate','WkAIog1WCiGrpId','FundEndDate',col('ci.WsMemberMbrPid'),col('sf.SubscriberId')).\
  withColumn('Info',lit('Dob not matching'))
  
  df_output = ci_df.union(sf_df).union(df_mismatched_dob)

  df_output=df_output.select('*',coalesce(col("WsMemberCustomerNbr"), col("MemberCustomerNumber")).alias("WsOutCustId"),
  coalesce(col("WsMemberMbrPid"), col("Memberid")).alias("WsOutMemberPid"),
  coalesce(col("ci_eff_dt"), col("sf_eff_dt")).alias("WsOutFundMonth"),
  coalesce(col("MemberCustomerNumber"), col("WsMemberCustomerNbr")).alias('WsUghCustomer'),
  coalesce(col("MemberId"), col("WsMemberMbrPid")).alias('WsUghMember'),
  coalesce(col('dob'),col('WsMemberDob')).alias('WsUghDob'),
  coalesce(col('WsMemberLastName'),col('MemberLastName')).alias('WsUghMbrLname'),
  coalesce(col('WsMemberFirstName'),col('MemberFirstName')).alias('WsUghMbrFname'),
  coalesce(col('WsMemberMiddleName'),col('MemberMiddleName')).alias('WsUghMbrMname'))

except Exception as e:
  excep = 'Writing output file: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Define Column Mapping
col_schema={
    'WsOutCustId':'string'
    ,'WsOutMemberPid':'string'
    ,'WsOutFundMonth':'string'
    ,'CycleNumber':'string'
    ,'ProviderGrouperId':'string'
    ,'ProviderContractId':'string'
    ,'WsMemberCustomerNbr':'string'
    ,'WsMemberMbrPid':'string'
    ,'FundBeginDt':'string'
    ,'WsMemberLobCode':'string'
    ,'WsUghCustomer':'string'
    ,'WsUghMember':'string'
    ,'WsUghDob':'string'
    ,'WsUghMbrLname':'string'
    ,'WsUghMbrFname':'string'
    ,'WsUghMbrMname':'string'
    ,'MemberCustomerNumber':'string'
    ,'MemberId':'string'
    ,'WkASfg49CovEffDate':'string'
    ,'LineOfBusinessCode':'string'
    ,'dob':'Date'
    ,'WkACertAuthTypeCd':'string'
    ,'WkAIeg2ZMedicareId':'string'
    ,'MemberLastName':'string'
    ,'MemberFirstName':'string'
    ,'MemberMiddleName':'string'
    ,'Info':'string'
}

col_mapping={
    'WsOutCustId'	    :	'WsOutCustId'
    ,'WsOutMemberPid'	:	'WsOutMemberPid'
    ,'WsOutFundMonth'	:	'WsOutFundMonth'
    ,'CycleNumber'	    :	'WsUsfCycNbr'
    ,'ProviderGrouperId'	:	'WsUsfGrouper'
    ,'ProviderContractId'	:	'WsUsfGkCtrct'
    ,'WsMemberCustomerNbr'	:	'WsUsfCustomer'
    ,'WsMemberMbrPid'	:	'WsUsfMemberPid'
    ,'FundBeginDt'	    :	'WsUsfCovEffDt'
    ,'WsMemberLobCode'	:	'WsUsfLob'
    ,'WsUghCustomer'	:	'WsUghCustomer'
    ,'WsUghMember'	    :	'WsUghMember'
    ,'WsUghDob'	        :	'WsUghDob'
    ,'WsUghMbrLname'	:	'WsUghMbrLname'
    ,'WsUghMbrFname'	:	'WsUghMbrFname'
    ,'WsUghMbrMname'	:	'WsUghMbrMname'
    ,'MemberCustomerNumber'	:	'WsUciCustomer'
    ,'MemberId'	        :	'WsUciMemberPid'
    ,'WkASfg49CovEffDate'	:	'WsUciCovEffDt'
    ,'LineOfBusinessCode'	:	'WsUciLob'
    ,'dob'	            :	'WsUciDob'
    ,'WkACertAuthTypeCd'	:	'WsUciCertAuthTypeCd'
    ,'WkAIeg2ZMedicareId'	:	'WsUciMedicareId'
    ,'MemberLastName'	:	'WsUciMbrLname'
    ,'MemberFirstName'	:	'WsUciMbrFname'
    ,'MemberMiddleName'	:	'WsUciMbrMname'
    ,'Info'	            :	'WsUdiffDesc'
}

# COMMAND ----------

# DBTITLE 1,Transform dataframe as per mapping
try:
  df_discr_rprt_trm = trim_leading_trailing_space(df_output)
  df_discr_rprt_trans = dtype_conversion(df_discr_rprt_trm, col_schema) 
  df_discr_rprt_mapped =col_name_mapping(df_discr_rprt_trans, col_mapping) 
    
except Exception as e:
  excep = 'Datatype and column mapping failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving and renaming the .csv file to outbound folder.
try:  
  # Convert dataframe to fixed width length column.
  df_write_ci_sf_disr = convert_col_to_fixed_width(fixed_config_df, df_discr_rprt_mapped)

  # write dataframe as .txt file as position delimited.
  write_outbnd_file_to_adls(df_write_ci_sf_disr, temp_csv_path, config)

  #Write to table
  write_df_as_delta_table(df_discr_rprt_mapped,Re3023Tbl)

except Exception as e:
  excep = 'Write to ADLS: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Copy file to outbound path
try:
    #Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
    
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }
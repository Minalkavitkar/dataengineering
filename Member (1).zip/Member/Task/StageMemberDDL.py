# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This Notebook help us to create Member unmanaged delta Stage tables in Adls Gen2

# COMMAND ----------

# DBTITLE 1,Run EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Run ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Run transform notebook.
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database creation.
schema_name = databricks_schema_suf
stage_catalog_name = databricks_stage_catalog_name

# COMMAND ----------

# DBTITLE 1,MemberCoverage table create script.
Member_Coverage = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Member_StageMemberCoverage(
    MemberCoverageKey BIGINT NOT NULL,
    MemberKey BIGINT NOT NULL,
    ProviderContractKey BIGINT NOT NULL,
    ExtProdSeqNo INT,
    ProductKey BIGINT NOT NULL,
    CoverageTypeCode STRING,
    CoverageTypeCodeLabel STRING,
    CoverageStartDate DATE NOT NULL,
    CoverageEndDate DATE,
    CoverageEndReasonCode STRING,
    CoverageEndReasonCodeLabel STRING,
    VendorSequenceNumber INTEGER,
    GateKeeperProviderId STRING,
    GateKeeperProviderSuffixCode STRING,
    GateKeeperProviderTypeCode STRING,
    WokerCompensationOccurenceId DECIMAL (20,6),
    CIClassNumber STRING,
    MemberCustomerNumber STRING,
    MemberGroupNumber STRING,
    CreatedBy STRING,
    CreatedDateTime TIMESTAMP,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP
)"""


# COMMAND ----------

# DBTITLE 1,Member table create script
Member = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.Member_StageMember(
  MemberKey BIGINT NOT NULL
  ,SourceSystemCode VARCHAR(10) NOT NULL
  ,MemberId VARCHAR(50)
  ,SubscriberId VARCHAR(50)
  ,MemberCustomerNumber VARCHAR(50) NOT NULL
  ,ClaimFundExceptionIndicator	CHAR(1)
  ,HumanaIdentifier VARCHAR(50)
  ,MemberFirstName	VARCHAR(55)
  ,MemberLastName VARCHAR(55)
  ,MemberMiddleName VARCHAR(55)
  ,MemberSexCode VARCHAR(20)
  ,MemberBirthDate	DATE
  ,CreatedBy VARCHAR(150)
  ,CreatedDateTime TIMESTAMP
  ,ModifiedBy VARCHAR(150)
  ,ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

Customer_Product = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.Member_StageCustomerProduct(
    CustomerProductKey  BIGINT NOT NULL,
    ExtProdSeqNo INTEGER,
    SourceSystemCode STRING,
    MemberCustomerNumber STRING,
    MemberGroupNumber STRING,
    CIClassNumber STRING,
    ProductCategoryCode STRING,
    LineOfBusinessCode STRING,
    PlanNumber STRING,
    OptNumber STRING,
    MarketNumber STRING,
    CustomerProductStartDate DATE,
    CustomerProductEndDate DATE,
    CreatedBy STRING NOT NULL,
    CreatedDateTime TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP
)"""


# COMMAND ----------

# DBTITLE 1,MemberORDRHeader
Member_ORDRHeader = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Member_StageMemberORDRHeader(
    MemberORDRHeaderKey BIGINT NOT NULL,
     ORDRClassNumber STRING,
     ORDRCustomerNumber STRING, 
     ORDRGroupNumber STRING, 
     SubscriberId STRING,
     MemberId STRING, 
     SourceSystemCode STRING, 
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING, 
     ModifiedDateTime TIMESTAMP
)"""


# COMMAND ----------

# DBTITLE 1,MemberORDRDetail
Member_ORDRDetail = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Member_StageMemberORDRDetail(
    MemberORDRDetailKey BIGINT NOT NULL, 
    MemberORDRHeaderKey BIGINT NOT NULL , 
    RiderCode STRING ,  
    RiderPlanNumber STRING , 
    RiderOptNumber STRING , 
    BrandCopayAmount DECIMAL (20,6) , 
    GenericCopayAmount DECIMAL (20,6) , 
    RiderStartDate DATE , 
    RiderEndDate DATE , 
    CreatedBy STRING NOT NULL, 
    CreatedDateTime TIMESTAMP NOT NULL, 
    ModifiedBy STRING , 
    ModifiedDateTime TIMESTAMP
)"""


# COMMAND ----------

# DBTITLE 1,MemberGRDRHeader
Member_GRDRHeader = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Member_StageMemberGRDRHeader(
  MemberGRDRHeaderKey BIGINT NOT NULL
  ,GRDRClassNumber STRING
  ,GRDRCustomerNumber STRING
  ,GRDRGroupNumber STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# DBTITLE 1,MemberGRDRDetail
Member_GRDRDetail = f"""CREATE TABLE IF NOT EXISTS {stage_catalog_name}.{schema_name}.Member_StageMemberGRDRDetail(
    MemberGRDRDetailKey BIGINT NOT NULL
  ,MemberGRDRHeaderKey BIGINT NOT NULL
  ,RiderCode STRING
  ,RiderPlanNumber STRING
  ,RiderOptNumber STRING
  ,BrandCopayAmount DECIMAL(20,6)
  ,GenericCopayAmount DECIMAL(20,6)
  ,RiderStartDate DATE
  ,RiderEndDate DATE
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  
)"""

# COMMAND ----------

# DBTITLE 1,Member Contact
Member_Contact = f"""CREATE OR REPLACE TABLE {stage_catalog_name}.{schema_name}.Member_stageMemberContact(
     MemberContactKey BIGINT NOT NULL , 
     MemberKey BIGINT NOT NULL , 
     AddressTypeCode STRING , 
     StreetAddress1 STRING , 
     StreetAddress2 STRING , 
     CityName STRING , 
     CountyName STRING , 
     ZipCode STRING , 
     ZipPlusCode STRING , 
     FIPSCountyCode STRING , 
     FIPSCountryCode STRING , 
     FIPSCountyName STRING , 
     AdminDivisionCode STRING ,
     CellPhoneNumber STRING , 
     HomePhoneNumber STRING , 
     WorkPhoneNumber STRING , 
     OtherPhoneNumber STRING ,
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING , 
     ModifiedDateTime TIMESTAMP
)"""

# COMMAND ----------

# DBTITLE 1,Table name mapping dictionary.
tbl_mapping = {
    "Member_StageMember":Member,
    "Member_StageMemberCoverage":Member_Coverage,
    "Member_StageCustomerProduct" : Customer_Product,
    "Member_StageMemberORDRHeader": Member_ORDRHeader,
    "Member_StageMemberORDRDetail": Member_ORDRDetail,
    "Member_StageMemberGRDRHeader": Member_GRDRHeader,
    "Member_StageMemberGRDRDetail": Member_GRDRDetail,
    "Member_StageMemberContact" : Member_Contact
    }

# COMMAND ----------

# DBTITLE 1,Stage table creation.
try:
    # Logic to create table based on the input parameter.
    # If 'All' is provided as parameter then it will create all table in the notebook.
    # If specific table names are provided in parameter then only those will run.
    TABLE_NAMES = TABLE_NAMES.split(',')
    if len(TABLE_NAMES) == 0:
        raise Exception("Table name cannot be empty")
    elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
        cur_table_creation(tbl_mapping, tbl_mapping.keys())
    else:
        cur_table_creation(tbl_mapping, TABLE_NAMES)
except Exception as e:
    excep = "Exception occured in stage table creation cell:" + str(e)
    raise Exception(excep)


# COMMAND ----------

# DBTITLE 1,Notebook exit statement.
dbutils.notebook.exit('Success')
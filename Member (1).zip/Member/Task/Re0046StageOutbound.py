# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - This notebook is created to provide the outbound file of stage area table of Re0046 job in txt format to MF for testing.
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - re0046StageOutbound.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Preeti Sinha
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Importing sql functions
from pyspark.sql.functions import *
import json

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    #fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    config_dict =  get_file_config(file_conf_path)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    temp_path_suffix = "member/temp/Re0046StageOutbound/"
    outbnd_file_name = "re0046StageOutbound.txt"
    re0046_tbl_name = "provider_main_dev_000.mainframe_servicefund_sit.member_re0046dailyprocess"
    cust_tbl_name = "provider_main_dev_000.mainframe_servicefund_sit.member_Customer"
    #audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try: 
    # Read data from stage area.
    re0046_stg_df = read_table_to_df(re0046_tbl_name)
    cust_df = read_table_to_df(cust_tbl_name)
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

try:
    # join the final dataset with CiCustomer, for non joined records join with CIMember table to get MbrGhGroup field
    re0046_stg_converted = (
        re0046_stg_df.alias("LH")
        .join(cust_df.alias("CC"),
            (col("LH.GRDRCustomerNumber") == col("CC.CIGroupIdentifier"))
            & (col("LH.GRDRGroupNumber") == col("CC.BenefitSequence"))
            & (col("LH.GRDRClassNumber") == col("CC.CIClassNumber")),"left")  
       .selectExpr("LH.*","GHGroupIdentifier","CC.EmployerGroupNumber","0 as MemberId","' ' as MemberDepCode","' ' as Filler1","' ' as Filler2"))
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

dict = {
        "FileDetails": [
			{"ColumnName": "GHGroupIdentifier","SequenceNo": 1,"Length": 5,"DataType": "STRING"},
			{"ColumnName": "EmployerGroupNumber","SequenceNo": 2,"Length": 3,"DataType": "STRING"},
			{"ColumnName": "MemberId","SequenceNo": 3,"Length": 9,"DataType": "NUMERIC"},
			{"ColumnName": "MemberDepCode","SequenceNo": 4,"Length": 2,"DataType": "STRING"},
			{"ColumnName": "RiderCode","SequenceNo": 5,"Length": 3,"DataType": "STRING"},
			{"ColumnName": "RiderStartDate","SequenceNo": 6,"Length": 10,"DataType": "STRING"},
			{"ColumnName": "RiderEndDate","SequenceNo": 7,"Length": 10,"DataType": "STRING"},
			{"ColumnName": "RiderPlanNumber","SequenceNo": 8,"Length": 3,"DataType": "STRING"},
			{"ColumnName": "RiderOptNumber","SequenceNo": 9,"Length": 2,"DataType": "STRING"},
			{"ColumnName": "Filler1","SequenceNo": 10,"Length": 1,"DataType": "STRING"},
			{"ColumnName": "GenericCopayAmount","SequenceNo": 11,"Length": 5,"DataType": "Numeric"},
            {"ColumnName": "BrandCopayAmount","SequenceNo": 12,"Length": 5,"DataType": "Numeric"},
            {"ColumnName": "Filler2","SequenceNo": 13,"Length": 26,"DataType": "STRING"},
            {"ColumnName": "DerivedIndicator","SequenceNo": 14,"Length": 6,"DataType": "STRING"}
		]}

# COMMAND ----------

fxd_dtl_df = pd.json_normalize(dict, record_path = ['FileDetails'])
        # Converting pandas dataframe to spark dataframe.
fixed_config_df = spark.createDataFrame(fxd_dtl_df)

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try: 
    # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0046_stg_converted)
    # # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }   

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
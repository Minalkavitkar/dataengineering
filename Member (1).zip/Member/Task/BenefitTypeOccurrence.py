# Databricks notebook source
# MAGIC %md 
# MAGIC This notebook is a part of Customer feed and Coverage process. The notebook groups all benefits, BenTyCodes and BenEffDtlDate for all customers
# MAGIC ##### Source Files 
# MAGIC - Member.CICustomer
# MAGIC ##### Target/Curated Tables
# MAGIC - Member.BenefitTypeOccurrence
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
table_code='Member_BenefitTypeOccurrence'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','') 

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    raise Exception("checking for table run failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Import required python libraries
import re

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_cicustomer = table_name_selector(tbl_conf_df, 'CI_CUSTOMER_STAGE')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
    customer_tbl_name=table_name_selector(tbl_conf_df,'Member_Customer')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
try:
    cicustomer_stage_df = read_table_to_df(stage_cicustomer)\
                    .filter((col('Status') == 'S'))
except Exception as e:
    raise Exception("Table not found",str(e))

# COMMAND ----------

# DBTITLE 1,Creating list of Benefit columns for every occurrence
try:
    ben_lst = []
    slt_lst = [] + ['CiGrpId','GrpNbrBen','CiClsNbr','EmprFacIdNbr','SmgtPlanNbr','SmgtOptNbr','BenTyCnt','CiProdPkgKey','BenDtlEffDate','GrpCancelDate','DerivedIndicator']
    for x in cicustomer_stage_df.columns:
        if x.startswith('BenTyCd'):
            ben_lst.append(x)
            temp = re.compile("([a-zA-Z]+)([0-9]+)")
            res = temp.match(x).groups()[1]
            BenCovId = "BenCovId"+res
            slt_lst.append(f"concat({x},',', {BenCovId}) as {x}")
except Exception as e:
    raise Exception("group all BENTyCd and BenCovId:", str(e))

# COMMAND ----------

# DBTITLE 1,Create dataframe based on the calculated columns
try:
    df1 = cicustomer_stage_df.selectExpr(*slt_lst)

    win_spec = Window.partitionBy('CiGrpId','GrpNbrBen','CiClsNbr').orderBy('BenDtlEffDate')
    rn_clac_df = df1.withColumn('BenefitYearSequenceNumber', row_number().over(win_spec))

    df_unpivot=rn_clac_df.unpivot(['CiGrpId','GrpNbrBen','CiClsNbr','EmprFacIdNbr','SmgtPlanNbr','SmgtOptNbr','BenTyCnt','CiProdPkgKey','BenDtlEffDate','GrpCancelDate','BenefitYearSequenceNumber','DerivedIndicator'], ben_lst, "TypeName","TypeValue")
except Exception as e:
    raise Exception("get the valid customers record:", str(e))

# COMMAND ----------

# DBTITLE 1,Split BenefitType Code and filter the values where BenefitType code is not present
try:
    split_df= df_unpivot.select(expr('CiGrpId AS CIGroupIdentifier'),
                            expr('GrpNbrBen AS BenefitSequence'),
                            expr('CiClsNbr AS CIClassNumber'),
                            expr('EmprFacIdNbr AS SellingLedger'),
                            expr('SmgtPlanNbr AS ProductPlanNumber'),
                            expr('SmgtOptNbr AS ProductOptionNumber'),
                            expr('BenTyCnt AS BenefitTypeCount'),
                            expr('CAST(CiProdPkgKey AS STRING) AS CIProductPackageKey'),
                            expr('BenDtlEffDate AS BenefitEffectiveDate'),
                            expr('GrpCancelDate AS BenefitENDDate'),
                            'BenefitYearSequenceNumber',
                            'DerivedIndicator',
                            split(col("TypeName"),"BenTyCd").getItem(1).alias("BenefitTypeSequenceNumber"),
                            split(col('TypeValue'),',').getItem(0).alias('BenTypeCode'),
                            split(col('TypeValue'),',').getItem(1).alias('BenCoverageID')).filter(trim(col('BenTypeCode')) != '')
except Exception as e:
    raise Exception ("Failed in split column",str(e))

# COMMAND ----------

# DBTITLE 1,Read customer table for joining
try:
    customer_df=  read_table_to_df(customer_tbl_name)\
        .select('CustomerKey','CIClassNumber','CIGroupIdentifier','BenefitSequence')
except Exception as e:
    raise Exception ("Table not found",str(e))

# COMMAND ----------

# DBTITLE 1,Final structure of Benefit table
try:
    join_df= split_df.alias('LH').join(customer_df.alias('RH'),
                                        (col('LH.CIClassNumber')==col('RH.CIClassNumber'))&
                                        (col('LH.CIGroupIdentifier')==col('RH.CIGroupIdentifier'))&
                                        (col('LH.BenefitSequence')==col('RH.BenefitSequence')),'left')\
                                            .select('LH.*','RH.CustomerKey')
except Exception as e:
    raise Exception('joining or filtering valid records failed',str(e))

# COMMAND ----------

# DBTITLE 1,Adding audit columns
final_df = add_tgt_audit_column(join_df, PIPELINE_NAME,LOAD_TYPE)

# COMMAND ----------

# DBTITLE 1,Merge function in case of Delta data
def delta_operation(cur_tbl_name,final_df):
    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)

    
    dfUpdates =final_df.filter(' DerivedIndicator in ("UPDATE","INSERT","DELETE") ')
    
    deltaTableCurated.alias('Curated')\
        .merge(
            dfUpdates.alias('Stage'),
            'Curated.CIGroupIdentifier = Stage.CIGroupIdentifier AND Curated.BenefitSequence = Stage.BenefitSequence AND Curated.CIClassNumber = Stage.CIClassNumber AND Curated.BenefitEffectiveDate = Stage.BenefitEffectiveDate AND Curated.BenefitTypeSequenceNumber = Stage.BenefitTypeSequenceNumber')\
        .whenMatchedUpdate(set={
            'CustomerKey':'Stage.CustomerKey',
            'BenCoverageID':'Stage.BenCoverageID',
            'SellingLedger':'Stage.SellingLedger',
            'BenTypeCode':'Stage.BenTypeCode',
            'ProductPlanNumber':'Stage.ProductPlanNumber',
            'ProductOptionNumber':'Stage.ProductOptionNumber',
            'BenefitEffectiveDate':'Stage.BenefitEffectiveDate',
            'BenefitENDDate':'Stage.BenefitENDDate',
            'BenefitTypeCount':'Stage.BenefitTypeCount',
            'CIProductPackageKey':'Stage.CIProductPackageKey',
            'DerivedIndicator':'Stage.DerivedIndicator',
            'ModifiedBy':f"'{PIPELINE_NAME}'",
            'ModifiedDateTime':current_timestamp()
            })\
        .whenNotMatchedInsert(values={
            'CustomerKey':'Stage.CustomerKey',
            'CIClassNumber':'Stage.CIClassNumber',
            'CIGroupIdentifier':'Stage.CIGroupIdentifier',
            'BenefitSequence':'Stage.BenefitSequence',
            'BenefitYearSequenceNumber':'Stage.BenefitYearSequenceNumber',
            'BenefitTypeSequenceNumber':'Stage.BenefitTypeSequenceNumber',
            'BenTypeCode':'Stage.BenTypeCode',
            'BenCoverageID':'Stage.BenCoverageID',
            'SellingLedger':'Stage.SellingLedger',
            'ProductPlanNumber':'Stage.ProductPlanNumber',
            'ProductOptionNumber':'Stage.ProductOptionNumber',
            'BenefitEffectiveDate':'Stage.BenefitEffectiveDate',
            'BenefitENDDate':'Stage.BenefitENDDate',
            'BenefitTypeCount':'Stage.BenefitTypeCount',
            'CIProductPackageKey':'Stage.CIProductPackageKey',
            'DerivedIndicator':'Stage.DerivedIndicator',
            'CreatedBy':f"'{PIPELINE_NAME}'",
            'CreatedDateTime':current_timestamp()
        })\
        .execute()


# COMMAND ----------

# DBTITLE 1,Load data as per LoadType
#If it is full load we will be overwrite data to BenefitType table.
try:
    if LOAD_TYPE == 'FullLoad':
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":"Member_BenefitTypeOccurrence"})
        write_to_curated(final_df,cur_tbl_name)

        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        

    elif LOAD_TYPE == 'DeltaLoad':
        delta_operation(cur_tbl_name,final_df)
        
        cur_loaded_time = datetime.now()
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
        
except Exception as e:
    raise Exception("Please check the load_type. Its not valid", str(e))
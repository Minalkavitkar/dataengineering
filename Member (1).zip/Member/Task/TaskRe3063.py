# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview
# MAGIC - Monthly Job RE3063 to create medicare grouper report which contains all active member details for each group for next 24 months period
# MAGIC ###### Source details (Stage layer Adls - Unmanaged delta table):
# MAGIC - MemberCoverage.StageMemberCoverage
# MAGIC - Product.StageProduct
# MAGIC - Provider.StageProviderGrouper
# MAGIC - ProviderContract.StageProviderContract
# MAGIC
# MAGIC ###### Target Details (File)
# MAGIC - Re3063Monthly.txt
# MAGIC - Member_Re3063ActiveMbrCvg
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
  file_conf_path = env_file_config_path
  fxd_wdth_path = env_fxd_wdt_file_config_path
  storage_account = env_storage_account_name
except Exception as e:
  excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config.
# Fixed width function to save output file in csv format
try:
  job_name = JOB_NAME
  config_dict =  get_file_config(file_conf_path)
  fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)

except Exception as e:
  excep = 'Read File Config and Fixed Width File Config: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))


# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
  default_config = config_dict['DEFAULT']
  default_out_config = default_config['Outbound']
  Re3063Monthly_config = config_dict[job_name]

  container_name = default_config['ContainerName']
  file_path_prefix = default_out_config['FilePathPrefix']
  config = default_out_config['Config']

  prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
  temp_path_suffix = Re3063Monthly_config["Outbound"]["TempFilePathSuffix"]   
  curated_path_suffix = Re3063Monthly_config["Outbound"]["CuratedFilePathSuffix"]
  outbnd_file_name = Re3063Monthly_config["Outbound"]["FileName"]
  re3063ActiveMbrCvg= Re3063Monthly_config["Outbound"]["TableName"]

  stg_member = Re3063Monthly_config["Inbound"]["StageMember"]
  stg_member_cov = Re3063Monthly_config["Inbound"]["StageMemberCoverage"]
  stg_product = Re3063Monthly_config["Inbound"]["StageProduct"]
  stg_provider_grpr = Re3063Monthly_config["Inbound"]["StageProviderGrouper"]
  stg_provider_contract = Re3063Monthly_config["Inbound"]["StageProviderContract"]
  sync_process_names = Re3063Monthly_config["Inbound"]["StageSyncProcessNames"]
  ctrl_table_name = default_config["AuditTableName"]
    
except Exception as e:
  excep = 'Variable assignment from FileConfig: '+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
# If not up-to-date raise exception and stop the process.
try:
  prc_status = start_process_check(ctrl_table_name, sync_process_names)
  if prc_status != True:
      dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
  excep = "ControlTable check failed: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    cur_delta_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        curated_path_suffix
    )
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix     
    )  
    outbnd_csv_path = abfss_path_builder(
        container_name, 
        storage_account, 
        path_prefix=file_path_prefix
    )
except Exception as e:
    excep = "Path creation failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

mbr_cols=['MemberId','MemberKey']
mbr_cvg_cols=['MemberKey','ProductKey','ProviderContractKey','CoverageStartDate','CoverageEndDate','membercoveragekey']
prod_cols=['ProductKey','LineOfBusinessCode']
prv_cntrct_cols=['ProviderContractKey','ProviderGrouperId']
prv_grpr_cols=['ProviderGrouperId','CompanyName','LedgerNumber','TypeCode']

# COMMAND ----------

try: 

  # Read the data from MeberCoverage Stage table(Adls).
  df_member = read_table_to_df(stg_member).select(*mbr_cols)

  # Read the data from MeberCoverage Stage table(Adls).
  df_member_cov = read_table_to_df(stg_member_cov).select(*mbr_cvg_cols)
  
  # Read the data from Product Stage table(Adls).
  df_product = read_table_to_df(stg_product).select(*prod_cols).filter(col('LineOfBusinessCode').isin('MER','MRO'))
  
  # Read the data from Provider Stage table(Adls).
  df_provider_grpr = read_table_to_df(stg_provider_grpr).select(*prv_grpr_cols)
  
  # Read the data from Provider_contract Stage table(Adls).
  df_provider_contract = read_table_to_df(stg_provider_contract).select(*prv_cntrct_cols)
       
except Exception as e:
  excep = "Read Sql Tables: "+ str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Joining the required tables and calculate Begin date
try:
  df_mbr_cov_data = df_member.alias('m')\
    .join(df_member_cov.alias("mc"),'MemberKey','inner')\
    .join(df_product.alias("prod"), "ProductKey", "inner")\
    .join(df_provider_contract.alias('pc'), "ProviderContractKey", 'inner')\
    .join(df_provider_grpr.alias('pg'), 'ProviderGrouperId', 'inner')\
    .filter((col('TypeCode')=='R'))\
    .drop('ProductKey','LineOfBusinessCode')

  df_calculate_begin_dt=df_mbr_cov_data.withColumn('BeginDt',expr("""
                  CASE WHEN date_format(to_date('20230701','yyyyMMdd'),'MM') = '07'
                        THEN add_months(to_date('20230701','yyyyMMdd'),-12)
                        ELSE '20220701'
                  END"""))
  df_calculate_end_dt = df_calculate_begin_dt.withColumn('EndDate',add_months('BeginDt',23))\
  .withColumn('CoverageStartDate',date_format('mc.CoverageStartDate','yyyyMM'))\
  .withColumn('CoverageEndDate',date_format('mc.CoverageEndDate','yyyyMM'))

except Exception as e:
  excep = ("Joining tables failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Calculate active medicare member coverages 
try:
  df_expand_months=df_calculate_end_dt.select("*",expr("""sequence(
                  to_date(BeginDt),to_date(EndDate),interval 1 month) as GenMonths""")).drop('BeginDt','EndDate')
  
  df_normalised = df_expand_months.select('*',explode('GenMonths').alias('Months')).drop('GenMonths')
  
  df_year_month=df_normalised.withColumn('Months',date_format('Months','yyyyMM'))

  df_int_casted = df_year_month\
  .withColumn('CoverageStartDate',col('CoverageStartDate').cast('int'))\
  .withColumn('CoverageEndDate',col('CoverageEndDate').cast('int'))\
  .withColumn('Months',col('Months').cast('int'))

  df_filter_active_mbr_cov = df_int_casted.filter((col('CoverageStartDate') == col('Months'))  | (col('CoverageEndDate') == col('Months')) | ((col('CoverageStartDate') < col('Months')) & ((col('CoverageEndDate') > col('Months')))))
                                            
  df_get_active_mbr_cov_cnt = df_filter_active_mbr_cov.groupBy('ProviderGrouperId','CompanyName','Months').agg(count('*').alias('ActiveCvgCount')).orderBy('ProviderGrouperId','Months').withColumn('Filler',lpad(lit(' '),9,' '))

except Exception as e:
  excep = ("Joining tables failed: "+ str(e))
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output)) 

# COMMAND ----------

col_schema={
    'ProviderGrouperId'		:'string'
    ,'Months'	:'string'
    ,'CompanyName'	:'string'
    ,'ActiveCvgCount':'numeric'
    ,'Filler'		:'string'
}

col_mapping ={
    'ProviderGrouperId' : 'RembroutGrouperId'
    ,'Months' : 'RembroutRptCcyymm'
    ,'CompanyName' : 'RembroutGrouperName'
    ,'ActiveCvgCount' : 'RembroutMemberMonthCnt'
    ,'Filler' : 'RembroutFiller'
}

# COMMAND ----------

try:
  df_get_active_cov_trim = trim_leading_trailing_space(df_get_active_mbr_cov_cnt)
  df_get_active_cov_trans = dtype_conversion(df_get_active_cov_trim, col_schema)
  get_active_cov_map_df = col_name_mapping(df_get_active_cov_trans, col_mapping)  

except Exception as e:
  excep = 'Datatype and column mapping failed: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to table and ADLS Gen2.
try: 
  #write to table 
  write_df_as_delta_table(get_active_cov_map_df,re3063ActiveMbrCvg,mode = 'overwrite')

  # Convert dataframe to fixed width length column.
  df_write_active_cov = convert_col_to_fixed_width(fixed_config_df, get_active_cov_map_df)
  
  # write dataframe as .txt file as position delimited.
  write_outbnd_file_to_adls(df_write_active_cov, temp_csv_path, config)

except Exception as e:
  excep = 'Write to ADLS: ' + str(e)
  output = {
  'NOTEBOOK_RUN_STATUS' : excep
  }
  dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Moving and renaming the .csv file to outbound folder.
try:
    #Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)

except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Daily job RE0469 - The main purpose of this job is to built an interface to extract member details from Member Coverage database based on the Grouper ID passed form CR Grouper input file and create a Member_CR stage area table and an outbound MF file for CR system
# MAGIC ###### Source Details (Stage layer Adls - Unmanaged delta table):
# MAGIC
# MAGIC - ProviderContract.ProviderContract
# MAGIC - Member.MemberCoverage
# MAGIC
# MAGIC ###### Intermediate table details (Curated layer Adls - Unmanaged delta table)
# MAGIC - Member.Re0469DailyMemberCR
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ProdrenRE469MemberFile.csv (CSV File) 
# MAGIC ###### Created By: Supriya Bhadre
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook.
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS connection notebook.
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import transform notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Import json
import json

# COMMAND ----------

# DBTITLE 1,Parameter Cell
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
# Fixed width function to save output file in csv format for GG processe
try:
    job_name = JOB_NAME
    config_dict = get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(
        col("JobName") == job_name
    )
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
     default_config = config_dict["DEFAULT"]
     default_out_config = default_config["Outbound"]
     default_in_config = default_config["Inbound"]
     re0469_config = config_dict[job_name] 
     container_name = default_config["ContainerName"]
     file_path_prefix = default_out_config["FilePathPrefix"]
     file_path_suffix = default_in_config['FilePathSuffix']
     config = default_out_config["Config"]
     prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
     curated_path_suffix = re0469_config["Outbound"]["CuratedFilePathSuffix"]
     temp_path_suffix = re0469_config["Outbound"]["TempFilePathSuffix"]
     tbl_name = re0469_config["Outbound"]["TableName"]
     outbnd_file_name = re0469_config["Outbound"]["FileName"]
     inbnd_config = re0469_config["Inbound"]["InboundFileName"]
     mbr_cvrg_tbl_name = re0469_config["Inbound"]["StageMemberCoverageTableName"]
     prod_tbl_name = re0469_config["Inbound"]["StageProductTableName"]
     prov_ctrt_tbl_name = re0469_config["Inbound"]["StageProviderContractTableName"]
     mbr_tbl_name=re0469_config["Inbound"]["StageMemberTableName"]
     ci_mbr_tbl_name=re0469_config["Inbound"]["StageCIMemberTableName"]
     audit_table_name = default_config["AuditTableName"]
     sync_process_names = re0469_config["Inbound"]["StageSyncDependencyProcess"]
    
except Exception as e:
     excep = 'Variable assignment from FileConfig: '+ str(e)
     output = {
		'NOTEBOOK_RUN_STATUS' : excep
     }
     dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check Product, Member and MemberCoverage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(
        container_name,
        storage_account,
        prc_file_path_prefix,
        temp_path_suffix
    )
    outbnd_csv_path = abfss_path_builder(
        container_name, storage_account, file_path_prefix
    )
    inbnd_file_path = abfss_path_builder(
        container_name, storage_account, file_path_suffix, inbnd_config
    )

except Exception as e:
    excep = "Reading config file failed: " + str(e)
    dbutils.notebook.exit(excep)

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from product table.
prod_req_cols = [
    "ProductKey",
    "OptNumber",
    "PlanNumber"
    ]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from provider contract table.
prov_ctrt_req_cols = [
    "ProviderContractKey",
    "ProviderGrouperId",
    "ReportIndicator",
    concat("ProviderId","ProviderSuffixCode").alias("PcpNbr")   
]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from member coverage table.
mbr_cvrg_req_cols = [
    "MemberKey",
    "ProviderContractKey",
    "ProductKey",
    "CoverageStartDate",
    "CoverageEndDate",
    "MemberCustomerNumber",
    "MemberGroupNumber",
    "CIClassNumber"
]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from member table.
mbr_req_cols = [
    "MemberKey",
    "MemberId",
    "SubscriberId"
     
]

# COMMAND ----------

# DBTITLE 1,Create list with necessary columns for each table.
# Add required columns to the list from ci-member table.
ci_mbr_req_cols = [
    "MbrGhGroup",
    "CiGrpId",
    "CiBenSeqNbr",
    "CiClsNbr",
    "MbrPid",
    "MbrSubPid"
]

# COMMAND ----------

# DBTITLE 1,Read data from ADLS.
try:
    # Read ProviderContract from ADLS curated table
    prov_ctrt_df = read_table_to_df(prov_ctrt_tbl_name).select(*prov_ctrt_req_cols).withColumn("CurrentDate",current_date()) 

    # Read MemberCoverage from ADLS curated table
    mbr_cvrg_df = read_table_to_df(mbr_cvrg_tbl_name).select(*mbr_cvrg_req_cols)

    # Read Member from ADLS curated table
    mbr_df = read_table_to_df(mbr_tbl_name).select(*mbr_req_cols)
    
    # Read ci-Member from ADLS curated table
    ci_mbr_df = read_table_to_df(ci_mbr_tbl_name).select(*ci_mbr_req_cols)

    # Read Product from ADLS curated table
    prd_df = read_table_to_df(prod_tbl_name).select(*prod_req_cols)

    # Read Inbound file from ADLS curated table
    inbnd_file_df=read_inbound_csv_file(inbnd_file_path)

except Exception as e:
    excep = "Read data from Stage(ADLS): "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join inbound file with provider contract table 
try:
    # Join inbound file with provider contract table if given condition matches.
    joined_df = (
        prov_ctrt_df.alias("LH")
        .join(
            inbnd_file_df.alias("RH"),
            (col("LH.ProviderGrouperId") == col("RH.CR_GROUPER"))
            & (col("LH.ReportIndicator") == "Y"),
            "right",
        )
        .select("LH.*", col("RH.CR_WORK_TASK_KEY").alias("CrWorkTaskKey"))
        .drop("ReportIndicator", "ProviderGrouperId")
    )
except Exception as e:
    excep = "Join inbound file with provider contract table failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join Member and MemberCoverage
try:
    # Join Member and MemberCoverage table to get MemberId
    mbr_with_mbrcvrg_df = (
        mbr_cvrg_df.alias("LH")
        .join(mbr_df.alias("RH"), (col("LH.MemberKey") == col("RH.MemberKey")), "left")
        .select("LH.*", "RH.MemberId","RH.SubscriberId")
        .drop("MemberKey")
    )
except Exception as e:
    excep = "Join Member and MemberCoverage failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join ProviderContract with MemberCoverage 
try:
    # Join ProviderContract with MemberCoverage and fetch the records with Coverage End Date greater than current date
    joined_with_mbrcvrg_df = (
        joined_df.alias("LH")
        .join(
            mbr_with_mbrcvrg_df.alias("RH"),
            (col("LH.ProviderContractkey") == col("RH.ProviderContractkey")),
            "inner",
        )
        .filter((col("CoverageEndDate") > col("CurrentDate")))
        .drop("ProviderContractkey", "CurrentDate")
    )
except Exception as e:
    excep = "Join result with MemberCoverage failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join result dataset with Product table
try:
    # join result dataset with Product table to fetch Option number and plan number.
    final_joined_df = (
        joined_with_mbrcvrg_df.alias("LH")
        .join(
            prd_df.alias("RH"), (col("LH.ProductKey") == col("RH.ProductKey")), "left"
        )
        .drop("ProductKey")
    )
except Exception as e:
    excep = "Join result with MemberCoverage failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Join final dataset with CIMember table to get MbrGhGroup field
try:
    # join the final dataset with CIMember table to get MbrGhGroup field
    calc_final_df = (
        final_joined_df.alias("LH")
        .join(
            ci_mbr_df.alias("RH"),
            (col("LH.MemberCustomerNumber") == col("RH.CiGrpId"))
            & (col("LH.MemberGroupNumber") == col("RH.CiBenSeqNbr"))
            & (col("LH.CIClassNumber") == col("RH.CiClsNbr"))
            & (col("LH.MemberId") == col("RH.MbrPid"))
            & (col("LH.SubscriberId") == col("RH.MbrSubPid")),
            "left",
        )
        .select("LH.*", col("RH.MbrGhGroup"))
    )
except Exception as e:
    excep = "Join result with CIMember failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Add Filler column to the dataframe
try:
    final_joined_df=calc_final_df.withColumn("Filler",lit(" "))
except Exception as e:
    excep = "Adding Filler column to the dataframe failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Add blank spaces to the filler column.
try:
    final_joined_df=final_joined_df.withColumn("Filler",lpad(col("Filler"),30,' '))
    final_rerex_df=final_joined_df.select(col("MbrGhGroup").alias("MemberCustomerNumber"),"MemberId","SubscriberId","PcpNbr","CoverageStartDate","CoverageEndDate","PlanNumber","OptNumber","CrWorkTaskKey","Filler").distinct()
except Exception as e:
    excep = "lpad failed: " + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write processed data to ADLS Gen2.
try:
    # Write data to ADLS stage area as delta format.
    write_df_as_delta_table(final_rerex_df, tbl_name)

    # Read data from stage layer.
    re0469_df = read_table_to_df(tbl_name)

    # Convert dataframe columns to fixed width length columns.
    final_df = convert_col_to_fixed_width(fixed_config_df, re0469_df)

    # write dataframe as single csv file with "|" seperator.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
    
except Exception as e:
    excep = 'Write to ADLS: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
		'NOTEBOOK_RUN_STATUS' : 'Success'
    }

# COMMAND ----------

# DBTITLE 1,Rename the csv file as per task name and move the file to outbound folder
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: ' + str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Exit from the notebook
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
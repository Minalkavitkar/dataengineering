# Databricks notebook source
# MAGIC %md
# MAGIC ###### Overview:
# MAGIC - Weekly job RE0051 - Its a process to to create outbound file member extract files and creates weekly job file
# MAGIC
# MAGIC ###### Source Details (Stage Layer ADLS -Unmanaged Delta Tables):
# MAGIC
# MAGIC - ProviderContract.StageProviderContract
# MAGIC - Member.StageMemberCoverage
# MAGIC - Member.StageMember
# MAGIC - product.StageProductGeoMarketAffiliation
# MAGIC - Provider.Re0051WeeklyExtractMembershipFile
# MAGIC
# MAGIC
# MAGIC ###### intermediate Table Details (Curated Layer ADLS -Unmanaged Delta Tables):
# MAGIC - ProviderContract.Re0051WeeklyExtractMembershipFile
# MAGIC
# MAGIC ###### Target Details (File):
# MAGIC - ReWeeklyExtractMembershipFile.csv (CSV File) 
# MAGIC
# MAGIC ###### Created By: Venkata Ramaraju
# MAGIC ###### Eviden Data Engineering Team
# MAGIC

# COMMAND ----------

# DBTITLE 1,Import EnvironmentVariableHelper notebook
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,Import ADLS Connection Notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Import Transform Notebook
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Import load notebook
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Importing sql functions
from pyspark.sql.functions import *
import json

# COMMAND ----------

# DBTITLE 1,Parameter cell.
dbutils.widgets.text('JOB_NAME','')
JOB_NAME = dbutils.widgets.get('JOB_NAME')

# COMMAND ----------

# DBTITLE 1,Get required details from environment variable helper notebook.
try:
    file_conf_path = env_file_config_path
    fxd_wdth_path = env_fxd_wdt_file_config_path
    storage_account = env_storage_account_name
except Exception as e:
    excep = 'Get required details from environment variable helper notebook failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Read File Config and Fixed Width File Config
try:  
    job_name = JOB_NAME
    config_dict =  get_file_config(file_conf_path)
    fixed_config_df = get_fixed_width_file_config(fxd_wdth_path).filter(col('JobName') == job_name)
except Exception as e:
    excep = 'Read File Config and Fixed Width File Config: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Variable assignment from FileConfig
try:
    default_config = config_dict['DEFAULT']
    default_out_config = default_config['Outbound']
    re0051_config = config_dict[JOB_NAME]

    container_name = default_config['ContainerName']
    file_path_prefix = default_out_config['FilePathPrefix']
    config = default_out_config['Config']

    prc_file_path_prefix = default_out_config["ProcessFilePathPrefix"]
    curated_path_suffix = re0051_config["Outbound"]["CuratedFilePathSuffix"]
    temp_path_suffix = re0051_config["Outbound"]["TempFilePathSuffix"]
    tbl_name = re0051_config["Outbound"]["TableName"]
    outbnd_file_name = re0051_config["Outbound"]["FileName"]
    
    #input table name
    stg_mbr_tbl = re0051_config["Inbound"]["StageMember"] 
    stg_mem_cov_tbl = re0051_config["Inbound"]["StageMemberCoverage"]
    stg_pc_tbl = re0051_config["Inbound"]["StageProviderContract"] 
    stg_prdmrktaffl_tbll = re0051_config["Inbound"]["StageProductGeoMarketAffiliation"]
    sync_process_names = re0051_config["Inbound"]["StageSyncDependencyProcess"]
    audit_table_name = default_config["AuditTableName"]
except Exception as e:
    excep = 'Variable assignment from FileConfig: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Check if the stage tables are up-to-date with the SQL tables.
# Check required stage tables are up-to-date with the SQL tables.
    # If not up-to-date raise exception and stop the process.
try:
    prc_status = start_process_check(audit_table_name, sync_process_names)
    if prc_status != True:
        dbutils.notebook.exit(f"Stage tables: {sync_process_names} are not in sync with Azure SQL table")
except Exception as e:
    excep = "ControlTable check failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Path creation for Stage and Curated
try:
    temp_csv_path = abfss_path_builder(container_name, storage_account,prc_file_path_prefix, temp_path_suffix)
    outbnd_csv_path = abfss_path_builder(container_name, storage_account, file_path_prefix)
except Exception as e:
    excep = "Path creation for Stage and Curated failed: "+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Reading Required Tables from ADLS and AzureSQL
try:  
    df_mbr= read_table_to_df(stg_mbr_tbl).select('MemberKey','MemberId')
    df_mbr_cvrg= read_table_to_df(stg_mem_cov_tbl).select('MemberKey','CoverageTypeCode','ProviderContractKey','MemberCoverageKey')
    df_prvdr_ctrct= read_table_to_df(stg_pc_tbl).select('ProviderContractKey','ProviderKey')
    df_prd_geomrk_affl= read_table_to_df(stg_prdmrktaffl_tbll).select('ProductAffiliationKey','ProductGeoMarketAffiliationKey')
except Exception as e:
    excep = 'Read Sql Tables failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Filter the Records of Member Coverage
#Filtering ProviderContract on members with active coverage members
try:
  cond1 = (col('mcv.MemberKey')==col('mem.MemberKey'))  
  df_mbr_cnt_fle = df_mbr_cvrg.alias('mcv')\
                          .join(df_mbr.alias('mem'),cond1,'left')\
                          .select('mcv.MemberKey','mcv.MemberCoverageKey','ProviderContractKey','MemberId')\
                          .withColumn('NEWT-MCAID-ID',lit(''))
except Exception as e:
    excep = 'Filter the Records of ProviderContract failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

def ci_member_distinct(df):
    window_spec = Window.partitionBy("MbrPid", "CiGrpId",'MbrsubPid').orderBy(desc('MbrUmidEffDate'), desc('MbrUmid'))
    rn_clac_df = df.withColumn('RN', row_number().over(window_spec))
    valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN')
    return(valid_df)

# COMMAND ----------

# DBTITLE 1,Join Member, MemberCoverage to get required field
try:
    # Join Member, MemberCoverage to get required field
    joined_mbr_mbrcvrg_df = (
        mbr_df.alias("LH")
        .join(mbr_cvrg_df.alias("RH"),(col("LH.MemberKey") == col("RH.MemberKey")),"right")
        .select("RH.*","LH.MemberId",'LH.SubscriberId','LH.HumanaIdentifier','LH.ClaimFundExceptionIndicator')
    )
except Exception as e:
    excep = "Join Member and MemberCoverage failed: " + str(e)
    output = {
        'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,join Member with CiMember table to fetch Gh group fields
try:
    # join Member with CiMember table to fetch Gh group fields
    calc_final_df = (
        joined_mbr_mbrcvrg_df.alias("RH")
        .join(
            ci_mbr_df.alias("LH"),
            (col("LH.CiGrpId") == col("RH.MemberCustomerNumber"))
            & (col("LH.CiBenSeqNbr") == col("RH.MemberGroupNumber"))
            & (col("LH.CiClsNbr") == col("RH.CIClassNumber"))
            & (col("LH.MbrPid") == col("RH.MemberId"))
            & (col("LH.MbrSubPid") == col("RH.SubscriberId")),
            "inner",
        ).select("RH.*",col("LH.MbrGhGroup"),col("LH.MbrGhSubGroup"),col("LH.McaidId"))
    )
except Exception as e:
    excep = "join Member with CiMember table to fetch Gh group fields failed: " + str(e)
    output = {"NOTEBOOK_RUN_STATUS": excep}
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

#fetching final combined results
try:
    cond2 = (col('cnt.ProviderContractKey')==col('prvdctr.ProviderContractKey')) 
    df_mbr_cnt_fle3 = df_mbr_cnt_fle.alias('cnt')\
                    .join(df_prvdr_ctrct.alias("prvdctr"),cond2,'inner')\
                    .select('ProviderKey','NEWT-MCAID-ID','cnt.ProviderContractKey')\
                    .withColumnRenamed('ProviderKey','NEWT-MBRPRV')\
                    .withColumnRenamed('ProviderContractKey','NEWT-CTRCT-KEY')\
                    .withColumnRenamed('ProviderContractKey','WS-HOLD-CTRCT-KEY')\
                    .withColumn('NEW-DEST-CNTR-ID',lit(''))\
                    .withColumn('NEWT-CYC-NBR',lit(''))\
                    .withColumn('WS-HOLD-CYC-NBR',lit(''))
except Exception as e:
    excep = 'Filter the Records of ProviderContract failed: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Write transformed data to ADLS Gen2.
try:  

    # # Convert dataframe to fixed width length column.
    final_df = convert_col_to_fixed_width(fixed_config_df, df_mbr_cnt_fle3)
    # write dataframe as single text file with position delimited.
    write_outbnd_file_to_adls(final_df, temp_csv_path, config)
except Exception as e:
    excep = 'Write to ADLS: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))

# COMMAND ----------

# DBTITLE 1,Move file to outbound folder and rename it.
try:
    # Spark generate its own name when writing the file in ADLS. So we are writing the outbound file in the temp folder, then when we move the file from temp to outbound folder we are renaming it.
    copy_file_to_outbnd_with_new_name(temp_csv_path, outbnd_csv_path, outbnd_file_name)
except Exception as e:
    excep = 'Rename outbound file: '+ str(e)
    output = {
		'NOTEBOOK_RUN_STATUS' : excep
    }
    dbutils.notebook.exit(json.dumps(output))
else:
    output = {
        'OUTBOUND_FILE_NAMES' : outbnd_file_name,
        'NOTEBOOK_RUN_STATUS' : 'Success'
    }   

# COMMAND ----------

# DBTITLE 1,Notebook Exit Value.
# If the notebook run without any error then exit Success.
dbutils.notebook.exit(json.dumps(output))
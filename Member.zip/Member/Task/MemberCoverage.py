# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - DB2 Tables
# MAGIC   - TRE2320, TRE2321
# MAGIC - Curated
# MAGIC   - CIMember ( derived columns 
# MAGIC MbrGhGroup,MbrGhSubGroup,CiGrpId,CiBenSeqNbr,CiClsNbr,MbrGhGroup,MbrGhSubGroup,MbrSubPid)
# MAGIC - SQL Tables for PK and FK relationships
# MAGIC   - Product, Member and ProviderContract
# MAGIC   
# MAGIC ##### Target Table 
# MAGIC - MemberCoverage
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
table_code = 'Member_MemberCoverage'
not_null_col_lst = ['ProviderContractKey','ProductKey','MemberKey']

# COMMAND ----------

# DBTITLE 1,Parameters to be ingested from ADF
dbutils.widgets.text('PIPELINE_NAME','nb_Member')
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Member', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,ADLS connection notebook
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Functions to ingest files into stage Delta
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Functions used during Transforming the data
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Functions to read and load data to SQL
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Schema of the DB2 tables
# MAGIC %run "./MemberStageSchema"

# COMMAND ----------

# DBTITLE 1,Get the tableNames in a dataframe
default_conf = {**file_config["DEFAULT"]}
tbl_conf_df = get_table_config(default_conf["TableDetailsConfigPath"]).cache()
child_tbl_config_path = default_conf["ChildTblConfigPath"]
buz_keys = ['MbrEnrlCustNbr','MbrEnrlGrpNbr','MbrProvEffDt','MbrPid','MbrSubPid']

# COMMAND ----------

# DBTITLE 1,Main function used to ingest files to stage tables
#  main_function is used from the ingest notebook to execute the load of files into stage Delta tables

def stageCreation(file_conf_key, LOAD_TYPE, stage_tbl_name, tabSchema, buz_keys):
    try:
        conf = {**file_config["DEFAULT"], **file_config[file_conf_key]}
        main_function(conf, LOAD_TYPE, stage_tbl_name, tabSchema, buz_keys)
    except Exception as e:
        raise Exception("cot_count_update: ",str(e))

# COMMAND ----------

# DBTITLE 1,Call ingest main function to load TRE2321 in stage
def LoadTre2321(LOAD_TYPE):
    try:
        file_conf_key = 'MEMBER_TRE2321'
        stage_tbl_name2321 = table_name_selector(tbl_conf_df, file_conf_key)
        tabSchema = tre2321_schema
        stageCreation(file_conf_key, LOAD_TYPE, stage_tbl_name2321, tabSchema, buz_keys)
        return stage_tbl_name2321
    
    except Exception as e:
        raise Exception("LoadTre2321: ", str(e))


# COMMAND ----------

# DBTITLE 1,Call ingest main function to load TRE2320 in stage
def LoadTre2320(LOAD_TYPE):
    try:
        file_conf_key = 'MEMBER_TRE2320'
        stage_tbl_name2320 = table_name_selector(tbl_conf_df, file_conf_key)
        tabSchema = tre2320_schema
        stageCreation(file_conf_key, LOAD_TYPE, stage_tbl_name2320, tabSchema, buz_keys)
        return stage_tbl_name2320
    
    except Exception as e:
        raise Exception("LoadTre2320: ",str(e))

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table & destination table names
# function to get the curated table names and create dataframes out of it

def CurTblDf():
    try:
        # memberCoverage Table
        curMemCov = table_name_selector(tbl_conf_df, table_code)
        CIMem = table_name_selector(tbl_conf_df, 'Member_CIMember')
        CustTbl = table_name_selector(tbl_conf_df, 'Member_Customer')
        StageMemTbl = table_name_selector(tbl_conf_df, 'Member_StageMember')
        curProvContctTbl = table_name_selector(tbl_conf_df, 'ProviderContract_ProviderContract')
        curProdctTbl = table_name_selector(tbl_conf_df, 'Product_Product')

        # SQL Member table and its dataframe        
        dfMember = read_table_to_df(StageMemTbl).selectExpr('MemberKey','MemberId','MemberCustomerNumber','SubscriberId','SourceSystemCode')

        # SQL ProviderContract table and its dataframe
        dfProvContrct = read_table_to_df(curProvContctTbl)\
            .selectExpr('ProviderContractKey','providerid','providersuffixcode','providerservicetypecode','providersequencenumber')

        # SQL Product table and its dataframe
        dfProd = read_table_to_df(curProdctTbl).selectExpr('ProductKey','lineofbusinesscode','marketnumber','optnumber','plannumber','ExtProdSeqNo')

        dfCust = read_table_to_df(CustTbl)
        dfCiMem = read_table_to_df(CIMem)

        return curMemCov, dfCiMem, dfMember, dfProvContrct, dfProd, dfCust
    
    except Exception as e:
        raise Exception("CurSQLTblDf: ", str(e))


# COMMAND ----------

# DBTITLE 1,Read tables to dataframe and derive the ETL columns
# add the derived ETL columns as per mapping sheet
def AddDerivedColumns(stage_tbl_name2320,stage_tbl_name2321):
    try:
        df2320 = read_table_to_df(stage_tbl_name2320).filter("Status=='S' and trim(MbrPid) !='' ")\
            .select("*",
                    lit("PCP").alias("CovTyCd"), 
                    lit("Primary Care Physician").alias("CovTyCdLabl"),
                    lit(None).alias("CovEndReasonCdLvl"), 
                    lit(0).alias("VendorSeqNbr"))
        
        df2321 = read_table_to_df(stage_tbl_name2321).filter("Status == 'S' and trim(MbrPid) !='' ")\
            .select("*",
                    lit("VCP").alias("CovTyCd"),
                    lit("Vendor Primary Care Physician").alias("CovTyCdLabl"),
                    lit(None).alias("CovEndReasonCdLvl"))

        audit_col_mapping_tre2320 = {
                        "CreatedBy":lit(f'{PIPELINE_NAME}'),
                        "CreatedDateTime":col("Re2320MbrprvTs"),
                        "ModifiedBy": when(
                                            ((substring(col("RecUpdtId"),1,2))=="OF") & 
                                            ((col("ProdLobCd")=="MEP")|(col("ProdLobCd")=="MEF")),
                                            concat(lit(PIPELINE_NAME),lit("#mbr_attr_of"))
                                            )
                                    .otherwise(f'{PIPELINE_NAME}'),
                        "ModifiedDateTime":col("Re2320MbrprvTs")
                        }
        
        audit_col_mapping_tre2321 = {
                        "CreatedBy":lit(f'{PIPELINE_NAME}'),
                        "CreatedDateTime":col("Re2321MbrprvTs"),
                        "ModifiedBy": when(
                                            ((substring(col("RecUpdtId"),1,2))=="OF") & 
                                            ((col("ProdLobCd")=="MEP")|(col("ProdLobCd")=="MEF")),
                                            concat(lit(PIPELINE_NAME),lit("#mbr_attr_of"))
                                            )
                                    .otherwise(f'{PIPELINE_NAME}'),
                        "ModifiedDateTime":col("Re2321MbrprvTs")
                        }
        
        audit_col_added_2320_df = df2320.withColumns(audit_col_mapping_tre2320)
        audit_col_added_2321_df = df2321.withColumns(audit_col_mapping_tre2321)

        return audit_col_added_2320_df, audit_col_added_2321_df

    except Exception as e:
        raise Exception("AddDerivedColumns: ", str(e))

# COMMAND ----------

# DBTITLE 1,Derive the Member Relation and CI columns
def deriveCustData(df2320,df2321, dfCust, dfCIMem, stg_tbl_2320, stg_tbl_2321):
    try:
        df2320_column_renamed_df  = df2320\
                                        .withColumnRenamed("MbrEnrlCustNbr","GHGroupIdentifier")\
                                        .withColumnRenamed("MbrEnrlGrpNbr","EmployerGroupNumber")

        df2321_column_renamed_df  = df2321\
                                        .withColumnRenamed("MbrEnrlCustNbr","GHGroupIdentifier")\
                                        .withColumnRenamed("MbrEnrlGrpNbr","EmployerGroupNumber")

        df20_gh_ci_convereted_df = gh_ci_conversion(df2320_column_renamed_df, dfCust, dfCIMem)
        df21_gh_ci_convereted_df = gh_ci_conversion(df2321_column_renamed_df, dfCust, dfCIMem)

        df20_conver_valid_df = df20_gh_ci_convereted_df.filter(col("CIGroupIdentifier").isNotNull())
        df21_conver_valid_df = df21_gh_ci_convereted_df.filter(col("CIGroupIdentifier").isNotNull())

        df20_conver_null_df = df20_gh_ci_convereted_df.filter(col("CIGroupIdentifier").isNull())
        df21_conver_null_df = df21_gh_ci_convereted_df.filter(col("CIGroupIdentifier").isNull())

        update_rej_records(df20_conver_null_df, "CIConversionFailed", stg_tbl_2320)
        update_rej_records(df21_conver_null_df, "CIConversionFailed", stg_tbl_2321)     

        return df20_conver_valid_df, df21_conver_valid_df
    
    except Exception as e:
        raise Exception("selectReqColumns: ", str(e))

# COMMAND ----------

# DBTITLE 1,Create the records as per MemberCoverage for each 2320/2321
# Join Stage tables with Membr on PID Column
# Join Stage tables with Product on Market, LobCode, Option and PLan columns
# Join Stage tables with ProviderContract on ProviderIdNbr, ProvSuffCd, LobCode, provSeqNumber 
# join changed to inn for faster run, although left join is the prefered join

def JoinProdMemProvCt(df2320Mem,df2321Mem, dfMember, dfProvContrct, dfProd):
    try:
        df2320Full = df2320Mem.alias('LH1')\
            .join(dfProvContrct.alias('PC1'), (lpad(col('LH1.ProvIdNbr'),9,'0')==col('PC1.ProviderId')) &(col('LH1.ProvSuffcd')==col('PC1.ProviderSuffixCode')) &(col('LH1.PcaServTyCd')==col('PC1.ProviderServiceTypeCode')) & (col('LH1.PcaSeqNbr')==col('PC1.ProviderSequenceNumber')), "left" )\
            .join(dfProd.alias('PRD1'), (col('LH1.ProdLobCd')==col('PRD1.LineOfBusinessCode')) & (col('LH1.ProdMktNbr')==col('PRD1.MarketNumber')) & (col('LH1.ProdOptNbr')==col('PRD1.OptNumber')) & (col('LH1.ProdPlanNbr')==col('PRD1.PlanNumber')) , "left")\
            .join(dfMember.alias('MEM1'), (col('LH1.MbrPid')==col('MEM1.MemberId')) & (trim(col('LH1.CIGroupIdentifier')) == trim(col('MEM1.MemberCustomerNumber'))) & (col('LH1.MbrSubPid') == col('MEM1.SubscriberId')) , "left")\
            .select('LH1.*','PC1.ProviderContractKey','PRD1.ProductKey','MEM1.MemberKey','MEM1.SourceSystemCode','PRD1.ExtProdSeqNo')
        
        df2321Full = df2321Mem.alias('LH2')\
            .join(dfProvContrct.alias('PC2'), (lpad(col('LH2.ProvIdNbr'),9,'0')==col('PC2.ProviderId')) &(col('LH2.ProvSuffcd')==col('PC2.ProviderSuffixCode')) &(col('LH2.PcaServTyCd')==col('PC2.ProviderServiceTypeCode')) & (col('LH2.PcaSeqNbr')==col('PC2.ProviderSequenceNumber')), "left" )\
            .join(dfProd.alias('PRD2'), (col('LH2.ProdLobCd')==col('PRD2.LineOfBusinessCode')) & (col('LH2.ProdMktNbr')==col('PRD2.MarketNumber')) & (col('LH2.ProdOptNbr')==col('PRD2.OptNumber')) & (col('LH2.ProdPlanNbr')==col('PRD2.PlanNumber')) , "left")\
            .join(dfMember.alias('MEM2'), (col('LH2.MbrPid')==col('MEM2.MemberId')) & (trim(col('LH2.CIGroupIdentifier')) == trim(col('MEM2.MemberCustomerNumber'))) & (col('LH2.MbrSubPid') == col('MEM2.SubscriberId')) , "left")\
            .select('LH2.*','PC2.ProviderContractKey','PRD2.ProductKey','MEM2.MemberKey','MEM2.SourceSystemCode','PRD2.ExtProdSeqNo')

        return df2320Full, df2321Full
    
    except Exception as e:
        raise Exception("JoinProdMemProvCt: ", str(e))


# COMMAND ----------

# DBTITLE 1,Mapping of the source columns with MemberCoverage
# Column Mapping from dataFrame to SQL table structure

colMp_2320 = {
    'CovTyCd':'CoverageTypeCode',
    'MbrProvEffDt':'CoverageStartDate',
    'MbrProvEndDt':'CoverageEndDate',
    'PcpEndReasCd':'CoverageEndReasonCode',
    'VendorSeqNbr':'VendorSequenceNumber',
    'GkProvIdNbr':'GateKeeperProviderId',
    'GkProvSuffCd':'GateKeeperProviderSuffixCode',
    'GkProvTyCd':'GateKeeperProviderTypeCode',
    'WorkcmpOccurPId':'WokerCompensationOccurenceId',
    'CreatedDateTime':'CreatedDateTime',
    'ModifiedDateTime':'ModifiedDateTime',
    'ProvIdNbr':'ProviderId',
    'ProvSuffcd':'ProviderSuffixCode',
    'PcaServTyCd':'ProviderServiceTypeCode',
    'PcaSeqNbr':'ProviderSequenceNumber',
    'ProdLobCd':'LineOfBusinessCode',
    'ProdMktNbr':'MarketNumber',
    'ProdOptNbr':'OptNumber',
    'ProdPlanNbr':'PlanNumber',
    'MbrPid':'MemberId',
    'MbrSubPid':'SubscriberId',
    'CIGroupIdentifier':'MemberCustomerNumber',
    'BenefitSequence':'MemberGroupNumber',
    'CIClassNumber':'CIClassNumber',
    'CovTyCdLabl':'CoverageTypeCodeLabel',
    'CovEndReasonCdLvl':'CoverageEndReasonCodeLabel',
    'CreatedBy':'CreatedBy',
    'ModifiedBy':'ModifiedBy',
    'ProviderContractKey':'ProviderContractKey',
    'ProductKey':'ProductKey',
    'MemberKey':'MemberKey',
    'SourceSystemCode':'SourceSystemCode',
    'ExtProdSeqNo':'ExtProdSeqNo',
    'YYYY':'YYYY',
    'StgUnqId':'StgUnqId',
    "RunId":"RunId",
    "DerivedIndicator":"DerivedIndicator",
    "Status":"Status",
    "RejectReason":"RejectReason"
}

colMp_2321 = {
    'CovTyCd':'CoverageTypeCode',
    'MbrProvEffDt':'CoverageStartDate',
    'MbrProvEndDt':'CoverageEndDate',
    'PcpEndReasCd':'CoverageEndReasonCode',
    'VendorSeqNbr':'VendorSequenceNumber',
    'GkProvIdNbr':'GateKeeperProviderId',
    'GkProvSuffCd':'GateKeeperProviderSuffixCode',
    'GkProvTyCd':'GateKeeperProviderTypeCode',
    'WorkcmpOccurPId':'WokerCompensationOccurenceId',
    'CreatedDateTime':'CreatedDateTime',
    'ModifiedDateTime':'ModifiedDateTime',
    'ProvIdNbr':'ProviderId',
    'ProvSuffcd':'ProviderSuffixCode',
    'PcaServTyCd':'ProviderServiceTypeCode',
    'PcaSeqNbr':'ProviderSequenceNumber',
    'ProdLobCd':'LineOfBusinessCode',
    'ProdMktNbr':'MarketNumber',
    'ProdOptNbr':'OptNumber',
    'ProdPlanNbr':'PlanNumber',
    'MbrPid':'MemberId',
    'MbrSubPid':'SubscriberId',
    'CIGroupIdentifier':'MemberCustomerNumber',
    'BenefitSequence':'MemberGroupNumber',
    'CIClassNumber':'CIClassNumber',
    'CovTyCdLabl':'CoverageTypeCodeLabel',
    'CovEndReasonCdLvl':'CoverageEndReasonCodeLabel',
    'CreatedBy':'CreatedBy',
    'ModifiedBy':'ModifiedBy',
    'ProviderContractKey':'ProviderContractKey',
    'ProductKey':'ProductKey',
    'MemberKey':'MemberKey',
    'SourceSystemCode':'SourceSystemCode',
    'ExtProdSeqNo':'ExtProdSeqNo',
    'YYYY':'YYYY',
    'StgUnqId':'StgUnqId',
    "RunId":"RunId",
    "DerivedIndicator":"DerivedIndicator",
    "Status":"Status",
    "RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Datatype conversion dictionary
schema = {
    'ProviderId':'STRING',
    'ProviderSequenceNumber':'STRING',
    'WokerCompensationOccurenceId':'DECIMAL(20,6)'
}

# COMMAND ----------

# DBTITLE 1,Data type conversion
#data type converstion and adding audit columns
def dtypeConvrt(input_df, schema):
    try:
        dtypeConverted_df = dtype_tgt_conversion(input_df, schema)\
            .withColumn('ProviderId', lpad(col('ProviderId'), 9, '0'))
        return dtypeConverted_df  
    except Exception as e:
        raise Exception('data type conversion or adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Load data to SQL
# As the data is being loaded using partition strategy hence created a separate function for this
def loadCurSQL(LOAD_TYPE,input_df, curMemCov):
    try:
        if LOAD_TYPE == 'FullLoad':
            # Load dfFinal to curated layer
            TABLE_NAMES = curMemCov.split('.')[-1]
            dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":TABLE_NAMES})
            write_to_curated(input_df, curMemCov, partition='YYYY')

            cur_loaded_time = datetime.now()

            # pull the curated records in a dataframe to be pushed to SQL table
            MemCov = read_table_to_df(curMemCov).drop('DerivedIndicator','ProviderId','ProviderSuffixCode','ProviderServiceTypeCode','ProviderSequenceNumber','LineOfBusinessCode','MarketNumber','OptNumber', 'PlanNumber','MemberId','SubscriberId','SourceSystemCode')

            #  create a list of distinct values of the YYYYmm values, which is the partition column. Loop that list and lood data for each partition. This is done because the data is large to load in one go.
            lst = spark.sql(f'SHOW PARTITIONS {curMemCov}').rdd.map(lambda x : x.YYYY).collect()
            for i in lst:
                MemCov1 = MemCov.filter(MemCov.YYYY == i ).drop('YYYY')
                load_df_to_sf_sql_db_spark(MemCov1, 'Member.MemberCoverage')

        elif LOAD_TYPE == 'DeltaLoad':
            conditions = ['MemberGroupNumber','CIClassNumber', 'MemberKey','CoverageStartDate','CoverageTypeCode']
            delta_operate(curMemCov,input_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "MemberCoverageKey")
            cur_loaded_time = datetime.now()

            mapping = {
            'ProcessName' : lit(None).cast('STRING'),
            'ProductKey':lit(None).cast("BIGINT"),
            'DeltaStatus':lit(None).cast('STRING'),
            'MemberCoverageKey':lit(None).cast("BIGINT"),
            'MemberKey':lit(None).cast("BIGINT"),
            'ProviderContractKey':lit(None).cast("BIGINT"),
            'CoverageTypeCodeLabel':col('CoverageTypeCodeLabel').cast('STRING'),
            'CoverageEndReasonCodeLabel':col('CoverageEndReasonCodeLabel').cast('STRING')
            }

            mapped_df= input_df.withColumns(mapping).drop('YYYY')
            not_null_set_df = set_df_columns_not_nullable(spark,mapped_df,['CoverageStartDate','CreatedBy','CreatedDateTime','SourceSystemCode'])
            nullable_set_df = set_df_columns_nullable(spark,not_null_set_df , ['CoverageTypeCode','CoverageTypeCodeLabel','ModifiedBy','ModifiedDateTime'])
            delta_df = nullable_set_df.filter(col('DerivedIndicator')!='IGNORE')
            
            load_df_to_sf_sql_db_spark(delta_df, 'Member.StageMemberCoverage')
    
        return cur_loaded_time

    except Exception as e:
        raise Exception("loadCurSQL: ", str(e))


# COMMAND ----------

# DBTITLE 1,Final try & except block to call all functions sequentially
try:
    notebook_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

    # load tre2320 and tre2321 stage tables
    stage_tbl_name2320 = LoadTre2320(LOAD_TYPE)
    stage_tbl_name2321 = LoadTre2321(LOAD_TYPE)
    
    # get the curated table and its respective sql data
    curMemCov, dfCIMem, dfMember, dfProvContrct, dfProd, dfCust = CurTblDf()

    # add few derived columns as per mapping sheet
    df2320, df2321 = AddDerivedColumns(stage_tbl_name2320,stage_tbl_name2321)

    if dfMember.rdd.isEmpty() or dfProvContrct.rdd.isEmpty() or dfProd.rdd.isEmpty():
        dbutils.notebook.exit('Member, ProviderContract or product any one of them is empty')
    else:
        # derive the Customer data after joining the Customer curated table
        df2320Mem,df2321Mem = deriveCustData(df2320,df2321, dfCust, dfCIMem, stage_tbl_name2320, stage_tbl_name2321)

        # join the stage tables with Member, Product and ProviderContract
        df2320Full, df2321Full = JoinProdMemProvCt(df2320Mem,df2321Mem, dfMember, dfProvContrct, dfProd)

        # Map the selected columns with SQL column Names
        mappedDf2320 = col_name_mapping(df2320Full,colMp_2320)
        mappedDf2321 = col_name_mapping(df2321Full,colMp_2321)

        # Removing invalid records
        validDf2320 = remove_invalid_records(mappedDf2320, stage_tbl_name2320, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')
        validDf2321 = remove_invalid_records(mappedDf2321, stage_tbl_name2321, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')

        # Merge the file 2320 and 2321 dataframes for final MemberCoverage data
        dfValidated = validDf2320.union(validDf2321)

        # Data type conversion
        dfConverted = dtypeConvrt(dfValidated, schema)
        
        cur_loaded_time = loadCurSQL(LOAD_TYPE, dfConverted, curMemCov)
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

except Exception as e:
    raise Exception(notebook_name,": ",str(e))

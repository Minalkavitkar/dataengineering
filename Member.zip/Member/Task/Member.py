# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - CI_Member, TRE2319
# MAGIC ##### Curated Tables
# MAGIC - Member.Member
# MAGIC ##### Target Table
# MAGIC - Member.Member
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = 'MEMBER_TRE2319'
buz_keys = ['MbrEnrlCustNbr','MbrPid','MbrSubPid']
table_code = 'Member_Member'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_Member') 
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Member', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    stage_tre2319_full_tbl_name = table_name_selector(tbl_conf_df, "MEMBER_TRE2319_FULL")
    ci_mbr_tbl = table_name_selector(tbl_conf_df, 'Member_CIMember')
    cur_tbl_name = table_name_selector(tbl_conf_df, table_code)
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load TRE2319 to stage
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, tre2319_schema, buz_keys, stage_full="StageFull")
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table 
try:
    cimbr_cur_df = read_table_to_df(ci_mbr_tbl)
    tre2319_stage_df = read_table_to_df(stage_tbl_name).filter(col('Status') == 'S')
    tre2319_stage_full_df = read_table_to_df(stage_tre2319_full_tbl_name)
except Exception as e:
    raise Exception("validation failed",str(e)) 

# COMMAND ----------

try:
    joining_condition_tre2319 = (col('LH.MbrPid') == col('RH.MbrPid')) &\
                        (col('LH.MbrGhGroup') == col('RH.MbrEnrlCustNbr')) &\
                        (col('LH.MbrSubPid') == col('RH.MbrSubPid'))

    cimember_tre2319_df = cimbr_cur_df.alias('LH')\
                                .join(tre2319_stage_df.alias('RH'),joining_condition_tre2319,'inner')\
                                .select('LH.MbrPid','LH.MbrSubPid','LH.CiGrpId','LH.platformcd','LH.MbrUmidEffDate','LH.MbrUmid', 'RH.ClmFundExcpInd', 'RH.UpdtDt','RH.DerivedIndicator')

except Exception as e:
    raise Exception("joining cimember and tre2319 failed : ",str(e))


# COMMAND ----------

# DBTITLE 1,narrow down into unique members
try:
    window_spec = Window.partitionBy("MbrPid", "CiGrpId",'MbrSubPid').orderBy(desc('MbrUmidEffDate'), desc('MbrUmid'), desc("UpdtDt"))
    rn_clac_df = cimember_tre2319_df.withColumn('RN', row_number().over(window_spec))
    valid_df = rn_clac_df.filter(col('RN') == 1).drop('RN')

    selected_df = valid_df.select("MbrPid", "MbrSubPid",'CiGrpId',"ClmFundExcpInd","platformcd","DerivedIndicator")
except Exception as e:
    raise Exception("validation failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,converting derviedIndicator
column_mapping = {
    "ClmFundExcpInd" : "ClaimFundExceptionIndicator"
    ,"MbrPid" : "MemberId"
    ,"MbrSubPid" : "SubscriberId"
    ,"CiGrpId" : "MemberCustomerNumber"
    ,"platformcd":"SourceSystemCode"
    ,"DerivedIndicator":"DerivedIndicator"
}

try:    
    col_mapped_df = col_name_mapping(selected_df, column_mapping)

    source_system_code_added_df = col_mapped_df.withColumn('SourceSystemCode',
                                            when((col('SourceSystemCode')=='HP') | (col('SourceSystemCode')=='LV') | (col('SourceSystemCode')=='Y'),lit('CI'))\
                                            .when((col('SourceSystemCode')=='EM'),lit('MTV')).otherwise(lit('CI')))
    
    audit_col_added_df =source_system_code_added_df.selectExpr(
                            "*", 
                            "current_timestamp() as CreatedDateTime",
                            f"'{PIPELINE_NAME}' as CreatedBy",
                            "current_timestamp() as ModifiedDateTime",
                            f"'{PIPELINE_NAME}' as ModifiedBy"
                            )
except Exception as e:
    raise Exception("column mapping failed or audit col addition : ",str(e))


# COMMAND ----------

# DBTITLE 1,change derived indicator
try:
    nullify_delete_rec_df = audit_col_added_df.withColumn('ClaimFundExceptionIndicator',
                                                        when((col('DerivedIndicator')=='DELETE'),lit(None))
                                                        .otherwise(col('ClaimFundExceptionIndicator'))).filter(col("DerivedIndicator")!="IGNORE")
    
    delta_df = nullify_delete_rec_df.withColumn('DerivedIndicator',lit("UPDATE"))

except Exception as e:
    raise Exception("change of derived indicator : ",str(e))

# COMMAND ----------

# DBTITLE 1,update curated layer
try:
    conditions = [ 'MemberId', 'SubscriberId', 'MemberCustomerNumber', 'SourceSystemCode']

    ins_upd_cond_lst = []
    for colm in conditions:
        ins_upd_cond_lst.append('curated.'+colm+'='+'stage.'+colm)
    ins_upd_cond_str = ' and '.join(ins_upd_cond_lst)

    updt_dict = {"ClaimFundExceptionIndicator":"Stage.ClaimFundExceptionIndicator"}

    deltaTableCurated= DeltaTable.forName(spark,cur_tbl_name)
    deltaTableCurated.alias('Curated')\
        .merge(delta_df.alias('Stage'),ins_upd_cond_str)\
                    .whenMatchedUpdate(set = updt_dict)\
                    .execute()

    cur_loaded_time = datetime.now()
except Exception as e:
    excep = 'loading into stage failed : ' + str(e)
    raise Exception(excep)

# COMMAND ----------

# DBTITLE 1,update sql table
try:
    mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'MemberKey':lit(None).cast("BIGINT"),
        'MemberFirstName':lit(None).cast('STRING'),
        'MemberLastName':lit(None).cast('STRING'),
        'MemberMiddleName':lit(None).cast('STRING'),
        'MemberSexCode':lit(None).cast('STRING'),
        'MemberBirthDate':lit(None).cast('DATE'),
        'HumanaIdentifier':lit(None).cast('STRING')
        }
    
    mapped_df= delta_df.withColumns(mapping)
    not_null_set_df = set_df_columns_not_nullable(spark, set_df_columns_nullable(spark,mapped_df,['DerivedIndicator','ModifiedBy','ModifiedDateTime']),['SourceSystemCode','MemberCustomerNumber','CreatedBy','CreatedDateTime'])

    load_df_to_sf_sql_db_spark(not_null_set_df, "Member.StageMember")
except Exception as e:
    raise Exception("Table configuration failed: ",Message)

# COMMAND ----------

# DBTITLE 1,exit successful run
# successful exit of member notebook
exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
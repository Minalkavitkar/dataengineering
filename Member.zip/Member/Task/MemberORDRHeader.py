# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files 
# MAGIC - TREORDR
# MAGIC ##### Curated Tables
# MAGIC - Member.MemberORDRHeader
# MAGIC ##### Target Table
# MAGIC - Member.MemberORDRHeader
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "MEMBER_TREORDR"
buz_keys = ['ReordrGenKey']
not_null_col_lst = ['ORDRCustomerNumber','ORDRGroupNumber','ORDRClassNumber']
uniq_keys = ['ORDRCustomerNumber', 'ORDRGroupNumber','ORDRClassNumber', 'MemberId','SubscriberId', 'SourceSystemCode']
table_code = 'Member_MemberORDRHeader'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('PIPELINE_NAME','Nb_MemberORDRHeader') 
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')
  
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME') 
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM') 

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Member', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run ./MemberStageSchema

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Running ingestion functions
# MAGIC %run ../../Utility/Ingest

# COMMAND ----------

# DBTITLE 1,Running transformation functions 
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Running loading functions
# MAGIC %run ../../Utility/Load

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
#getting keys, stage table names & destination table names
try:
    conf = {**file_config["DEFAULT"],**file_config[file_conf_key]}
    child_tbl_config_path = conf["ChildTblConfigPath"]
    tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
    stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)
    cust_tbl = table_name_selector(tbl_conf_df,'Member_Customer')
    cur_tbl_name = table_name_selector(tbl_conf_df,table_code)
    cimember_tbl_name = table_name_selector(tbl_conf_df, 'Member_CIMember')
except Exception as e:
    raise Exception("table configuration failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Reading data from stage table
#loading stage table
try:
    main_function(conf, LOAD_TYPE, stage_tbl_name, treordr_schema, buz_keys, stage_full="StageFull")
except Exception as e:
    raise Exception("Stage load failed: ",str(e))

# COMMAND ----------

# DBTITLE 1,Load tables into data frames
#Reading data from stage table & filtering the valid records
try:
    memberordr_stage_df = read_table_to_df(stage_tbl_name)\
                    .filter(col('Status') == 'S')
    mem_df = read_table_to_df(cimember_tbl_name )
    cust_df = read_table_to_df(cust_tbl)
except Exception as e:
    raise Exception("validation failed",str(e))   

# COMMAND ----------

# DBTITLE 1,GH to CI conversion
try:
    column_renamed_df  = memberordr_stage_df\
                        .withColumnRenamed("ReordrCustId","GHGroupIdentifier")\
                        .withColumnRenamed("ReordrGrpNbr","EmployerGroupNumber")


    gh_ci_convereted_df = gh_ci_conversion(column_renamed_df, cust_df, mem_df)
except Exception as e:
        raise Exception("gh_ci_conversion failed: ", str(e))


# COMMAND ----------

# DBTITLE 1,Column mapping between stage and curated tables
col_map= {
    "CIGroupIdentifier":"ORDRCustomerNumber", 
    "BenefitSequence":"ORDRGroupNumber",
    "CIClassNumber":"ORDRClassNumber",
    "ReordrSubPid":"SubscriberId",
    "ReordrPid":"MemberId",
    "DerivedIndicator":"DerivedIndicator",
    "StgUnqId":"StgUnqId",
    "RunId":"RunId",
    "Status":"Status",
    "RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Column mapping for literal columns
add_col = {
    'SourceSystemCode': lit('LV')
}

# COMMAND ----------

# DBTITLE 1,Perform column mapping, add audit columns, add literal columns
#adding audit columns
try:
    col_mapped_df = add_tgt_audit_column(col_name_mapping(gh_ci_convereted_df,col_map), PIPELINE_NAME,LOAD_TYPE)
    add_col_df = col_mapped_df.withColumns(add_col)
except Exception as e:
    raise Exception('adding columns failed',str(e))

# COMMAND ----------

# DBTITLE 1,Filtering valid records
try:
    result_df = remove_invalid_records(add_col_df, stage_tbl_name, not_null_col_lst)
    final_df = remove_dup_records(result_df,uniq_keys,stage_tbl_name).drop('RunId','Status','RejectReason','StgUnqId')
except Exception as e:
    raise Exception("Removing invalid records failed", str(e))

# COMMAND ----------

# DBTITLE 1,Load data into curated layer and SQL
#curated load & Azure SQL load
try:
    if LOAD_TYPE == 'FullLoad':
        TABLE_NAMES = cur_tbl_name.split('.')[-1]
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":TABLE_NAMES})

        write_to_curated(final_df,cur_tbl_name)
        cur_loaded_time = datetime.now()

        mbr_ordrhd_df = read_table_to_df(cur_tbl_name).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(mbr_ordrhd_df, 'Member.MemberORDRHeader')
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad':
        conditions = ['ORDRCustomerNumber', 'ORDRGroupNumber','ORDRClassNumber', 'MemberId','SubscriberId', 'SourceSystemCode']
        delta_operate(cur_tbl_name,final_df,conditions, table_code, tbl_conf_df, child_tbl_config_path, "MemberORDRHeaderKey")

        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'MemberORDRHeaderKey':lit(None).cast("BIGINT")
        }
        mapped_df= final_df.withColumns(mapping)

        not_nullable_df= set_df_columns_not_nullable(spark,mapped_df,['CreatedBy','CreatedDateTime'])
        delta_df = set_df_columns_not_nullable(spark,not_nullable_df,['SourceSystemCode'], True)

        df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(df, 'Member.StageMemberORDRHeader')
        
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)
except Exception as e:
    raise Exception ('load failed',str(e))
# Databricks notebook source
# MAGIC %md 
# MAGIC ##### Source Files/Tables
# MAGIC - TRE2401
# MAGIC - Curated Customer, BenefrOccurance
# MAGIC - Product curated data
# MAGIC ##### Curated Tables
# MAGIC - Member.Customer
# MAGIC ##### Target Table
# MAGIC - CustomerProduct
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Running validate functions
# MAGIC %run ../../Utility/Validate

# COMMAND ----------

# DBTITLE 1,Setting up local parameters
file_conf_key = "MEMBER_TRE2401"
buz_keys = ['MbrEnrlCustNbr','MbrEnrlGrpNbr','InsProdCatCd','ProdEffCymdDt']
not_null_col_lst = ['MemberCustomerNumber', 'MemberGroupNumber', 'CIClassNumber']
table_code = 'Member_CustomerProduct'

# COMMAND ----------

# DBTITLE 1,Setting up global parameters
dbutils.widgets.text('PIPELINE_NAME','Nb_CustomerProduct') 
dbutils.widgets.text('LOAD_TYPE','')
dbutils.widgets.text('RUN_ID','')
dbutils.widgets.text('SEQ_NUM','')

PIPELINE_NAME = dbutils.widgets.get('PIPELINE_NAME')
LOAD_TYPE = dbutils.widgets.get('LOAD_TYPE')
run_id = dbutils.widgets.get('RUN_ID')
seq_num = dbutils.widgets.get('SEQ_NUM')

# COMMAND ----------

# DBTITLE 1,Check the table run
try:
    nb_start_time = datetime.now()
    cur_loaded_time = None
    notebook_run_check('Member', table_code, seq_num, audit_table_name)
except Exception as e:
    Message = "checking for table run failed: " + str(e)
    exit_notebook(run_id,'Member', LOAD_TYPE,table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name,Message,'Failed')
    raise Exception(Message)

# COMMAND ----------

# DBTITLE 1,Running stage table schema
# MAGIC %run "./MemberStageSchema"

# COMMAND ----------

# DBTITLE 1,Establishing ADLS connection
# MAGIC %run "../../Utility/Helpers/AdlsHelper"

# COMMAND ----------

# DBTITLE 1,Running Ingestion Functions
# MAGIC %run "../../Utility/Ingest"

# COMMAND ----------

# DBTITLE 1,Running Transformation Functions
# MAGIC %run "../../Utility/Transform"

# COMMAND ----------

# DBTITLE 1,Running Load Functions
# MAGIC %run "../../Utility/Load"

# COMMAND ----------

# DBTITLE 1,Reading the config
conf = {**file_config["DEFAULT"], **file_config[file_conf_key]}
tbl_conf_df = get_table_config(conf["TableDetailsConfigPath"])
child_tbl_config_path = conf["ChildTblConfigPath"]

# COMMAND ----------

# DBTITLE 1,Getting keys, stage table names & destination table names
def getTables(file_conf_key):
    try:

        stage_tbl_name = table_name_selector(tbl_conf_df, file_conf_key)

        curCustProd = table_name_selector(tbl_conf_df, table_code)

        curProd = table_name_selector(tbl_conf_df, 'Product_Product')

        curCust = table_name_selector(tbl_conf_df,'Member_Customer')

        CIMem = table_name_selector(tbl_conf_df, 'Member_CIMember')

        return stage_tbl_name,curCustProd,curProd,curCust, CIMem 
    except Exception as e:
        raise Exception("getTables: ", str(e))


# COMMAND ----------

# DBTITLE 1,Load stage table
def stageCreation(file_conf_key,stage_tbl_name,buz_keys):
    try:
        main_function(conf, LOAD_TYPE, stage_tbl_name, tre2401_schema, buz_keys)
    except Exception as e:
        raise Exception("stageCreation: ",str(e))

# COMMAND ----------

# DBTITLE 1,Read tables into dataframes
# according to business requirements as per mapping sheet if ProdEffCymdDt == "0001-01-01" mark it as null

def createDf(stage_tbl_name,curProd, CIMem, curCust):
    try:
        df2401 = read_table_to_df(stage_tbl_name).filter("Status == 'S' ")
        df2401 = df2401.withColumn('ProdEffCymdDt1', when(df2401.ProdEffCymdDt == "0001-01-01", lit("1901-01-01").cast('date'))\
            .otherwise(df2401.ProdEffCymdDt))

        dfProd = read_table_to_df(curProd).selectExpr('ProductKey','MarketNumber','OptNumber','PlanNumber','LineOfBusinessCode','ExtProdSeqNo')

        dfCiMem = read_table_to_df(CIMem)

        dfCust = read_table_to_df(curCust)

        return df2401, dfProd, dfCiMem, dfCust
    except Exception as e:
        raise Exception("createDf: ", str(e))

# COMMAND ----------

# DBTITLE 1,Retrieve the CI details from customer
def joinCustTRE2401(df2401, dfProd, dfCust, dfCIMem):
    try:
        df2401_column_renamed_df = df2401\
                                    .withColumnRenamed("MbrEnrlCustNbr","GHGroupIdentifier")\
                                    .withColumnRenamed("MbrEnrlGrpNbr","EmployerGroupNumber")
        df2401Cust = gh_ci_conversion(df2401_column_renamed_df, dfCust, dfCIMem)

        col_map = { "SourceSystemCode": lit('LV')}
        source_code_added_df = df2401Cust.withColumns(col_map)
        
        dfFinal = source_code_added_df.alias('LH').join(dfProd.alias('RH'), 
                                              (col('LH.ProdMktNbr') == col('RH.MarketNumber')) 
                                              & (col('LH.ProdOptNbr') == col('RH.OptNumber')) 
                                              & (col('LH.ProdPlanNbr') == col('RH.PlanNumber')) 
                                              & (col('LH.ProdLobCd') == col('RH.LineOfBusinessCode')), "left")\
                                        .selectExpr('LH.*', 'RH.ExtProdSeqNo')
        

        return dfFinal
    except Exception as e:
        raise Exception("joinCustTRE2401: ", str(e))


# COMMAND ----------

# DBTITLE 1,Mapping of the source columns with CustomerProduct
col_mapping = {
    'ExtProdSeqNo':'ExtProdSeqNo',
    'SourceSystemCode':'SourceSystemCode',
    'CIGroupIdentifier':'MemberCustomerNumber',
    'BenefitSequence':'MemberGroupNumber',
    'CIClassNumber':'CIClassNumber',
    'InsProdCatCd':'ProductCategoryCode',
    'ProdLobCd':'LineOfBusinessCode',
    'ProdPlanNbr':'PlanNumber',
    'ProdOptNbr':'OptNumber',
    'ProdMktNbr':'MarketNumber',
    'ProdEffCymdDt1':'CustomerProductStartDate',
    'ProdEndCymdDt':'CustomerProductEndDate',
    'StgUnqId':'StgUnqId',
    "RunId":"RunId",
    "DerivedIndicator":"DerivedIndicator",
    "Status":"Status",
    "RejectReason":"RejectReason"
}

# COMMAND ----------

# DBTITLE 1,Final try & except block to call all functions sequentially
try:
    notebook_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

    #  get Tables Names
    stage_tbl_name, curCustProd, curProd, curCust, CIMem = getTables(file_conf_key)
    
    # Stage load of the files

    stageCreation(file_conf_key,stage_tbl_name,buz_keys)

    #  create the dataframes for the respective tables
    df2401, dfProd, dfCiMem, dfCust = createDf(stage_tbl_name, curProd, CIMem, curCust)
        
    # join 2401 and customer data
    joined_df = joinCustTRE2401(df2401, dfProd, dfCust, dfCiMem)

    # Rename the columns as per domain tables and add audit columns
    dfFinal = add_tgt_audit_column(col_name_mapping(joined_df,col_mapping),PIPELINE_NAME,LOAD_TYPE)

    # Removing invalid records
    validDf = remove_invalid_records(dfFinal , stage_tbl_name, not_null_col_lst).drop('RunId','Status','RejectReason','StgUnqId')

    if LOAD_TYPE == 'FullLoad':
        # Load final dataframe to curated environment
        TABLE_NAMES = curCustProd.split('.')[-1]
        dbutils.notebook.run('./MemberDDL',0,{"TABLE_NAMES":TABLE_NAMES})
        write_to_curated(validDf,curCustProd)

        cur_loaded_time = datetime.now()
        
        # Load curated data to SQL environment
        df_CustProd_sql = read_table_to_df(curCustProd).drop('DerivedIndicator')
        load_df_to_sf_sql_db_spark(df_CustProd_sql,'Member.CustomerProduct')

        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)

    elif LOAD_TYPE == 'DeltaLoad': 
        conditions = ['MemberCustomerNumber', 'MemberGroupNumber', 'CIClassNumber', 'ProductCategoryCode', 'CustomerProductEndDate']
        delta_operate(curCustProd,validDf,conditions, table_code, tbl_conf_df, child_tbl_config_path, "CustomerProductKey")
        cur_loaded_time = datetime.now()

        mapping = {
        'ProcessName' : lit(None).cast('STRING'),
        'DeltaStatus' : lit(None).cast('STRING'),
        'CustomerProductKey':lit(None).cast("BIGINT")
        }
        
        mapped_df= validDf.withColumns(mapping)

        delta_df= set_df_columns_not_nullable(spark,set_df_columns_nullable(spark,mapped_df,['SourceSystemCode']),['CreatedBy','CreatedDateTime'])   
        
        customer_product_df = delta_df.filter(col('DerivedIndicator')!='IGNORE')
        load_df_to_sf_sql_db_spark(customer_product_df, 'Member.StageCustomerProduct')
        
        exit_notebook(run_id, "Member", LOAD_TYPE, table_code, seq_num, nb_start_time, cur_loaded_time, audit_table_name)      
    
except Exception as e:
    raise Exception(notebook_name,": ", str(e))
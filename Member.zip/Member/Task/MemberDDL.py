# Databricks notebook source
# MAGIC %md 
# MAGIC ##### This Notebook creates Member Curater Layer Tables DDL
# MAGIC ###### Eviden Data Engineering Team

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')
TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES') 

# COMMAND ----------

# DBTITLE 1,Database Creation
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# DBTITLE 1,MemberCoverage
MemberCoverage = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.member_MemberCoverage(
    MemberCoverageKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 10 INCREMENT BY 1) NOT NULL,
    SourceSystemCode STRING NOT NULL, 
    MemberKey BIGINT NOT NULL,
    ProviderContractKey BIGINT NOT NULL,
    ProductKey BIGINT NOT NULL,
    ExtProdSeqNo INTEGER,
    CoverageTypeCode STRING,
    CoverageTypeCodeLabel STRING,
    CoverageStartDate DATE NOT NULL,
    CoverageEndDate DATE,
    CoverageEndReasonCode STRING,
    CoverageEndReasonCodeLabel STRING,
    VendorSequenceNumber INTEGER,
    GateKeeperProviderId STRING,
    GateKeeperProviderSuffixCode STRING,
    GateKeeperProviderTypeCode STRING,
    WokerCompensationOccurenceId DECIMAL (20,6),
    DerivedIndicator STRING,
    CreatedBy STRING NOT NULL,
    CreatedDateTime TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP,
    ProviderId STRING,
    ProviderSuffixCode STRING,
    ProviderServiceTypeCode STRING,
    ProviderSequenceNumber STRING,
    LineOfBusinessCode STRING,
    MarketNumber STRING,
    OptNumber STRING,
    PlanNumber STRING,
    MemberId STRING,
    SubscriberId STRING,
    MemberCustomerNumber STRING,
    MemberGroupNumber STRING,
    CIClassNumber STRING,
    YYYY STRING
)PARTITIONED BY(YYYY)"""


# COMMAND ----------

# DBTITLE 1,CustomerProduct
CustomerProduct = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.member_CustomerProduct(
    CreatedBy STRING NOT NULL,
    CreatedDateTime TIMESTAMP NOT NULL,
    ModifiedBy STRING,
    ModifiedDateTime TIMESTAMP,
    CustomerProductKey  BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) NOT NULL,
    ExtProdSeqNo INTEGER,
    SourceSystemCode STRING,
    MemberCustomerNumber STRING,
    MemberGroupNumber STRING,
    CIClassNumber STRING,
    ProductCategoryCode STRING,
    LineOfBusinessCode STRING,
    PlanNumber STRING,
    OptNumber STRING,
    MarketNumber STRING,
    CustomerProductStartDate DATE,
    CustomerProductEndDate DATE,
    DerivedIndicator STRING
)"""


# COMMAND ----------

# DBTITLE 1,MemberORDRHeader
MemberORDRHeader = f"""CREATE OR REPLACE TABLE  {catalog_name}.{schema_name}.member_MemberORDRHeader(
     MemberORDRHeaderKey BIGINT generated Always As IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL ,
     ORDRClassNumber STRING,
     ORDRCustomerNumber STRING , 
     ORDRGroupNumber STRING , 
     SubscriberId STRING,
     MemberId STRING , 
     SourceSystemCode STRING , 
     DerivedIndicator STRING,
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING , 
     ModifiedDateTime TIMESTAMP 
)"""

# COMMAND ----------

# DBTITLE 1,MemberORDRDetail
MemberORDRDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.member_MemberORDRDetail(
     MemberORDRDetailKey BIGINT GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1) NOT NULL, 
     MemberORDRHeaderKey BIGINT NOT NULL , 
     RiderCode STRING ,  
     RiderPlanNumber STRING , 
     RiderOptNumber STRING , 
     BrandCopayAmount DECIMAL (20,6) , 
     GenericCopayAmount DECIMAL (20,6) , 
     RiderStartDate DATE , 
     RiderEndDate DATE , 
     CreatedBy STRING NOT NULL, 
     CreatedDateTime TIMESTAMP NOT NULL, 
     ModifiedBy STRING , 
     ModifiedDateTime TIMESTAMP,
     DerivedIndicator STRING,
     ORDRClassNumber STRING,
     ORDRCustomerNumber STRING , 
     ORDRGroupNumber STRING , 
     SubscriberId STRING,
     MemberId STRING , 
     SourceSystemCode STRING 
)"""

# COMMAND ----------

# DBTITLE 1,MemberGRDRHeader
MemberGRDRHeader = f"""CREATE OR REPLACE TABLE  {catalog_name}.{schema_name}.member_MemberGRDRHeader(
  MemberGRDRHeaderKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
  ,GRDRClassNumber STRING
  ,GRDRCustomerNumber STRING
  ,GRDRGroupNumber STRING
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
)"""

# COMMAND ----------

# DBTITLE 1,MemberGRDRDetail
MemberGRDRDetail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.member_MemberGRDRDetail(
  MemberGRDRDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
  ,MemberGRDRHeaderKey BIGINT NOT NULL
  ,RiderCode STRING
  ,RiderPlanNumber STRING
  ,RiderOptNumber STRING
  ,BrandCopayAmount DECIMAL(20,6)
  ,GenericCopayAmount DECIMAL(20,6)
  ,RiderStartDate DATE
  ,RiderEndDate DATE
  ,CreatedBy STRING NOT NULL
  ,CreatedDateTime TIMESTAMP NOT NULL
  ,ModifiedBy STRING
  ,ModifiedDateTime TIMESTAMP
  ,DerivedIndicator STRING
  ,GRDRClassNumber STRING
  ,GRDRCustomerNumber STRING
  ,GRDRGroupNumber STRING
)"""

# COMMAND ----------

tbl_mapping = {
    "member_MemberGRDRDetail":MemberGRDRDetail,
    "member_MemberGRDRHeader":MemberGRDRHeader,
    "member_MemberORDRDetail":MemberORDRDetail,
    "member_MemberORDRHeader":MemberORDRHeader,
    "member_CustomerProduct":CustomerProduct,
    "member_MemberCoverage":MemberCoverage
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
# Databricks notebook source
# MAGIC %md 
# MAGIC ### This Notebook creates Capitation curater layer tables DDL

# COMMAND ----------

# DBTITLE 1,Setting up environment variables
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# DBTITLE 1,ADLS connectivity
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# DBTITLE 1,Establish Transform functions
# MAGIC %run ../../Utility/Transform

# COMMAND ----------

# DBTITLE 1,Setting up parameters
dbutils.widgets.text('TABLE_NAMES','')

TABLE_NAMES = dbutils.widgets.get('TABLE_NAMES')

# COMMAND ----------

# DBTITLE 1,Database Creation
# database_name = f"Capitation{databricks_database_suf}"
# spark.sql(f"""CREATE DATABASE IF NOT EXISTS hive_metastore.{database_name};""")
schema_name = databricks_schema_suf
catalog_name = databricks_catalog_name

# COMMAND ----------

# MAGIC %md ###### CapRate

# COMMAND ----------

cap_rate = f"""
CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.capitation_CapRate(
  CapRateKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  RateId VARCHAR(50),
  RateFullName VARCHAR(55),
  RatTypeCode VARCHAR(20),
  RateCutOffDate DATE,
  HMPNonHMPCode VARCHAR(20),
  CapRateTableId VARCHAR(50),
  ActionCode VARCHAR(10),
  DerivedIndicator STRING,
  CreatedBy VARCHAR(150) NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/capitation/curated/CapRate'"""

# COMMAND ----------

# MAGIC %md
# MAGIC CapRateSchedule

# COMMAND ----------

cap_rate_schedule = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.capitation_CapRateSchedule(
  CapRateScheduleKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  CapRateKey BIGINT NOT NULL,
  ProductPlanNumber VARCHAR(50),
  ProductOptNumber VARCHAR(50),
  CustomerLedgerNumber VARCHAR(50),
  PlanBenefitPackageCode VARCHAR(20),
  SegmentId VARCHAR(50),
  ProductIndicator CHAR(1),
  MCOContractNumber INTEGER,
  DerivedIndicator STRING,
  CreatedBy VARCHAR(150) NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP,
  RateId STRING
  
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/capitation/curated/CapRateSchedule'"""

# COMMAND ----------

# MAGIC %md
# MAGIC CapRateContractualPercent

# COMMAND ----------

cap_rate_contractual_percent = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.capitation_CapRateContractualPercent(
  CapRateContractualPercentKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  CapRateKey BIGINT NOT NULL,
  LineOfBusinessCode VARCHAR(20),
  ContractualPercentBeginDate DATE,
  ContractualPercentEndDate DATE,
  ContractualPercentBeginAge INT,
  ContractualPercentEndAge INT,
  ContractualPercentHCFACode VARCHAR(20),
  ContractualPercentPartARate DECIMAL(10, 5),
  ContractualPercentPartDRate DECIMAL(10, 5),
  RateFIPSCountyCode VARCHAR(20),
  ContractualPercentPartBRate DECIMAL(10, 5),
  RateStateCode VARCHAR(20),
  SNIPDescription VARCHAR(20),
  RateId VARCHAR(50),
  DerivedIndicator STRING,
  CreatedBy VARCHAR(150) NOT NULL,
  CreatedDateTime TIMESTAMP NOT NULL,
  ModifiedBy VARCHAR(150),
  ModifiedDateTime TIMESTAMP,
  GenKey INT
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/capitation/curated/CapRateContractualPercent'"""

# COMMAND ----------

# MAGIC %md
# MAGIC CapRateDetail

# COMMAND ----------

cap_rate_detail = f"""CREATE OR REPLACE TABLE {catalog_name}.{schema_name}.capitation_CapRateDetail(
CapRateDetailKey BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
CapRateScheduleKey BIGINT NOT NULL,
FundTypeCode STRING,
HCFAClassificationCode STRING,
RateBeginAgeNumber INT,
RateEndAgeNumber INT,
RateFemaleAdjustmentAmount DECIMAL(10,5),
RateFemaleFundAmount DECIMAL(10,5),
RateMaleAdjustmentAmount DECIMAL(10,5),
RateMaleFundAmount DECIMAL(10,5),
RateStateCode STRING,
RateRiderCode STRING,
BenefitRiderPlanCode STRING,
BenefitRiderOptCode STRING,
BenefitGenericCopayAmount DECIMAL(20,6),
BenefitBrandCopayAmount DECIMAL(20,6),
CountyCode STRING,
RateBeginDate DATE NOT NULL,
DollarVsPercentCode STRING,
RateEndDate DATE,
CapitationRateRuleNumber INT,
DerivedIndicator STRING,
CreatedBy VARCHAR(150) NOT NULL,
CreatedDateTime TIMESTAMP NOT NULL,
ModifiedBy VARCHAR(150),
ModifiedDateTime TIMESTAMP
)"""
# USING DELTA
# LOCATION 'abfss://datamovement@{env_storage_account_name}.dfs.core.windows.net/capitation/curated/CapRateDetail'"""

# COMMAND ----------

tbl_mapping = {
    "capitation_CapRate" : cap_rate
    ,"capitation_CapRateSchedule" : cap_rate_schedule
    ,"capitation_CapRateContractualPercent" : cap_rate_contractual_percent
    ,"capitation_CapRateDetail" : cap_rate_detail
}

# COMMAND ----------

TABLE_NAMES = TABLE_NAMES.split(',')
if len(TABLE_NAMES) == 0:
    raise Exception("Table name cannot be empty")
elif len(TABLE_NAMES) == 1 and 'All' in TABLE_NAMES:
    cur_table_creation(tbl_mapping, tbl_mapping.keys())
else:
    cur_table_creation(tbl_mapping, TABLE_NAMES)
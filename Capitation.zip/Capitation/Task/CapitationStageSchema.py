# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

file_config = {
    "DEFAULT":{
        "DatabaseName":"Stage",
        "StorageAccountName" : env_storage_account_name,
        "ContainerName" : "datamovement",
        "FilePathSuffix" : "capitation/raw/",
        "TableDetailsConfigPath" :env_table_details_config_path,
        "ChildTblConfigPath":"../../Config/TableChildDetails.json",
        "Config":{
            "header":"true",
            "delimiter":"|"
        },
        "SourceFileFormat" : "csv"
    },
    "CAPITATION_TRERTBL":{
        "FileRegex" : "CAPITATION_TRERTBL.TXT",
        "StagePathSuffix" : "capitation/stage/StageTRERTBL"
    },
    "CAPITATION_TRERTSC":{
        "FileRegex" : "CAPITATION_TRERTSC.TXT",
        "StagePathSuffix" : "capitation/stage/StageTRERTSC"
    },
    "CAPITATION_TRECTPC":{
        "FileRegex" : "CAPITATION_TRECTPC.TXT",
        "StagePathSuffix" : "capitation/stage/StageTRECTPC"
    },
    "CAPITATION_TRERATE":{
        "FileRegex" : "CAPITATION_TRERATE.TXT",
        "StagePathSuffix" : "capitation/stage/StageTRERATE"
    }
}

# COMMAND ----------

trertbl_schema = {
    "IND1":"STRING"
    ,"IND2":"STRING"
    ,"TIMESTAMP":"TIMESTAMP"
    ,"RT_TBL_ID" : "STRING"
    ,"RT_TBL_NM" : "STRING"
    ,"RT_UPDT_CYMD_DT" : "DATE"
    ,"HMP_VS_NON_HMP_IND" : "STRING"
    ,"CAP_BASE_TBL_ID" : "STRING"
    ,"ACT_CD" : "STRING"
    ,"RT_CUTOFF_CYM_DT" : "INT"
    ,"APPL_UPDT_IND" : "STRING"
    ,"TBL_TYPE_IND" : "STRING"
    ,"RE2390_RTETBL_TS" : "TIMESTAMP"
    ,"RE_RTETBL_IX_IND" : "STRING"
    ,"PLTFM_CD" : "STRING"
}

# COMMAND ----------

trertsc_schema ={
    "IND1":"STRING"
    ,"IND2":"STRING"
    ,"TIMESTAMP":"TIMESTAMP"
    ,"RT_TBL_ID" : "STRING"
    ,"CUST_LEDGR_NBR" : "STRING"
    ,"PROD_PLAN_NBR" : "STRING"
    ,"PROD_OPT_NBR" : "STRING"
    ,"RE_RTETBL_RTES_IND" : "STRING"
    ,"PLTFM_CD" : "STRING"
    ,"CONTR_NBR" : "STRING"
    ,"PBP_CD" : "STRING"
    ,"SEG_ID" : "STRING"
    ,"PROD_IND" : "STRING"
}

# COMMAND ----------

trectpc_schema ={
    "IND1":"STRING"
    ,"IND2":"STRING"
    ,"TIMESTAMP":"TIMESTAMP"
    ,"GEN_KEY" : "INT"
    ,"RT_TBL_ID" : "STRING"
    ,"CONTR_PCT_LOB_CD" : "STRING"
    ,"CONTR_PCT_BEG_DT" : "DATE"
    ,"CONTR_PCT_END_DT" : "DATE"
    ,"CONTR_PCT_BEG_AGE" : "INT"
    ,"CONTR_PCT_END_AGE" : "INT"
    ,"YR_MO_IND" : "STRING"
    ,"CONTR_PCT_HCFA_CD" : "STRING"
    ,"CONTR_PCT_PARTA_RT" : "DECIMAL(5,2)"
    ,"CONTR_PCT_PARTB_RT" : "DECIMAL(5,2)"
    ,"CONTR_PCT_PARTD_RT" : "DECIMAL(5,2)"
    ,"RT_ST_CD" : "STRING"
    ,"RT_FIPS_CNTY_CD" : "STRING"
    ,"PLTFM_CD" : "STRING"
    ,"SNIP_DESC" : "STRING"
}

# COMMAND ----------

trerate_schema={
"IND1":"STRING",
"TIMESTAMP":"TIMESTAMP",
"RT_TBL_ID":"STRING",
"CUST_LEDGR_NBR":"STRING",
"PROD_PLAN_NBR":"STRING",
"PROD_OPT_NBR":"STRING",
"FUND_TY_CD":"STRING",
"RT_RIDR_CD":"STRING",
"BEN_RIDR_PLAN_CD":"STRING",
"BEN_RIDR_OPT_CD":"STRING",
"BEN_GEN_COPAY_AMT":"DECIMAL(5,2)",
"BEN_BRD_COPAY_AMT":"DECIMAL(5,2)",
"RT_BEG_AGE":"SMALLINT",
"RT_ST_CD":"STRING",
"RT_FIPS_CNTY_CD":"STRING",
"HCFA_CLASF_CD":"STRING",
"RT_BEG_CC_DT":"SMALLINT",
"RT_BEG_YY_DT":"SMALLINT",
"RT_BEG_MM_DT":"SMALLINT",
"DLLR_VS_PCT_CD":"STRING",
"RT_END_CYM_DT":"STRING",
"RT_END_AGE":"SMALLINT",
"RT_MALE_FUND_AMT":"DECIMAL(9,2)",
"RT_FEM_FUND_AMT":"DECIMAL(9,2)",
"RT_MALE_ADJ_AMT":"DECIMAL(9,2)",
"RT_FEM_ADJ_AMT":"DECIMAL(9,2)",
"RE_RTESCH_RATE_IND":"STRING",
"PLTFM_CD":"STRING",
"YR_MO_IND":"STRING",
"CREATION_TS":"TIMESTAMP",
"CAP_RATE_RULE_NBR":"INT"
}
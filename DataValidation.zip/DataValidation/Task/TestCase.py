# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/AdlsHelper

# COMMAND ----------

# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

# MAGIC %run ../Utility/Transform

# COMMAND ----------

from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Parameter Cell.
try:
    dbutils.widgets.text('FILE_NAME','')
    dbutils.widgets.text('CONTAINER_NAME','')
    FILE_NAME = dbutils.widgets.get('FILE_NAME')
    STORAGE_ACCOUNT_NAME = env_storage_account_name
    CONTAINER_NAME = dbutils.widgets.get('CONTAINER_NAME')
except Exception as e:
    raise Exception("Parameter definition failed: ", str(e))


# COMMAND ----------

# DBTITLE 1,Get table name from config.
try:
    tbl_conf_df = get_table_config(env_table_details_config_path)
    STAT_TABLE_NAME = table_name_selector(tbl_conf_df, 'DataValidation_ValidationStats')
    tbl_lst = STAT_TABLE_NAME.split('.')
    DATABASE_NAME = f"{tbl_lst[0]}.{tbl_lst[1]}{databricks_database_suf}"
except Exception as e:
    raise Exception("Get table name from config failed: ", str(e))

# COMMAND ----------

# DBTITLE 1,Path definition.
input_file_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/datavalidation/input/"
temp_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/datavalidation/temp/"
output_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/datavalidation/output/"

# COMMAND ----------

try:
    input_df = spark.read.format('csv').option('header', True)\
        .option('sep', '|').load(input_file_path).filter(col('TestInd') == 'Y')
except Exception as e:
    raise Exception("Read input file failed: ", str(e))

# COMMAND ----------

try:
    set_dict_to_default_value()
    lst = convert_sync_config_df_to_lst(input_df)
except Exception as e:
    raise Exception("Convert input dataframe to list: ", str(e))

# COMMAND ----------

# DBTITLE 1,Validation Process
try:
    area_filter_lst = []
    stat_path =  f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/datavalidation/validationdatabase/ValidationStats"
    for area, file_name, adls_query, sql_query in lst:
        area_filter_lst.append(area)
        set_dict_to_default_value()
        result_dict['Area'] = area
        opt_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/datavalidation/validationdatabase/{area}"
        file_name_lst = file_name.split(',')
        for fl_name in file_name_lst:
            fl_name = fl_name.strip()
            subj_area = find_subject_area_from_file_name(fl_name)
            result_dict['Module'] = subj_area.title()
            path = path_builder(CONTAINER_NAME, STORAGE_ACCOUNT_NAME, subj_area, fl_name)
            df1 = read_data_from_adls(path)
            tbl_name = ''.join(fl_name.split('_')[-1].split('.')[:-1])
            df1.createOrReplaceTempView(f"{tbl_name.lower()}")

        adls_query, adls_key = change_adls_query_tbl_name(adls_query)
        sql_qry, sql_key = sql_query.lower().split('order by')
        adls_df = spark.sql(adls_query.strip())
        adls_df.cache()
        sql_df = read_sf_sql_tbl_to_df_spark(query = sql_qry.lower().strip())
        sql_df.cache()
        
        adls_col_cnt, sql_col_cnt, status = column_count_validation(adls_df, sql_df)
        
        result_dict['AdlsColCount'] = adls_col_cnt
        result_dict['SqlColCount'] = sql_col_cnt

        if status == 1:
            adls_dist_df = spark.sql(adls_query.strip()).distinct()
            sql_dist_df = sql_df.distinct()
            result_dict['AdlsTotalRows'] = adls_df.count()
            result_dict['AdlsDistRows'] = adls_dist_df.count()
            result_dict['SqlTotalRows'] = sql_df.count()
            result_dict['SqlDistRows'] = sql_dist_df.count()
            dup_sql_df = sql_df.groupBy(*sql_df.columns).count().withColumn('count', col('count') - 1)
            dup_adls_df = adls_df.groupBy(*adls_df.columns).count().withColumn('count', col('count') - 1)
            result_dict['AdlsDupRows'] = dup_adls_df.select('count').agg({"count":"sum"}).collect()[0][0]
            result_dict['SqlDupRows'] = dup_sql_df.select('count').agg({"count":"sum"}).collect()[0][0]
            adls_df = convert_null_value_to_default(adls_dist_df, adls_key.split(','))
            sql_df = convert_null_value_to_default(sql_dist_df, sql_key.split(','))
            proc_df = column_value_comparsion(adls_key.split(','), sql_key.split(','), adls_df, sql_df)
            final_df2 = convert_dafault_to_null_value(proc_df, adls_key.split(',')+ sql_key.split(','))
            final_df2.cache()
            adls_df.unpersist()
            sql_df.unpersist()
            column_wise_comp_count(final_df2)
            write_as_delta_table(final_df2, opt_path, f'{DATABASE_NAME}.{area}')
            result_dict['TableDetails'] = f'{DATABASE_NAME}.{area}'
        final_stat_df = test_case_calculation(result_dict) 
        if spark.catalog.tableExists(STAT_TABLE_NAME):
            apply_upsert(final_stat_df,STAT_TABLE_NAME)
        else:
            write_as_delta_table(final_stat_df, stat_path, STAT_TABLE_NAME, part_col = 'Module', mode='append')
        final_df2.unpersist()
        print(f"{area} - Done")
except Exception as e:
    raise Exception("Validation Process failed", str(e))
    

# COMMAND ----------

# DBTITLE 1,Write to temp folder failed
try:
    stats_df = spark.read.table(STAT_TABLE_NAME).filter((col('Area').isin(area_filter_lst)))\
                .withColumn('ColumnMatchTC', col('ColumnMatchTC').cast('string'))
    stats_df.coalesce(1).write.format('csv').mode('overwrite').option('sep', ',').option('quote', '"').option('header', True).save(temp_path)
except Exception as e:
    raise Exception("Write to temp folder failed", str(e))

# COMMAND ----------

# DBTITLE 1,Renaming file name and write to output folder
try:
    out_file_name = f"{FILE_NAME}_{str(datetime.now())}.csv"
    copy_file_to_outbnd_with_new_name(temp_path, output_path,out_file_name)
except Exception as e:
    raise Exception("Renaming file name and write to output folder failed", str(e))
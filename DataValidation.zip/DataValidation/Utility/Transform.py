# Databricks notebook source
# MAGIC %run ../../Utility/Helpers/EnvironmentVariableHelper

# COMMAND ----------

from pyspark.sql.functions import *
from delta.tables import *
import pandas as pd

# COMMAND ----------

#config for servicefund sql database
sf_user = dbutils.secrets.get(scope = env_scope , key = env_app_id_key)
#sf_password = dbutils.secrets.get(scope = env_scope , key = env_secret_key)
sf_password = "y3t8Q~2e3kjNO75vlRVirBTM8skDz8bwwnAKTbN9"
sf_db_host = env_sf_server_address
sf_db_name = env_sf_db_name
server_address = env_sf_server_address
server_name = "jdbc:sqlserver://" + server_address
sf_url = server_name + ";" + "databaseName=" + sf_db_name + ";"

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS hive_metastore.datavalidation")

# COMMAND ----------

# port is optional, can use default port 1433 if omittedpor
def read_sf_sql_tbl_to_df_spark(tbl_name=None, query=None, auth="ActiveDirectoryServicePrincipal"):
    try:
        if tbl_name:
            remote_table = (
                spark.read.format("com.microsoft.sqlserver.jdbc.spark")
                .option("url", sf_url)
                .option("authentication", auth)
                .option("user", sf_user)
                .option("password", sf_password)
                .option("dbtable", tbl_name)
                .load()
            )
            return remote_table
        elif query:
            remote_table = (
                spark.read.format("com.microsoft.sqlserver.jdbc.spark")
                .option("url", sf_url)
                .option("authentication", auth)
                .option("user", sf_user)
                .option("password", sf_password)
                .option("query", query)
                .load()
            )
            return remote_table
        else:
            raise Exception("Invalid SQL table details")
    except Exception as e:
        raise Exception("read_table_spark: ", str(e))

# COMMAND ----------

result_dict = {}
def set_dict_to_default_value():
    result_dict['Module'] = ''
    result_dict['Area'] = ''
    result_dict['AdlsColCount'] = -1
    result_dict['SqlColCount'] = -1
    result_dict['AdlsTotalRows'] = -1
    result_dict['AdlsDupRows'] = -1
    result_dict['AdlsOrphanRows'] = -1
    result_dict['AdlsDistRows'] = -1
    result_dict['SqlTotalRows'] = -1
    result_dict['SqlDupRows'] = -1
    result_dict['SqlOrphanRows'] = -1
    result_dict['SqlDistRows'] = -1 
    result_dict['MatchedRecords'] = -1
    result_dict['TableDetails'] = ''
    result_dict['Comment'] = ''
    result_dict['ColumnMatchTC'] = {}
    result_dict['ColumnCountTC'] = False
    result_dict['RecordCountTC'] = False


# COMMAND ----------

def get_table_config(path):
    try:
        with open(path) as f:
            src_file = json.load(f)
        tbl_dtl_df = pd.json_normalize(src_file, record_path = ['table_details'], meta = ['subject_area'])
        spark_df = spark.createDataFrame(tbl_dtl_df).cache()
        return spark_df
    except: 
        raise Exception("Table details config file not found. Please check...")


def table_name_selector(df, table_code):
    try:
        table_name = df.filter(col('table_code') == table_code)\
        .select('table_name').rdd.flatMap(lambda x : x).collect()
        if len(table_name) == 0:
            raise Exception("Table_name_selector : Table not found")
        elif len(table_name) > 1:
            raise Exception("Table_name_selector : More than one table found for the Table Code")
        return table_name[0]
    except Exception as e:
        raise Exception("table_name_selector:", str(e))


# COMMAND ----------

def convert_sync_config_df_to_lst(df):
    try:
        rows = df.collect()
        conf_lst = [[row.Area, row.AdlsFileName, row.AdlsQuery, row.AzureSQLQuery]for row in rows]
        return conf_lst
    except Exception as e:
        raise Exception("convert_sync_config_df_to_lst:", str(e))

# COMMAND ----------

def path_builder(container_name, storage_account, subject_area, file_name):
    try:
        path = f"abfss://{container_name}@{storage_account}.dfs.core.windows.net/{subject_area}/raw/{file_name}"
        return path
    except Exception as e:
        raise Exception("path_builder:", str(e))

def trim_leading_trailing_space(df):
    try:
        lst = [f"CASE WHEN trim({col}) = '' THEN {col} ELSE trim({col}) END AS {col}" for col in df.columns]
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("trim_leading_trailing_space: ", str(e))


# COMMAND ----------

def read_data_from_adls(path):
    try:
        df = spark.read.format('csv').option('header', True)\
            .option('sep', '|').load(path)
        trm_df = trim_leading_trailing_space(df)
        return trm_df
    except Exception as e:
        raise Exception("read_data_from_adls:", str(e))

# COMMAND ----------

def find_subject_area_from_file_name(file_name):
    try:
        temp_lst = fl_name.split('_')[:-1]
        sub_area = ''.join(temp_lst).lower()
        return sub_area
    except Exception as e:
        raise Exception("find_subject_area_from_file_name:", str(e))

# COMMAND ----------

def column_count_validation(adls_df, sql_df):
    try:
        is_valid = 1
        adls_col_count = len(adls_df.columns)
        sql_col_count = len(sql_df.columns)
        if adls_col_count != sql_col_count:
            result_dict['Comment'] = 'Column count not matching between adls and sql query. Please correct it and rerun'
            is_valid = 0
        return adls_col_count, sql_col_count, is_valid
    except Exception as e:
        raise Exception("column_count_validation:", str(e))

# COMMAND ----------

def create_filter_expression(col_lst, condition_type):
    try:
        if condition_type == 'NULL':
            modified_lst = [item + ' IS NULL' for item in col_lst]
        elif condition_type == 'NOTNULL':
            modified_lst = [item + ' IS NOT NULL' for item in col_lst]
        filter_cond = expr(' and '.join(modified_lst))
        return filter_cond
    except Exception as e:
        raise Exception("create_filter_expression:", str(e))

# COMMAND ----------

def write_as_delta_table(df, path, tbl_name, part_col = None, mode = 'overwrite'):
    try:
        if part_col:
                df.write.partitionBy(part_col).format('delta').mode(mode).option("path", path).saveAsTable(tbl_name)
        else:
                df.write.format('delta').mode(mode).option("path", path).saveAsTable(tbl_name)
    except Exception as e:
        raise Exception("create_filter_expression:", str(e))

# COMMAND ----------

def test_case_calculation(dictn):
    try:
        if len(result_dict['ColumnMatchTC']) == 0:
            result_dict.pop('ColumnMatchTC')
            stat_df = spark.createDataFrame([tuple(dictn.values())],list(dictn.keys()))
            stat_df = stat_df.withColumn('ColumnMatchTC', lit(create_map()))
        else:
            stat_df = spark.createDataFrame([tuple(dictn.values())],list(dictn.keys()))
        col_map = {
            'ColumnCountTC' : when(col('AdlsColCount') == col('SqlColCount'), lit(True)).otherwise(False),
            'RecordCountTC' : (when((col('AdlsTotalRows') == -1) | (col('MatchedRecords') == -1), lit(False))
                            .when((col('AdlsTotalRows') == col('MatchedRecords')), lit(True)).otherwise(False)),
            'RunTimestamp' : lit(current_timestamp())
        }
        final_df = stat_df.withColumns(col_map)
        return final_df
    except Exception as e:
        raise Exception("test_case_calculation:", str(e))

# COMMAND ----------

def apply_upsert(df, tbl_name):
    try:
        delta_tbl = DeltaTable.forName(spark,tbl_name)
        delta_tbl.alias("tgt").merge(
            df.alias('src'),
            f"src.Area = tgt.Area")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll().execute()
    except Exception as e:
        raise Exception("apply_upsert:", str(e))

# COMMAND ----------

def change_adls_query_tbl_name(adls_query):
    try:
        adls_qry, adls_key = adls_query.split('ORDER BY')
        adls_qry = adls_qry.replace(f"AQ1.", "")
        return adls_qry, adls_key
    except Exception as e:
        raise Exception("change_adls_query_tbl_name:", str(e))

# COMMAND ----------

def remove_alias_name_from_key(lst):
    try:
        als_rmd_lst = []
        for x in lst:
            temp = x.split('.')
            if len(temp) == 1:
                als_rmd_lst.append(temp[0])
            else:
                als_rmd_lst.append(temp[1])
        return als_rmd_lst
    except Exception as e:
        raise Exception("remove_alias_name_from_key: ",str(e))


# COMMAND ----------

def column_value_comparsion(adls_jn_key, sql_jn_key, adls_df, sql_df):
    try:
        adls_key_cnt = len(adls_jn_key)
        sql_key_cnt = len(sql_jn_key)
        if adls_key_cnt != sql_key_cnt:
            result_dict['Comment'] = 'Primary key count not matching between adls and sql. Please correct it and rerun'

        adls_join_key = remove_alias_name_from_key(adls_jn_key)
        sql_join_key = remove_alias_name_from_key(sql_jn_key)
        combined_list = [[x.strip(),y.strip()]for x,y in zip(adls_join_key, sql_join_key)]

        cond_lst = []
        for x, y in combined_list:
            cond_lst.append(f"LH.{x} = RH.{y}")
        join_cond = expr(' and '.join(cond_lst))
        joined_df = adls_df.alias('LH').join(sql_df.alias('RH'),(join_cond),'full')
        adls_orphan_cnt = joined_df.filter(create_filter_expression(adls_join_key, 'NULL')).count()
        sql_orphan_cnt = joined_df.filter(create_filter_expression(sql_join_key, 'NULL')).count()
        valid_df = joined_df.filter(create_filter_expression(adls_join_key  + sql_join_key, 'NOTNULL'))
        valid_cnt = valid_df.count()
        result_dict['AdlsOrphanRows'], result_dict['SqlOrphanRows'], result_dict['MatchedRecords'] = adls_orphan_cnt, sql_orphan_cnt, valid_cnt
        col_cmpr = [[x,y]for x,y in zip(adls_df.columns, sql_df.columns)]

        lst1, lst2 = [], []
        for x, y in col_cmpr:
            comb = x +'#'+ y
            lst1.append(comb)
            lst2.append(f'case when (({x} = {y}) or ({x} is null and {y} is null)) then True else False end as `{x}#{y}`')
        final_df = joined_df.selectExpr('*', *lst2)
        return final_df
    except Exception as e:
        raise Exception("column_value_comparsion:", str(e))

# COMMAND ----------

def convert_null_value_to_default(df, keys):
    try:
        lst = []
        for x in df.columns:
            if x in keys:
                lst.append(f"CASE WHEN {x} IS NULL THEN '#@#' else {x} END as {x}")
            else:
                lst.append(f"{x} as {x}")
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("convert_null_value_to_default:", str(e))

# COMMAND ----------

def convert_dafault_to_null_value(df, keys):
    try:
        lst = []
        for x in df.columns:
            if x in keys:
                lst.append(f"CASE WHEN `{x}` = '#@#' THEN null else `{x}` END as `{x}`")
            else:
                lst.append(f"`{x}` as `{x}`")
        return df.selectExpr(*lst)
    except Exception as e:
        raise Exception("convert_dafault_to_null_value:", str(e))

# COMMAND ----------

def column_wise_comp_count(df):
    try:
        for colm in df.columns:
            if '#' in colm:
                filtered_df = df.select(colm).filter(col(f'{colm}') == False).count()
                result_dict['ColumnMatchTC'][colm] = filtered_df
    except Exception as e:
        raise Exception("column_wise_comp_count:", str(e))

# COMMAND ----------

def copy_file_to_outbnd_with_new_name(temp_path, outbnd_path, outbnd_file_name):
    """
        Description:
        This function is used to move file from one path to another, and during the move, it will also rename the file according to provided input.
        :param temp_path: [Type: string] Source path.
        :param outbnd_path: [Type: string] Target path.
        :param outbnd_file_name: [Type: string].
    """
    try:
        counter = 0
        for file_info in dbutils.fs.ls(temp_path):
            if file_info.name.endswith('.csv'):
                counter += 1
                temp_file_name = file_info.name
        if counter == 0:
            raise Exception(f"{temp_path} directory doesn't have csv file.")
        elif counter == 1:
            dbutils.fs.cp(temp_path + temp_file_name, outbnd_path + outbnd_file_name)
            dbutils.fs.rm(temp_path, True)
        else:
            raise Exception(f"{temp_path} directory contain more than one csv file.")
    except Exception as e:
        raise Exception("copy_file_to_outbnd_with_new_name", str(e))